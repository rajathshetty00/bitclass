yarn
yarn build:prod
aws s3 sync build/ s3://bitclass-aarohan --acl public-read