yarn
yarn build
aws s3 sync build/ s3://bitclass-aarohan-staging --acl public-read