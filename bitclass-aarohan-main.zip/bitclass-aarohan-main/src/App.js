import React, { Suspense, useState } from "react"
import { Provider } from "react-redux"
import { createBrowserHistory } from "history"
import { BrowserRouter as Router, Switch } from "react-router-dom"

import { Spin } from "antd"
import PublicRoute from "./PublicRoute"
import "antd/dist/antd.css"
import { Layout, PageHeader } from "antd"
import "./App.scss"
import { ChevronLeft, ChevronRight } from "react-feather"
import AppSideBar from "./components/AppSideBar"
import { isLoggedIn } from "./utils/auth"
import store from "./store"

const { Header, Content } = Layout

const PrivateRoute = React.lazy(() => import("./PrivateRoute"))
const LoginPage = React.lazy(() => import("./containers/LoginPage/index"))
const DashboardPage = React.lazy(() =>
  import("./containers/DashboardPage/index")
)
const AppHeader = React.lazy(() => import("./components/AppHeader/index"))
const AdHocPage = React.lazy(() => import("./containers/AdHocPage/index"))
const GeniePage = React.lazy(() => import("./containers/GeniePage/index"))
const PayoutPage = React.lazy(() => import("./containers/Payouts/index"))
const ApproveTeacherPage = React.lazy(() =>
  import("./containers/ApproveTeacherPage")
)
const StudentProfilePage = React.lazy(() =>
  import("./containers/StudentProfilePage")
)
const FeedbackPage = React.lazy(() => import("./containers/FeedbackPage"))
const ChatPage = React.lazy(() => import("./containers/ChatPage"))
const CouponPage = React.lazy(() => import("./containers/CouponPage"))
const CategoryPage = React.lazy(() => import("./containers/CategoryPage"))
const PayoutSharePage = React.lazy(() => import("./containers/PayoutSharePage"))
const CalendarPage = React.lazy(() => import("./containers/CalendarPage"))
const TechSupportPage = React.lazy(() => import("./containers/TechSupport"))
const CourseFacilitator = React.lazy(() =>
  import("./containers/CourseFacilitator")
)
const LaunchpadPage = React.lazy(() => import("./containers/LaunchpadPage"))
const PayoutsNewPage = React.lazy(() => import("./containers/PayoutsPage"))
const StudentDirectory = React.lazy(() =>
  import("./containers/StudentDirectory")
)
const GigEconomyPage = React.lazy(() => import("./containers/GigEconomyPage"))
const UnAuthorizedPage = React.lazy(() =>
  import("./containers/UnAuthorizedPage")
)
const RedFlagTeacherPage = React.lazy(() =>
  import("./containers/RedFlagTeacher")
)
const CurriculumPage = React.lazy(() => import("./containers/Curriculum"))
const CurriculumSearch = React.lazy(() =>
  import("./containers/Curriculum/components/CurriculumSearch")
)
const TeacherDetails = React.lazy(() => import("./containers/TeacherDetails"))
const WhatsappDashboard = React.lazy(() =>
  import("./containers/WhatsappDashboard")
)
const TeacherPoc = React.lazy(() => import("./containers/TeacherPoc"))
const Recordings = React.lazy(() =>
  import("./containers/Recordings/Recordings")
)
const CollectionPage = React.lazy(() => import('./containers/CollectionPage'))


const history = createBrowserHistory()

const _appLayout = (props, Component, pageName) => {
  const [menuCollapsed, setMenuCollapsed] = useState(false)

  return (
    <Layout className="mainContainer">
      <Header className="headerContainer">
        <AppHeader history={props.history} />
      </Header>
      <Layout>
        {isLoggedIn() && (
          <AppSideBar collapsed={menuCollapsed} history={props.history} />
        )}
        <Layout>
          {pageName && (
            <PageHeader
              title={pageName}
              onBack={() => setMenuCollapsed(!menuCollapsed)}
              backIcon={menuCollapsed ? <ChevronRight /> : <ChevronLeft />}
              className="pageNameContainer"
            />
          )}
          <Layout className="bodyContainer">
            <Content>
              <Component {...props}></Component>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </Layout>
  )
}

function App() {
  return (
    <Provider store={store}>
      <Router history={history}>
        <Suspense fallback={<Spin size="large" />}>
          <Switch>
            <PublicRoute
              exact
              path="/"
              component={(props) => _appLayout(props, LoginPage)}
            />
            <PrivateRoute
              exact
              path="/dashboard/:view"
              component={(props) =>
                _appLayout(props, DashboardPage, "Teacher Onboarding")
              }
            />
            <PrivateRoute
              exact
              path="/ad-hoc"
              component={(props) => _appLayout(props, AdHocPage, "Ad-Hoc")}
            />
            <PrivateRoute
              exact
              path="/genie"
              component={(props) => _appLayout(props, GeniePage, "Genie")}
            />
            <PrivateRoute
              exact
              path="/payouts"
              component={(props) => _appLayout(props, PayoutPage, "Payouts")}
            />
            <PrivateRoute
              exact
              path="/payouts-share"
              component={(props) =>
                _appLayout(props, PayoutSharePage, "Payouts Share")
              }
            />
            <PrivateRoute
              exact
              path="/approve-teacher"
              component={(props) =>
                _appLayout(props, ApproveTeacherPage, "Approve Teacher")
              }
            />
            <PrivateRoute
              exact
              path="/student-profiling"
              component={(props) =>
                _appLayout(props, StudentProfilePage, "Student Profiling")
              }
            />
            <PrivateRoute
              exact
              path="/course-feedbacks"
              component={(props) =>
                _appLayout(props, FeedbackPage, "Course Feedbacks")
              }
            />
            <PrivateRoute
              exact
              path="/chat"
              component={(props) => _appLayout(props, ChatPage, "Chat")}
            />
            <PrivateRoute
              exact
              path="/coupon-dashboard"
              component={(props) =>
                _appLayout(props, CouponPage, "Coupon Dashboard")
              }
            />
            <PrivateRoute
              exact
              path="/category"
              component={(props) =>
                _appLayout(props, CategoryPage, "Manage Course Category")
              }
            />
            <PrivateRoute
              exact
              path="/calendar"
              component={(props) =>
                _appLayout(
                  props,
                  CalendarPage,
                  `Hi, ${localStorage.getItem("username")}.`
                )
              }
            />
            <PrivateRoute
              exact
              path="/ist"
              component={(props) => _appLayout(props, GigEconomyPage, "IST")}
            />
            <PrivateRoute
              exact
              path="/tech-support"
              component={(props) =>
                _appLayout(props, TechSupportPage, "Tech Support")
              }
            />
            <PrivateRoute
              exact
              path="/roster"
              component={(props) =>
                _appLayout(props, CourseFacilitator, "Roster")
              }
            />

            <PrivateRoute
              exact
              path="/payouts-new"
              component={(props) =>
                _appLayout(props, PayoutsNewPage, "Payouts New")
              }
            />

            <PrivateRoute
              exact
              path="/student-directory"
              component={(props) =>
                _appLayout(props, StudentDirectory, "Student Directory")
              }
            />

            <PrivateRoute
              exact
              path="/launchpad"
              component={(props) =>
                _appLayout(props, LaunchpadPage, "Launchpad")
              }
            />
            <PrivateRoute
              exact
              path="/red-flag-teacher"
              component={(props) =>
                _appLayout(props, RedFlagTeacherPage, "RedFlag Teacher")
              }
            />

            <PrivateRoute
              exact
              path="/curriculum/edit/:courseCode"
              component={(props) =>
                _appLayout(props, CurriculumPage, "Curriculum creation")
              }
            />
            <PrivateRoute
              exact
              path="/curriculum"
              component={(props) =>
                _appLayout(props, CurriculumSearch, "Curriculum Search")
              }
            />
            <PrivateRoute
              exact
              path="/teacher-compliance"
              component={(props) =>
                _appLayout(props, TeacherDetails, "Teacher Compliance")
              }
            />
            <PrivateRoute
              exact
              path="/whatsapp"
              component={(props) =>
                _appLayout(props, WhatsappDashboard, "Whatsapp Dashboard")
              }
            />
            <PrivateRoute
              exact
              path="/teacher-poc"
              component={(props) =>
                _appLayout(props, TeacherPoc, "Teacher POC")
              }
            />
            <PrivateRoute
              exact
              path="/recordings"
              component={(props) => _appLayout(props, Recordings, "Recordings")}
            />

             <PrivateRoute
              exact
              path="/collection"
              component={props =>
                _appLayout(props, CollectionPage, "Collection & Category")
              }
            />
           
            
            <PrivateRoute
              exact
              path="/unauthorized"
              component={(props) => _appLayout(props, UnAuthorizedPage, "")}
            />
          </Switch>
        </Suspense>
      </Router>
    </Provider>
  )
}

export default App
