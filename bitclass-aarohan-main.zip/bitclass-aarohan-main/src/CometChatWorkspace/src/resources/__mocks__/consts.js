export const COMETCHAT_CONSTANTS = {
    APP_ID: 'APP_ID',
    REGION: 'REGION',
    AUTH_KEY: 'AUTH_KEY',
    UID: 'UID'
}