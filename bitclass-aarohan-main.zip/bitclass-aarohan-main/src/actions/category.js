import { message } from "antd"
import { deleteFeatureCategoryApi, fetchCategory, fetchCategoryCourses, updateCategory, updateFeatureCategoryApi } from "../utils/api"
import { FAILURE_FETCH_CATEGORY, FAILURE_FETCH_CATEGORY_COURSE, FAILURE_UPDATE_CATEGORY, FAILURE_UPDATE_FEATURED_CATEGORY, LOADING_CATEGORY, LOADING_CATEGORY_COURSES, LOADING_UPDATE_CATEGORY, LOADING_UPDATE_FEATURED_CATEGORY, PAGE_CHANGE_CATEGORY, PAGE_CHANGE_COURSE_TABLE, SELECTED_CATEGORY_ID, SUCCESSFULLY_FETCH_CATEGORY, SUCCESSFULLY_FETCH_CATEGORY_COURSES, SUCCESSFULLY_UPDATE_CATEGORY, SUCCESSFULLY_UPDATE_FEATURED_CATEGORY } from "./types"

export const pageChangeCategory = (page) => {
    return { type: PAGE_CHANGE_CATEGORY, payload: page }
  }
  export const pageChangeCategoryCouseTable = (page) => {
    return { type: PAGE_CHANGE_COURSE_TABLE, payload: page }
  }
  export const setSelectedId =(id)=> ( { type: SELECTED_CATEGORY_ID, payload: id })

  export const updateCategoryData = (slug, body, page) => async (dispatch) => {
    message.info("Category detail updating....")
    dispatch({ type: LOADING_UPDATE_CATEGORY })
  
    try {
      const acutalData = await updateCategory(slug, body)
      if (acutalData?.success) {
        dispatch({
          type: SUCCESSFULLY_UPDATE_CATEGORY,
          payload: acutalData.data,
        })
        message.success("successfully update category data")
      } else {
        dispatch({ type: FAILURE_UPDATE_CATEGORY })
        message.error("failure to update category data")
      }
      return acutalData
    } catch (error) {
      dispatch({ type: FAILURE_UPDATE_CATEGORY })
      message.error("Error: Failure to update category data")
    }
  }
  export const updateFeaturedCategory = (slug, body,page,value,code) => async (dispatch) => {
    dispatch({ type: LOADING_UPDATE_FEATURED_CATEGORY })
    try {
      let acutalData ={};
      if (value) {
         acutalData = await updateFeatureCategoryApi(slug, body)
      } else {
        acutalData = await deleteFeatureCategoryApi(slug, code)
      }
      if (acutalData)
      if (acutalData?.success) {
        dispatch({
          type: SUCCESSFULLY_UPDATE_FEATURED_CATEGORY,
          payload: acutalData.data,
        })
        message.success("successfully update featured course")
        dispatch(fetchCategoryCourseData(slug,page))
      } else {
        dispatch({ type: FAILURE_UPDATE_FEATURED_CATEGORY })
        message.error("failure to update category data")
      }
      return acutalData
    } catch (error) {
      dispatch({ type: FAILURE_UPDATE_FEATURED_CATEGORY })
      message.error("Error: Failure to update featured course")
    }
  }
  
  export const fetchCategoryData = (page, notify) => async (dispatch) => {
    message.info("Loading  category data", "info")
    dispatch({ type: LOADING_CATEGORY })
    try {
      const acutalData = await fetchCategory(page)
      if (acutalData?.success) {
        dispatch({
          type: SUCCESSFULLY_FETCH_CATEGORY,
          payload: {
            data: acutalData?.data.results,
            total: acutalData?.data.count,
          },
        })
        message.success("successfully category data")
      } else {
        message.error("failure to fetch category data")
        dispatch({ type: FAILURE_FETCH_CATEGORY })
      }
    } catch (error) {
      message.error("Error: Failure to fetch category data")
      dispatch({ type: FAILURE_FETCH_CATEGORY })
    }
  }

  // fetch category courses
export const fetchCategoryCourseData =(query, page) => async (dispatch) => {
  dispatch({ type: LOADING_CATEGORY_COURSES })
  try {
    const acutalData = await fetchCategoryCourses(query,page)
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_FETCH_CATEGORY_COURSES,
        payload: {
          data: acutalData.data,
          total: acutalData.data.length,
        },
      })
      message.success("successfully category courses")
    } else {
      message.error("failure to fetch category courses")
      dispatch({ type: FAILURE_FETCH_CATEGORY_COURSE })
    }
  } catch (error) {
    message.error("Error: Failure to fetch category courses")
    dispatch({ type: FAILURE_FETCH_CATEGORY_COURSE  })
  }
}