import { message } from "antd"
import {
  deleteCollection,
  deleteCollectionCourse,
  deleteCollectionRecording,
  deleteFeatureCollectionApi,
  fetchCollection,
  fetchCollectionCourses,
  searchCourseData,
  sendCollection,
  updateCollection,
  updateFeatureCategoryApi,
  updateFeatureCollectionApi,
} from "../utils/api"
import {
  FAILURE_ADD_COLLECTION,
  FAILURE_COURSE_SEARCH_DATA,
  FAILURE_DELETE_COLLECTION,
  FAILURE_FETCH_COLLECTION,
  FAILURE_FETCH_COLLECTION_COURSE,
  FAILURE_SINGLE_FETCH_COLLECTION,
  FAILURE_UPDATE_COLLECTION,
  FAILURE_UPDATE_FEATURED_COLLECTION,
  LOADING_ADD_COLLECTION,
  LOADING_COLLECTION,
  LOADING_COLLECTION_COURSES,
  LOADING_COURSE_SEARCH_DATA,
  LOADING_DELETE_COLLECTION,
  LOADING_SINGLE_COLLECTION,
  LOADING_UPDATE_COLLECTION,
  LOADING_UPDATE_FEATURED_COLLECTION,
  PAGE_CHANGE_COLLECTION,
  PAGE_CHANGE_COLLECTION_COURSE,
  PAGE_CHANGE_COURSE,
  SET_SELECTED_COLLECTION_SLUG,
  SUCCESSFULLY_ADD_COLLECTION,
  SUCCESSFULLY_COURSE_SEARCH_DATA,
  SUCCESSFULLY_DELETE_COLLECTION,
  SUCCESSFULLY_FETCH_COLLECTION,
  SUCCESSFULLY_FETCH_COLLECTION_COURSES,
  SUCCESSFULLY_SINGLE_FETCH_COLLECTION,
  SUCCESSFULLY_UPDATE_COLLECTION,
  SUCCESSFULLY_UPDATE_FEATURED_COLLECTION,
  TOGGLE_DELETE_COLLECTION_MODEL,
} from "./types"

export const pageChangeCollection = (page) => {
  return { type: PAGE_CHANGE_COLLECTION, payload: page }
}

export const pageChangeCourseTable = (page) => {
  return { type: PAGE_CHANGE_COURSE, payload: page }
}
export const pageChangeCollectionCourseTable = (page) => {
  return { type: PAGE_CHANGE_COLLECTION_COURSE, payload: page }
}
export const setSelectedSlug = (slug) => {
  return { type: SET_SELECTED_COLLECTION_SLUG, payload: slug }
}

export const fetchCourseFilterData = (query, page) => async (dispatch) => {
  message.info("Loading the course data", "info")
  dispatch({ type: LOADING_COURSE_SEARCH_DATA })
  try {
    const acutalData = await searchCourseData(query, page)
    dispatch({
      type: SUCCESSFULLY_COURSE_SEARCH_DATA,
      payload: { data: acutalData.data, total: acutalData.total_records },
    })
    message.success("successfully fetch course data", "success")
  } catch (error) {
    dispatch({
      type: FAILURE_COURSE_SEARCH_DATA,
      payload: error.message,
    })
    message.error("Error: Failure to fetch course data", "error")
  }
}
export const addCollectionData = (body, page, notify) => async (dispatch) => {
  message.info("Loading the collection data", "info")
  dispatch({ type: LOADING_ADD_COLLECTION })

  try {
    const acutalData = await sendCollection(body)
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_ADD_COLLECTION,
        payload: acutalData.data,
      })
      dispatch(fetchCollectionData(`page=${page}&limit=10&type=${body.type}`))
      message.success("successfully add collection data", "success")
    } else {
      dispatch({ type: FAILURE_ADD_COLLECTION })
      message.success("failure to add collection data", "success")
    }
    return acutalData
  } catch (error) {
    dispatch({ type: FAILURE_ADD_COLLECTION })
    message.error("Error: Failure to add collection data", "error")
  }
}

export const updateCollectionData = (slug, body, page) => async (dispatch) => {
  message.info("Loading the update collection data", "info")
  dispatch({ type: LOADING_UPDATE_COLLECTION })

  try {
    const acutalData = await updateCollection(slug, body)
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_UPDATE_COLLECTION,
        payload: acutalData.data,
      })
      message.success("successfully update collection data", "success")
    } else {
      dispatch({ type: FAILURE_UPDATE_COLLECTION })
      message.error("failure to update collection data", "success")
    }
    return acutalData
  } catch (error) {
    dispatch({ type: FAILURE_UPDATE_COLLECTION })
    message.error("Error: Failure to update collection data", "error")
  }
}

export const updateFeaturedCollection = (slug, body,page,value,code) => async (dispatch) => {
  dispatch({ type: LOADING_UPDATE_FEATURED_COLLECTION })
  try {
    let acutalData ={};
    if (value) {
       acutalData = await updateFeatureCollectionApi(slug, body)
    } else {
      acutalData = await deleteFeatureCollectionApi(slug, code)
    }
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_UPDATE_FEATURED_COLLECTION,
        payload: acutalData.data,
      })
      message.success("successfully update featured course")
      dispatch(fetchCollectionCourseData(slug))
    } else {
      dispatch({ type: FAILURE_UPDATE_FEATURED_COLLECTION })
      message.error("failure to update category data")
    }
  } catch (error) {
    dispatch({ type: FAILURE_UPDATE_FEATURED_COLLECTION })
    message.error("Error: Failure to update featured course")

  }
}

export const fetchCollectionData = (query) => async (dispatch) => {
  message.info("Loading  collection data", "info")
  dispatch({ type: LOADING_COLLECTION })
  try {
    const acutalData = await fetchCollection(query)
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_FETCH_COLLECTION,
        payload: {
          data: acutalData?.data.results,
          total: acutalData?.data.count,
        },
      })
      message.success("successfully collection data", "success")
    } else {
      message.error("failure to fetch collection data", "error")
      dispatch({ type: FAILURE_FETCH_COLLECTION })
    }
  } catch (error) {
    message.error("Error: Failure to fetch collection data", "error")
    dispatch({ type: FAILURE_FETCH_COLLECTION })
  }
}
// fetch collection courses
export const fetchCollectionCourseData =
  (query, page) => async (dispatch) => {
    dispatch({ type: LOADING_COLLECTION_COURSES })
    try {
      const acutalData = await fetchCollectionCourses(query,page)
    
      if (acutalData?.success) {
        dispatch({
          type: SUCCESSFULLY_FETCH_COLLECTION_COURSES,
          payload: {
            data: acutalData?.data,
            total: acutalData.data.length,
          },
        })
        message.success("successfully collection courses", "success")
      } else {
        message.error("failure to fetch collection courses", "error")
        dispatch({ type: FAILURE_FETCH_COLLECTION_COURSE })
      }
    } catch (error) {
      message.error("Error: Failure to fetch collection courses", "error")
      dispatch({ type: FAILURE_FETCH_COLLECTION_COURSE })
    }
  }

export const fetchSingleCollectionData =
  (query, notify) => async (dispatch) => {
    message.info("Loading  collection data", "info")
    dispatch({ type: LOADING_SINGLE_COLLECTION })
    try {
      const acutalData = await fetchCollection(query)
      if (acutalData?.success) {
        dispatch({
          type: SUCCESSFULLY_SINGLE_FETCH_COLLECTION,
          payload: acutalData.data,
        })
        message.success("successfully collection data", "success")
      } else {
        message.error("failure to fetch collection data", "error")
        dispatch({ type: FAILURE_SINGLE_FETCH_COLLECTION })
      }
    } catch (error) {
      message.error("Error: Failure to fetch collection data", "error")
      dispatch({ type: FAILURE_SINGLE_FETCH_COLLECTION })
    }
  }

export const deleteCollectionData = (query, notify) => async (dispatch) => {
  message.info("deleting collection data ", "info")
  dispatch({ type: LOADING_DELETE_COLLECTION })
  try {
    const acutalData = await deleteCollection(query)
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_DELETE_COLLECTION,
        payload: query,
      })
      dispatch({ type: TOGGLE_DELETE_COLLECTION_MODEL, payload: false })
      message.success("successfully delete collection data", "success")
    } else {
      message.error("Error: Failure to delete collection data", "error")
      dispatch({ type: FAILURE_DELETE_COLLECTION })
    }
  } catch (error) {
    message.error("Error: Failure to delete collection data", "error")
    dispatch({ type: FAILURE_DELETE_COLLECTION })
  }
}

export const deleteCollectionCourseData = (slug, body,isRecording=false) =>  async (dispatch) => {
  message.info("deleting collection cours ", "info")
  dispatch({ type: LOADING_DELETE_COLLECTION })
  try {
    const acutalData =  isRecording?await deleteCollectionRecording(slug, body):await deleteCollectionCourse(slug, body)
    if (acutalData?.success) {
      dispatch({
        type: SUCCESSFULLY_DELETE_COLLECTION,
        payload: acutalData.data,
      })
      dispatch({ type: TOGGLE_DELETE_COLLECTION_MODEL, payload: false })
      dispatch(fetchCollectionCourseData(slug))
      message.success("successfully delete collection course", "success")
    } else {
      message.error("Error: Failure to delete collection course", "error")
      dispatch({ type: FAILURE_DELETE_COLLECTION })
    }
  } catch (error) {
    message.error("Error: Failure to delete collection course", "error")
    dispatch({ type: FAILURE_DELETE_COLLECTION })
  }
}
