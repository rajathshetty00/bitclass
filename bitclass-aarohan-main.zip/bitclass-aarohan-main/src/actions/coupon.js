import { 
  getCoupons,
 } from '../utils/api'
import { exists } from '../utils/index'
import {
  COUPON_FETCH_DATA,
  COUPON_CLEAR_DATA,
  COUPON_HIDE_LOADING,
  COUPON_SHOW_LOADING,
} from './types'

export const showLoader = () => ({
  type: COUPON_SHOW_LOADING,
})

export const hideLoader = () => ({
  type: COUPON_HIDE_LOADING,
})

export const clearData = () => ({
  type: COUPON_CLEAR_DATA,
})

export const fetchData = (courseCode) => (dispatch) => {
  dispatch(showLoader())
  getCoupons(courseCode)
    .then(res => {
      if(exists(res['data'])) {
        dispatch({
          type: COUPON_FETCH_DATA,
          payload: res['data'], 
        })
      } else {
        dispatch(clearData())
      }
      dispatch(hideLoader())
    })
    .catch(e => {
      dispatch(clearData())
      dispatch(hideLoader())
    })
}
