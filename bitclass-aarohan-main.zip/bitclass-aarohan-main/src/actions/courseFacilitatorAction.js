import { message } from "antd"
import { constructFilterParams } from "../containers/CourseFacilitator/helper"
import {
  autoAssignCourseFacilitator,
  getAllCourseCalender,
  getAllCourseFacilitator,
  getAvailableCfs,
  postCallCancelData,
  setCfToCourse,
  unAssignCourseFacilitators,
} from "../utils/api"
import {
  FAILURE_CANCEL_TEACHER,
  LOADING_CANCEL_TEACHER,
  SAVE_AVAILABLE_CFS,
  SAVE_COURSE_ASSIGNER_DETAILS,
  SAVE_COURSE_FACILITATOR,
  SET_AUTO_ASSIGN_STATUS,
  SET_LOADING_COURSE_FACILITATOR,
  SET_MESSAGE_LOG,
  SUCCESS_CANCEL_TEACHER
} from "./types"

export const getCourseAssignerDetails = (filters) => async (dispatch) => {
  try {
    dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: true })
    const filter = constructFilterParams(filters)
    const { data, error, total_count, assigned_count, message } =
      await getAllCourseCalender(filter)
    if (!error) {
      dispatch({
        type: SAVE_COURSE_ASSIGNER_DETAILS,
        payload: { data, total_count, assigned_count },
      })
      dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: false })
    } else if (message) {
      dispatch({
        type: SET_MESSAGE_LOG,
        payload: message,
      })
    }
  } catch (error) {
    message.error("Failed to fetch calendar details!")
    dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: false })
  }
}

export const getAvailableCfsByCourseCode = (courseCode) => async (dispatch) => {
  try {
    // dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: true })
    const { data, error } = await getAvailableCfs(courseCode)
    if (!error) {
      dispatch({ type: SAVE_AVAILABLE_CFS, payload: data })
      // dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: false })
    }
  } catch (error) {
    // dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: false })
    message.error(error)
  }
}

export const setCourseFacilitatorForCourse =
  (courseId, stakeholderId) => async (dispatch) => {
    dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: true })
    try {
      const { data, error } = await setCfToCourse(courseId, stakeholderId)
      if (!error) {
        message.success("Successfully assigned!")
        return true
      }
      if (error) {
        message.error(error)
        return false
      }
    } catch (error) {
      message.error(error)
      return false
    }
    finally {
      dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: false })
    }

  }

export const unsetCourseFacilitatorFromCourse =
  (courseId, stakeholderId) => async (dispatch) => {
    dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: true })
    try {
      const { data, error } = await unAssignCourseFacilitators(courseId, stakeholderId)
      if (!error) {
        message.success("Successfully Unassigned!")
        return true
      }
      if (error) {
        message.error(error)
        return false
      }
    }
    catch (error) {
      message.error(error)
      return false
    }
    finally {
      dispatch({ type: SET_LOADING_COURSE_FACILITATOR, payload: false })
    }
  }

export const saveAllCourseFacilitators = () => async (dispatch) => {
  try {
    const { data } = await getAllCourseFacilitator()
    dispatch({ type: SAVE_COURSE_FACILITATOR, payload: data })
  } catch (error) { }
}

export const initializeAutoAssignCourseFacilitators = (filters) => async dispatch => {
  try {
    const { auto_assign_in_process } = await autoAssignCourseFacilitator(filters)
    dispatch({ type: SET_AUTO_ASSIGN_STATUS, payload: auto_assign_in_process })
  } catch (error) {

  }
}

export const setClassCancelData = (body, courseCode) => async (dispatch) => {
  try {
    dispatch({ type: LOADING_CANCEL_TEACHER })
    const { data, error, message } =
      await postCallCancelData(body, courseCode)
    if (!error) {
      dispatch({
        type: SUCCESS_CANCEL_TEACHER,
        payload: courseCode,
      })
    } else if (message) {
      dispatch({
        type: SET_MESSAGE_LOG,
        payload: message,
      })
    }
  } catch (error) {
    message.error("Failed to fetch calendar details!")
    dispatch({ type: FAILURE_CANCEL_TEACHER })
  }
}
