import { message } from "antd"
import { addFreeCurriculumBatch, addFullCourseCurriculum, deleteCurriculumByBatchCode, fetchCurriculum, fetchCurriculumByCode, fetchCurriculumCategory, updateCurriculum } from "../utils/api"
import { ABOUT_COURSE, CHANGE_TAB, CURRICULUM_FAQ, CURRICULUM_MARKETING_DATA, CURRICULUM_META, CURRICULUM_WARM_UP_PLAN_DATA, FAILURE_ADD_BATCH, FAILURE_ADD_NEW_FULL_COURSE, FAILURE_DELETE_BATCH, FAILURE_FETCH_COURSE_CATEGORY, FAILURE_FETCH_CURRICULUM_CODE_DATA, FAILURE_FETCH_CURRICULUM_DATA, FAILURE_UPDATING_CURRICULUM_DATA, FREE_CURRICULUM_DATA, FULL_COURSE_CURRICULUM, LOADING_ADD_BATCH, LOADING_ADD_NEW_FULL_COURSE, LOADING_CURRICULUM_CODE_DATA, LOADING_CURRICULUM_DATA, LOADING_DELETE_BATCH, LOADING_FETCH_COURSE_CATEGORY, LOADING_UPDATING_CURRICULUM_DATA, SHOW_CASE, SUCCESSFULLY_ADD_BATCH, SUCCESSFULLY_ADD_NEW_FULL_COURSE, SUCCESSFULLY_DELETE_BATCH, SUCCESSFULLY_FETCH_COURSE_CATEGORY, SUCCESSFULLY_FETCH_CURRICULUM_CODE_DATA, SUCCESSFULLY_FETCH_CURRICULUM_DATA, SUCCESSFULLY_UPDATING_CURRICULUM_DATA, TESTIMONIAL, WHY_BUY_DATA } from "./types"

export const handleChangeTab= (key)=>{
    return {type:CHANGE_TAB,payload:key}
}
export const submitAboutCourseData =(abouCourse)=>{
    return {type:ABOUT_COURSE,payload:abouCourse}
}
export const submitWhyBuyData =(whybuy)=>{
    return {type:WHY_BUY_DATA,payload:whybuy}
}
export const submitFreeCurriculumData =(freeCourse)=>{
    return {type:FREE_CURRICULUM_DATA,payload:freeCourse}
}
export const submitFullCourseCurriculumData =(fullCourse)=>{
    return {type:FULL_COURSE_CURRICULUM,payload:fullCourse}
}
export const submitstudentShowCaseData =(showCase)=>{
    return {type:SHOW_CASE,payload:showCase}
}
export const submitTestimonialData =(testimonial)=>{
    return {type:TESTIMONIAL,payload:testimonial}
}
export const submitCurriculumFaqData =(meta)=>{
    return {type:CURRICULUM_FAQ,payload:meta}
}
export const submitFullCourseMetaData =(meta)=>{
    return {type:CURRICULUM_META,payload:meta}
}
export const submitFullCourseMaketingData =(marketing)=>{
  return {type:CURRICULUM_MARKETING_DATA,payload:marketing}
}
export const submitWarmUpPlanData =(planData)=>{
  return {type:CURRICULUM_WARM_UP_PLAN_DATA,payload:planData}
}

export const updateCurriculumByApi = (coursecode,body) => async (dispatch) => {
    dispatch({ type:LOADING_UPDATING_CURRICULUM_DATA})
    try {
      const acutalData = await updateCurriculum(coursecode,body);
      dispatch({ type: SUCCESSFULLY_UPDATING_CURRICULUM_DATA })
     message.success('successfully update the curriculum data')
    } catch (error) {
      dispatch({ type: FAILURE_UPDATING_CURRICULUM_DATA, payload: error.message });
     message.error('Error:failed to  update the curriculum data ')
  
    }
  }

  export const fetchCurriculumByApi = (coursecode, notify) => async (dispatch) => {
    dispatch({ type:LOADING_CURRICULUM_DATA})
    try {
      const acutalData = await fetchCurriculum(coursecode);
      if (acutalData?.success) {
          
          dispatch({ type: SUCCESSFULLY_FETCH_CURRICULUM_DATA,payload: acutalData?.data})
         message.success('successfully fetch the curriculum data')
      }
    } catch (error) {
      dispatch({ type: FAILURE_FETCH_CURRICULUM_DATA, payload: error.message });
     message.error(`Error:failed to fetching the curriculum :${error.message}`);
  
    }
  }
  export const fetchCurriculumByCourseCode = (coursecode) => async (dispatch) => {
    dispatch({ type:LOADING_CURRICULUM_CODE_DATA})
    try {
      const acutalData = await fetchCurriculumByCode(coursecode);
      if (acutalData?.success) {
          
          dispatch({ type: SUCCESSFULLY_FETCH_CURRICULUM_CODE_DATA,payload: acutalData?.data})
         message.success('Successfully fetched curriculum details')
      }
    } catch (error) {
      dispatch({ type: FAILURE_FETCH_CURRICULUM_CODE_DATA, payload: error.message });
     message.error(`Error:failed to fetch curriculum detail  :${error.message}`);
  
    }
  }
  export const deleteCurriculumBatch = (batchcode,type) => async (dispatch) => {
    dispatch({ type:LOADING_DELETE_BATCH})
    try {
      const acutalData = await deleteCurriculumByBatchCode(batchcode);
      if (acutalData?.success) {
          dispatch({ type: SUCCESSFULLY_DELETE_BATCH,payload: {batchcode,courseType:type}})
         message.success('successfully deleted curriculum batch')
      }
    } catch (error) {
      dispatch({ type: FAILURE_DELETE_BATCH, payload: error.message });
     message.error(`Error:failed to delete curriculum  batch:${error.message}`);
  
    }
  }
  export const addFreeClassBatch = (coursecode,body) => async (dispatch) => {
    dispatch({ type:LOADING_ADD_BATCH})
    try {
      const acutalData = await addFreeCurriculumBatch(coursecode,body);
      if (acutalData?.success) {
          
          dispatch({ type: SUCCESSFULLY_ADD_BATCH,payload: true})
         message.success('successfully added curriculum batch')
      }
    } catch (error) {
      dispatch({ type: FAILURE_ADD_BATCH, payload: error.message });
     message.error(`Error:failed to add curriculum batch :${error.message}`);
  
    }
  }

  export const addFullCourseBatch = (coursecode,body) => async (dispatch) => {
    dispatch({ type:LOADING_ADD_NEW_FULL_COURSE})
    try {
      const acutalData = await addFullCourseCurriculum(coursecode,body);
      if (acutalData?.success) {
          
          dispatch({ type: SUCCESSFULLY_ADD_NEW_FULL_COURSE,payload:true})
         message.success('successfully added full course curriculum batch')
      }
    } catch (error) {
      dispatch({ type: FAILURE_ADD_NEW_FULL_COURSE, payload: error.message });
     message.error(`Error:failed to add full course curriculum batch :${error.message}`);
  
    }
  }

  export const fetchCourseCategory = () => async (dispatch) => {
    dispatch({ type:LOADING_FETCH_COURSE_CATEGORY})
    try {
      const acutalData = await fetchCurriculumCategory();
      if (acutalData?.success) {
          
          dispatch({ type: SUCCESSFULLY_FETCH_COURSE_CATEGORY,payload: acutalData?.data})
         message.success('Successfully fetched curriculum details')
      }
    } catch (error) {
      dispatch({ type: FAILURE_FETCH_COURSE_CATEGORY, payload: error.message });
     message.error(`Error:failed to fetch curriculum detail  :${error.message}`);
  
    }
  }

  export const fetchCategories  =async (category)=>{
    try {
      const apiResponse = await fetchCurriculumCategory(category)
      if (apiResponse.success) {
        return apiResponse.data;
      }else{
      message.success('Error while fetching category');
      return null;
      }
    } catch (error) {
      message.success('Error while fetching category');
      return null;
    } 
}
  
