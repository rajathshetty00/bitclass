import { fetchCampaignData, campaignDataInit } from '../utils/api';
import {
  DASHBOARD_CLEAR_DATA,
  DASHBOARD_FETCH_DATA,
  DASHBOARD_UPDATE_DATA,
  DASHBOARD_SHOW_LOADER,
  DASHBOARD_HIDE_LOADER,
  DASHBOARD_INIT,
  SET_MESSAGE_LOG,
} from '../actions/types'
import { isEmpty } from 'lodash-es';

export const clearData = () => ({
  type: DASHBOARD_CLEAR_DATA
})

export const showLoader = () => ({
  type: DASHBOARD_SHOW_LOADER
})

export const hideLoader = () => ({
  type: DASHBOARD_HIDE_LOADER
})

export const fetchData = (startDate ='', endDate='', search = '') => (dispatch) => {
  dispatch(showLoader())
  return fetchCampaignData(startDate, endDate, search)
    .then((res) => {
      
      dispatch(hideLoader())

      if(!isEmpty(res.error)){
        dispatch({
          type: DASHBOARD_CLEAR_DATA
        })
      } else {
        dispatch({
          type: DASHBOARD_FETCH_DATA,
          payload: res.data
        })
      }
    })
    .catch((e) => {
      dispatch(hideLoader())
      dispatch({
        type: DASHBOARD_CLEAR_DATA
      })
    })
}

export const updateData = (data) => ({
  type: DASHBOARD_UPDATE_DATA,
  payload: data
})

export const init = () => (dispatch) => {
  return campaignDataInit()
    .then((data) => {

       if(data.error) {
        dispatch({type: SET_MESSAGE_LOG, payload: data.message})
       } else if(data){
         dispatch({
        type: DASHBOARD_INIT,
        payload: data
      })
      }
    })
}
