import { getFeedbacks, getFeedbacksByDayRange } from '../utils/api'
import { exists } from '../utils/index'
import {
  FEEDBACK_FETCH_DATA,
  FEEDBACK_CLEAR_DATA,
  FEEDBACK_HIDE_LOADING,
  FEEDBACK_SHOW_LOADING,
  FEEDBACK_FETCH_AGGREGATED_DATA,
  FEEDBACK_FETCH_DATA_WITH_RANGE,
} from './types'

export const showLoader = () => ({
  type: FEEDBACK_SHOW_LOADING,
})

export const hideLoader = () => ({
  type: FEEDBACK_HIDE_LOADING,
})

export const clearData = () => ({
  type: FEEDBACK_CLEAR_DATA,
})

export const fetchData = (courseCode) => (dispatch) => {
  dispatch(showLoader())
  getFeedbacks(courseCode)
    .then(res => {
      if(exists(res['data'])) {
        dispatch({
          type: FEEDBACK_FETCH_DATA,
          payload: res['data'], 
        })
      } else {
        dispatch(clearData())
      }
      dispatch(hideLoader())
    })
    .catch(e => {
      dispatch(clearData())
      dispatch(hideLoader())
    })
}

export const fetchAggregateData = (range) => (dispatch) => {
  dispatch(showLoader())
  getFeedbacksByDayRange(range)
    .then(res => {
      if(exists(res['data'])) {
        dispatch({
          type: FEEDBACK_FETCH_AGGREGATED_DATA,
          payload: res['data'], 
        })
      } else {
        dispatch(clearData())
      }
      dispatch(hideLoader())
    })
    .catch(e => {
      dispatch(clearData())
      dispatch(hideLoader())
    })
}

// Fetch feedback for a particular period
export const fetchDataWithRange = (courseCode) => (dispatch) => {
  dispatch(showLoader())
  getFeedbacksByDayRange(courseCode)
    .then(res => {
      if(exists(res['data'])) {
        dispatch({
          type: FEEDBACK_FETCH_DATA_WITH_RANGE,
          payload: res['data'], 
        })
      } else {
        dispatch(clearData())
      }
      dispatch(hideLoader())
    })
    .catch(e => {
      dispatch(clearData())
      dispatch(hideLoader())
    })
}
