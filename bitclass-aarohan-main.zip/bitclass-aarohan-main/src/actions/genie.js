import { getGenieData } from '../utils/api';
import { exists } from '../utils/index';
import {
  GENIE_FETCH_DATA,
  GENIE_HIDE_LOADING,
  GENIE_SHOW_LOADING,
  GENIE_CLEAR_DATA,
  SET_MESSAGE_LOG,
} from './types'

export const showLoader = () => ({
  type: GENIE_SHOW_LOADING
})

export const hideLoader = () => ({
  type: GENIE_HIDE_LOADING
})

export const fetchGenieData = () => (dispatch) => {
  dispatch(showLoader())
  getGenieData()
    .then((res) => {
      dispatch(hideLoader())
      if( exists(res.data)) {
        dispatch({
          type: GENIE_FETCH_DATA,
          payload: res.data
        })
      } 
      else if(res.error){
        dispatch({ type: SET_MESSAGE_LOG, payload: res.message })
      }
      else{
        dispatch({
          type: GENIE_CLEAR_DATA
        })
      }
    })
    .catch((e) => {
      dispatch(hideLoader())
      dispatch({
        type: GENIE_CLEAR_DATA
      })
    })
}
