import { message } from "antd"
import { getPayoutTerms, savePayoutTerms } from "../utils/api"
import { PAYOUTS_SHARE_FETCH_ERROR, PAYOUTS_SHARE_FETCH_FINISHED, PAYOUTS_SHARE_FETCH_STATED, PAYOUTS_SHARE_SAVING_ERROR, PAYOUTS_SHARE_SAVING_FINISHED, PAYOUTS_SHARE_SAVING_STARTED } from "./types"


export const fetchPayoutShareTerms = (phoneNumber)=>async(dispatch)=> {
  try {
    dispatch({type:PAYOUTS_SHARE_FETCH_STATED})
    const {data,success} = await getPayoutTerms(phoneNumber)
    if(success){
      const reversedPayouts = data.reverse()
      dispatch({type:PAYOUTS_SHARE_FETCH_FINISHED,payload:reversedPayouts})
    }
    if(data.length<1){message.error(`No payout share term found for ${phoneNumber}`)}
  } catch (error) {
    dispatch({type:PAYOUTS_SHARE_FETCH_ERROR,payload:error})
  }
}

export const savePayoutShareTerms = (payoutTermData)=>async(dispatch)=> {
  try {
    dispatch({type:PAYOUTS_SHARE_SAVING_STARTED})
    const {data,success} = await savePayoutTerms(payoutTermData)
    if(success){
      const loading = message.loading('Saving payout term...')
      loading()
      dispatch({type:PAYOUTS_SHARE_SAVING_FINISHED,payload:data})
      message.success('Payout term saved successfully')
    }
      else message.error('Failed to save payout term. Invalid course code!')
  } catch (error) {
    dispatch({type:PAYOUTS_SHARE_SAVING_ERROR,payload:error})
    message.error('Failed to save payout term.')
  }
}