import { getPayouts } from '../utils/api'
import { exists } from '../utils/index'
import {
  PAYOUTS_FETCH_DATA,
  PAYOUTS_SHOW_LOADING,
  PAYOUTS_HIDE_LOADING,
  PAYOUTS_CLEAR_DATA,
} from './types'

export const showLoader = () => ({
  type: PAYOUTS_SHOW_LOADING,
})

export const hideLoader = () => ({
  type: PAYOUTS_HIDE_LOADING,
})

export const clearData = () => ({
  type: PAYOUTS_CLEAR_DATA,
})

export const fetchPayoutsData = (params = {}) => (dispatch) => {
  dispatch(showLoader())
  getPayouts(params)
    .then((res) => {
      dispatch(hideLoader())
      if (exists(res.data)) {
        dispatch({
          type: PAYOUTS_FETCH_DATA,
          payload: res.data,
        })
      } else {
        dispatch({
          type: PAYOUTS_CLEAR_DATA,
        })
      }
    })
    .catch((e) => {
      dispatch(hideLoader())
      dispatch({
        type: PAYOUTS_CLEAR_DATA,
      })
    })
}
