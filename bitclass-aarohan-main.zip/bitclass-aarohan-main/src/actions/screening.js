import { getLaunchpadScreenData, postLaunchpadScreenApproved } from "../utils/api"
import { SCREENING_APPROVAL_FAILURE, SCREENING_APPROVAL_REQUEST, SCREENING_APPROVAL_SUCCESS, SCREENING_DETAIL_FAILURE, SCREENING_DETAIL_REQUEST, SCREENING_DETAIL_SUCCESS, SCREENING_PAGE_CHANGE } from "./types"


export const handleScreeningPagination = (page) => {
  return { type: SCREENING_PAGE_CHANGE, payload: page }
}
export const getScreeningData = (filters, page, notify) => async (dispatch) => {
  notify.current.openToaster('Loading the screning  data', 'info')
  dispatch({ type: SCREENING_DETAIL_REQUEST })
  dispatch({ type: SCREENING_PAGE_CHANGE, payload: page })
  try {
    
    const acutalData = await getLaunchpadScreenData(filters,page)
    if (acutalData['success']) {
      dispatch({ type: SCREENING_DETAIL_SUCCESS, payload:{total:acutalData['total_records'],data:acutalData['data']} })
      notify.current.openToaster('Successfully fetch data', 'success')
    }else{
      notify.current.openToaster(`Error:${acutalData['error']}`, 'error')
    dispatch({ type: SCREENING_DETAIL_FAILURE, payload: acutalData['error'] });
    }

  } catch (error) {
    notify.current.openToaster(`Error:${error.message}`, 'error')
    dispatch({ type: SCREENING_DETAIL_FAILURE, payload: error.message });

  }
}

export const postApprovedData = (teacher_id, body, notify, closeModel) => async (dispatch) => {
  notify.current.openToaster('sending status', 'info')
  dispatch({ type: SCREENING_APPROVAL_REQUEST, payload: true })
  try {
    const acutalData = await postLaunchpadScreenApproved(teacher_id,body)
    if (acutalData['success']) {
      dispatch({ type: SCREENING_APPROVAL_SUCCESS, payload: [] })
      notify.current.openToaster('Successfully Screening Data', 'success')
      closeModel(false);
    }else{
      notify.current.openToaster(`Error:${acutalData['error']}`, 'error')
      dispatch({ type: SCREENING_APPROVAL_FAILURE, payload:acutalData['error']});
      closeModel(false);

    }
  } catch (error) {
    notify.current.openToaster(`Error:${error.message}`, 'error')
    dispatch({ type: SCREENING_APPROVAL_FAILURE, payload: error.message });

  }
}
