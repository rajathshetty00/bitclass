import { getStudentCourseData, getStudentDirectoryData, getStudentTicketData } from "../utils/api"
import { FITLER_STUDENT_DIRECTORY_FAILURE, FITLER_STUDENT_DIRECTORY_REQUEST, FITLER_STUDENT_DIRECTORY_SUCCESS, SD_CLEAR_DATA, SD_COURSE_DETAIL_FAILURE, SD_COURSE_DETAIL_REQUEST, SD_COURSE_DETAIL_SUCCESS, SD_COURSE_PAGE_CHANGE, SD_TICKET_DETAIL_FAILURE, SD_TICKET_DETAIL_REQUEST, SD_TICKET_DETAIL_SUCCESS, SD_TICKET_PAGE_CHANGE, STUDENT_DIRECTORY_HANDLE_PAGE_CHANGE } from "./types"

export const PageChangeStudentDirectory = (page)=>{
    return{type:STUDENT_DIRECTORY_HANDLE_PAGE_CHANGE,payload:page}
}
export const pageChangeTicketTable = (page)=>{
  return{type:SD_TICKET_PAGE_CHANGE,payload:page}
}
export const pageChangeCourseTable = (page)=>{
  return{type:SD_COURSE_PAGE_CHANGE,payload:page}
}
export const clearAllData = ()=>{
  return {type:SD_CLEAR_DATA}
}
  export const fetchStudentDirectoryData  =(query,page,notify)=>async (dispatch) => {
    notify.current.openToaster('Loading the student directory','info')
    dispatch({type:FITLER_STUDENT_DIRECTORY_REQUEST})
    try {
       const acutalData = await getStudentDirectoryData(query,page);
      dispatch({
        type: FITLER_STUDENT_DIRECTORY_SUCCESS,
        payload: {data: acutalData.data, total: acutalData.total_records},
      })
        notify.current.openToaster('successfully fetch student directory','success')
    } catch (error) {
        dispatch({
            type: FITLER_STUDENT_DIRECTORY_FAILURE,
            payload:error.message,
          })
    notify.current.openToaster('Error: Failure to fetch student directory','error')
    }
  }

  export const fetchStudentCourseData  =(student_code,page,notify)=>async (dispatch) => {
    notify.current.openToaster('Loading the courses','info')

    dispatch({type:SD_COURSE_DETAIL_REQUEST})
    try {
       const acutalData = await getStudentCourseData(student_code,page);
      dispatch({
        type: SD_COURSE_DETAIL_SUCCESS,
        payload: {data: acutalData.data, total: acutalData.total_records},
      })
      notify.current.openToaster('successfully fetch course Data','success')

    } catch (error) {
        dispatch({
            type: SD_COURSE_DETAIL_FAILURE,
            payload:error.message,
          })
          notify.current.openToaster('Error: Failure to fetch course data','error')

    }
  } 
  export const fetchStudentTicketData  =(student_code,page,notify)=>async (dispatch) => {
    notify.current.openToaster('Loading the tickets','info')
    dispatch({type:SD_TICKET_DETAIL_REQUEST})
    try {
       const acutalData = await getStudentTicketData(student_code,page);
      dispatch({
        type: SD_TICKET_DETAIL_SUCCESS,
        payload: {data: acutalData.data['tickets'], total: acutalData.total_records},
      })
        notify.current.openToaster('successfully fetch ticket Data','success')
    } catch (error) {
        dispatch({
            type: SD_TICKET_DETAIL_FAILURE,
            payload:error.message,
          })
    notify.current.openToaster('Error: Failure to fetch ticker data','error')
    }
  }