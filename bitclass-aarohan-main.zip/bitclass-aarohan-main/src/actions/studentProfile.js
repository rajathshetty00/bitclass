import { getStudentProfilingData } from '../utils/api'
import { exists } from '../utils/index'
import {
  SP_CLEAR_DATA,
  SP_FETCH_DATA,
  SP_HIDE_LOADING,
  SP_SHOW_LOADING,
} from './types'

export const showLoader = () => ({
  type: SP_SHOW_LOADING,
})

export const hideLoader = () => ({
  type: SP_HIDE_LOADING,
})

export const clearData = () => ({
  type: SP_CLEAR_DATA,
})

export const fetchData = (courseCode) => (dispatch) => {
  dispatch(showLoader())
  getStudentProfilingData(courseCode)
    .then(res => {
      if(exists(res['data'])) {
        dispatch({
          type: SP_FETCH_DATA,
          payload: res['data'], 
        })
      } else {
        dispatch(clearData())
      }
      dispatch(hideLoader())
    })
    .catch(e => {
      dispatch(clearData())
      dispatch(hideLoader())
    })
}
