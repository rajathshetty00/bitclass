import { getTeacherFormSubmissions } from '../utils/api';
import { exists } from '../utils/index';
import {
  TEACHER_FETCH_DATA,
  TEACHER_SHOW_LOADING,
  TEACHER_HIDE_LOADING,
  TEACHER_CLEAR_DATA,
} from './types'

export const showLoader = () => ({
  type: TEACHER_SHOW_LOADING
})

export const hideLoader = () => ({
  type: TEACHER_HIDE_LOADING
})

export const clearData = () => ({
  type: TEACHER_CLEAR_DATA
})

export const fetchTeacherSubmissionData = (params = {}) => (dispatch) => {
  dispatch(showLoader())
  getTeacherFormSubmissions(params)
    .then((res) => {
      dispatch(hideLoader())
      if( exists(res.data)) {
        dispatch({
          type: TEACHER_FETCH_DATA,
          payload: {data: res.data, total: res.total_records},
        })
      } else {
        dispatch({
          type: TEACHER_CLEAR_DATA
        })
      }
    })
    .catch((e) => {
      dispatch(hideLoader())
      dispatch({
        type: TEACHER_CLEAR_DATA
      })
    })
}
