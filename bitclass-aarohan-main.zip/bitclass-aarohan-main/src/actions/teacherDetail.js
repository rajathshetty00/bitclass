import { addTeacherMous, getTeacherFilterData, getTeacherMousData, postTeacherLegalForm, postTeacherRedFlagReason } from "../utils/api"
import { FAILURE_FETCH_MOUS, FAILURE_SUBMITTING_MOUS, FAILURE_SUBMITTING_MOUSS, FAILURE_SUMBIT_LEGAL_FORM, FITLER_TEACHER_RED_FLAG_FAILURE, FITLER_TEACHER_RED_FLAG_REQUEST, FITLER_TEACHER_RED_FLAG_SUCCESS, IS_FORM_UPDATE, LOADING_FETCH_MOUS, LOADING_SUBMITTING_MOUS, LOADING_SUMBIT_LEGAL_FORM, POST_RESON_TEACHER_RED_FLAG_FAILURE, POST_RESON_TEACHER_RED_FLAG_REQUEST, POST_RESON_TEACHER_RED_FLAG_SUCCESS, SD_CLEAR_DATA, SD_COURSE_DETAIL_FAILURE, SD_COURSE_DETAIL_REQUEST, SD_COURSE_DETAIL_SUCCESS, SD_COURSE_PAGE_CHANGE, SD_TICKET_DETAIL_FAILURE, SD_TICKET_DETAIL_REQUEST, SD_TICKET_DETAIL_SUCCESS, SD_TICKET_PAGE_CHANGE, STUDENT_DIRECTORY_HANDLE_PAGE_CHANGE, SUCCESSFULLY_FETCH_MOUS, SUCCESSFULLY_SUBMITTING_MOUS, SUCCESSFULLY_SUMBIT_LEGAL_FORM, TEACHER_RED_FLAG_CLEAR_DATA, TEACHER_RED_FLAG_HANDLE_PAGE_CHANGE, TEACHER_RED_FLAG_IS_UPDATED } from "./types"

export const PageChangeTeacherDetail = (page) => {
    return { type: TEACHER_RED_FLAG_HANDLE_PAGE_CHANGE, payload: page }
}
export const clearAllData = () => {
    return { type: TEACHER_RED_FLAG_CLEAR_DATA }
}

export const teacherRedFlagData = (payload) => {
    return { type: TEACHER_RED_FLAG_IS_UPDATED, payload: payload }
}
export const fetchTeacherData = (query, page, notify) => async (dispatch) => {
    notify.current.openToaster('Loading the teacher data', 'info')
    dispatch({ type: FITLER_TEACHER_RED_FLAG_REQUEST })
    try {
        const acutalData = await getTeacherFilterData(query, page);
        dispatch({
            type: FITLER_TEACHER_RED_FLAG_SUCCESS,
            payload: { data: acutalData.data, total: acutalData.total_records },
        })
        notify.current.openToaster('successfully fetch teacher data', 'success')
    } catch (error) {
        dispatch({
            type: FITLER_TEACHER_RED_FLAG_FAILURE,
            payload: error.message,
        })
        notify.current.openToaster('Error: Failure to fetch teacher data', 'error')
    }
}

export const updateTeacherRedFlagData = (body, notify) => async (dispatch) => {
    notify.current.openToaster('Loading', 'info')

    dispatch({ type: POST_RESON_TEACHER_RED_FLAG_REQUEST })
    try {
        const acutalData = await postTeacherRedFlagReason(body);
        dispatch({
            type: POST_RESON_TEACHER_RED_FLAG_SUCCESS,
            payload: body,
        })
        notify.current.openToaster('successfully change the teacher flag', 'success')

    } catch (error) {
        dispatch({
            type: POST_RESON_TEACHER_RED_FLAG_FAILURE,
            payload: error.message,
        })
        notify.current.openToaster('Error: Failure to post teacher flag', 'error')

    }
}
// SUMBIT LABEL FORM DATA

export const submitTeacherLegalFormData = (body, notify) => async (dispatch) => {
    dispatch({ type: LOADING_SUMBIT_LEGAL_FORM })
    try {
        const acutalData = await postTeacherLegalForm(body);
        dispatch({
            type: SUCCESSFULLY_SUMBIT_LEGAL_FORM,
            
        })
        dispatch({type: IS_FORM_UPDATE,payload:true})
        notify.current.openToaster('successfully submitting form', 'success')
    } catch (error) {
        dispatch({
            type: FAILURE_SUMBIT_LEGAL_FORM,
            payload: error.message,
        })
        notify.current.openToaster('Error: Failure to submit form data', 'error')
    }
}


export const fetchTeacherMousData = (teacherCode, notify) => async (dispatch) => {
    notify.current.openToaster("Loading fetch Mou's", 'info')
    dispatch({ type: LOADING_FETCH_MOUS })
    try {
        const acutalData = await getTeacherMousData(teacherCode);
        dispatch({
            type: SUCCESSFULLY_FETCH_MOUS,
            payload: { data: acutalData.data, total: acutalData.total_records },
        })
        notify.current.openToaster("successfully fetch Mou's", 'success')
    } catch (error) {
        dispatch({
            type: FAILURE_FETCH_MOUS,
            payload: error.message,
        })
        notify.current.openToaster("Error: Failure to fetch Mou's", 'error')
    }
}
// submitting mous
export const submitTeacherMousData = (body,notify) => async (dispatch) => {
    dispatch({ type: LOADING_SUBMITTING_MOUS })
    try {
        const acutalData = await addTeacherMous(body);
        dispatch({
            type: SUCCESSFULLY_SUBMITTING_MOUS,
        })
        dispatch(fetchTeacherMousData(body?.user_code,notify));
        notify.current.openToaster("successfully added Mou's", 'success')
    } catch (error) {
        dispatch({
            type: FAILURE_SUBMITTING_MOUS,
            payload: error.message,
        })
        notify.current.openToaster("Error: Failure to add Mou's", 'error')

    }
}
