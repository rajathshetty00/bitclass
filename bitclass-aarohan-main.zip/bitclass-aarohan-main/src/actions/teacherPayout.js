import { message } from "antd"
import { downloadPayoutTransectionData, getPayoutCourseType, getTeacherEarningByFilter, getTeacherPayoutByFilter, getTeacherSummaryByFilter, refreshPayoutData, updateTeacherDetailByFilter, updateTeacherPayoutDetail, updateTeacherPayoutTypeData, updateTeacherSharingData, updateURTData, uploadPayoutTransectionData } from "../utils/api"
import { FAILURE_FETCH_PAYOUT_COURSE_TYPE, LOADING_FETCH_PAYOUT_COURSE_TYPE, SUCCESSFULLY_FETCH_PAYOUT_COURSE_TYPE, TEACHER_DETAIL_PAGE_CHANGE, TEACHER_DETAIL_UPDATE_DATA_FAILURE, TEACHER_DETAIL_UPDATE_DATA_SUCCESS, TEACHER_EARNING_FILTER_FAILURE, TEACHER_EARNING_FILTER_REQUEST, TEACHER_EARNING_FILTER_SUCCESS, TEACHER_EARNING_PAGE_CHANGE, TEACHER_EARNING_UPDATE_PAY_TYPE_FAILURE, TEACHER_EARNING_UPDATE_PAY_TYPE_SUCCESS, TEACHER_PAYOUT_DOWNLOAD_FILE_FAILURE, TEACHER_PAYOUT_DOWNLOAD_FILE_REQUEST, TEACHER_PAYOUT_DOWNLOAD_FILE_SUCCESS, TEACHER_PAYOUT_FILTER_FAILURE, TEACHER_PAYOUT_FILTER_REQUEST, TEACHER_PAYOUT_FILTER_SUCCESS, TEACHER_PAYOUT_HIDE_LOADER, TEACHER_PAYOUT_PAGE_CHANGE, TEACHER_PAYOUT_REFRESH_FAILURE, TEACHER_PAYOUT_REFRESH_REQUEST, TEACHER_PAYOUT_REFRESH_SUCCESS, TEACHER_PAYOUT_SHOW_LOADER, TEACHER_PAYOUT_UPDATE_DATA_FAILURE, TEACHER_PAYOUT_UPDATE_DATA_SUCCESS, TEACHER_PAYOUT_UPLOAD_FILE_FAILURE, TEACHER_PAYOUT_UPLOAD_FILE_REQUEST, TEACHER_PAYOUT_UPLOAD_FILE_SUCCESS, TEACHER_SHARED_AMOUNT_UPDATE_FAILURE, TEACHER_SHARED_AMOUNT_UPDATE_REQUEST, TEACHER_SHARED_AMOUNT_UPDATE_SUCCESS, TEACHER_SUMMARY_FILTER_FAILURE, TEACHER_SUMMARY_FILTER_REQUEST, TEACHER_SUMMARY_FILTER_SUCCESS } from "./types"


export const showLoader = () => {
  return { type: TEACHER_PAYOUT_SHOW_LOADER }
}
export const hideLoader = () => {
  return { type: TEACHER_PAYOUT_HIDE_LOADER }
}
export const handleDetailPagination = (page) => {
  return { type: TEACHER_DETAIL_PAGE_CHANGE, payload: page }
}
export const handleEarningPagination = (page) => {
  return { type: TEACHER_EARNING_PAGE_CHANGE, payload: page }
}
export const handlePayoutPagination = (page) => {
  return { type: TEACHER_PAYOUT_PAGE_CHANGE, payload: page }
}
export const getTeacherSummaryDataByFilter = (filters, page, notify) => async (dispatch) => {
  notify?.current.openToaster('Loading the filtered data', 'info')
  dispatch(showLoader())
  dispatch({ type: TEACHER_SUMMARY_FILTER_REQUEST, payload: true })
  dispatch({ type: TEACHER_DETAIL_PAGE_CHANGE, payload: page })
  try {
    const acutalData = await getTeacherSummaryByFilter(filters, page)
    dispatch(hideLoader())
    dispatch({ type: TEACHER_SUMMARY_FILTER_SUCCESS, payload: acutalData })
    notify?.current.openToaster('Successfully fetch filtered data', 'success')

  } catch (error) {
    notify?.current.openToaster(`Error:${error.message}`, 'error')
    dispatch({ type: TEACHER_SUMMARY_FILTER_FAILURE, payload: error.message });

  }
}

export const getTeacherPayoutDataByFilter = (filters, page, notify, csv = false) => async (dispatch) => {
  notify?.current.openToaster('Loading the filtered data', 'info')
  dispatch(showLoader())
  dispatch({ type: TEACHER_PAYOUT_FILTER_REQUEST, payload: true })
  dispatch({ type: TEACHER_PAYOUT_PAGE_CHANGE, payload: page })
  try {
    const acutalData = await getTeacherPayoutByFilter(filters, page)

    dispatch(hideLoader())
    dispatch({ type: TEACHER_PAYOUT_FILTER_SUCCESS, payload: acutalData })
    notify?.current.openToaster('Successfully fetch Payout data', 'success')

  } catch (error) {
    notify?.current.openToaster(`Error:${error.message}`, 'error')

    dispatch({ type: TEACHER_PAYOUT_FILTER_FAILURE, payload: error.message });

  }
}
export const getTeacherEarningDataByFilter = (filters, page, notify) => async (dispatch) => {
  notify?.current.openToaster('Loading the filtered data', 'info')
  dispatch(showLoader())
  dispatch({ type: TEACHER_EARNING_FILTER_REQUEST, payload: true })
  dispatch({ type: TEACHER_EARNING_PAGE_CHANGE, payload: page })
  try {
    const acutalData = await getTeacherEarningByFilter(filters, page)

    dispatch(hideLoader())
    dispatch({ type: TEACHER_EARNING_FILTER_SUCCESS, payload: acutalData })
    notify?.current.openToaster('Successfully fetch Earning data', 'success')

  } catch (error) {
    notify?.current.openToaster(`Error:${error.message}`, 'error')
    dispatch({ type: TEACHER_EARNING_FILTER_FAILURE, payload: error.message });

  }
}

export const updateTeacherDetail = (body, notify) => async (dispatch) => {
  notify.current.openToaster('updating the techer data', 'info')
  try {
    const acutalData = await updateTeacherDetailByFilter(body);
    dispatch({ type: TEACHER_DETAIL_UPDATE_DATA_SUCCESS })
    notify.current.openToaster('successfully update the techer data', 'success')


  } catch (error) {
    dispatch({ type: TEACHER_DETAIL_UPDATE_DATA_FAILURE, payload: error.message });
    notify.current.openToaster('Error:Failed to update data Please try after some time', 'error')


  }
}

export const updateTeacherPayoutData = (body, notify) => async (dispatch) => {
  notify.current.openToaster('updating the teacher payout ', 'info')

  try {
    const acutalData = await updateTeacherPayoutDetail(body);
    dispatch({ type: TEACHER_PAYOUT_UPDATE_DATA_SUCCESS })
    notify.current.openToaster('successfully update the teacher payout ', 'success')

    // dispatch(getTeacherPayoutDataByFilter())      
  } catch (error) {
    dispatch({ type: TEACHER_PAYOUT_UPDATE_DATA_FAILURE, payload: error.message });
    notify.current.openToaster('Error:failed to  update the teacher payout ', 'error')


  }
}

export const updateTeachersharedAmount = (body, notify) => async (dispatch) => {
  notify.current.openToaster('updating the shared Data', 'info')
  dispatch({ type: TEACHER_SHARED_AMOUNT_UPDATE_REQUEST })
  try {

    const acutalData = await updateTeacherSharingData(body);

    dispatch({ type: TEACHER_SHARED_AMOUNT_UPDATE_SUCCESS })
    notify.current.openToaster('successfully update shared Data', 'success')



  } catch (error) {
    dispatch({ type: TEACHER_SHARED_AMOUNT_UPDATE_FAILURE, payload: error.message });
    if (error.status === 400) {
      notify.current.openToaster('Modification forbidden(Processed Payouts exists)', 'error')
      return;
    }
    notify.current.openToaster('Error: Failure to update shared data', 'error')
  }
}

export const teacherEarningPayTypeUpdate = (body, notify) => async (dispatch) => {
  notify.current.openToaster('updating the shared Data', 'info')
  try {
    const acutalData = await updateTeacherPayoutTypeData(body);
    dispatch({ type: TEACHER_EARNING_UPDATE_PAY_TYPE_SUCCESS })
    notify.current.openToaster('successfully update payout type Data', 'success')
  } catch (error) {
    dispatch({ type: TEACHER_EARNING_UPDATE_PAY_TYPE_FAILURE, payload: error.message });
    if (error.status === 400) {
      notify.current.openToaster('Modification forbidden(Processed Payouts exists)', 'error')
      return;
    }
    notify.current.openToaster('Error: Failure to update payout type data', 'error')
  }
}

// upload  file for transaction
export const uploadTransactionFile = (body, notify) => async (dispatch) => {
  notify.current.openToaster('uploading file', 'info')
  dispatch({ type: TEACHER_PAYOUT_UPLOAD_FILE_REQUEST })

  try {
    const acutalData = await uploadPayoutTransectionData(body);
    dispatch({ type: TEACHER_PAYOUT_UPLOAD_FILE_SUCCESS })
    notify.current.openToaster('successfully upload file', 'success')


  } catch (error) {
    dispatch({ type: TEACHER_PAYOUT_UPLOAD_FILE_FAILURE, payload: error.message });
    notify.current.openToaster('Error: Failure to upload file', 'error')
  }
}
// upload  file for transaction
export const downloadTransactionFile = (query, notify, callback) => async (dispatch) => {
  dispatch({ type: TEACHER_PAYOUT_DOWNLOAD_FILE_REQUEST })

  try {
    const acutalData = await downloadPayoutTransectionData(query);
    dispatch({ type: TEACHER_PAYOUT_DOWNLOAD_FILE_SUCCESS })
    callback()
    notify.current.openToaster(JSON.parse(acutalData).msg, 'success', 5000)


  } catch (error) {
    dispatch({ type: TEACHER_PAYOUT_DOWNLOAD_FILE_FAILURE, payload: error.message });
    notify.current.openToaster('Error: Failure to email csv', 'error')

  }
}

export const teacherPayoutRefreshData = (notify) => async (dispatch) => {
  dispatch({ type: TEACHER_PAYOUT_REFRESH_REQUEST })
  try {
    const acutalData = await refreshPayoutData();
    dispatch({ type: TEACHER_PAYOUT_REFRESH_SUCCESS, payload: acutalData['last_refresh_ts'] })
    notify.current.openToaster(`${acutalData['msg']}`, 'success')
  } catch (error) {
    dispatch({ type: TEACHER_PAYOUT_REFRESH_FAILURE, payload: error.message });
    notify.current.openToaster('Error: Failure to Refresh data', 'error')
  }
}

// update the UTR data
export const updatePayoutUTRData = (body, notify) => async (dispatch) => {
  notify.current.openToaster('updating the teacher payout UTR data ', 'info')

  try {
    const acutalData = await updateURTData(body);
    dispatch({ type: TEACHER_PAYOUT_UPDATE_DATA_SUCCESS })
    notify.current.openToaster('successfully update payout UTR data ', 'success')
  } catch (error) {
    dispatch({ type: TEACHER_PAYOUT_UPDATE_DATA_FAILURE, payload: error.message });
    notify.current.openToaster('Error:failed to  update the UTR data ', 'error')


  }
}

// payout techer type
export const fetchPayoutTeacherTypeData = () => async (dispatch) => {
  dispatch({ type: LOADING_FETCH_PAYOUT_COURSE_TYPE })
  try {
    const acutalData = await getPayoutCourseType();
    dispatch({ type: SUCCESSFULLY_FETCH_PAYOUT_COURSE_TYPE, payload:acutalData})
  } catch (error) {
    dispatch({ type: FAILURE_FETCH_PAYOUT_COURSE_TYPE, payload: error.message });
    message.error("Error while fetching category")

  }
}
