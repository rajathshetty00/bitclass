import { fetchTeacherSupplyData, searchTeacher } from "../utils/api"
import {   FAILURE_TEACHER_SEARCH_DATA,   LOADING_TEACHER_SEARCH_DATA,  SUCCESSFULLY_FETCH_SUPPLY_TEAM,   SUCCESSFULLY_TEACHER_SEARCH_DATA, TEACHER_RED_FLAG_CLEAR_DATA, TEACHER_RED_FLAG_HANDLE_PAGE_CHANGE, TEACHER_RED_FLAG_IS_UPDATED } from "./types"

export const PageChangeTeacherPOC = (page) => {
    return { type: TEACHER_RED_FLAG_HANDLE_PAGE_CHANGE, payload: page }
}
export const clearAllData = () => {
    return { type: TEACHER_RED_FLAG_CLEAR_DATA }
}

export const teacherRedFlagData = (payload) => {
    return { type: TEACHER_RED_FLAG_IS_UPDATED, payload: payload }
}
export const fetchTeacherPocFilterData = (query, page, notify) => async (dispatch) => {
    notify.current.openToaster('Loading the teacher data', 'info')
    dispatch({ type: LOADING_TEACHER_SEARCH_DATA })
    try {
        const acutalData = await searchTeacher(query, page);
        dispatch({
            type: SUCCESSFULLY_TEACHER_SEARCH_DATA,
            payload: { data: acutalData.data, total: acutalData.total_records },
        })
        notify.current.openToaster('successfully fetch teacher data', 'success')
    } catch (error) {
        dispatch({
            type: FAILURE_TEACHER_SEARCH_DATA,
            payload: error.message,
        })
        notify.current.openToaster('Error: Failure to fetch teacher data', 'error')
    }
}

export const fetchSupplyTeamData = (query, notify) => async (dispatch) => {
    try {
        const acutalData = await fetchTeacherSupplyData(query);
        if (acutalData?.success) {
            dispatch({
                type: SUCCESSFULLY_FETCH_SUPPLY_TEAM,
                payload: acutalData.data ,
            })
        }else{
        notify.current.openToaster('Error: Failure to fetch supply data', 'error')
        }
    } catch (error) {
        notify.current.openToaster('Error: Failure to fetch supply data', 'error')
    }
}
