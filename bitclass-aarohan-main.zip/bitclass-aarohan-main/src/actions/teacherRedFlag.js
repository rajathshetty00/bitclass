import { getTeacherFilterData, postTeacherRedFlagReason } from "../utils/api"
import { FITLER_TEACHER_RED_FLAG_FAILURE, FITLER_TEACHER_RED_FLAG_REQUEST, FITLER_TEACHER_RED_FLAG_SUCCESS, POST_RESON_TEACHER_RED_FLAG_FAILURE, POST_RESON_TEACHER_RED_FLAG_REQUEST, POST_RESON_TEACHER_RED_FLAG_SUCCESS, SD_CLEAR_DATA, SD_COURSE_DETAIL_FAILURE, SD_COURSE_DETAIL_REQUEST, SD_COURSE_DETAIL_SUCCESS, SD_COURSE_PAGE_CHANGE, SD_TICKET_DETAIL_FAILURE, SD_TICKET_DETAIL_REQUEST, SD_TICKET_DETAIL_SUCCESS, SD_TICKET_PAGE_CHANGE, STUDENT_DIRECTORY_HANDLE_PAGE_CHANGE, TEACHER_RED_FLAG_CLEAR_DATA, TEACHER_RED_FLAG_HANDLE_PAGE_CHANGE, TEACHER_RED_FLAG_IS_UPDATED } from "./types"

export const PageChangeTeacherRedFlag = (page) => {
    return { type: TEACHER_RED_FLAG_HANDLE_PAGE_CHANGE, payload: page }
}
export const clearAllData = () => {
    return { type: TEACHER_RED_FLAG_CLEAR_DATA }
}

export const teacherRedFlagData = (payload) => {
    return { type: TEACHER_RED_FLAG_IS_UPDATED, payload: payload }
}
export const fetchTeacherFilterData = (query, page, notify) => async (dispatch) => {
    notify.current.openToaster('Loading the teacher data', 'info')
    dispatch({ type: FITLER_TEACHER_RED_FLAG_REQUEST })
    try {
        const acutalData = await getTeacherFilterData(query, page);
        dispatch({
            type: FITLER_TEACHER_RED_FLAG_SUCCESS,
            payload: { data: acutalData.data, total: acutalData.total_records },
        })
        notify.current.openToaster('successfully fetch teacher data', 'success')
    } catch (error) {
        dispatch({
            type: FITLER_TEACHER_RED_FLAG_FAILURE,
            payload: error.message,
        })
        notify.current.openToaster('Error: Failure to fetch teacher data', 'error')
    }
}

export const sendTeacherRedFlagResonData = (body, notify) => async (dispatch) => {
    notify.current.openToaster('Loading', 'info')

    dispatch({ type: POST_RESON_TEACHER_RED_FLAG_REQUEST })
    try {
        const acutalData = await postTeacherRedFlagReason(body);
        dispatch({
            type: POST_RESON_TEACHER_RED_FLAG_SUCCESS,
            payload: body,
        })
        notify.current.openToaster('successfully change the teacher flag', 'success')

    } catch (error) {
        dispatch({
            type: POST_RESON_TEACHER_RED_FLAG_FAILURE,
            payload: error.message,
        })
        notify.current.openToaster('Error: Failure to post teacher flag', 'error')

    }
}
