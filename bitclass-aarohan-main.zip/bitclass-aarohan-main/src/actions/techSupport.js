import { message } from "antd"
import { TASKS_TYPES } from "../containers/TechSupport/helper"
import {isArray} from 'lodash-es'
import {
  deleteRecordingById,
  getCourseInfo,
  getRecentTasks,
  getRecordingByCourseCode,
  makeRefund,
  shiftBatch,
} from "../utils/api"
import {
  CLOSE_CONFIRMATION_MODAL,
  GET_RECENT_TASKS,
  OPEN_MODAL,
  SAVE_COURSE_DETAILS,
  SAVE_NEW_COURSE_DETAILS,
  SAVE_RECORDINGS,
  SET_LOADING,
  SET_MESSAGE_LOG,
  SET_MODAL_CLOSABLE,
} from "./types"

export const getAllRecentTasks =
  (...args) =>
  async (dispatch) => {
    try {
      const res = await getRecentTasks(...args)
      if (res.success) {dispatch({ type: GET_RECENT_TASKS, payload: res })}
      else {dispatch({type: SET_MESSAGE_LOG, payload: res.message})}
    } catch (error) {}
  }

export const initiateRefund =
  (course_code, batch, students,reason) => async (dispatch) => {
    try {
      message.loading("Waiting for server response..")
      dispatch({type:SET_LOADING, payload:true})
      const { data, success } = await makeRefund(course_code, batch, students,reason)
      if (success) {
        message.success("Refund successfully initialized")
        dispatch({ type: SET_MODAL_CLOSABLE, payload: true })
        dispatch({ type: OPEN_MODAL, payload: TASKS_TYPES.REFUND_CANCELLATION })
        dispatch({ type: CLOSE_CONFIRMATION_MODAL })
        dispatch(getAllRecentTasks(1))
      // dispatch({type:SET_LOADING, payload:false})

      } else {
        message.error("Failed to initialize refund")
      }
    } catch (error) {}
  }

export const initiateBatchShifting =
  (courseCodes, batch, students,reason) => async (dispatch) => {
    try {
      dispatch({type:SET_LOADING, payload:true})

      message.loading("Waiting for server response..")
      const { data, success } = await shiftBatch(courseCodes, batch, students,reason)
      if (success) {
        message.success("Batch shifting initialized")
        dispatch({ type: SET_MODAL_CLOSABLE, payload: true })
        dispatch({ type: OPEN_MODAL, payload: TASKS_TYPES.REFUND_CANCELLATION })
        dispatch({ type: CLOSE_CONFIRMATION_MODAL })
        dispatch(getAllRecentTasks(1))
      // dispatch({type:SET_LOADING, payload:false})

      } else {
        message.error("Failed to initialize batch shifting")
      }
    } catch (error) {}
  }

export const deleteRecording =
  (recordingId, courseCode) => async (dispatch) => {
    try {
      // message.loading("Waiting for server response..")
      const { data, success } = await deleteRecordingById(recordingId,courseCode)
      dispatch({type:SET_LOADING, payload:true})

      if (success) {
        message.success("Recording deleted successfully")
        // dispatch(getRecordings(courseCode))
        dispatch({ type: SET_MODAL_CLOSABLE, payload: true })
        dispatch({ type: OPEN_MODAL, payload: TASKS_TYPES.RECORDINGS })
        dispatch({ type: CLOSE_CONFIRMATION_MODAL })
        dispatch(getAllRecentTasks(1))
        dispatch({type:SET_LOADING, payload:false})

      } else {
        message.error("Failed to delete recording")
        dispatch({type:SET_LOADING, payload:false})
      }
    } catch (error) {}
  }

export const getRecordings = (courseCode) => async (dispatch) => {
  message.loading("Fetching recording details...")
  try {
    const { data, success } = await getRecordingByCourseCode(courseCode)
    dispatch({type:SET_LOADING, payload:true})

    if (success&&isArray(data)) {
      dispatch({ type: SAVE_RECORDINGS, payload: data })
      message.success("Successfully fetched recording details")
      // dispatch({type:SET_LOADING, payload:false})

    } else {
      dispatch({ type: SAVE_RECORDINGS, payload: [] })
      message.error("Failed to fetch recording details")
      
    }
    dispatch({type:SET_LOADING, payload:false})

  } catch (error) {}
}

export const getCourseSummary = (courseCodes) => async (dispatch) => {
  if (courseCodes[0] === courseCodes[1]) return
  try {
    dispatch({type:SET_LOADING, payload:true})

    const { data } = await getCourseInfo(courseCodes)
    if (data.length > 0) {
    dispatch({type:SET_LOADING, payload:false})

      // message.success("Successfully fetched course details")
      dispatch({ type: SAVE_COURSE_DETAILS, payload: data[0] })
      if (data.length > 1)
        dispatch({ type: SAVE_NEW_COURSE_DETAILS, payload: data[1] })
    } else {
    dispatch({type:SET_LOADING, payload:false})

      message.error("Failed to fetch course details")
      dispatch({ type: SAVE_COURSE_DETAILS, payload: {} })
      dispatch({ type: SAVE_NEW_COURSE_DETAILS, payload: {} })
    }

  } catch (error) {}
}
