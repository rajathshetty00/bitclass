import { message } from "antd";
import { submittingDashboardBotData, submittingDashboardData } from "../utils/api";
import { FAILURE_WHATSAPPDATA_SUBMITING, LOADING_WHATSAPPDATA_SUBMITING, SUCCESSFULLY_WHATSAPPDATA_SUBMITING } from "./types";

// payout techer type
export const submitWhatsAppDashboardData = (body) => async (dispatch) => {
    dispatch({ type: LOADING_WHATSAPPDATA_SUBMITING })
    try {
      const acutalData = await submittingDashboardData(body);
      dispatch({ type: SUCCESSFULLY_WHATSAPPDATA_SUBMITING, payload:acutalData})
      message.success("Successfully submitted data")
    } catch (error) {
      dispatch({ type: FAILURE_WHATSAPPDATA_SUBMITING, payload: error.message });
      message.error("Error while submitting data")
    }
  }


  export const submitWhatsAppDashboardBotData = (body) => async (dispatch) => {
    dispatch({ type: LOADING_WHATSAPPDATA_SUBMITING })
    try {
      const acutalData = await submittingDashboardBotData(body);
      dispatch({ type: SUCCESSFULLY_WHATSAPPDATA_SUBMITING, payload:acutalData})
      message.success("Successfully submitted Bot data")
    } catch (error) {
      dispatch({ type: FAILURE_WHATSAPPDATA_SUBMITING, payload: error.message });
      message.error("Error while submitting bot data ")
    }
  }
  