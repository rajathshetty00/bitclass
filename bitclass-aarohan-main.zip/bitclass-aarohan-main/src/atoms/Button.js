import React from 'react'

const Button = () => {
    return (
        <button>Just a Button!</button>
    )
}

export default Button
