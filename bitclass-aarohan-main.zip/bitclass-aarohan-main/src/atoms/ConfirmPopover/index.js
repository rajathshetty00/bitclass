import React, { useState, useEffect } from 'react';

import { Popconfirm } from 'antd';

const ConfirmPopover = ({
  title,
  showPopconfirm,
  handleOkFn,
  handleCancelFn,
  ...props
}) => {
  const [visible, setVisible] = useState(showPopconfirm);
  const [confirmLoading, setConfirmLoading] = useState(false);

  useEffect(() => {
    setVisible(showPopconfirm)
  }, [showPopconfirm])

  const handleOk = async () => {
    setConfirmLoading(true);
    if(typeof handleOkFn === 'function')
      await handleOkFn()
    setVisible(false);
    setConfirmLoading(false);
  };

  const handleCancel = () => {
    if(typeof handleCancelFn === 'function')
      handleCancelFn()
    setVisible(false);
  };

  return (
    <Popconfirm
      title={title}
      visible={visible}
      onConfirm={handleOk}
      okButtonProps={{ loading: confirmLoading }}
      onCancel={handleCancel}
    >
      { props.children }
    </Popconfirm>
  );
};

export default ConfirmPopover