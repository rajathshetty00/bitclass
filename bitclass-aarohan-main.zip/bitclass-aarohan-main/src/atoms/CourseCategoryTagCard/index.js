import React, { useState, useEffect } from 'react'
import {
  Card,
  Select,
  Button,
  message,
} from 'antd'

import default_image from '../../assets/svg/default_video_thumb.svg'
import styles from './styles.module.scss'
import { mapCategoriesToCourse } from '../../utils/api'

const { Meta } = Card
const { Option }  = Select

const CourseCategoryTagCard = ({
  doc,
  allCategories,
}) => {

  const getCategoryIdArray = (c) => {
    return c.map((_c, i) => {
      for(let i = 0; i < allCategories.length; i++) {
        let ele = allCategories[i]
        if(ele.display_text ===  _c){
          return ele.id
        }
      }
      return false
    })
  }

  const [categories, setCategories] = useState(doc ? getCategoryIdArray(doc.categories) : [])

  useEffect(() => {
    if(doc){
      let _categories = getCategoryIdArray(doc.categories)
      setCategories(_categories)
    }
  }, [doc])

  const addCategoriesToCourse = async () => {
    const loading = message.loading(`saving categories of ${doc.heading}`, 100)
    try {
      const { success } = await mapCategoriesToCourse(doc._entity_type === "tmpr" ? doc.tmpr_code : doc.code, categories)
      loading()
      if(success) {
        message.success("category saved")
      } else {
        message.error("Failed to save category")
      }
    } catch (error) {
      console.log(error);
      message.error("Failed to save category")
    }
  }

  if(!doc) return ''

  return (
    <Card
      hoverable
      style={{ width: '20rem' }}
      cover={
        <img alt={doc.heading} src={doc.intro_video_thumbnail  ? doc.intro_video_thumbnail : default_image} />
      }
      className={styles.cctcMaster}
    >
      <Meta title={doc.heading} description={"by " + doc.teacher.name} />
      <b><span>{doc.amount} {doc.currency}</span></b>
      <Select
        mode="multiple"
        placeholder="category"
        className={styles.categoryFilter}
        defaultValue={categories}
        optionFilterProp="children"
        filterOption={(input, option) =>
          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
        }
        onChange={setCategories}
      >
        {allCategories.map((v, i) => (
          <Option key={i.toString()} value={v.id}>
            {v.display_text}
          </Option>
        ))}
      </Select>
      <Button
        type={"primary"}
        className={styles.button}
        onClick={addCategoriesToCourse}
      >
        Add To Course
      </Button>
    </Card>
  )

}

export default CourseCategoryTagCard
