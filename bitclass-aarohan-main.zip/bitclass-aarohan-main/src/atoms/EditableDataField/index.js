import React, { useState, useContext, useRef} from 'react'
import {
  Form,
  Select,
  Input,
  InputNumber,
  DatePicker,
  Popconfirm,
  Modal,
} from 'antd';
import { isEmpty } from 'lodash-es';
import moment from "moment";
import { Edit2 } from 'react-feather'

import { READABLE_DATE_FORMAT } from '../../constants'
import styles from './style.module.scss'

const EditableDataField = ({
  fieldType,
  val,
  fieldKey,
  handleSave,
  id,
  extraParams,
  validationRules,
  editFieldProps,
  selectOptions,
  ...props
}) => {

  const [editing, setEditing] = useState(false);
  const [visible, setVisible] = useState(false);

  const { Option } = Select;
  const { TextArea } = Input;
  const EditableContext = React.createContext();
  const inputRef = useRef();
  const _allowedFieldTypes = ['text', 'number', 'select', 'date', 'link', 'textarea']
  const [form] = Form.useForm();

  const toggleEdit = () => {
    setEditing(!editing);
    let _val = val
    if(fieldType === "link") {
      _val = val.editValue || ""
    }
    form.setFieldsValue({
      [fieldKey]: _val
    });
  };

  const save = async (e) => {
    try {
      const values = await form.validateFields();
      handleSave({ 
        id: id,
        extraParams: !isEmpty(extraParams) ? extraParams : {},
        ...values
      });
      setVisible(false)
      toggleEdit();
    } catch (errInfo) {
      console.log("Save failed:", errInfo);
    }
  };

  const checkValueChanged = async() => {
    const values = await form.validateFields();
    let _isValueChanged = false
    if(fieldType === "link") {
      _isValueChanged = ((val.editValue || "") !== values[fieldKey])
    } else if(fieldType === "date") {
      let _oldIsMoment = moment.isMoment(val)
      let _newIsMoment = moment.isMoment(values[fieldKey])
      if(!_oldIsMoment && !_newIsMoment) {
        _isValueChanged = false
      } else if(_oldIsMoment !== _newIsMoment) {
        _isValueChanged = true
      } else {
        _isValueChanged = !val.isSame(values[fieldKey])
      }
    } else {
      _isValueChanged = (val !== values[fieldKey])
    }
    if(!_isValueChanged) {
      setVisible(false)
      toggleEdit();
      return
    } // Don't trigger api if value not changed
    if(fieldType === "textarea") {
      save()
    } else {
      setVisible(true)
    }
  }

  const _renderEditField = (fieldType, selectOptions, extraProps, val, inputRef) => {
    switch(fieldType) {
      case 'text':
      case 'link':
        return <Input defaultValue={val} onPressEnter={() => checkValueChanged()} onBlur={() => checkValueChanged()} {...extraProps} ref={inputRef} />
      case 'number':
        return <InputNumber defaultValue={val} onPressEnter={() => checkValueChanged()} onBlur={() => checkValueChanged()} {...extraProps} ref={inputRef} />
      case 'select':
        return (
          <Select
            defaultValue={val}
            onPressEnter={() => checkValueChanged()}
            onBlur={() => checkValueChanged()}
            showSearch
            ref={inputRef}
            {...extraProps}>
            { selectOptions.map((v, i) => (
              <Option key={i.toString()} value={v.value}>
                { v.label }
              </Option>
            )) }
          </Select>
        )
      case 'date':
        return (<DatePicker defaultValue={val} onBlur={() => checkValueChanged()} onChange={() => checkValueChanged()} onPressEnter={() => checkValueChanged()} {...extraProps} format={READABLE_DATE_FORMAT} ref={inputRef} />)
      default: return ''
    }
  }

  let childNode = props.children;
  childNode = editing ?
    fieldType === 'textarea'
      ? (
        <Modal
          title="Add note"
          centered
          visible={editing}
          onOk={() => { setTimeout(() => {
            document.body.style.overflow = 'auto';
            }, 1000)
            checkValueChanged()
          }}
          onCancel={() => { setTimeout(() => {
            document.body.style.overflow = 'auto';
            }, 1000)
            toggleEdit()
          }}
          okText="Add"
        >
          <Form.Item
            style={{
              margin: 0
            }}
            name={fieldKey}
            rules={validationRules}
          >
            <TextArea rows={10} {...editFieldProps} />
          </Form.Item>
        </Modal>
      )
      : (
        <Form.Item
          style={{
            margin: 0
          }}
          name={fieldKey}
          rules={validationRules}
        >
          { _allowedFieldTypes.indexOf(fieldType) !== -1
            && _renderEditField(fieldType, selectOptions, editFieldProps, val, inputRef)
          }
        </Form.Item>
    ) : (
      <div className={styles.editableWrap}
        onClick={toggleEdit}
      >
        <Edit2 className={styles.editPen} />
        {props.children}
      </div>
    )

  return(
    <Form form={form} component={false}>
      <EditableContext.Provider value={form}>
        <Popconfirm
          title="Do you want to update this?"
          visible={visible}
          onConfirm={save}
          onCancel={() => {
            toggleEdit()
            setVisible(false)
          }}
        >
          {childNode}
        </Popconfirm>
      </EditableContext.Provider>
    </Form>
  )
}

export default EditableDataField
