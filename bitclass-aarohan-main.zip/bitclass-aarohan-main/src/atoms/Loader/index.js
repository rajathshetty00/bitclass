import React from "react";
import { Spin } from "antd";
import { LoadingOutlined } from "@ant-design/icons";
import clsx from 'clsx'

import styles from './style.module.scss'

const antIcon = <LoadingOutlined className={styles.spinner} spin />;

const Loader = ({
  className,
}) => {
  return(
    <div className={clsx(styles.loaderContainer, className)}>
      <Spin indicator={antIcon} />
    </div>
  )
}

export default Loader