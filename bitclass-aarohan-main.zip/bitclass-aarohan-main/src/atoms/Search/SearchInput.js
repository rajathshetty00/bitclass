import Search from 'antd/lib/transfer/search'
import React from 'react'
import styles from './style.module.scss'
const SearchInput = ({searchError=false,...props}) => {
    return (
        <div>
        <div className = {styles.search_field_wrapper}>
        <Search placeholder="Type here to search"   enterButton {...props}   />
        </div>
        {searchError.length > 0 &&<div className={styles.field_error}>{searchError}</div>}
        </div>
    )
}

export default  SearchInput