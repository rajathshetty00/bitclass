const Spacer = ({
    size,
    axis,
    classes,
    delegated,
  }) => {
    const width = axis === 'vertical' ? 1 : size;
    const height = axis === 'horizontal' ? 1 : size;
    return (
      <span
        style={{
          width,
          minWidth: width,
          height,
          minHeight: height,
        }}
        className={`${classes}`}
      >
        {delegated}
      </span>
    );
  };
  export default Spacer;