import { useImperativeHandle, forwardRef, useEffect, useState } from 'react';

import { Alert } from 'antd';

const AlertComponent = forwardRef((props, ref) => {
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("Alert Message Text");
  const [type, setType] = useState("success");



  useImperativeHandle(ref, () => ({

    openToaster(msg, typeData = "info") {
      setOpen(true);
      setMsg(msg);
      setType(typeData);
      setTimeout(() => {
        handleClose()
      }, 3000)
    }
  }));

  const handleClose = (event, reason) => {
    // if (reason === 'clickaway') {
    //   return;
    // }
    setOpen(false)
    setMsg("");

  };

  return (
    <div style={{ position: 'absolute', top: '67px', right: '15px', zIndex: 99 }}>

      {open ? (
        <Alert message={msg} type={type} closable afterClose={handleClose} />
      ) : null}
    </div>
  );
});
export default AlertComponent;