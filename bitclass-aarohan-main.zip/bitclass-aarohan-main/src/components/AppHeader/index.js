/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from 'react'
import { useDispatch } from 'react-redux'

import styles from './style.module.scss'
import {ReactComponent as Logo } from '../../assets/svg/logo.svg'
import { Dropdown, Menu } from 'antd'
import { wipeAuth } from '../../actions/auth'
import { wipeLocalStorage } from '../../utils/auth'
import { DownOutlined } from '@ant-design/icons';
import clsx from 'clsx';

const AppHeader = ({ history }) => {

  const username = localStorage.getItem('username')
  const code = localStorage.getItem('code')
  const dispatch = useDispatch()

  const logout = (e) => {
    e.preventDefault()
    dispatch(wipeAuth())
    wipeLocalStorage()
    history.push('/')
  }

  const menu = (
    <Menu>
      <Menu.Item>
        <a rel="noopener noreferrer" href="#" onClick={(e) => logout(e)}>
          Logout
        </a>
      </Menu.Item>
    </Menu>
  )

  return(
    <div className={styles.appHeader}>
      <div className={styles.bitClassLogo}>
        <Logo />
      </div>
      {
        code &&
        (
          <Dropdown overlay={menu}>
            <a className={clsx("ant-dropdown-link", styles.menu)} onClick={e => e.preventDefault()}>
              {username} <DownOutlined />
            </a>
          </Dropdown>
        )
      }
    </div>
  )
}

export default AppHeader