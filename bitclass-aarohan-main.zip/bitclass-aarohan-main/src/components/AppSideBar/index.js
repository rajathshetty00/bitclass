import React, { Fragment } from 'react'
import { Menu, Layout } from 'antd';
import { MENU } from '../../config/index';
import styles from './style.module.scss'
import { filter, isEmpty } from 'lodash-es';
import { isLoggedIn } from '../../utils/auth';
import clsx from 'clsx'
const { Sider } = Layout;
const { SubMenu } = Menu;

const AppSideBar = ({ collapsed, history }) => {
  const findCurrentActiveMenu = (MenuItem) => {
    let currentActiveMenu = '';
    MenuItem.forEach(element => {
      const activeObj = filter(element?.subMenu ? element.menu : MenuItem, ['url', history.location.pathname])
      if (activeObj.length > 0)
        currentActiveMenu = !isEmpty(activeObj) ? activeObj[0]['key'] : ''
    });
    return currentActiveMenu
  }
  return (
    <Sider trigger={null}
      width="280"
      collapsible
      collapsed={collapsed} theme="light">
      <Menu
        theme="light"
        mode="inline"
        selectedKeys={[findCurrentActiveMenu(MENU)]}
        onClick={(info) => {
          if (info.item.props.forceReload)
            window.location = (info.item.props.dataUrl)
          else
            history.push(info.item.props.dataUrl)
        }}>
        {
          MENU.map((menu, i) => {
            return <Fragment key={menu?.subMenu?.key || menu.key}>
              {menu?.subMenu ? <SubMenu key={menu.subMenu.key} icon={menu.subMenu.icon} title={menu.subMenu.menuLabel} className={styles.submenu}>
                {
                  menu.menu.map((submenu, i) => (
                    <Menu.Item
                      key={submenu.key}
                      dataUrl={submenu.url}
                      icon={submenu.icon}
                      forceReload={submenu.forceReload}
                      className={clsx(styles.menuItem)}
                    >
                      {submenu.menuLabel}
                    </Menu.Item>
                  ))
                }
              </SubMenu> : <Menu.Item
                key={menu.key}
                dataUrl={menu.url}
                icon={menu.icon}
                forceReload={menu.forceReload}
              >
                {menu.menuLabel}
              </Menu.Item>}
            </Fragment>
          })
        }
      </Menu>
    </Sider>
  )

}

export default AppSideBar
