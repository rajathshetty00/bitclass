import { CheckCircle, X } from "react-feather"
import styles from "./styles.module.scss"

const Status = ({data}) => (
  <div className={styles.status}>{data ? <CheckCircle color="green" /> : <X color="tomato" />}</div>
)

export default Status
