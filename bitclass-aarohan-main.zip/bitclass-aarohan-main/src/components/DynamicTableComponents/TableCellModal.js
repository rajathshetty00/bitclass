import Modal from "antd/lib/modal/Modal"

const TableCellModal = ({visible}) => {
  return (
    <Modal visible={visible}>
      hello
    </Modal>
  )
}

export default TableCellModal
