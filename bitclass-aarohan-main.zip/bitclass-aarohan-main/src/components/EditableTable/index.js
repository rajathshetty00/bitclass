import React, { useState, useRef, useContext, useEffect } from 'react'
import {
  Table,
  Form,
  Select,
  Input,
  InputNumber,
  DatePicker,
  Popconfirm,
  Modal,
} from 'antd';

import styles from './style.module.scss'
import { isEmpty } from 'lodash-es';
import moment from "moment";
import { READABLE_DATE_FORMAT } from '../../constants'

const EditableContext = React.createContext();
const { Option } = Select;
const { TextArea } = Input;

/**
 * 
 *  This component is only for editing cells.
 *  If changing to row edit then needs to take care of the functions 
 *  which handles data and parameters also will change
 * 
 *  pass an id in row data so it will return in save data
 *  pass extraParams, will be passed back on save function
 */

/**
  title: string
  validationRules: [{required: boolean, message: string }]
  fieldType: enum [text, number, select, date, link, textarea] for link in data add field editValue
  selectOptions: Array [{ label: string, value:string }]
  editFieldProps: Object 
*/

const _allowedFieldTypes = ['text', 'number', 'select', 'date', 'link', 'textarea']

const EditableRow = ({ index, ...props }) => {
  const [form] = Form.useForm();
  return (
    <Form form={form} component={false}>
      <EditableContext.Provider value={form}>
        <tr {...props} />
      </EditableContext.Provider>
    </Form>
  );
};


const EditableCell = ({
  title,
  editable,
  children,
  dataIndex,
  record,
  handleSave,
  validationRules,
  fieldType,
  selectOptions,
  editFieldProps,
  ...restProps
}) => {
  const [editing, setEditing] = useState(false);
  const [visible, setVisible] = useState(false);
  const inputRef = useRef();
  const form = useContext(EditableContext);
  useEffect(() => {
    if (editing) {
      inputRef.current.focus()
    }
  }, [editing]);

  const toggleEdit = () => {
    setEditing(!editing);
    let val = record[dataIndex]
    if(fieldType === "link") {
      val = record[dataIndex].editValue || ""
    }
    form.setFieldsValue({
      [dataIndex]: val
    });
  };

  const save = async (e) => {
    try {
      const values = await form.validateFields();
      handleSave({ 
        id: record.id,
        extraParams: !isEmpty(record.extraParams) ? record.extraParams : {},
        ...values
      });
      setVisible(false)
      toggleEdit();
    } catch (errInfo) {
      console.log("Save failed:", errInfo);
    }
  };

  const checkValueChanged = async() => {
    const values = await form.validateFields();
    let _isValueChanged = false
    if(fieldType === "link") {
      _isValueChanged = ((record[dataIndex].editValue || "") !== values[dataIndex])
    } else if(fieldType === "date") {
      let _oldIsMoment = moment.isMoment(record[dataIndex])
      let _newIsMoment = moment.isMoment(values[dataIndex])
      if(!_oldIsMoment && !_newIsMoment) {
        _isValueChanged = false
      } else if(_oldIsMoment !== _newIsMoment) {
        _isValueChanged = true
      } else {
        _isValueChanged = !record[dataIndex].isSame(values[dataIndex])
      }
    } else {
      _isValueChanged = (record[dataIndex] !== values[dataIndex])
    }
    if(!_isValueChanged) {
      setVisible(false)
      toggleEdit();
      return
    } // Don't trigger api if value not changed
    if(fieldType === "textarea") {
      save()
    } else {
      setVisible(true)
    }
  }
 
  const _renderEditField = (fieldType, inputRef, selectOptions, extraProps) => {
    switch(fieldType) {
      case 'text':
      case 'link':
        return <Input ref={inputRef} onPressEnter={() => checkValueChanged()} onBlur={() => checkValueChanged()} {...extraProps} />
      case 'number':
        return <InputNumber ref={inputRef} onPressEnter={() => checkValueChanged()} onBlur={() => checkValueChanged()} {...extraProps} />
      case 'select':
        return (
          <Select
            filterOption={(input, option) =>
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
            ref={inputRef}
            onPressEnter={() => checkValueChanged()}
            onBlur={() => checkValueChanged()}
            showSearch
            {...extraProps}>
            { selectOptions.map((v, i) => (
              <Option key={i.toString()} value={v.value}>
                { v.label }
              </Option>
            )) }
          </Select>
        )
      case 'date':
        return (<DatePicker onBlur={() => checkValueChanged()} onChange={() => checkValueChanged()} onPressEnter={() => checkValueChanged()} {...extraProps} ref={inputRef} format={READABLE_DATE_FORMAT} />)
      default: return ''
    }
  }

  let childNode = children;
  if (editable) {
    childNode = editing ?
    fieldType === 'textarea'
      ? (
        <Modal
          title="Add note"
          centered
          visible={editing}
          onOk={() => { setTimeout(() => {
            document.body.style.overflow = 'auto';
           }, 1000)
           checkValueChanged()
          }}
          onCancel={() => { setTimeout(() => {
            document.body.style.overflow = 'auto';
           }, 1000)
           toggleEdit()
          }}
          okText="Add"
        >
          <Form.Item
            style={{
              margin: 0
            }}
            name={dataIndex}
            rules={validationRules}
          >
            <TextArea rows={10} ref={inputRef} {...editFieldProps} />
          </Form.Item>
        </Modal>
      )
      : (
        <Form.Item
          style={{
            margin: 0
          }}
          name={dataIndex}
          rules={validationRules}
        >
          { _allowedFieldTypes.indexOf(fieldType) !== -1
            && _renderEditField(fieldType, inputRef, selectOptions, editFieldProps)
          }
        </Form.Item>
    ) : (
      <div
        className={"editable-cell-value-wrap"}
        onClick={toggleEdit}
      >
        {children}
      </div>
    );
  }

  return (
    <Popconfirm
      title="Do you want to update this?"
      visible={visible}
      onConfirm={save}
      // okButtonProps={{ loading: confirmLoading }}
      onCancel={() => {
        toggleEdit()
        setVisible(false)
      }}
    >
      <td {...restProps}>{childNode}</td>
    </Popconfirm>
  );
};

const EditableTable = ({
  columns,
  dataSource,
  ...props
}) => {

  const components = {
    body: {
      row: EditableRow,
      cell: EditableCell
    }
  };

  const _columns = columns.map((col) => {
    if (!col.editable) {
      return col;
    }
    return {
      ...col,
      onCell: (record) => {
        return ({
        record,
        editable: col.editable,
        dataIndex: col.dataIndex,
        title: col.title,
        handleSave: col.handleSave,
        validationRules: col.validationRules ? col.validationRules : [],
        fieldType: col.fieldType ? col.fieldType : 'text',
        selectOptions: col.selectOptions,
        editFieldProps: col.editFieldProps,
      })}
    };
  });

  return(
    <Table
      components={components}
      rowClassName={() => "editable-row"}
      columns={ _columns }
      dataSource={dataSource}
      {...props}
    />
  )
}

export default EditableTable