import styles from './style.module.scss'

const ErrorComponent = ({errorMessage}) => {
  return ( 
    <h1 className = {styles.errorHeader}>{errorMessage}</h1>
   )
}
 
export default ErrorComponent