import Modal from "antd/lib/modal/Modal"
import { CLOSE_MODAL } from "../../actions/types"
import { getModalTitle,getModalFooter,getModalBody } from "../../helpers/modal"
import useRedux from "../../helpers/useRedux"

const BitModal = (props) => {
  const [{modalContext,modalState,closable},dispatch]= useRedux('modal')
  const closeModal=()=>dispatch({type: CLOSE_MODAL})
  return (
    <Modal
      title={getModalTitle(modalContext)}
      closable={closable}
      visible={modalState}
      onCancel={closeModal}
      footer={getModalFooter(modalContext)}
      {...props}
    >
      {getModalBody(modalContext)}
    </Modal>
  )
}

export default BitModal
