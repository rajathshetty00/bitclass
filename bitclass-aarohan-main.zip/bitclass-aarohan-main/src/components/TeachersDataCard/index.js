/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from 'react'
import {
  Card,
  Row,
  Col,
  Divider,
  Input,
  Button,
  Modal,
  Form,
  message,
  Tooltip,
  Table,
  Popconfirm,
} from 'antd'
import { ChevronDown, ChevronUp, List, Copy, Trash2 } from 'react-feather'
import clsx from 'clsx'
import { isEmpty } from 'lodash-es'

import styles from './style.module.scss'
import {
  deleteTMPR,
  getPayoutReport,
  updateCampaignStageAndDiscovery,
} from '../../utils/api'
import { exists, createUrlSlug, copyText } from '../../utils/index'
import { READABLE_DATE_FORMAT, WEB_URL } from '../../constants'
import { ReactComponent as Wallet } from '../../assets/svg/wallet.svg'
import { ReactComponent as Whatsapp } from '../../assets/svg/whatsapp.svg'
import EditableDataField from '../../atoms/EditableDataField/index'
import { payoutColumns } from './payoutData'
import dayjs from 'dayjs'

const DataCard = ({
  data,
  moment,
  internalUsers,
  campaignStatuses,
  demoTypes,
  handleSave,
  updateRawData,
  refetchData,
}) => {
  const [collapsed, setCollapsed] = useState(false)
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false)
  const [showDeleteLoading, setShowDeleteLoading] = useState(false)

  const [isModalVisible, setIsModalVisible] = useState(false)
  const [payoutDetails, setPayoutDetails] = useState([])

  const showDeletePopconfirm = () => {
    setShowDeleteConfirmation(true);
  }

  const deleteTmprFn = async(tmpr_code) => {
    if(!exists(tmpr_code)) {
      return
    }

    setShowDeleteLoading(true)
    try {
      let _res = await deleteTMPR(tmpr_code)
      setShowDeleteConfirmation(false);
      setShowDeleteLoading(false);
      if(_res['data']) {
        message.success("Successfully deleted Campaign")
        refetchData()
      } else {
        message.error("Failed to delete Campaign...!")
      }
    } catch(e) {
      message.error("Failed to delete Campaign...!")
    }
  }

  const deleteTmprCancel = () => {
    setShowDeleteConfirmation(false);
  }

  const showModal = () => {
    setIsModalVisible(true)
  }

  const handleOk = () => {
    setIsModalVisible(false)
  }

  const handleCancel = () => {
    setIsModalVisible(false)
  }

  const getPayoutData = async (teacherId) => {
    try {
      const res = await getPayoutReport(teacherId)
      if(exists(res['data']))
        setPayoutDetails(res['data'])
      else setPayoutDetails([])
      
    } catch (error) {
      setPayoutDetails([])
    }
  }
  const DataWrapper = (props) => (
    <div className={styles.dataWrapper} {...props}>
      <span className={styles.labelSpan}>{props.label}</span>
      <span className={styles.dataSpan}>{props.children}</span>
    </div>
  )

  const fetchEditToken = (teacherCode, link) => {
    // getTokenForTenant(teacherCode)
    //   .then(r => {
    //     if(exists(r.data) && exists(r.data.auth_token)) {
    //       let token = r.data.auth_token
    //       setCookie('_auth', token, 1)
    //       if(link)
    window.open(link)
    //   } else {
    //     message.error("Failed to get teacher login access")
    //   }
    // })
  }
  useEffect(() => {
    getPayoutData(id)
  }, [])

  const CourseCard = ({
    courseType = 'demo', // demo/upsell
    title,
    courseCode,
    type = '',
    currency = '',
    earning = '',
    waLink = '',
    registrations = 0,
    extraParams,
    link,
    external_campaign_ids = '',
    meetingLink,
    MeetingPassword,
    startTs,
    startTime,
    endTs,
  }) => {
    const [showAddMeeting, setShowAddMeeting] = useState(false)

    const _addMeetingLink = async (data) => {
      let loadMessage = message.loading('Saving data...', 0)
      let _res = await updateCampaignStageAndDiscovery(
        id,
        'external_classroom_details',
        {
          course_code: courseCode,
          external_lesson_url: data.meeting_link,
          external_lesson_password: data.meeting_password,
        }
      )
      if (exists(_res.data)) {
        updateRawData(id, _res.data)
        loadMessage()
        message.success('Meeting link added.')
        setShowAddMeeting(false)
      } else {
        loadMessage()
        message.error('Failed to add meeting link')
      }
    }

    return (
      <Card
        className={clsx(
          styles.demoUpsellCard,
          courseType === 'demo' ? styles.lightBlue : styles.lightGreen
        )}
      >
        <div className={styles.deleteButton}>
          {courseCode && (
            <Trash2
              onClick={() => {
                Modal.confirm({
                  title: 'Confirm',
                  // icon: <ExclamationCircleOutlined />,
                  content: 'Are you sure want to delete this?',
                  okText: 'Delete',
                  cancelText: 'Cancel',
                  onOk: () => {
                    handleSave({
                      id: id,
                      extraParams: !isEmpty(extraParams) ? extraParams : {},
                      [courseType === 'demo'
                        ? 'demoCourseDetails'
                        : 'upsellCourseDetails']: -1,
                    })
                  },
                })
              }}
            />
          )}
        </div>
        <h4 className={styles.title}>
          <EditableDataField
            fieldType="link"
            val={{ editValue: courseCode }}
            handleSave={handleSave}
            extraParams={extraParams}
            id={id}
            fieldKey={
              courseType === 'demo'
                ? 'demoCourseDetails'
                : 'upsellCourseDetails'
            }
          >
            <a
              rel="noreferrer"
              target="_blank"
              href={link}
              onClick={(e) => {
                e.stopPropagation()
                e.preventDefault()
                fetchEditToken(teacherName.teacherUserCode, link)
              }}
            >
              {title}
            </a>
          </EditableDataField>
        </h4>
        <Row>
          <Col span={12}>
            <Row>
              {courseType === 'demo' && (
                <Col span={24} className={styles.lineItem}>
                  <div className={styles.icon}>
                    <List />
                  </div>
                  <div className={clsx(styles.data)}>
                    <EditableDataField
                      fieldType="select"
                      selectOptions={demoTypes}
                      val={type}
                      handleSave={handleSave}
                      extraParams={extraParams}
                      id={id}
                      fieldKey="demoCourseType"
                    >
                      {type || '-'}
                    </EditableDataField>
                  </div>
                </Col>
              )}
              <Col span={24} className={styles.lineItem}>
                <div className={styles.icon}>
                  <Wallet />
                </div>
                <div className={clsx(styles.data)}>
                  {exists(earning)
                    ? `${currency} ${earning.toLocaleString()}/-`
                    : 0}
                </div>
              </Col>
              <Col span={24} className={styles.lineItem}>
                <div className={styles.icon}>
                  <Whatsapp />
                </div>
                <EditableDataField
                  fieldType="text"
                  val={waLink}
                  handleSave={handleSave}
                  extraParams={extraParams}
                  id={id}
                  fieldKey={
                    courseType === 'demo' ? 'demoWaLink' : 'upsellWaLink'
                  }
                >
                  <div className={clsx(styles.data)}>{waLink}</div>
                </EditableDataField>
              </Col>
            </Row>
          </Col>
          <Col span={12}>
            <div className={styles.rightSideText}>Registrations</div>
            <div className={clsx(styles.registeredCount)}>{registrations}</div>
            <div className={clsx(styles.lineItem)} style={{ color: '#000' }}>
              <div className={styles.icon}>
                <List />
              </div>
              <EditableDataField
                fieldType="text"
                val={external_campaign_ids}
                handleSave={handleSave}
                extraParams={extraParams}
                id={id}
                fieldKey="external_campaign_ids"
              >
                {external_campaign_ids || 'Campaign IDs:'}
              </EditableDataField>
            </div>
          </Col>
          <Col span={12} className={styles.dateTimeData}>
            <Row>
              <Col span={24} className={styles.dataTitle}>
                Start Date
              </Col>
            </Row>
            <Row>
              <Col span={24} className={styles.dataData}>
                { startTs && dayjs.unix(startTs).format('DD MMM YYYY, hh:mm a') }
              </Col>
            </Row>
          </Col>
          <Col span={12} className={styles.dateTimeData}>
            <Row>
              <Col span={24} className={styles.dataTitle}>
                End Date
              </Col>
            </Row>
            <Row>
              <Col span={24} className={styles.dataData}>
                { endTs && dayjs.unix(endTs).format('DD MMM YYYY') }
              </Col>
            </Row>
          </Col>
        </Row>
        {courseCode && (
          <Row style={{ marginTop: '16px' }}>
            <Col span={24}>
              <span className={styles.meetingLinkLabel}>Meeting Link:</span>
              <span className={styles.meetingLink}>
                <a target="_blank" href="meetingLink">
                  {meetingLink}
                </a>
              </span>
            </Col>
            <Col span={24}>
              <span className={styles.meetingLinkLabel}>Password:</span>
              <span className={styles.meetingLink}>{MeetingPassword}</span>
            </Col>
            <Col span={24} style={{ textAlign: 'center', marginTop: '8px' }}>
              <Button
                style={{ fontWeight: 500 }}
                type={'link'}
                onClick={() => setShowAddMeeting(true)}
              >
                Add Meeting Link
              </Button>
            </Col>
          </Row>
        )}
        {showAddMeeting && (
          <Modal
            visible={showAddMeeting}
            centered
            title="Add meeting link"
            footer={null}
            onCancel={() => setShowAddMeeting(false)}
          >
            <Form
              initialValues={{
                meeting_link: meetingLink,
                meeting_password: MeetingPassword,
              }}
              onFinish={_addMeetingLink}
            >
              <Form.Item
                name="meeting_link"
                rules={[
                  {
                    required: true,
                    message: 'Please add meeting URL',
                  },
                ]}
              >
                <Input placeholder="Meeting URL" />
              </Form.Item>
              <Form.Item name="meeting_password">
                <Input placeholder="Meeting Password" />
              </Form.Item>
              <Form.Item>
                <Button type={'primary'} htmlType={'submit'}>
                  Add
                </Button>
              </Form.Item>
            </Form>
          </Modal>
        )}
      </Card>
    )
  }

  const {
    id,
    teacherName,
    assignedTo,
    planType,
    profileCompletionPercentage,
    overallStatus,
    paidOn,
    discoveryCallDate,
    assignedToVal,
    extraParams,
    internalNotes,
    teacherCountryCode,
    teacherPhone,
  } = data

  let { courses } = data
  courses = courses.filter(cF => (!isEmpty(cF.demo_course) || !isEmpty(cF.upsell_course)))
  let footerButtons = [
    <Button
      type={'primary'}
      onClick={() =>
        window.open(
          `${WEB_URL}/courses/new?code=${encodeURIComponent(
            teacherCountryCode
          )}&phone=${teacherPhone}`
        )
      }
    >
      Add Course
    </Button>,
  ]

  if (
    exists(courses[0]) &&
    (exists(courses[0].demo_course) || exists(courses[0].upsell_course))
  ) {
    const heading =
      exists(courses[0].upsell_course) &&
      exists(courses[0].upsell_course.heading)
        ? courses[0].upsell_course.heading
        : exists(courses[0].demo_course) &&
          exists(courses[0].demo_course.heading)
        ? courses[0].demo_course.heading
        : ''
    if (payoutDetails.length && id) {
      footerButtons.push(
        <>
          <Button type="primary" onClick={showModal}>
            Total Earnings
          </Button>
          <Modal
            title="Payout Report"
            visible={isModalVisible}
            onOk={handleOk}
            onCancel={handleCancel}
            width={1300}
          >
            <Table dataSource={payoutDetails} columns={payoutColumns} />
          </Modal>
        </>
      )
    }

    if (heading && id) {
      const slug = createUrlSlug(heading)
      const url = `${WEB_URL}/live-classes/${id}`
      footerButtons.push(
        <Button
          type={'link'}
          onClick={() => window.open(url)}
          className={styles.viewCdpButton}
        >
          View CDP Page
          <Tooltip title="Copy CDP URL">
            <Copy
              title="Copy URL"
              onClick={(e) => {
                e.stopPropagation()
                copyText(url)
                message.info('Link copied...')
              }}
            />
          </Tooltip>
        </Button>
      )
    }
    if (heading && id) {
      const slug = createUrlSlug(heading)
      const url = `${WEB_URL}/live-courses/${id}`
      footerButtons.push(
        <Button
          type={'link'}
          onClick={() => window.open(url)}
          className={styles.viewCdpButton}
        >
          EMI CDP Page
          <Tooltip title="Copy CDP URL">
            <Copy
              title="Copy URL"
              onClick={(e) => {
                e.stopPropagation()
                copyText(url)
                message.info('Link copied...')
              }}
            />
          </Tooltip>
        </Button>
      )
    }

  }
  
  if(id) {
    footerButtons.push(
      <Popconfirm
        title="Are you sure？"
        okText="Yes"
        cancelText="No"
        visible={showDeleteConfirmation}
        onConfirm={() => deleteTmprFn(id)}
        okButtonProps={{ loading: showDeleteLoading }}
        onCancel={deleteTmprCancel}
      >
        <a
          href="#"
          style={{
            color: 'red',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onClick = { (e) => {
            e.preventDefault()
            showDeletePopconfirm()
          }}
        >
          Delete Campaign
        </a>
      </Popconfirm>
    )
  }

  return (
    <Card
      className={clsx(styles.cardMainWrapper, 'roundedCard')}
      actions={footerButtons}
    >
      <Row className={styles.basicDetails}>
        <Col span={6}>
          <DataWrapper label="Teacher Name">
            <a
              rel="noreferrer"
              target="_blank"
              href={teacherName.link}
              onClick={(e) => {
                e.stopPropagation()
                e.preventDefault()
                fetchEditToken(
                  teacherName.teacherUserCode,
                  `${teacherName.link}`
                )
              }}
            >
              {teacherName.label}
            </a>
          </DataWrapper>
          <DataWrapper label="Date" style={{marginTop:'10px'}}>
              {moment.isMoment(paidOn)
                ? paidOn.format(READABLE_DATE_FORMAT)
                : ''}
            </DataWrapper>
        </Col>
        <Col span={5}>
          <DataWrapper label="Assigned To">
            <EditableDataField
              fieldType="select"
              selectOptions={internalUsers}
              val={assignedToVal}
              handleSave={handleSave}
              extraParams={extraParams}
              id={id}
              fieldKey="assignedTo"
            >
              {assignedTo}
            </EditableDataField>
          </DataWrapper>
        </Col>
        <Col span={4}>
          <DataWrapper label="Type">{planType}</DataWrapper>
        </Col>
        <Col span={4}>
          <DataWrapper label="Profile Completion">
            {profileCompletionPercentage.percentage || 0}%
          </DataWrapper>
        </Col>
        <Col span={4}>
          <DataWrapper label="Status">
            <EditableDataField
              fieldType="select"
              selectOptions={campaignStatuses}
              val={overallStatus}
              handleSave={handleSave}
              extraParams={extraParams}
              id={id}
              fieldKey="overallStatus"
            >
              {overallStatus}
            </EditableDataField>
          </DataWrapper>
        </Col>
        <Col span={1}>
          <DataWrapper label="" style={{ textAlign: 'center' }}>
            {collapsed ? (
              <ChevronUp
                onClick={() => setCollapsed(false)}
                className={styles.cardExpander}
              />
            ) : (
              <ChevronDown
                onClick={() => setCollapsed(true)}
                className={styles.cardExpander}
              />
            )}
          </DataWrapper>
        </Col>
      </Row>
      <div
        className={clsx(styles.detailedContent, collapsed && styles.collapsed)}
      >
        <Row className={styles.detailRow}>
          <Col span={6}>
            {false&&<DataWrapper label="Paid On">
              {moment.isMoment(paidOn)
                ? paidOn.format(READABLE_DATE_FORMAT)
                : ''}
            </DataWrapper>}
          </Col>
          <Col span={4}>
            <DataWrapper label="Discovery Call Date">
              <EditableDataField
                fieldType="date"
                val={discoveryCallDate}
                handleSave={handleSave}
                extraParams={extraParams}
                id={id}
                fieldKey="discoveryCallDate"
              >
                {moment.isMoment(discoveryCallDate)
                  ? discoveryCallDate.format(READABLE_DATE_FORMAT)
                  : ''}
              </EditableDataField>
            </DataWrapper>
          </Col>
          <Col span={10}>
            <DataWrapper label="Internal Notes / Note">
              <EditableDataField
                fieldType="textarea"
                val={internalNotes}
                handleSave={handleSave}
                extraParams={extraParams}
                id={id}
                fieldKey="internalNotes"
              >
                {internalNotes}
              </EditableDataField>
            </DataWrapper>
          </Col>
        </Row>
        <Row
          className={styles.detailRow}
          style={{ borderTop: '1px solid #f5f5f5' }}
        >
          <Col span={24}>
            <Row>
              <Col span={10}>
                <Divider className={styles.dividers}>Demo Courses</Divider>
              </Col>
              <Col span={4}></Col>
              <Col span={10}>
                <Divider className={styles.dividers}>Upsell Courses</Divider>
              </Col>
            </Row>
            <Row>
              <Col span={10}>
                <EditableDataField
                  fieldType="link"
                  val={{ editValue: '' }} //jus to avoid error
                  handleSave={handleSave}
                  extraParams={{
                    tmpc_code: '',
                  }}
                  id={id}
                  fieldKey="demoCourseDetails"
                >
                  <Input placeholder="Add Demo Course" />
                </EditableDataField>
              </Col>
              <Col span={4}></Col>
              <Col span={10}>
                <EditableDataField
                  fieldType="link"
                  val={{ editValue: '' }} //jus to avoid error
                  handleSave={handleSave}
                  extraParams={extraParams}
                  id={id}
                  fieldKey="upsellCourseDetails"
                >
                  <Input placeholder="Add Upsell Course" />
                </EditableDataField>
              </Col>
            </Row>
          </Col>
          <Col span={24}>
            {courses &&
              courses.map((course, i) => (
                <Row className={styles.courseRow} key={i.toString()}>
                  <Col span={10}>
                    {exists(course.demo_course) &&
                      exists(course.demo_course.course_code) && (
                        <CourseCard
                          title={course.demo_course.heading}
                          courseCode={course.demo_course.course_code}
                          type={course.demo_type}
                          currency={
                            course.demo_course.earning &&
                            course.demo_course.earning.currency
                          }
                          earning={
                            course.demo_course.earning &&
                            course.demo_course.earning.amount
                          }
                          waLink={course.demo_course.wa_group_invite_code}
                          external_campaign_ids={(
                            course.demo_course.external_campaign_ids || []
                          ).join(',')}
                          registrations={course.demo_course.registration_count}
                          extraParams={{
                            tmpc_code: exists(course.tmpc_code)
                              ? course.tmpc_code
                              : '',
                            demoCourseCode: exists(course.demo_course)
                              ? course.demo_course.course_code
                              : '',
                            upsellCourseCode: exists(course.upsell_course)
                              ? course.upsell_course.course_code
                              : '',
                          }}
                          link={course.demo_course.course_update_url}
                          meetingLink={course.demo_course.external_lesson_url}
                          MeetingPassword={
                            course.demo_course.external_lesson_password
                          }
                          startTs={course?.demo_course?.start_ts || ''}
                          startTime={course?.demo_course?.weekly_schedule ? course.demo_course.weekly_schedule[0] : ''}
                          endTs={course?.demo_course?.end_ts || ''}
                        />
                      )}
                  </Col>
                  <Col span={4}></Col>
                  <Col span={10}>
                    {((exists(course.upsell_course) &&
                      exists(course.upsell_course.course_code)) ||
                      (exists(course.demo_course) &&
                        exists(course.demo_course.course_code))) && (
                      <CourseCard
                        title={course.upsell_course.heading || ''}
                        courseCode={course.upsell_course.course_code || ''}
                        courseType="upsell"
                        currency={
                          course.upsell_course.earning &&
                          course.upsell_course.earning.currency
                        }
                        earning={
                          course.upsell_course.earning &&
                          course.upsell_course.earning.amount
                        }
                        waLink={course.upsell_course.wa_group_invite_code}
                        external_campaign_ids={(
                          course.upsell_course.external_campaign_ids || []
                        ).join(',')}
                        registrations={course.upsell_course.registration_count}
                        extraParams={{
                          tmpc_code: exists(course.tmpc_code)
                            ? course.tmpc_code
                            : '',
                          demoCourseCode: exists(course.demo_course)
                            ? course.demo_course.course_code
                            : '',
                          upsellCourseCode: exists(course.upsell_course)
                            ? course.upsell_course.course_code
                            : '',
                        }}
                        link={course.upsell_course.course_update_url}
                        meetingLink={course.upsell_course.external_lesson_url}
                        MeetingPassword={
                          course.upsell_course.external_lesson_password
                        }
                        startTs={course?.upsell_course?.start_ts || ''}
                        startTime={course?.upsell_course?.weekly_schedule ? course.upsell_course.weekly_schedule[0] : ''}
                        endTs={course?.upsell_course?.end_ts || ''}
                      />
                    )}
                  </Col>
                </Row>
              ))}
          </Col>
        </Row>
      </div>
      <div className={styles.footerButtons}>
        {/* <Button type={"dashed"}>Add Course</Button> */}
      </div>
    </Card>
  )
}

export default DataCard
