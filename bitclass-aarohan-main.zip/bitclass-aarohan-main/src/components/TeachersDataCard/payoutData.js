export const payoutColumns = [
  {
    title: 'Course Name',
    dataIndex: 'course_heading',
    key: 'course_heading',
  },
  {
    title: 'Registrations',
    dataIndex: 'registrations',
    key: 'registrations',
  },
  {
    title: 'Currency',
    dataIndex: 'currency',
    key: 'currency',
  },
  {
    title: 'Highest Price',
    dataIndex: 'max_fee',
    key: 'total_discount',
  },
  {
    title: 'Lowest Price',
    dataIndex: 'min_fee',
    key: 'min_fee',
  },
  {
    title: 'Coupon Used',
    dataIndex: 'couponed_orders',
    key: 'couponed_orders',
  },
  {
    title: 'Potential Earning',
    dataIndex: 'potential_earnings',
    key: 'potential_earnings',
  },
  {
    title: 'Total Earning',
    dataIndex: 'total_earnings',
    key: 'total_earnings',
  },
  {
    title: 'Discount',
    dataIndex: 'total_discount',
    key: 'total_discount',
  },
  {
    title: 'Refunds',
    dataIndex: 'total_refunds',
    key: 'total_refunds',
  },
]
