import {
  UserPlus,
  FileText,
  UserCheck,
  Tag,
  MessageCircle,
  Calendar,
  Settings,
  Tool,
  Package,
  Layers,
  PhoneOutgoing,
  PenTool,
  FileMinus,
  Video,
} from "react-feather"
import {
  BoldOutlined,
  GlobalOutlined,
  DollarCircleOutlined,
  ContainerOutlined,
  UserOutlined,
  CheckCircleOutlined,
  TeamOutlined,
  AppstoreOutlined,
  UserDeleteOutlined,
  DatabaseOutlined,
  SoundOutlined,
  WhatsAppOutlined,CopyrightOutlined
} from "@ant-design/icons";

export const MENU = [
  {
    subMenu: {
      key: "supply",
      menuLabel: "Supply",
      icon: <TeamOutlined />,
    },
    menu: [
      {
        key: "LaunchPad",
        menuLabel: "LaunchPad",
        url: "/launchpad",
        icon: <Package style={{ width: "15px" }} />,
      },
      {
        key: "approve_teacher",
        menuLabel: "Approve Teacher",
        url: "/approve-teacher",
        icon: <UserCheck style={{ width: "15px" }} />,
      },
      {
        key: "Teacher Compliance",
        menuLabel: "Teacher Compliance",
        url: "/teacher-compliance",
        icon: <PenTool style={{ width: "15px" }} />,
      },
      {
        key: "teacher_poc",
        menuLabel: "Teacher POC",
        url: "/teacher-poc",
        icon: <FileMinus style={{ width: "15px" }} />,
      },
    ],
  },

  {
    subMenu: {
      key: "content",
      menuLabel: "Content-Ops",
      icon: <ContainerOutlined />,
    },
    menu: [
      {
        key: "t2",
        menuLabel: "Teacher Onboarding",
        url: "/dashboard/table",
        forceReload: true,
        icon: <UserOutlined />,
      },
      {
        key: "t1",
        menuLabel: "Teacher Update",
        url: "/dashboard/edit",
        forceReload: true,
        icon: <UserPlus style={{ width: "15px" }} />,
      },
      {
        key: "redFlag",
        menuLabel: "Teacher RedFlag",
        url: "/red-flag-teacher",
        icon: <UserDeleteOutlined style={{ width: "15px" }} />,
      },
      {
        key: "manage_category",
        menuLabel: "Course Category",
        url: "/category",
        icon: <AppstoreOutlined />,
      },
      {
        key: "curriculum",
        menuLabel: "Curriculum Creation",
        url: "/curriculum",
        icon: <DatabaseOutlined />,
      },
      {
        key: "recordings",
        menuLabel: "Recordings",
        url: "/recordings",
        icon: <Video size="15px" />,
      },{
        key: "collection",
        menuLabel: "Collection & Category",
        url: "/collection",
        icon: <CopyrightOutlined />,
      },
    ],
  },

  {
    subMenu: {
      key: "businessOps",
      menuLabel: "Business Operations",
      icon: <BoldOutlined />,
    },
    menu: [
      {
        key: "tech_support",
        menuLabel: "Shifting,Cancellations & Recordings",
        url: "/tech-support",
        icon: <Settings style={{ width: "15px" }} />,
      },
    ],
  },

  {
    subMenu: {
      key: "sales",
      menuLabel: "Sales",
      icon: <DollarCircleOutlined />,
    },
    menu: [
      {
        key: "coupon",
        menuLabel: "Coupon",
        url: "/coupon-dashboard",
        icon: <Tag style={{ width: "15px" }} />,
      },
      {
        key: "roster",
        menuLabel: "Roster",
        url: "/roster",
        icon: <Tool style={{ width: "15px" }} />,
      },
      {
        key: "calendar",
        menuLabel: "Calendar",
        url: "/calendar",
        icon: <Calendar style={{ width: "15px" }} />,
      },
      {
        key: "ist",
        menuLabel: "IST",
        url: "/ist",
        icon: <PhoneOutgoing style={{ width: "15px" }} />,
      },
    ],
  },

  {
    key: "payouts_new",
    menuLabel: "Payouts",
    url: "/payouts-new",
    icon: <CheckCircleOutlined />,
  },

  {
    subMenu: {
      key: "customerSupport",
      menuLabel: "Customer Support & Experience ",
      icon: <GlobalOutlined />,
    },
    menu: [
      {
        key: "student_directory",
        menuLabel: "Student Directory",
        url: "/student-directory",
        icon: <Layers style={{ width: "15px" }} />,
      },
      {
        key: "adHoc",
        menuLabel: "Recordings & certificate",
        url: "/ad-hoc",
        icon: <FileText />,
      },
      {
        key: "chat_page",
        menuLabel: "Group Chats",
        url: "/chat",
        icon: <MessageCircle style={{ width: "15px" }} />,
      },
    ],
  },
  {
    subMenu: {
      key: "marketing",
      menuLabel: "Marketing",
      icon: <SoundOutlined />,
    },
    menu: [
      {
        key: "whatsapp",
        menuLabel: "Whatsapp Dashboard",
        url: "/whatsapp",
        icon: <WhatsAppOutlined />,
      },
    ],
  },
]
