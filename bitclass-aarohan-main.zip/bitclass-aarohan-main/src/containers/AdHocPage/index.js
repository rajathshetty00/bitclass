import {
  Button,
  Card,
  Divider,
  Form,
  Input,
  message,
  Modal,
} from 'antd'
import React, { useState } from 'react'

import styles from './style.module.scss'
import {downloadCSV, exists} from '../../utils/index'
import {
  getStudentRegistrations,
  addClassRecordings,
  sendCertificate,
  addTeacherSignature,
} from '../../utils/api'

const AdHocPage = () => {

  const [studentRegReportForm] = Form.useForm()
  const [addRecordingForm] = Form.useForm()
  const [sendCertificateForm] = Form.useForm()

  const [showSignatureUpload, setShowSignatureUpload] = useState(false)
  const [signatureCourseCode, setSignatureCourseCode] = useState('')

  const studentRegistrationSubmit = (data) => {
    if (!exists(data.courseCode)) {
      message.error("Please add course code")
      return
    }

    const loading = message.loading("Fetching data...", 0)
    getStudentRegistrations(data.courseCode)
      .then(res => {
        loading()
        if (exists(res.error)) {
          message.error(res.error)
        } else {
          downloadCSV(`${data.courseCode} - student registration report.csv`, res.data)
          studentRegReportForm.resetFields()
        }
      })
  }

  const recordingCourseCodeSubmit = (data) => {
    const {courseCode, videoUrl} = data
    if (!exists(courseCode && videoUrl)) {
      message.error("Please fill required field")
      return
    }


    const loading = message.loading("Fetching data...")
    addClassRecordings(courseCode, videoUrl)
      .then((res => {
        loading()
        if (exists(res.success)) {
          message.success("updated")
          addRecordingForm.resetFields()
        } else {
          message.error("error")
        }
      })
    )
  }

  const sendCertificates = async({courseCode}) => {
    if(!exists(courseCode)) {
      message.error("Please enter course code")
      return
    }
    const loading = message.loading("Sending certificates...")
    try {
      const res = await sendCertificate(courseCode)
      loading()
      if (res.success) {
        message.success("Certificates are sent to participants")
        sendCertificateForm.resetFields()
      } 
      else message.error("Failed to send certificates")
      if(!res.success && res.data.total_registrations === -1) {
        setShowSignatureUpload(true)
        setSignatureCourseCode(courseCode)
      }
    } catch (error) {
      message.error("Failed to send certificates")
    }
    
  }

  const addSignature = async() => {
    var formData = new FormData(document.getElementById('teacherSignatureForm'))
    if(!exists(signatureCourseCode)) {
      return
    }

    let loading = message.loading("updating signature...")
    let res = await addTeacherSignature(signatureCourseCode, formData)
    loading()
    setSignatureCourseCode('')
    if(res.success) {
      message.success("Signature uploaded")
      setShowSignatureUpload(false)
    } else {
      message.error("Failed to update signature")
      setShowSignatureUpload(false)
    }
  }

  return (
    <div className={styles.adHocContainer}>
      <div className={styles.itemRow}>
        <div className={styles.eachItems}>
          <Divider orientation="left">Student Registrations Report</Divider>
          <Card>
            <Form
              onFinish={studentRegistrationSubmit}
              className={styles.form}
              form={studentRegReportForm}
            >
              <Form.Item
                name="courseCode"
                rules={[
                  {
                    required: true,
                    message: "Course code is mandatory"
                  }
                ]}
                style={{marginRight: '8px'}}
              >
                <Input placeholder="Course Code" />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit">Download</Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      </div>
      <div className={styles.itemRow}>
        <div className={styles.eachItems}>
          <Divider orientation="left">Class Recordings</Divider>
          <Card>
            <Form
              onFinish={recordingCourseCodeSubmit}
              className={styles.form}
              form={addRecordingForm}
            >
              <Form.Item
                name="courseCode"
                rules={[
                  {
                    required: true,
                    message: "Course code is mandatory"
                  }
                ]}
                style={{marginRight: '8px'}}
              >
                <Input placeholder="Course Code" />
              </Form.Item>
              <Form.Item
                name="videoUrl"
                rules={[
                  {
                    required: true,
                    message: "Video url is mandatory"
                  }
                ]}
                style={{marginRight: '8px'}}
              >
                <Input placeholder="Video Url" />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit">Update</Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      </div>
      {/* certification */}
      <div className={styles.itemRow}>
        <div className={styles.eachItems}>
          <Divider orientation="left">Send Certificate</Divider>
          <Card>
            <Form
              onFinish={sendCertificates}
              className={styles.form}
              form={sendCertificateForm}
            >
              <Form.Item
                name="courseCode"
                rules={[
                  {
                    required: true,
                    message: "Course code is mandatory"
                  }
                ]}
                style={{marginRight: '8px'}}
              >
                <Input placeholder="Course Code" />
              </Form.Item>
              <Form.Item>
                <Button type="primary" htmlType="submit">Submit</Button>
              </Form.Item>
            </Form>
          </Card>
        </div>
      </div>

      {/* upload signature modal */}
      <Modal
          visible={showSignatureUpload}
          centered
          title="Add teacher signature"
          footer={null}
          onCancel={() => {
            document.getElementById("teacherSignatureForm").reset();
            setSignatureCourseCode('')
            setShowSignatureUpload(false)
          }}
        >
          <form enctype="multipart/form-data" id="teacherSignatureForm" onSubmit={(e) => {
            e.preventDefault()
            addSignature()
          }}>
            <input type="file" name="file"/>
            <br />
            <br />
            <Button type={'primary'} htmlType={'submit'}>
              Add
            </Button>
          </form>
        </Modal>
      {/* upload signature modal ends */}
    </div>
  )
}

export default AdHocPage