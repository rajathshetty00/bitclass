export const TableModel = [
  {
    title: 'Name',
    align: 'center',
    dataIndex: 'name',
    width: 200,
    fixed: 'left',
    sorter: true,
  },
  {
    title: 'Email',
    align: 'center',
    dataIndex: 'email',
    width: 200,
  },
  {
    title: 'Mobile',
    align: 'center',
    dataIndex: 'mobile',
    width: 200,
  },
  {
    title: 'Gender',
    align: 'center',
    dataIndex: 'gender',
    width: 200,
  },
  {
    title: 'Experience',
    align: 'center',
    dataIndex: 'experience',
    width: 200,
    sorter: true,
  },
  {
    title: 'What to Teach',
    align: 'center',
    dataIndex: 'subject',
    width: 200,
  },
  {
    title: 'Assigned To',
    align: 'center',
    dataIndex: 'assignedTo',
    width: 200,
    editable: true,
    fieldType: 'select'
  },
  {
    title: 'Created On',
    align: 'center',
    dataIndex: 'createdOn',
    width: 200,
    sorter: true,
  },
  {
    title: 'Updated On',
    align: 'center',
    dataIndex: 'updatedOn',
    width: 200,
  },
  {
    title: 'Status',
    align: 'center',
    dataIndex: 'status',
    width: 200,
  },
]