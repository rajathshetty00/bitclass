/*global chrome*/
import React, { useState, useEffect, useRef, useCallback } from 'react'
import clsx from 'clsx'
import {
  Card,
  Input,
  Button,
  Select,
  DatePicker,
  Row,
  Col,
  Divider,
  message,
  Modal,
} from 'antd'
import { useSelector, useDispatch } from 'react-redux'
import { LoadingOutlined } from '@ant-design/icons'
import ReactPlayer from 'react-player'
import dayjs from 'dayjs'
import { debounce } from 'lodash-es'
import moment from 'moment'
import { CSVLink } from "react-csv"

import styles from './style.module.scss'
import { TableModel } from './TableModel'
import EditableTable from '../../components/EditableTable'
import { exists } from '../../utils/index'
import { fetchTeacherSubmissionData } from '../../actions/teacher'
import { init } from '../../actions/dashboard'
import { getTeacherFormSubmissions, updateTeacherRequestStatus } from '../../utils/api'
import { READABLE_DATE_FORMAT } from '../../constants'
import { DownloadOutlined } from '@ant-design/icons'

const { Option } = Select
const { RangePicker } = DatePicker
const { TextArea } = Input

const ApproveTeacherPage = ({ ...props }) => {
  const [tableData, setTableData] = useState([])
  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [dateRange, setDateRange] = useState([
    moment().subtract(10, 'days'),
    moment(),
  ])
  const [startDate, setStartDate] = useState(
    moment().subtract(10, 'days').unix()
  )
  const [endDate, setEndDate] = useState(moment().unix())
  const [teacherName, setTeacherName] = useState('')
  const [teacherPhone, setTeacherPhone] = useState('')
  const [statusCode, setStatusCode] = useState()
  const [refreshData, setRefreshData] = useState(0)
  const [assignedTo, setAssignedTo] = useState()
  const [sortBy, setSortBy] = useState('created_at')
  const [sortedAscending, setSortedAscending] = useState('false')
  const [csvData, setCsvData] = useState([])
  const [csvButtonLoading, setCsvButtonLoading] = useState(false)
  const dispatch = useDispatch()
  const csvRef = useRef()
  const {
    data,
    loading,
    totalRecords,
    internalUsers,
    onboardingStages,
  } = useSelector((state) => ({
    data: state.teacher.data,
    totalRecords: state.teacher.totalRecords,
    loading: state.teacher.loading,
    internalUsers: state.dashboard.internalUsers,
    onboardingStages: state.dashboard.onboardingStages,
  }))

  useEffect(() => {
    ;(async () => {
      await dispatch(init())
    })()
  }, [])

  useEffect(() => {
    if (exists(data)) {
      const _tableData = data.map((v, i) => {
        return {
          id: v.code,
          code: v.code,
          name: v.username,
          mobile: v.phone,
          experience: v.teaching_experience,
          gender: v.gender,
          subject: v.teaching_interest,
          assignedTo: v.owner_name,
          email: v.email,
          status: v.status_code,
          key: i,
          notes: v.notes,
          formData: v.form_submission,
          createdOn: v.created_at
            ? moment.unix(v.created_at).format(READABLE_DATE_FORMAT)
            : '',
          updatedOn: v.updated_at
            ? moment.unix(v.updated_at).format(READABLE_DATE_FORMAT)
            : '',
        }
      })
      setTableData(_tableData)
    }
  }, [data])

  useEffect(() => {
    dispatch(
      fetchTeacherSubmissionData({
        page,
        limit,
        teacherName,
        teacherPhone,
        startDate,
        endDate,
        statusCode,
        ownerCode: assignedTo,
        sortBy,
        ascending: sortedAscending,
      })
    )
  }, [page, limit, refreshData])

  const getDownloadVideoUrl = (url) => {
    const splittedUrl = url.split('/')
    const length = splittedUrl.length - 1

    // Modify video format to mp4
    let videoFormat = splittedUrl[length]
    videoFormat = videoFormat.split('.')
    videoFormat.splice(1, 1, 'mp4')
    videoFormat = videoFormat.join('.')
    splittedUrl.splice(length, 1, videoFormat)

    // change to https if http
    if (splittedUrl[0] === 'http:') splittedUrl.splice(0, 1, 'https:')
    const index = splittedUrl.indexOf('upload')
    
    // make url downloadable
    splittedUrl.splice(index + 1, 0, 'fl_attachment')
    const downloadUrl = splittedUrl.join('/')
    window.open(downloadUrl, '_blank')
  }
  const ExpandCard = ({ rec, setRefreshData, refreshData }) => {
    const { formData, status, notes, code } = rec
    const { teacher_profile, course_request, intro_video } = formData
    const [note, setNote] = useState(notes)

    const approveOrReject = async (status) => {
      let loadingToast = message.loading('Saving data...')
      let _res = await updateTeacherRequestStatus({
        code,
        data: {
          status_code: status,
          notes: note,
        },
      })
      if (_res['success']) {
        setRefreshData(refreshData + 1)
        loadingToast()
        message.success('Successfully updated.')
      } else {
        loadingToast()
        message.error('Failed to Approve / Reject')
      }
    }

    const LineItem = ({ label, data }) => (
      <div className={styles.LineItemContainer}>
        <div className={styles.LICLabel} span={12}>
          {label}
        </div>
        <div className={styles.LICAnswer} span={12}>
          {data}
        </div>
      </div>
    )

    return (
      <div className={styles.expandContainer}>
        {teacher_profile && (
          <>
            <Divider orientation="left">Teacher Profile</Divider>
            <Row className={styles.row}>
              <Col span={12}>
                <LineItem
                  label="Qualifications / Achievements"
                  data={teacher_profile.qualification}
                />
              </Col>
              <Col span={12}>
                <LineItem
                  label="Preferred Batch Size"
                  data={teacher_profile.average_batch_size}
                />
              </Col>
            </Row>

            <Row className={styles.row}>
              <Col span={12}>
                <LineItem
                  label="Preferred Language"
                  data={
                    Array.isArray(
                      teacher_profile.preferred_language_of_teaching
                    )
                      ? teacher_profile.preferred_language_of_teaching.join(
                          ', '
                        )
                      : teacher_profile.preferred_language_of_teaching
                  }
                />
              </Col>
              <Col span={12}>
                <LineItem
                  label="Active Social Profile"
                  data={teacher_profile.active_social_profile_url}
                />
              </Col>
            </Row>
          </>
        )}
        {course_request && (
          <>
            <Divider orientation="left">Course Request</Divider>

            <Row className={styles.row}>
              <Col span={12}>
                <LineItem
                  label="Course Description"
                  data={course_request.course_desc}
                />
              </Col>
              <Col span={12}>
                <LineItem
                  label="Targeting Audience"
                  data={
                    Array.isArray(course_request.preferred_audience)
                      ? course_request.preferred_audience.join(', ')
                      : course_request.preferred_audience
                  }
                />
              </Col>
            </Row>

            <Row className={styles.row}>
              <Col span={12}>
                <LineItem
                  label="Course Duration"
                  data={course_request.duration}
                />
              </Col>
              <Col span={12}>
                <LineItem
                  label="Past class links"
                  data={course_request.past_course_link}
                />
              </Col>
            </Row>
          </>
        )}
        {intro_video && (
          <>
            <Divider orientation="left">Intro Video</Divider>
            <Row className={styles.row}>
              <Col span={24}>
                <ReactPlayer
                  url={intro_video}
                  light={true}
                  width={320}
                  height={180}
                  controls={true}
                  className={styles.videoContainer}
                />
                <Button
                  className={styles.videoDownloadButton}
                  type="primary"
                  onClick={() => getDownloadVideoUrl(intro_video)}
                  icon={<DownloadOutlined />}
                  size="large"
                >
                  Download
                </Button>
              </Col>
            </Row>
          </>
        )}
        <Divider orientation="left">Notes</Divider>
        <Row className={styles.row}>
          <Col span={24} className={styles.notesContainer}>
            <TextArea
              value={note}
              rows={4}
              placeholder="notes"
              onChange={(e) => setNote(e.currentTarget.value)}
              disabled={!(status === 'submitted' || status === 'started')}
            />
          </Col>
        </Row>

        {(status === 'submitted' || status === 'started') && (
          <Row className={clsx(styles.row, styles.buttonRow)}>
            <Button
              type={'primary'}
              onClick={() => {
                Modal.confirm({
                  title: 'Are sure want to approve this?',
                  content:
                    'Please ensure you have verified the details. Click "Approve" to approve.',
                  okText: 'Approve',
                  cancelText: 'Cancel',
                  onOk: () => approveOrReject('approved'),
                })
              }}
            >
              Approve
            </Button>
            <Button onClick={() => approveOrReject('rejected')}>Reject</Button>
          </Row>
        )}
      </div>
    )
  }
  const delayedRefreshData = useCallback(debounce((value) =>setRefreshData(value + 1),500),[])
  const searchHandler = (type, val, extraVal = null) => {
    if (!type) return

    if (type === 'date_range') {
      setDateRange(extraVal)
      setStartDate(val[0] ? dayjs(val[0]).unix() : '')
      setEndDate(val[1] ? dayjs(val[1]).unix() : '')
    }
    if (type === 'teacher_name') {
      setTeacherName(val)
    }
    if (type === 'teacher_phone') {
      setTeacherPhone(val)
    }
    if (type === 'status_code') {
      setStatusCode(val)
    }
    if (type === 'owner_code') {
      setAssignedTo(val)
    }
    setPage(1)
    delayedRefreshData(refreshData)
  }

  const clearAll = () => {
    setDateRange('')
    setStartDate('')
    setEndDate('')
    setTeacherName('')
    setTeacherPhone('')
    setStatusCode()
    setAssignedTo()
    setPage(1)
    setRefreshData(refreshData + 1)
  }

  const tableChangeHandler = (pagination, filters, sorter) => {
    if (sorter && !pagination) {
      let sortField = sorter.field
      let sortAsc = sorter.order === 'ascend'
      switch (sortField) {
        case 'name':
          sortField = 'username'
          break
        case 'experience':
          sortField = 'teaching_experience'
          break
        case 'createdOn':
          sortField = 'created_at'
          break
        default:
          sortField = null
      }
      if (sortField) {
        setSortBy(sortField)
        setSortedAscending(sortAsc)
        setPage(1)
        setRefreshData(refreshData + 1)
      }
    }
  }

  const saveAssignUser = async (data) => {
    if (data.assignedTo && data.id) {
      let loadingToast = message.loading('Saving data...')
      let _res = await updateTeacherRequestStatus({
        code: data.id,
        data: {
          aarohan_user_code: data.assignedTo,
        },
      })
      if (_res['success']) {
        setRefreshData(refreshData + 1)
        loadingToast()
        message.success('Successfully updated.')
      } else {
        loadingToast()
        message.error('Failed to assign user')
      }
    }
  }

  const downloadCsv = async() => {
    try {
      setCsvButtonLoading(true)
      let data = await getTeacherFormSubmissions({
        page,
        limit: totalRecords,
        teacherName,
        teacherPhone,
        startDate,
        endDate,
        statusCode,
        ownerCode: assignedTo,
        sortBy,
        ascending: sortedAscending,
      })
      data = data.data
      let _csvData = [
        [
          "Name",
          "Email",
          "Mobile",
          "Gender",
          "Experience",
          "What to Teach",
          "Assigned To",
          "Created On",
          "Updated On",
          "Status",
        ]
      ]
      data.map((v) => {
        _csvData.push([
          v.username,
          v.email,
          v.phone,
          v.gender,
          v.teaching_experience,
          v.teaching_interest,
          v.owner_name,
          v.created_at
            ? moment.unix(v.created_at).format(READABLE_DATE_FORMAT)
            : '',
          v.updated_at
            ? moment.unix(v.updated_at).format(READABLE_DATE_FORMAT)
            : '',
          v.status_code,
        ])
      })
      await setCsvData(_csvData)
      setTimeout(() => {
        document.getElementById("downloadCsvAnchorTag").click()
        setCsvButtonLoading(false)
      }, 500)
      return true
    } catch(e) {
      setCsvButtonLoading(false)
      return false
    }
  }

  TableModel.forEach((v) => {
    if (v.dataIndex === 'assignedTo') {
      v.selectOptions = internalUsers.map((iv) => {
        return {
          label: iv.username,
          value: iv.code,
        }
      })
      v.handleSave = saveAssignUser
    }
    return v
  })

  const sortByAlphabeticalOrder = (a, b) => a.username.toLowerCase().localeCompare(b.username.toLowerCase())

  return (
    <div className={styles.approveContainer}>
      {/* Filter Section */}
      <Card
        className={clsx(styles.filters, 'roundedCard')}
        bodyStyle={{
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'row',
          flexWrap: 'wrap',
        }}
      >
        <RangePicker
          className={styles.inputs}
          value={dateRange}
          onChange={(d, v) => searchHandler('date_range', v, d)}
        />
        <Input
          placeholder="Search by teacher name"
          className={styles.inputs}
          value={teacherName}
          onChange={(e) => {
            searchHandler('teacher_name', e.currentTarget.value)
          }}
        />
        <Input
          placeholder="Search by teacher phone"
          className={styles.inputs}
          style={{ width: 200 }}
          value={teacherPhone}
          onChange={(e) => {
            searchHandler('teacher_phone', e.currentTarget.value)
          }}
        />
        <Select
          showSearch
          optionFilterProp="children"
          filterOption={(input, option) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
          filterSort={(optionA, optionB) =>{
            return optionA.children.toLowerCase().localeCompare(optionB.children.toLowerCase())
          }
          }
          className={styles.inputs}
          placeholder="Assigned To"
          value={assignedTo}
          style={{ width: 250 }}
          onChange={(v) => {
            searchHandler('owner_code', v)
          }}
        >
          {internalUsers.sort((a,b)=>sortByAlphabeticalOrder(a,b)).map((v, i) => (
            <Option value={v.code} key={i.toString()}>
              {v.username}
            </Option>
          ))}
        </Select>

        <Select
          className={styles.inputs}
          placeholder="Status"
          value={statusCode}
          style={{ width: 150 }}
          onChange={(status_code) => {
            searchHandler('status_code', status_code)
          }}
        >
          {onboardingStages.map((v, i) => (
            <Option value={v} key={i.toString()}>
              {v}
            </Option>
          ))}
        </Select>
        <Button onClick={() => clearAll()}>clear all</Button>
        {
          tableData.length > 0 && (
            <div className={styles.exportBtnContainer}>
              <Button
                type={"primary"}
                className={styles.csvDownload}
                onClick={downloadCsv}
                loading={csvButtonLoading}
              >
                Export CSV
              </Button>
              <CSVLink
                ref={csvRef}
                id="downloadCsvAnchorTag"
                className={styles.csvDownloadAtag}
                data={csvData}
                filename={`Teacher Approval Report.csv`}
              >
                Export CSV
              </CSVLink>
            </div>
          )
        }
      </Card>
      {/* Filter Section End */}

      {/* Table Section */}
      <EditableTable
        columns={TableModel}
        dataSource={tableData}
        bordered
        size="small"
        expandable={{
          expandedRowRender: (rec) => (
            <ExpandCard
              rec={rec}
              setRefreshData={setRefreshData}
              refreshData={refreshData}
            />
          ),
        }}
        pagination={{
          total: totalRecords,
          onChange: (d) => {
            setPage(d)
          },
          onShowSizeChange: (d, l) => {
            setLimit(l)
          },
          current: page,
        }}
        loading={{
          spinning: loading,
          indicator: <LoadingOutlined type="loading" />,
        }}
        onChange={tableChangeHandler}
        scroll={{ x: 1300 }}
      />
      {/* Table Section End */}
    </div>
  )
}

export default ApproveTeacherPage
