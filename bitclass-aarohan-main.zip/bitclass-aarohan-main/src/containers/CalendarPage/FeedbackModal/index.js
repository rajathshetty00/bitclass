import { Modal, Form, Radio, Input, Select, Button, message } from "antd"
import FormItem from "antd/lib/form/FormItem"
import { useEffect, useState } from "react"
import { PhoneOutgoing } from "react-feather"
import { postFeedbackSubmission } from "../../../utils/api"
import styles from "./styles.module.scss"

const { TextArea } = Input
const { Option } = Select

const FeedbackModal = ({ visible, setVisible, feedbackCourseCode, setFeedbackSaved }) => {
  const [loading, setLoading] = useState(false)
  const [formJson, setFormJson] = useState({})

  useEffect(() => {
    ;(async () => {
      if (formJson) {
      }
    })()
  }, [formJson])


  const onChangeHandler = (e, type) => {
    switch (type) {
      case "RadioOne":
        setFormJson({
          ...formJson,
          "How was the participation of the students in the class ? (chat, discussion with teacher, camera/mic on)":
            e.target.value,
        })
        break
      case "RadioTwo":
        setFormJson({
          ...formJson,
          "Was the teacher addressing student doubts and queries ?":
            e.target.value,
        })
        break
      case "TextOne":
        setFormJson({
          ...formJson,
          "Pricing of the Full Course": e.target.value,
        })
        break
      case "TextTwo":
        setFormJson({
          ...formJson,
          "Schedule of the full course": e.target.value,
        })
        break
      case "TextThree":
        setFormJson({
          ...formJson,
          "Additional Comments": e.target.value,
        })
        break
      default:
        break
    }
  }

  const onSelectHandler = (value) => {
    setFormJson({
      ...formJson,
      "Audience type": value,
    })
  }

  const onFinish = async () => {
    const payload = {
      course_code: feedbackCourseCode,
      feedback: formJson,
    }
    try {
      setLoading(true)
      const { data } = await postFeedbackSubmission(payload)
      if (data) {
        setVisible(false)
        message.success("Success")
        setFormJson("")
        setFeedbackSaved(true)
      }
    } catch (e) {
      message.error("Please try again")
    } finally {
      setLoading(false)
    }
  }

  const onFinishFailed = (errorInfo) => {
    console.log("Failed:", errorInfo)
  }

  return (
    <Modal
      className={styles.feedbackModal}
      visible={visible}
      onCancel={() => setVisible(false)}
      footer={null}
    >
      <Form name="basic" onFinish={onFinish} onFinishFailed={onFinishFailed}>
        <ul className={styles.questionContainer}>
          <li>
            How was the participation of the students in the class ? (chat,
            discussion with teacher, camera/mic on)
            <Form.Item
              name="How was the participation of the students in the class ? (chat,
                discussion with teacher, camera/mic on)"
              rules={[
                {
                  required: true,
                  message: "Please Select one of the following",
                },
              ]}
            >
              <Radio.Group onChange={(e) => onChangeHandler(e, "RadioOne")}>
                <Radio value={"low"}>Low</Radio>
                <Radio value={"medium"}>Medium</Radio>
                <Radio value={"high"}>High</Radio>
              </Radio.Group>
            </Form.Item>
          </li>

          <li>
            Was the teacher addressing student doubts and queries ?
            <Form.Item
              name="Was the teacher addressing student doubts and queries ?"
              rules={[
                {
                  required: true,
                  message: "Please Select one of the following",
                },
              ]}
            >
              <Radio.Group onChange={(e) => onChangeHandler(e, "RadioTwo")}>
                <Radio value={"Yes"}>Yes</Radio>
                <Radio value={"No"}>No</Radio>
              </Radio.Group>
            </Form.Item>
          </li>

          <h3>Comments on the following</h3>

          <li>
            Pricing of the Full Course
            <Form.Item
              name="Pricing of the Full Course"
              rules={[{ required: true, message: "Please add something" }]}
            >
              <TextArea
                onChange={(e) => onChangeHandler(e, "TextOne")}
                placeholder="reasonable/expensive, suggested price"
              />
            </Form.Item>
          </li>

          <li>
            Schedule of the full course
            <Form.Item
              name="Schedule of the full course"
              rules={[
                {
                  required: true,
                  message: "Please add schedule of full course",
                },
              ]}
            >
              <TextArea
                onChange={(e) => onChangeHandler(e, "TextTwo")}
                placeholder="Were the students comfortable with the timing of the full course?"
              />
            </Form.Item>
          </li>

          <li>
            Audience type
            <Form.Item
              name="Audience type"
              rules={[
                { required: true, message: "Please select at least one" },
              ]}
            >
              <Select onChange={onSelectHandler} placeholder="Select Audience">
                <Option value="working_professionals">
                  Working Professionals
                </Option>
                <Option value="women">Women</Option>
                <Option value="kids">Kids</Option>
                <Option value="college_students">College Students</Option>
              </Select>
            </Form.Item>
          </li>

          <li>
            Additional Comments
            <Form.Item
              name="Additional Comments"
              rules={[{ required: true, message: "Add your suggestions" }]}
            >
              <TextArea placeholder="Suggestions for calling the leads" />
            </Form.Item>
          </li>

          <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
            <Button type="primary" htmlType="submit" disabled={loading}>
              {loading ? "Please Wait" : "Submit"}
            </Button>
          </Form.Item>
        </ul>
      </Form>
    </Modal>
  )
}

export default FeedbackModal
