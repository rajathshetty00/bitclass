import { Mail, Phone } from "react-feather"
import { exists } from "../../../utils"
import styles from "./styles.module.scss"
import { Checkbox, Input, message, Button } from "antd"
import { postHotLeads, postRemarkForCf } from "../../../utils/api"
import { useState } from "react"

const Itemlist = ({ list, studentList, setHotLeadUpdate, hotLeadUpdate }) => {
  const { ended, title, code } = studentList
  const [value, setValue] = useState("")

  const onCheckboxHandler = async (e, studentId) => {
    const clicked = e.target.checked ? "select" : "unselect"
    try {
      const { data } = await postHotLeads(clicked, code, studentId)
      if (data) {
        message.success("Success")
        setHotLeadUpdate(!hotLeadUpdate)
      }
    } catch (e) {
    } finally {
    }
  }



  const remarkChangeHandler = (e) => {
    setValue(e.target.value)
  }

  const remarkSubmitHandler = async (studentId) => {
    if (value) {
      try {
        const { data } = await postRemarkForCf({
          course_code: code,
          student_id: studentId,
          remark: value
        })
        if (data) {
          message.success("Success")
        }
      } catch (e) {
      } finally {
      }
    }
  }




  return (
    <div className={styles.listWrapper}>
      {list &&
        list?.map((item) => (
          <div className={styles.listItem}>
            <p>{item?.username}</p>
            <div className={styles.flexContainer}>
              {item?.email && (
                <span>
                  {" "}
                  <Mail /> {item.email}
                </span>
              )}
              {item?.phone && (
                <span>
                  {" "}
                  <Phone />
                  {item.phone}
                </span>
              )}

              {title === "Registrations" && item?.is_registered ? (
                <span className={styles.greenPointer}>
                  Registered
                </span>
              ) : <span className={styles.redPointer}>
                  Not registered
                </span>}

              {ended && !item?.remark && (
                <div>
                  <Input
                    placeholder="remarks"
                    className={styles.remarkInput}
                    onChange={remarkChangeHandler}
                  />
                  <Button
                    type="primary"
                    onClick={() => remarkSubmitHandler(item?.student_id)}
                  >
                    OK
                  </Button>
                </div>
              )}

              {ended && (
                <Checkbox
                  defaultChecked={item?.is_hot_lead}
                  onChange={(e) => onCheckboxHandler(e, item?.student_id)}
                >
                  Hot lead?
                </Checkbox>
              )}
            </div>
          </div>
        ))}
      {list === null && <div className={styles.noData}>No Data</div>}
    </div>
  )
}

export default Itemlist