import clsx from "clsx"
import styles from "./styles.module.scss"
import { Input, Select } from "antd"
import { MessageSquare, Video } from "react-feather"
import {
  Button,
  Card,
  Collapse,
  DatePicker,
  Radio,
  Modal,
  Pagination,
  Spin,
  Tooltip,
} from "antd"
import { checkCourseEnded, exists, getDateFormat } from "../../utils"
import { useEffect, useState } from "react"
import moment from "moment"
import dayjs from "dayjs"
import {
  getAssignedCourseDetails,
  getAssignedCourses,
  getAttendanceListByDay,
  getCourseRegistrations,
  getHotLeads,
  updateMetaOfCourse,
} from "../../utils/api"
import Loader from "../../atoms/Loader"
import Itemlist from "./Itemlist"
import { LoadingOutlined } from "@ant-design/icons"
import { API_URL, WEB_URL } from "../../constants"
import Form from "antd/lib/form/Form"
import FormItem from "antd/lib/form/FormItem"
import FeedbackModal from "./FeedbackModal"
import { useCallback } from "react"
import useDebounce from "./useDebounce"

const { Option } = Select
const { Panel } = Collapse
const { TextArea,Search } = Input
const { RangePicker } = DatePicker
const RadioGroup = Radio.Group
const plainOptions = ["Yes", "No"]

const metaTypes = ["notes", "radio"]

const studentTypes = ["registered", "attended", "hotLeads"]

const filterButtons = [
  { text: "Yesterday", type: "yesterday" },
  { text: "Today", type: "today" },
  { text: "Tomorrow", type: "tomorrow" },
  { text: "This Week", type: "this_week" },
]

const CalendarPage = () => {
  const [dateRange, setDateRange] = useState({
    start_ts: moment().startOf("day").unix(),
    end_ts: moment().endOf("day").unix(),
  })
  const [activeBtn, setActiveBtn] = useState(1)
  const [scheduledClass, setScheduledClass] = useState(false)
  const [courseList, setCourseList] = useState(null)
  const [loading, setLoading] = useState(false)
  const [expandedLoading, setExpandedLoading] = useState(false)
  const [courseItem, setCourseItem] = useState(null)
  const [studentList, setStudentList] = useState(null)
  const [modalVisible, setModalVisible] = useState(false)
  const [popupLoading, setPopupLoading] = useState(null)
  const [details, setDetails] = useState(null)
  const [studentListType, setStudentListType] = useState(null)
  const [expandedCard, setExpandedCard] = useState(null)
  const [attendanceDay, setAttendanceDay] = useState(null)
  const [visible, setVisible] = useState(false)
  const [feedbackCourseCode, setFeedbackCourseCode] = useState(null)
  const [feedbackSaved, setFeedbackSaved] = useState(false)
  const [hotLeadUpdate, setHotLeadUpdate] = useState(false)
  const [queryData, setQueryData] = useState('')


  useEffect(() => {
    if (dateRange) {
      ;(async () => {
        setLoading(true)
        try {
          const { data } = await getAssignedCourses(dateRange)
          // checking if end date is greater than today
          if (dateRange?.end_ts >= moment().startOf("day").unix()) {
            setScheduledClass(data?.next_scheduled_class)
          } else {
            setScheduledClass(false)
          }
          setCourseList(data?.courses)
        } catch (e) {
          console.log("error while calling")
        } finally {
          setLoading(false)
        }
      })()
    }
  }, [dateRange, feedbackSaved])

  useEffect(() => {
    if (courseItem) {
      setDetails(null)
      ;(async () => {
        setExpandedLoading(true)
        try {
          const { data } = await getAssignedCourseDetails(
            courseItem?.course?.code,
            courseItem?.course?.day
          )
          setDetails({ ...data, courseItem })
        } catch (e) {
          return
        } finally {
          setExpandedLoading(false)
        }
      })()
    }
  }, [courseItem, hotLeadUpdate])

  const searchHandler = (
    index,
    type,
    dateRangeInMoment = null,
    dateRangeInFormat
  ) => {
    setActiveBtn(index)
    setExpandedCard(null)

    const dates = {
      start_ts: null,
      end_ts: null,
    }

    switch (type) {
      case "yesterday":
        dates.start_ts = moment().subtract(1, "days").startOf("day").unix()
        dates.end_ts = moment().subtract(1, "days").endOf("day").unix()
        return setDateRange(dates)

      case "today":
        dates.start_ts = moment().startOf("day").unix()
        dates.end_ts = moment().endOf("day").unix()
        return setDateRange(dates)

      case "tomorrow":
        dates.start_ts = moment().add(1, "days").startOf("day").unix()
        dates.end_ts = moment().add(1, "days").endOf("day").unix()
        return setDateRange(dates)

      case "this_week":
        dates.start_ts = moment().startOf("day").unix()
        dates.end_ts = moment().add(7, "days").endOf("day").unix()
        return setDateRange(dates)

      case "custom":
        if (dateRangeInMoment) {
          dates.start_ts = dateRangeInMoment[0]
            .set({ hour: 0, minute: 0, seconds: 0 })
            .unix()
          dates.end_ts = dateRangeInMoment[1]
            .set({ hour: 23, minute: 59, seconds: 59 })
            .unix()
          return setDateRange(dates)
        }
        return

      default:
        return ""
    }
  }

  const onClickHandler = (courseCode) => {
    setVisible(true)
    setFeedbackCourseCode(courseCode)
  }

  const expandHandler = (arr, courseItem) => {
    setDetails(null)
    setCourseItem(courseItem)
  }

  const showList = async (
    type,
    e,
    code,
    totalCount = 0,
    endDate,
    day = null,
    page = 1,query=''
  ) => {
    setStudentList(null)
    if (e) {
      e.stopPropagation()
    }
    setModalVisible(true)
    setStudentListType(type)

    switch (type) {
      case "registered":
        setPopupLoading(true)
        try {
          const res = await getCourseRegistrations(code, page)
          const ended = checkCourseEnded(endDate)
          setStudentList({
            ended,
            code,
            title: "Registrations",
            totalCount,
            ...res,
          })
        } catch (e) {
          setStudentList({ title: "Registrations" })
        } finally {
          setPopupLoading(false)
        }
        break

      case "attended":
        setPopupLoading(true)
        try {
          const res = await getAttendanceListByDay(code, day, page,query)
          const ended = checkCourseEnded(endDate)

          setStudentList({
            ended,
            title: "Attendance list",
            totalCount,
            ...res,
          })
        } catch (e) {
          setStudentList({ title: "Attendance list" })
        } finally {
          setPopupLoading(false)
        }
        break

      case "hotLeads":
        setPopupLoading(true)
        try {
          const res = await getHotLeads(code)
          const list = {
            data: res?.data?.lead_list,
          }
          setStudentList({ title: "Hot leads", totalCount, ...list })
        } catch (e) {
          setStudentList({ title: "Hot leads" })
        } finally {
          setPopupLoading(false)
        }
        break

      default:
        return ""
    }
  }

  const renderOtherCoursesText = () => {
    switch (activeBtn) {
      case 0:
        return `Your Yesterday's classes`
      case 1:
        return `Your Classes for today`
      case 2:
        return `Your tomorrow's classes`
      case 3:
        return "Classes this week"
      default:
        return "Classes in the time range"
    }
  }

  const updateMeta = async (type, result, defaultMeta, code) => {
    let payload = { ...defaultMeta }
    switch (type) {
      case "notes":
        payload = { ...defaultMeta, text: result }
        break
      case "radio":
        payload = { ...defaultMeta, is_teacher_training_done: result }
        break
      default:
        return ""
    }
    return await updateMetaOfCourse(code, payload)
  }

  const myHotLeadListHandler = async (code) => {
    try {
      await getHotLeads(code)
    } catch (e) {
    } finally {
    }
  }

  const onSearch =(e)=>{
    const {value} =e.target;
    if (value==="") {
      onPageChange(1,'')
    }
    setQueryData(value)
    
  }

const debouncedSearchTerm = useDebounce(queryData, 2000);
useEffect(
  () => {
    if (debouncedSearchTerm) {
      onPageChange(1,debouncedSearchTerm);
    } 
  },
  [debouncedSearchTerm] // Only call effect if debounced search term changes
);



  const onPageChange =(page,query)=>{
    if (studentListType === "registered") {
      if (courseItem) {
        showList(
          studentListType,
          null,
          courseItem?.course?.code,
          studentList?.totalCount,
          courseItem?.course?.end_date,
          "",
          page,
        )
      } else {
        showList(
          studentListType,
          null,
          scheduledClass?.course?.code,
          studentList?.totalCount,
          null,
          "",
          page
        )
      }
    } else {
      if (courseItem) {
        showList(
          studentListType,
          null,
          courseItem?.course?.code,
          details?.attendances[attendanceDay - 1],
          null,
          attendanceDay,
          page,query
        )
      } else {
        showList(
          studentListType,
          null,
          scheduledClass?.course?.code,
          studentList?.totalCount,
          null,
          scheduledClass?.course?.day,
          page,query
        )
      }
    }
  }


  return (
    <div className={styles.calendarWrapper}>
      <Card className={clsx(styles.filters, "roundedCard")}>
        <h5 className={styles.timeRangeHeader}>Select Range</h5>
        {filterButtons.map((item, index) => (
          <Button
            onClick={() => searchHandler(index, item.type)}
            type={index === activeBtn ? "primary" : ""}
            className={styles.today}
          >
            {item.text}
          </Button>
        ))}

        <RangePicker
          format="DD/MM/YYYY"
          className={styles.inputs}
          onChange={(d, v) => searchHandler(5, "custom", d, v)}
        />
      </Card>

      <div style={{ width: "80%", margin: "0 auto" }}>
        {loading ? (
          <Loader />
        ) : scheduledClass ? (
          <Collapse expandIconPosition="right">
            <Panel
              header={
                <>
                  <div className={styles.title}>
                    <p>
                      Your upcoming scheduled class is on{" "}
                      <span>
                        {getDateFormat(
                          scheduledClass?.course?.start_ts,
                          "MMM DD, h:mm A"
                        )}{" "}
                        (Day {scheduledClass?.course?.day})
                      </span>
                    </p>
                  </div>
                  <div className={styles.cardBody}>
                    <div className={styles.gridContainer1}>
                      <div className={styles.firstItem}>
                        <h1>
                          <a
                            target="bitclass-workshop"
                            href={`${WEB_URL}/live-classes/${scheduledClass?.course?.tmpr_code}`}
                            onClick={(e) => e.stopPropagation()}
                          >
                            {scheduledClass?.course?.heading}
                            <span>({scheduledClass?.course?.code})</span>
                            <span className={styles.amtBorder}>
                              {scheduledClass?.course?.amount === 0
                                ? "Free"
                                : "Paid"}
                            </span>
                          </a>
                        </h1>
                        <p>
                          <b>{scheduledClass?.teacher?.username}</b>{" "}
                          <span>{scheduledClass?.teacher?.phone}</span>
                        </p>
                      </div>

                      <div className={styles.secondItem}>
                        <h5>Course schedule</h5>
                        <p>
                          {getDateFormat(
                            scheduledClass?.course?.start_date,
                            "MMM-D-YYYY"
                          )}{" "}
                          to{" "}
                          {getDateFormat(
                            scheduledClass?.course?.end_date,
                            "MMM-D-YYYY"
                          )}
                        </p>
                      </div>
                    </div>

                    <div className={styles.gridContainer2}>
                      <div className={styles.firstItem}>
                        <h5>Category Manager</h5>
                        <p>
                          <b>
                            {" "}
                            {scheduledClass?.category_manager?.username ||
                              "--"}{" "}
                          </b>
                          <span>
                            {" "}
                            {scheduledClass?.category_manager?.phone ||
                              "--"}{" "}
                          </span>
                        </p>
                      </div>
                      <div className={styles.secondItem}>
                        <h5>
                          {getDateFormat(
                            scheduledClass?.course?.start_ts,
                            "MMM DD, h:mm A"
                          )}
                        </h5>
                        <div className={styles.buttonContainer}>
                          <a
                            className={styles.golive}
                            target="bitclass-class"
                            href={`${WEB_URL}/live-classes/classroom/${scheduledClass?.course?.code}`}
                          >
                            <Button
                              icon={<Video />}
                              type="primary"
                              onClick={(e) => {
                                e.stopPropagation()
                              }}
                            >
                              Go live
                            </Button>
                          </a>

                          <a
                            target="bitclass-chat"
                            href={`${WEB_URL}/course/summary/${scheduledClass?.course?.code}#chats`}
                          >
                            <Button
                              icon={<MessageSquare />}
                              type="primary"
                              ghost
                              onClick={(e) => {
                                e.stopPropagation()
                              }}
                            >
                              Group Chat
                            </Button>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              }
              key="1"
            >
              {/* Upsell details */}
              {scheduledClass?.upsell_courses?.length > 0 && (
                <div className={styles.gridContainer3}>
                  {scheduledClass?.upsell_courses.map((item, index) => (
                    <div key={index} className={styles.firstItem}>
                      <h5>UPSELL {index + 1}</h5>
                      <h6>{item?.heading}</h6>
                      <div className={styles.upsellGrid}>
                        <div className={styles.subfirstItem}>
                          <p>Floor price: {item?.meta?.floor_price || "--"}</p>
                          <p>
                            Price: {item?.currency} {item?.amount}
                          </p>
                          <p>Target: {item?.meta?.target_amount || "--"}</p>
                          <p>
                            Timings:{" "}
                            {getDateFormat(item?.start_ts, "DD/MMMM/YYYY")}
                            &nbsp;-&nbsp;
                            {getDateFormat(item?.end_ts, "DD/MMMM/YYYY")}
                          </p>
                        </div>
                        <div className={styles.secondItem}>
                          {item?.meta?.ppt_link && (
                            <a
                              target="bitclass-ppt"
                              href={item?.meta?.ppt_link}
                            >
                              PPT Link
                            </a>
                          )}
                          <a
                            target="bitclass-upsell"
                            href={`${WEB_URL}/live-classes/${item?.code}`}
                          >
                            Upsell Link
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* coupon details */}
              {scheduledClass?.coupons?.length > 0 && (
                <div className={styles.couponContainer}>
                  <h5>Coupons can be used</h5>
                  {scheduledClass?.coupons.map((item, index) => (
                    <Tooltip
                      title={
                        <>
                          <div>Coupon type: {item.type}</div>
                          <div>Coupon value: INR{item.value}/-</div>
                        </>
                      }
                    >
                      <p>{item.code}</p>
                    </Tooltip>
                  ))}
                </div>
              )}

              <div className={styles.gridContainer4}>
                <div className={styles.firstItem}>
                  <TextArea
                    defaultValue={scheduledClass?.meta?.text}
                    onBlur={(e) =>
                      updateMeta(
                        metaTypes[0],
                        e.target.value,
                        scheduledClass?.meta,
                        scheduledClass?.course?.code
                      )
                    }
                    rows={6}
                    placeholder="Add some personal notes here"
                  />
                </div>
                <div className={styles.secondItem}>
                  <p
                    onClick={(e) =>
                      showList(
                        studentTypes["0"],
                        e,
                        scheduledClass?.course?.code,
                        scheduledClass?.registrations
                      )
                    }
                  >
                    Registered students:{" "}
                    <span className={styles.listPara}>
                      {scheduledClass?.registrations}
                    </span>
                  </p>
                  <p
                    onClick={(e) =>
                      showList(
                        studentTypes["1"],
                        e,
                        scheduledClass?.course?.code,
                        "",
                        null,
                        scheduledClass?.course?.day
                      )
                    }
                  >
                    Attendance:{" "}
                    {scheduledClass?.attendances &&
                      scheduledClass?.attendances.map((subitem, subindex) => (
                        <>
                          <span
                            className={styles.listPara}
                            style={{ padding: "0 2px" }}
                            onClick={(e) => {
                              setAttendanceDay(subindex + 1)
                              showList(
                                studentTypes["1"],
                                e,
                                scheduledClass?.course?.code,
                                scheduledClass?.attendances[subindex],
                                null,
                                subindex + 1
                              )
                            }}
                          >
                            {subitem}[D{subindex + 1}]
                          </span>
                        </>
                      ))}
                  </p>
                  <p style={{ cursor: "text" }}>
                    Teacher training date:{" "}
                    <span style={{ color: "red" }}>
                      {getDateFormat(
                        scheduledClass?.teacher_training_date,
                        "DD MMMM YYYY"
                      )}{" "}
                    </span>
                  </p>
                  <p style={{ cursor: "text" }}>
                    Teacher training done:
                    <RadioGroup
                      // defaultValue = {false}
                      defaultValue={
                        scheduledClass?.meta?.is_teacher_training_done
                      }
                      onChange={(e) =>
                        updateMeta(
                          metaTypes[1],
                          e.target.value,
                          scheduledClass?.meta,
                          scheduledClass?.course?.code
                        )
                      }
                    >
                      <Radio
                        // defaultValue={
                        //   true
                        // }
                        value={true}
                      >
                        Yes
                      </Radio>
                      <Radio
                        // defaultValue={
                        //  false
                        // }
                        value={false}
                      >
                        No
                      </Radio>
                    </RadioGroup>
                  </p>
                </div>
              </div>
            </Panel>
          </Collapse>
        ) : scheduledClass === null ? (
          <div style={{ textAlign: "center" }}>
            <h2>No classes scheduled!</h2>
          </div>
        ) : (
          ""
        )}

        {/*Course list  */}

        {exists(courseList) && courseList.length > 0 ? (
          <>
            <div style={{ display: "flex" }}>
              <div className={styles.courseSeperator}></div>
              <div className={styles.courseSepText}>
                {renderOtherCoursesText()}
              </div>
              <div className={styles.courseSeperator}></div>
            </div>
            {/* {courseList.map((item, index) => ( */}
            <Collapse
              accordion
              expandIconPosition="right"
              onChange={(key, seconditem) =>
                expandHandler(key, courseList[key])
              }
            >
              {courseList.map((item, index) => {
                const ended = checkCourseEnded(item?.course?.end_date)
                return (
                  <>
                    {ended && !item?.course?.is_feedback_submitted ? (
                      <div className={styles.blurWrapper}>
                        <div className={styles.blurContainer}>
                          <div className={styles.gridContainer1}>
                            <div className={styles.firstItem}>
                              <h1>{item?.course?.heading}</h1>
                              <p>{item?.teacher?.username}</p>
                            </div>
                            <div className={styles.secondItem}>
                              <h5>Course schedule </h5>
                              <p>
                                {getDateFormat(
                                  item?.course?.start_date,
                                  "MMM-D-YYYY"
                                )}{" "}
                                to{" "}
                                {getDateFormat(
                                  item?.course?.end_date,
                                  "MMM-D-YYYY"
                                )}
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className={styles.feedbackBtnContainer}>
                          <p>Please submit the feedback to unlock your leads</p>
                          <Button
                            onClick={() => onClickHandler(item?.course?.code)}
                            type="primary"
                          >
                            Add Feedback
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Panel
                        header={
                          <>
                            <div>
                              <div
                                className={clsx(
                                  styles.title,
                                  styles.otherCourseTitle
                                )}
                              >
                                <p>
                                  <span>
                                    {getDateFormat(
                                      item?.course?.start_ts,
                                      "DD MMMM YYYY, h:mm A"
                                    )}{" "}
                                    (Day{item?.course?.day})
                                  </span>
                                </p>
                              </div>

                              <div className={styles.cardBody}>
                                <div className={styles.gridContainer1}>
                                  <div className={styles.firstItem}>
                                    <h1>
                                      <a
                                        target="bitclass-workshop"
                                        href={`${WEB_URL}/live-classes/${item?.course?.tmpr_code}`}
                                        onClick={(e) => e.stopPropagation()}
                                      >
                                        {item?.course?.heading}
                                        <span>({item?.course?.code})</span>
                                        <span className={styles.amtBorder}>
                                          {item?.course?.amount === 0
                                            ? "Free"
                                            : "Paid"}
                                        </span>
                                      </a>
                                    </h1>
                                    <p>
                                      <b>{item?.teacher?.username}</b>{" "}
                                      <span>{item?.teacher?.phone}</span>
                                    </p>
                                  </div>
                                  <div className={styles.secondItem}>
                                    <h5>Course schedule </h5>
                                    <p>
                                      {getDateFormat(
                                        item?.course?.start_date,
                                        "MMM-D-YYYY"
                                      )}{" "}
                                      to{" "}
                                      {getDateFormat(
                                        item?.course?.end_date,
                                        "MMM-D-YYYY"
                                      )}
                                    </p>
                                  </div>
                                </div>
                                <div className={styles.gridContainer2}>
                                  <div className={styles.firstItem}>
                                    <h5>Category Manager</h5>
                                    <p>
                                      <b>
                                        {item?.category_manager?.username ||
                                          "--"}{" "}
                                      </b>
                                      <span>
                                        {item?.category_manager?.phone || "--"}
                                      </span>
                                    </p>
                                  </div>

                                  <div className={styles.secondItem}>
                                    <h5>
                                      {getDateFormat(
                                        item?.course?.start_ts,
                                        "MMM DD, h:mm A"
                                      )}
                                    </h5>
                                    <div className={styles.buttonContainer}>
                                      <a
                                        className={styles.golive}
                                        target="bitclass-class"
                                        href={`${WEB_URL}/live-classes/classroom/${item?.course?.code}`}
                                      >
                                        <Button
                                          icon={<Video />}
                                          type="primary"
                                          onClick={(e) => {
                                            e.stopPropagation()
                                          }}
                                        >
                                          Go live
                                        </Button>
                                      </a>

                                      <a
                                        target="bitclass-chat"
                                        href={`${WEB_URL}/course/summary/${item?.course?.code}#chats`}
                                      >
                                        <Button
                                          icon={<MessageSquare />}
                                          type="primary"
                                          ghost
                                          onClick={(e) => {
                                            e.stopPropagation()
                                          }}
                                        >
                                          Group Chat
                                        </Button>
                                      </a>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        }
                      >
                        <>
                          {expandedLoading && (
                            <div className={styles.spinnerContainer}>
                              <Spin
                                indicator={
                                  <LoadingOutlined
                                    style={{ fontSize: 24 }}
                                    spin
                                  />
                                }
                              />
                            </div>
                          )}

                          {details && (
                            <>
                              {details?.upsell_courses &&
                              details?.upsell_courses.length > 0 ? (
                                <div className={styles.gridContainer3}>
                                  {details?.upsell_courses.map((item) => (
                                    <div className={styles.firstItem}>
                                      <h5>UPSELL {index + 1}</h5>
                                      <h6>{item?.heading}</h6>
                                      <div className={styles.upsellGrid}>
                                        <div className={styles.subfirstItem}>
                                          <p>
                                            Floor price:{" "}
                                            {item?.meta?.floor_price || "--"}
                                          </p>
                                          <p>
                                            Price: {item?.currency}{" "}
                                            {item?.amount}
                                          </p>
                                          <p>
                                            Target:{" "}
                                            {item?.meta?.target_amount || "--"}
                                          </p>
                                          <p>
                                            Timings:{" "}
                                            {getDateFormat(
                                              item?.start_ts,
                                              "DD/MMMM/YYYY"
                                            )}
                                            &nbsp;-&nbsp;
                                            {getDateFormat(
                                              item?.end_ts,
                                              "DD/MMMM/YYYY"
                                            )}
                                          </p>
                                        </div>
                                        <div className={styles.secondItem}>
                                          {item?.meta?.ppt_link && (
                                            <a
                                              target="bitclass-ppt"
                                              href={item?.meta?.ppt_link}
                                            >
                                              PPT Link
                                            </a>
                                          )}
                                          <a
                                            target="bitclass-upsell"
                                            href={`${WEB_URL}/live-classes/${item?.code}`}
                                          >
                                            Upsell Link
                                          </a>
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                ""
                              )}

                              {details?.coupons &&
                              details?.coupons.length > 0 ? (
                                <div className={styles.couponContainer}>
                                  <h5>Coupons can be used</h5>
                                  {details?.coupons.map((item, index) => (
                                    <Tooltip
                                      title={
                                        <>
                                          <div>Coupon type: {item.type}</div>
                                          <div>
                                            Coupon value: INR{item.value}/-
                                          </div>
                                        </>
                                      }
                                    >
                                      <p>{item.code}</p>
                                    </Tooltip>
                                  ))}
                                </div>
                              ) : (
                                ""
                              )}

                              <div className={styles.gridContainer4}>
                                <div className={styles.firstItem}>
                                  <TextArea
                                    defaultValue={details?.meta?.text}
                                    onBlur={(e) =>
                                      updateMeta(
                                        metaTypes[0],
                                        e.target.value,
                                        details?.meta,
                                        item?.course?.code
                                      )
                                    }
                                    rows={6}
                                    placeholder="Add some personal notes here"
                                  />
                                </div>
                                <div className={styles.secondItem}>
                                  <p
                                    onClick={(e) => {
                                      showList(
                                        studentTypes["0"],
                                        e,
                                        item?.course?.code,
                                        details?.registrations,
                                        item?.course?.end_date
                                      )
                                    }}
                                  >
                                    Registered students:
                                    <span className={styles.listPara}>
                                      {details?.registrations}
                                    </span>
                                  </p>
                                  <p
                                    style={{
                                      cursor: "pointer",
                                      color: "red",
                                      fontWeight: "bold",
                                    }}
                                    onClick={(e) => {
                                      details?.hot_lead_count === 0
                                        ? showList(
                                            studentTypes["0"],
                                            e,
                                            item?.course?.code,
                                            details?.registrations,
                                            item?.course?.end_date
                                          )
                                        : showList(
                                            studentTypes["2"],
                                            e,
                                            item?.course?.code,
                                            null,
                                            null,
                                            null
                                          )
                                    }}
                                  >
                                    Hot leads:
                                    <span>{details?.hot_lead_count}</span>
                                  </p>
                                  <p>
                                    Attendance:{" "}
                                    {details?.attendances &&
                                      details?.attendances.map(
                                        (subitem, subindex) => (
                                          <>
                                            <span
                                              className={styles.listPara}
                                              style={{ padding: "0 2px" }}
                                              onClick={(e) => {
                                                setAttendanceDay(subindex + 1)
                                                showList(
                                                  studentTypes["1"],
                                                  e,
                                                  item?.course?.code,
                                                  details?.attendances[
                                                    subindex
                                                  ],
                                                  null,
                                                  subindex + 1
                                                )
                                              }}
                                            >
                                              {subitem}[D{subindex + 1}]
                                            </span>
                                          </>
                                        )
                                      )}
                                  </p>
                                  <p style={{ cursor: "text" }}>
                                    Teacher training date:
                                    <span style={{ color: "red" }}>
                                      {getDateFormat(
                                        details?.teacher_training_date,
                                        "DD MMMM YYYY"
                                      )}
                                    </span>
                                  </p>
                                  <p style={{ cursor: "text" }}>
                                    Teacher training done:
                                    <RadioGroup
                                      // defaultValue = {false}
                                      defaultValue={
                                        details?.meta?.is_teacher_training_done
                                      }
                                      onChange={(e) => {
                                        updateMeta(
                                          metaTypes[1],
                                          e.target.value,
                                          details?.meta,
                                          item?.course?.code
                                        )
                                      }}
                                    >
                                      <Radio value={true}>Yes</Radio>
                                      <Radio value={false}>No</Radio>
                                    </RadioGroup>
                                  </p>
                                </div>
                              </div>
                            </>
                          )}
                        </>
                      </Panel>
                    )}
                  </>
                )
              })}
            </Collapse>
          </>
        ) : (
          ""
        )}
      </div>
      <Modal
        visible={modalVisible}
        onCancel={() => setModalVisible(false)}
        title={studentList?.title}
        destroyOnClose={true}
        footer={
          <Pagination
            onChange={(page) => {
              onPageChange(page,queryData)
            }}
            defaultCurrent={1}
            total={studentList?.totalCount ? studentList?.totalCount : 1}
            simple
          />
        }
        className={styles.studentlist}
      >
        <div className={styles.spinnerContainer}>
        {studentList?.title==="Attendance list"&& <Input placeholder="search" className={styles.input_search} allowClear value={queryData} onChange={onSearch} />}

          {popupLoading ? (
            <div>
              <Spin
                indicator={<LoadingOutlined style={{ fontSize: 24 }} spin />}
              />
            </div>
          ) : (
            <>
            <Itemlist
              list={studentList?.data}
              studentList={studentList}
              hotLeadUpdate={hotLeadUpdate}
              setHotLeadUpdate={setHotLeadUpdate}
              />
              </>
          )}
        </div>
      </Modal>
      <FeedbackModal
        visible={visible}
        setVisible={setVisible}
        feedbackCourseCode={feedbackCourseCode}
        setFeedbackSaved={setFeedbackSaved}
      />
    </div>
  )
}

export default CalendarPage
