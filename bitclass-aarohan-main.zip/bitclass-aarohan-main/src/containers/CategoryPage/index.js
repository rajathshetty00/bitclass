import React, { useEffect, useState } from "react"
import {
  Button,
  Card,
  Input,
  InputNumber,
  message,
  Select,
  Modal,
  Empty,
  Table,
  Popconfirm,
} from "antd"
import clsx from "clsx"
import { Upload, AlertCircle, ChevronRight } from "react-feather"
import styles from "./styles.module.scss"

import { CLOUDINARY_CONFIG } from "../../constants"
import {
  getAllCategories,
  createNewCategory,
  searchCourse,
  mapCategoriesToCourse,
} from "../../utils/api"
import CourseCategoryTagCard from "../../atoms/CourseCategoryTagCard"
import dayjs from "dayjs"

const { Option } = Select;

const CategoryPage = () => {
  const [courseDetails, setCourseDetails] = useState(null)
  const [categoryName, setCategoryName] = useState("")
  const [img, setImg] = useState()
  const [action, setAction] = useState("")
  const [courseCategories, setCourseCategories] = useState([])
  const [options, setOptions] = useState([])
  const [allCategories, setAllCategories] = useState([])
  // filters
  const [searchValue, setSearchValue] = useState("")
  const [minPrice, setMinPrice] = useState(null)
  const [maxPrice, setMaxPrice] = useState(null)
  const [filterCategories, setFilterCategories] = useState([])
  // filters end
  const [courses, setCourses] = useState([])
  const [defaultCategories, setDefaultCategories] = useState([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [isInfoModalVisible, setIsInfoModalVisible] = useState(false)
  const [infoModalSearchValue, setInfoModalSearchValue] = useState('')
  const [currentPage, setCurrentPage] = useState(1)

  useEffect(() => {
    (async function fetchData() {
      const { data } = await getAllCategories();
      setAllCategories(data);
      fetchCourses(1)
    })()
  }, [])

  const openCloudinaryUpload = () => {
    window.cloudinaryUploadWidget(
      {
        ...CLOUDINARY_CONFIG,
        multiple: false,
        resource_type: "image",
      },
      cloudinaryAfterUpload
    );
  }

  const cloudinaryAfterUpload = (err, res) => {
    if (err) {
      message.error(err);
      return;
    }
    if (res[0].url) {
      setImg(res[0].url.replace("http://", "https://"));
      message.success("Image successfully added to Cloudinary");
      // setStep(2)
    } else {
      // addToast("Failed to upload", { ...DEFAULT_TOAST_CONFIG, appearance: 'error' })
      message.error("Failed to upload image");
    }
  }

  const handleCourseSearch = async (page) => {
    // if (
    //   (!searchValue || searchValue.trim() === "") &&
    //   filterCategories.length === 0
    // ) {
    //   message.error("Please type course name or select category");
    //   return;
    // }
    setCourses([])
    fetchCourses(page)
  }

  const fetchCourses = async(page) => {
    const loading = message.loading("Fetching course details", 0)
    try {
      const res = await searchCourse({
        q: searchValue,
        min: minPrice ? minPrice : "",
        max: maxPrice ? maxPrice : "",
        limit: 60,
        page: page,
      });
      loading();
      if (res["data"].length === 0) {
        message.error("No data found");
        return;
      }
      setCourses(formatData(res["data"]));
      setCurrentPage(page)
    } catch (error) {
      message.error(error);
    }
  }

  const formatData = (data) => {
    return data.length > 0 ? data.map(v => ({
      heading: v.heading,
      teacherName: v.teacher_name,
      amount: v.amount + " " + v.currency,
      startTs: v.start_ts ? dayjs.unix(v.start_ts).format('DD MMM YYYY') : '-',
      endTs: v.end_ts ? dayjs.unix(v.end_ts).format('DD MMM YYYY') : '-',
      categories: {
        category: v.categories,
        code: v.code,
      },
    })) : []
  } 

  const addNewCategory = async () => {
    if (!img || !categoryName) {
      message.error("Please add category name and image");
      return;
    }
    const loading = message.loading("Adding you category", 0);
    try {
      const res = await getAllCategories();
      const isExisting = await res.data.findIndex(
        (category) => category.display_text === categoryName
      );
      if (isExisting > -1) {
        loading();
        message.error("Category  already exist");
        setCategoryName("");
        return;
      }
      const { data } = await createNewCategory(categoryName, img, action);
      loading();
      if (data) {
        message.success("New category created!");
        setCategoryName("");
        setImg();
        setAction("");
      } else message.error("Failed to create new category");
    } catch (error) {
      message.error(error);
    }
  }

  useEffect(() => {
    const newCategories = [];
    if (!courseDetails?.categories?.length) return;
    courseDetails.categories.forEach((category) => {
      const filteredCategories = allCategories.filter(
        (allCategory) => allCategory.id === parseInt(category)
      );
      newCategories.push(filteredCategories[0]);
    });
  }, [allCategories, courseDetails]);

  useEffect(() => {
    const newOptions = [];
    if (!allCategories) return;
    allCategories.map((category) => {
      if (!courseCategories.includes(category.id))
        newOptions.push([
          <Option key={category.id} value={category.id}>
            {category.display_text}
          </Option>,
        ]);
    });
    setOptions(newOptions);
  }, [allCategories, courseCategories, courseDetails]);

  const handleClear = () => {
    setSearchValue("");
    setMinPrice(null);
    setMaxPrice(null);
    setFilterCategories([]);
  }

  const infoTableColumns = [
    {
      title: 'Category',
      dataIndex: 'display_text',
      key: 'category',
    },
    {
      title: 'Link',
      dataIndex: 'display_text',
      key: 'link',
      render: (text) => (
        <a
          href={`https://categories.bitclass.live/c/${encodeURIComponent(text)}`}
          alt={text}
          target="_blank"
          style={{ display: "flex", alignItems: "center" }}
        >
          Open <ChevronRight />
        </a>
      )
    },
  ]

  const categoryTable = [
    {
      title: 'Heading',
      dataIndex: 'heading',
      key: 'heading',
      align: 'center',
    },
    {
      title: 'Teacher',
      dataIndex: 'teacherName',
      key: 'teacher',
      align: 'center',
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      align: 'center',
    },
    {
      title: 'Start Date',
      dataIndex: 'startTs',
      key: 'start_date',
      align: 'center',
    },
    {
      title: 'End Date',
      dataIndex: 'endTs',
      key: 'end_date',
      align: 'center',
    },
    {
      title: 'Category',
      dataIndex: 'categories',
      key: 'category',
      align: 'center',
      render: (data) => <CategoryUpdateComponent allCategories={allCategories} defaultCategories={data.category} code={data.code} />
    },
  ]

  return (
    <div className={styles.container}>
      {/* filter section */}
      <Card className={clsx(styles.category, "roundedCard")}>
        <Input
          value={searchValue}
          placeholder="Enter course name"
          onChange={(e) => setSearchValue(e.target.value)}
          className={styles.categoryInput}
          onKeyUp={(e) => {
            if(e.keyCode === 13) {
              handleCourseSearch(1)
            }
          }}
        />
        <InputNumber
          value={minPrice}
          placeholder="Min Price"
          onChange={setMinPrice}
          className={styles.filterInputNumbers}
          onKeyUp={(e) => {
            if(e.keyCode === 13) {
              handleCourseSearch(1)
            }
          }}
        />
        <InputNumber
          value={maxPrice}
          placeholder="Max Price"
          onChange={setMaxPrice}
          className={styles.filterInputNumbers}
          onKeyUp={(e) => {
            if(e.keyCode === 13) {
              handleCourseSearch(1)
            }
          }}
        />
        {/* <Select
          mode="multiple"
          placeholder="category"
          className={styles.categoryFilter}
          // defaultValue={['china']}
          value={filterCategories}
          optionFilterProp="children"
          filterOption={(input, option) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
          onChange={setFilterCategories}
        >
          {allCategories.map((v, i) => (
            <Option key={i.toString()} value={v.display_text}>
              {v.display_text}
            </Option>
          ))}
        </Select> */}
        <Button
          type={"primary"}
          className={styles.button}
          onClick={() => handleCourseSearch(1)}
        >
          Search
        </Button>
        <Button
          type={"secondary"}
          className={styles.button}
          onClick={handleClear}
        >
          Clear
        </Button>

        {/* right aligned */}
        <AlertCircle
          className={styles.infoIcon}
          onClick={() => {
            setIsInfoModalVisible(true);
          }}
        />
        <Button
          type={"primary"}
          className={styles.button}
          onClick={() => {
            setIsModalVisible(true);
          }}
        >
          Add New Category
        </Button>
      </Card>
      {/* filter section ended */}
      {/* courses section */}
      {/* <Card
        className={clsx(styles.course, "roundedCard")}
        bodyStyle={courses.length === 0 ? {
          gridTemplateColumns: "auto"
        }: {}}
      >
        {
          courses.length === 0 && <Empty description="No course found" />
        }
        {
          courses.map((c, i) => (
            <CourseCategoryTagCard
              key={i.toString()}
              doc={c}
              allCategories={allCategories}
            />
          ))
        }
      </Card> */} { /* v1 - card UI */ }
      {/* show more */}
      {/* {
        courses.length >= 9 && (
          <div className={styles.showMoreContainer}>
            <div onClick={() => handleCourseSearch(currentPage + 1)}>Next Page</div>
          </div>
        )
      } */}

      {/* table ui */}
      <Card
        className={clsx(styles.tableContainer, "roundedCard")}
      >
        <Table
          dataSource={courses}
          columns={categoryTable}
          bordered={true}
          pagination={false}
        />
        {
          courses.length >= 60 && (
            <div className={styles.showMoreContainer}>
              <div onClick={() => handleCourseSearch(currentPage + 1)}>Next Page</div>
            </div>
          )
        }
      </Card>
      {/* table ui ends here */}

      {/* courses section ends */}
      {/* add category modal */}
      <Modal
        title="Add Category"
        visible={isModalVisible}
        onOk={addNewCategory}
        onCancel={() => {
          setIsModalVisible(false);
        }}
        okText="Add"
      >
        <Input
          placeholder="Category Name"
          value={categoryName}
          className={styles.categoryInput}
          onChange={(e) => setCategoryName(e.currentTarget.value)}
        />
        {img ? (
          <div
            style={{
              width: "80px",
              height: "80px",
              borderRadius: "4px",
              backgroundImage: `url(${img})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              margin: "16px 0",
            }}
          ></div>
        ) : (
          <Button
            onClick={openCloudinaryUpload}
            style={{ display: "flex", alignItems: "center", margin: "16px 0" }}
          >
            <Upload style={{ width: "14px", marginRight: "8px" }} /> Upload Icon
          </Button>
        )}
        <Input
          placeholder="Action"
          value={action}
          className={styles.categoryInput}
          onChange={(e) => setAction(e.currentTarget.value)}
        />
      </Modal>
      {/* add category modal ends */}
      {/* info modal */}
      <Modal
        title="Category Links"
        visible={isInfoModalVisible}
        footer={null}
        onCancel={() => {
          setInfoModalSearchValue('')
          setIsInfoModalVisible(false);
        }}
      >
        <Input
          value={infoModalSearchValue}
          onChange={(e) => setInfoModalSearchValue(e.target.value)}
          placeholder="Category Name"
        />
        <Table
          dataSource={
            infoModalSearchValue && infoModalSearchValue !== ''
              ? allCategories.filter(
                  v => v.display_text.toLowerCase().includes(infoModalSearchValue.toLowerCase())
                )
              : allCategories
          }
          columns={infoTableColumns}
        />
      </Modal>
      {/* info modal ends */}
    </div>
  );
}

const CategoryUpdateComponent = ({ code, allCategories, defaultCategories = [] }) => {
  const [categories, setCategories] = useState(defaultCategories)
  const [visible, setVisible] = useState(false)
  const [confirmLoading, setConfirmLoading] = useState(false)

  const handleOk = async () => {
    const loading = message.loading(`saving categories`, 100)
    setConfirmLoading(true)
    try {
      const { success } = await mapCategoriesToCourse(code, categories)
      loading()
      setConfirmLoading(false)
      setVisible(false)
      if(success) {
        message.success("category saved")
      } else {
        message.error("Failed to save category")
      }
    } catch (error) {
      console.log(error);
      message.error("Failed to save category")
    }
  }

  return(
    <Popconfirm
      title="Are you sure?"
      visible={visible}
      onConfirm={handleOk}
      okButtonProps={{ loading: confirmLoading }}
      onCancel={() => setVisible(false)}
    >
      <Select
        mode="multiple"
        placeholder="category"
        className={styles.categoryFilter}
        defaultValue={categories.map(v => parseInt(v))}
        optionFilterProp="children"
        filterOption={(input, option) =>
          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
        }
        onChange={setCategories}
      >
        {allCategories.map((v, i) => (
          <Option key={i.toString()} value={v.id}>
            {v.display_text}
          </Option>
        ))}
      </Select>
      <Button
        type={"primary"}
        className={styles.button}
        onClick={() => setVisible(true)}
      >
        Save
      </Button>
    </Popconfirm>
  )
} 

export default CategoryPage;
