import React, { useEffect, useState } from "react"
import { Card, Input, Select, Button, message } from "antd"
import clsx from "clsx"
import { useSelector } from "react-redux"

import styles from "./styles.module.scss"
// import { init } from '../../actions/dashboard'
import { CometChat } from "@cometchat-pro/chat"
import { CometChatGroupListWithMessages } from "../../CometChatWorkspace/src"
import { COMET_CHAT_AUTH_KEY } from "../../constants"
import { getChatToken } from "../../utils/api"
const { Option } = Select

const ChatPage = () => {
  // const dispatch = useDispatch()
  const { internalUsers } = useSelector((state) => ({
    internalUsers: state.dashboard.internalUsers,
  }))

  const [authToken, setAuthToken] = useState("")
  const [error, setError] = useState("")
  const [searchValue, setSearchValue] = useState("")
  const [loading, setLoading] = useState(false)
  useEffect(() => {
    // dispatch(init())
    // window.startCometChat()
    if (!authToken) return
    // const authKey = COMET_CHAT_AUTH_KEY
    // const uid = 'SUPERHERO1'

    CometChat.login(authToken).then(
      (user) => {
        console.log("Login Successful:", { user })
      },
      (error) => {
        console.log("Login failed with exception:", { error })
      }
    )
  }, [authToken])

  useEffect(() => {
    //     var limit = 30;
    // var groupsRequest = new CometChat.GroupsRequestBuilder()
    //   .setLimit(limit)
    //   .build();
    // groupsRequest.fetchNext().then(
    //   groupList => {
    //     /* groupList will be the list of Group class */
    //     console.log("Groups list fetched successfully", groupList);
    //     /* you can display the list of groups available using groupList */
    //   },
    //   error => {
    //     console.log("Groups list fetching failed with error", error);
    //   }
    // );
  }, [])

  const handleStartChat = async () => {
    setLoading(true)
    try {
      const { data, error } = await getChatToken(encodeURI(searchValue))
      // console.log(res,'****')
      if (data) {
        setAuthToken(data)
        message.success("Fetching chat access")
      }
      if (error) {
        setError(error)
        message.warning("Failed to retrieve access")
      }
      setSearchValue("")
    } catch (error) {
      message.warning("Failed to retrieve access")
      console.error(error)
    }
    setLoading(false)
  }

  return (
    <div className={styles.mainContainer}>
      <Card
        className={clsx(styles.filters, "roundedCard")}
        bodyStyle={{
          display: "flex",
          alignItems: "center",
          flexDirection: "row",
        }}
      >
        <Input
          placeholder="Enter Teacher Name / Mobile Number"
          className={styles.inputs}
          onChange={(e) => setSearchValue(e.target.value)}
          value={searchValue}
        />
        {/* <Select className={styles.inputs} placeholder="Assigned To">
          {internalUsers.map((_iU, i) => (
            <Option value={_iU.code} key={i.toString()}>
              {_iU.username}
            </Option>
          ))}
        </Select> */}
        <Button type={"primary"} onClick={handleStartChat}>
          Start Chat
        </Button>
      </Card>
      {authToken && !loading && (
        <div id="chatCard" className={clsx(styles.chatCard, "roundedCard")}>
          <div style={{ width: "100%", height: "550px" }}>
            <CometChatGroupListWithMessages />
          </div>
        </div>
      )}
    </div>
  )
}

export default ChatPage
