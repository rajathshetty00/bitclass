import { message, Spin } from "antd"
import React, { useState } from "react"
import { ButtonIcon, Spacer } from "../../../Curriculum/components"
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator"
import { InputController } from "../../../TeacherDetails/components"
import { addCollectionFormlData, convertTextToSlug } from "../../helper"
import collectionValidator from "../../helper/collectionValidator"
import styles from "./styles.module.scss"
import useRedux from "../../../../helpers/useRedux"
import { checkSlugAvailability } from "../../../../utils/api"
import { debounce } from "lodash-es"
import { useCallback } from "react"
import { LoadingOutlined } from "@ant-design/icons"
import { CloseOutlined, CheckOutlined } from '@ant-design/icons';
import {
  addCollectionData,
  updateCollectionData,
} from "../../../../actions/collection"
import { Send } from "react-feather"
import { useEffect } from "react"
import { Fragment } from "react"
const antIcon = (
  <LoadingOutlined
    style={{ fontSize: 16, color: "white", marginRight: "5px" }}
    spin
  />
)

const AddCollection = ({ isUpdatable, rowData, slug ,isRecording }) => {
  const [addCollectionForm, setAddCollectionForm] = useState({
    discoverable: false,
    active:true,
    discoverable_recordings:true
  })
  const [isSlugAvailable, setIsSlugAvailable] = useState(false)

  const [{ loading, page }, dispatch] = useRedux("collection")

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...addCollectionForm, isSlugAvailable },
    collectionValidator
  )
  const debouncUpdate = useCallback(
    debounce(async (key, value) => {
      
      const reqBody = {
        ...rowData?.details,
        ...(key === "name" || key === "description"||key==='circular_icon'
          ? { [key]: value }
          : {
              banner: {
                ...rowData?.details?.banner,
                image: { ...rowData?.details?.banner?.image, [key]: value },
              },
            }),
      }
      const acutalReqObj=key==='discoverable'||key==='discoverable_recordings'?{[key]:value}:{ details: reqBody };

      try {
        await dispatch(updateCollectionData(slug,acutalReqObj , page))
      } catch (error) {
        message.error("Error while updating collection data")
      }
    }, 2000),
    [rowData]
  )
  const debouncCheckSlugAvailability = useCallback(
    debounce(async (value) => {
      try {
        const response = await checkSlugAvailability(value)
        if (response?.data?.slug_available) {
          setIsSlugAvailable(true)
        } else {
          setErrors({ slug: "Slug is not available" })
          setIsSubmitting(false)
          setIsSlugAvailable(false)
        }
      } catch (error) {
        setErrors({ slug: "Slug is not available" })
        setIsSubmitting(true)
        setIsSlugAvailable(false)
      }
    }, 1000),
    []
  )

  useEffect(() => {
    if (rowData) {
      const actualObj = {
        slug: rowData?.slug,
        name: rowData?.details?.name,
        description: rowData?.details?.description,
        discoverable: rowData?.discoverable,
        web: rowData?.details?.banner?.image?.web,
        mobile: rowData?.details?.banner?.image?.mobile,
        circular_icon:rowData?.details?.circular_icon,
        ...(isRecording&&{discoverable_recordings:rowData?.discoverable_recordings}),

      }
      // update the data
      setAddCollectionForm(actualObj)
    }
  }, [rowData])


  const handleChangeForm = (e) => {
    const { name, value } = e.target
    // isRecording?`${convertTextToSlug(value)}_series`:convertTextToSlug(value)
    const acutalSlug =convertTextToSlug(value);
    if (name === "name" && !isUpdatable) {
      setAddCollectionForm((preState) => ({
        ...preState,
        [name]: value,
        slug:acutalSlug,
      }))
      debouncCheckSlugAvailability(acutalSlug)
    } else if (name === "slug" && !isUpdatable) {
      setAddCollectionForm((preState) => ({
        ...preState,
        [name]: acutalSlug,
      }))
      debouncCheckSlugAvailability(acutalSlug)
    } else {
      setAddCollectionForm((preState) => ({ ...preState, [name]: value }))
    }
    //  called only when user update data
    if (isUpdatable) {
      debouncUpdate(name, value)
    }
    setErrors({})
    setIsSubmitting(false)
  }

  async function onSubmit() {
    const reqBody = {
      active: addCollectionForm?.active,
      ...(isRecording&&{discoverable_recordings:addCollectionForm?.discoverable_recordings}),
      slug:isRecording?`${addCollectionForm?.slug}-series`:addCollectionForm?.slug,
      discoverable: addCollectionForm?.discoverable,
      ...(isRecording?{type:'recording'}:{type:'generic'}),
      details: {
        name: addCollectionForm?.name,
        description: addCollectionForm?.description,
        circular_icon:addCollectionForm?.circular_icon,
        banner: {
          image: {
            mobile: addCollectionForm?.mobile,
            web: addCollectionForm?.web,
          },
          video: {
            mobile: "",
            web: "",
          },
        },
      },
    }
    // // api call for submit data
    const { success } = await dispatch(addCollectionData(reqBody, page))

    if (success) {
      setAddCollectionForm({
        discoverable: false,
      })
    }
  }

  return (
    <div>
      {addCollectionFormlData.map(({ type, label, name,onlyRecording, ...props }, index) => {
        return (
          <Fragment key={label}>
          <div className={styles.contactInput} key={name}>
            <InputController type="label" name={name}>
              {label}
            </InputController>
            <InputController
              errMsg={errors?.[name]}
              onChange={handleChangeForm}
              type={type}
              value={addCollectionForm[name]}
              name={name}
              {...props}
              disabled={isUpdatable && name === "slug" && true}
            />
            <Spacer size={10} />
          </div>
          
          </Fragment>

        )
      })}
      {isRecording&&<div className={styles.contactInput}>
            <InputController type="label" name='recoding_tab'>
            Show on recording tab
            </InputController>
            <InputController
              errMsg={errors?.discoverable_recordings}
              onChange={handleChangeForm}
              type='switch'
              value={addCollectionForm.discoverable_recordings}
              name='discoverable_recordings'
              checkedChildren={<CheckOutlined />}
        unCheckedChildren={<CloseOutlined />}
        defaultChecked={true}
            />
            <Spacer size={10} />
          </div>}
      {!isUpdatable && (
        <div className={styles.btnContainer}>
          <ButtonIcon className={styles.addItem} onClick={handleSubmit}>
            {loading?.addCollection ? (
              <Spin indicator={antIcon} />
            ) : (
              <Send style={{ width: "15px", marginRight: "7px" }} />
            )}
            Submit
          </ButtonIcon>
        </div>
      )}
    </div>
  )
}

export default AddCollection
