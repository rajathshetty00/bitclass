import { AutoComplete, Checkbox,  message, Select, Spin, Tag ,Typography} from 'antd'
import { debounce } from 'lodash-es'
import React from 'react'
import { useCallback } from 'react'
import { useState } from 'react'
import { UpdateCourseTable } from '..'
import { addCourseToCollection, addRecordingToCollection, fetchSeriesList, searchCollectionCourse, searchCourse } from '../../../../utils/api'
import { Spacer } from '../../../Curriculum/components'
import { DropDownComponent } from '../../../TeacherDetails/components'
import styles from './styles.module.scss'
import { useDispatch } from 'react-redux'
import { fetchCollectionCourseData } from '../../../../actions/collection'
import useRedux from '../../../../helpers/useRedux'
import dayjs from 'dayjs'
const { Option } = AutoComplete;

const { Text } = Typography;
const optionList =[{abb:'course',name:'Course'}]
const queryConstruct =(filtersObject) =>{
  const query = new URLSearchParams()
  Object.entries(filtersObject).forEach(filter =>query.set(filter[0],filter[1])
  )
  return query.toString()
}

const CourseLabel = ({
  title,
  teacher_name,
  duration,
  type
}) => {
  return (
    <span className={styles.label}>
      {title}
      <span class={styles.vDiv}>&nbsp;|&nbsp;</span>
      <span>By-{teacher_name}</span>
    </span>
  );
};

const AddSeriesRecording = ({slug,record}) => {

  const [selectedFilter, setSelectedFilter] = useState('course');
  const [selectedCourse, setSelectedFCourse] = useState({free:false,full:false});
  const [options, setOptions] = useState([]);
  const [fetching, setFetching] = useState(false);
  const dispatch = useDispatch();

  const debouncSearchData = useCallback(
    debounce(async (query) => {
      const searchQuery =queryConstruct({...(query&&{title:query}),page:1,limit:10});
      try {
        const {data}= await fetchSeriesList(`?${searchQuery}`);
        const valueLabelCourse =Array.isArray(data?.series_doc) ? data?.series_doc.map(({title,teacher_name,_id,duration,type})=>({value:_id,label:<CourseLabel title={title} type={type} duration={duration}teacher_name={teacher_name} />})):[];
              setOptions(valueLabelCourse)
              setFetching(false)
      } catch (error) {
        setFetching(false)
        message.error("Error while fetching courses")
      }
    }, 1000),
    [selectedCourse],
  );
  
  const handleSearch = (value) => {
    debouncSearchData(value);
    setFetching(true)
    setOptions([]);
  };

  const onSelect = async (value,query) => {
    const body = {
      type: 'recordings',
      code:value
  };
    // api called to append table list 
    try {
      const response = await addRecordingToCollection(slug,body);
      if (response.success) {
         dispatch(fetchCollectionCourseData(slug,1))
      }else{
      message.error(`Error while adding course into collection:`,[2])

      }
    } catch (error) {
      message.error(`Error while adding course into collection: ${error}`,[2])
    }
  };


  
  return (
    <section id="search_section" className={styles.search_section}>
    <Text strong>Please search by recording series name and click to add series in collection</Text>
    <div className={styles.searchContainer}>
    <Select
    showSearch
    placeholder="Search the Series Name ..."
    filterOption={false}
    onSearch={handleSearch}
    onSelect={onSelect}
    notFoundContent={fetching ? <Spin size="small" /> : null}
    className={styles.searchFilter}
  >
    {options.map(({value,label})=>{
      return <Option key={value} value={value}>{label}</Option>
    })}
  </Select>
    
  
    </div>
    <Spacer size={30} />
    <UpdateCourseTable slug={slug} record={record} isRecording={true} />
      </section>

  )
}

export default AddSeriesRecording