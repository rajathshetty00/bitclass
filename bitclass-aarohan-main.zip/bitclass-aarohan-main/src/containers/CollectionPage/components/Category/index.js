import React, { useEffect } from 'react'
import { categoryColumns } from "../../helper"
import useRedux from "../../../../helpers/useRedux"
import { Table } from 'antd'
import { fetchCategoryData, pageChangeCategory } from '../../../../actions/category'

const Category = () => {
    const [{ loading, page, total, categoryList }, dispatch] =
    useRedux("category")

     // fetch the latest collection
  useEffect(() => {
    dispatch(fetchCategoryData(page || 1))
  }, [dispatch, page])
  return (
    <section id="category_component">
         <Table
        rowKey="keyword"
        columns={categoryColumns}
        dataSource={categoryList}
        scroll={{ x: 1024, y: 600 }}
        loading={loading?.fetchCategoryList}
        page={page}
        pagination={{
          total,
          onChange: (page) => {
            dispatch(pageChangeCategory(page))
          },
          showSizeChanger: false,
          current: page,
        }}
      />
    </section>
  )
}

export default Category