

import React, { useState } from "react"
import { updateCategoryData } from "../../../../actions/category"
import useRedux from "../../../../helpers/useRedux"
import { SwitchComponent } from "../../../TeacherDetails/components"

const CategorySwitch = ({ id, isActive }) => {
  const [localIsActive, setLocalIsActive] = useState(isActive)
  const [{ page }, dispatch] = useRedux("collection")

  const updateStatusWithApi = (value) => {
    dispatch(updateCategoryData(id, { is_active: value }, page))
  }
  const handleChangeSwitch = (e) => {
    const { value } = e.target
    setLocalIsActive(value)
    updateStatusWithApi(value)
  }
  return (
    <div>
      <SwitchComponent
        value={localIsActive}
        onChange={handleChangeSwitch}
        checkedChildren={"Discoverable"}
        unCheckedChildren={"hidden"}
        defaultChecked
      />
    </div>
  )
}

export default CategorySwitch