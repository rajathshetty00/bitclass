import { Table } from "antd"
import React, { useEffect } from "react"
import { Plus } from "react-feather"

import { collectionColumns, collectionRecordingColumns } from "../../helper"
import styles from "./styles.module.scss"
import { TOGGLE_ADD_COLLECTION_MODEL } from "../../../../actions/types"
import { fetchCollectionData,pageChangeCollection } from "../../../../actions/collection"
import useRedux from "../../../../helpers/useRedux"
import { ButtonIcon } from "../../../Curriculum/components"
import { ModelContainer } from "../../../TeacherDetails/components"
import AddCollection from "../AddCollection"
import { queryConstructor } from "../../../../utils"
const Collection = (
  {isRecording=false}) => {
  const [{ loading, page, total,collectionCoursePage, isAddModelOpen, collectionList }, dispatch] =
    useRedux("collection")

  const OpenModel = () => {
    dispatch({ type: TOGGLE_ADD_COLLECTION_MODEL, payload: true })
  }
  // fetch the latest collection
  useEffect(() => {
     const query = queryConstructor({page:page||1,limit:10,...(isRecording? {type:'recording'}: {type:'generic'})})
    dispatch(fetchCollectionData(query))
  }, [dispatch, page])


  return (
    <section id="collection_component">
      <div className={styles.btnContainer}>
        <ButtonIcon onClick={OpenModel}>
          <Plus style={{ width: "15px", marginRight: "7px" }} />
          Add Collection
        </ButtonIcon>
      </div>

      <Table
        rowKey="slug"
        columns={isRecording?collectionRecordingColumns:collectionColumns
        }
        dataSource={collectionList}
        scroll={{ x: 1024, y: 600 }}
        loading={loading?.fetchCollectionList}
        page={page}
        pagination={{
          total,
          onChange: (page) => {
            dispatch(pageChangeCollection(page))
          },
          showSizeChanger: false,
          current: page,
        }}
      />

      <ModelContainer
        width={800}
        visible={isAddModelOpen}
        onCancel={() =>
          dispatch({ type: TOGGLE_ADD_COLLECTION_MODEL, payload: false })
        }
        heading={<h1>Add Collection</h1>}
        footer
      >
        <AddCollection isRecording={isRecording} isUpdatable={false} />
      </ModelContainer>
    </section>
  )
}

export default Collection
