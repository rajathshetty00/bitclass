import { Popconfirm } from 'antd';
import React from 'react'
import { useState } from 'react';
import { deleteCollectionData } from '../../../../actions/collection';
import useRedux from '../../../../helpers/useRedux';
import styles from './styles.module.scss'

const DeleteCollection = ({slug}) => {
    const [isVisibile, setisVisibile] = useState(false)
    const [{loading}, dispatch] = useRedux('collection');
      
    const showPopconfirm = () => setisVisibile(true)
    const handleCancel = () =>   setisVisibile(false)
  
    const handleOk = () => {
        dispatch(deleteCollectionData(slug))
    };
   
  return (
    <div>
         <Popconfirm
      title="Are you sure you want to delete"
      visible={isVisibile}
      onConfirm={handleOk}
      okButtonProps={{ loading: loading?.deleteCollection}}
      okText="Delete"
      onCancel={handleCancel}
    >
      <button className={styles.deleteBtn} onClick={showPopconfirm}>remove</button>
        
    </Popconfirm>
    </div>
  )
}

export default DeleteCollection