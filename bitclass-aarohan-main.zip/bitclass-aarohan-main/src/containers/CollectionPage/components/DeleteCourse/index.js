import { Popconfirm } from 'antd';
import React, { useState } from 'react'
import { Trash } from 'react-feather';
import { deleteCollectionCourseData } from '../../../../actions/collection';
import useRedux from '../../../../helpers/useRedux';
import styles from './styles.module.scss'

const DeleteCourseIcon = ({slug,record,isRecording=false}) => {
  const [isVisibile, setisVisibile] = useState(false)
  const [{loading,selectedSlug}, dispatch] = useRedux('collection');
    
  const showPopconfirm = () => setisVisibile(true)
  const handleCancel = () =>   setisVisibile(false)

  const handleOk = () => {
    const reqBody = {
      type: record?.entity?.type,
      code: record?.entity?.code,
    };
      dispatch(deleteCollectionCourseData(selectedSlug,reqBody,isRecording))
  };
  return (
    <div>
         <Popconfirm
      title="Are you sure you want to delete"
      visible={isVisibile}
      onConfirm={handleOk}
      okButtonProps={{ loading: loading?.deleteCollection }}
      onCancel={handleCancel}
      okText="Delete"
    >
      <Trash  role='button' onClick={showPopconfirm} className={styles.deleteicon}  />
    </Popconfirm>
    </div>
  )
}

export default DeleteCourseIcon