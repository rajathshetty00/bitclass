import { Spin, Table } from 'antd'
import React, { useEffect, useState } from 'react'
import {  Edit3, Send } from 'react-feather'
import { fetchCategoryCourseData, fetchCategoryData, pageChangeCategoryCouseTable, setSelectedId, updateCategoryData } from '../../../../actions/category'
import { fetchCollectionCourseData, fetchCollectionData, setSelectedSlug } from '../../../../actions/collection'
import useRedux from '../../../../helpers/useRedux'
import { ButtonIcon, Spacer } from '../../../Curriculum/components'
import useFormValidator from '../../../PayoutsPage/helper/useFormValidator'
import { InputController, ModelContainer } from '../../../TeacherDetails/components'
import { courseCategoryColumns, updateCategoryFormData } from '../../helper'
import { categoryValidator } from '../../helper/categoryValidator'
import { LoadingOutlined ,SendOutlined} from "@ant-design/icons"
import styles from './styles.module.scss'
import { isEmpty } from 'lodash-es'
const antIcon = (
    <LoadingOutlined
      style={{ fontSize: 16, color: "white", marginRight: "5px" }}
      spin
    />
  )
  const dat= new Date();
  const dataObj =[{start_date: dat.toDateString(), end_date: dat.toDateString(),heading:'this is the first dtaa ',course_url:'http://www.googgle.co.in',amount:'2000',is_feature_course:true}]

const EditCategory = ({id,record}) => {
  const [isVisible, setisVisible] = useState(false);
  const [isFormChanged, setIsFormChanged] = useState(false);

  const [updatableForm, setUpdatableForm] = useState({
    discoverable: false,
  })
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...updatableForm },
    categoryValidator  )
    const [{coursePage,loading,totalCourse,categoryCourseList}, dispatch] = useRedux('category');
  const OpenModel = ()=>{
    setisVisible(true)
    // api call to fetch category course information
    dispatch(fetchCategoryCourseData(id,1)) 
    dispatch(setSelectedId(id))
  }
  const closeModel =()=>{
    // dispatch(fetchCategoryData(page))
    setisVisible(false)
    dispatch(setSelectedId(id))
  }

  const handleChange =e=>{ 
    const { name, value } = e.target
    setUpdatableForm((preState)=>({...preState,[name]:value}))
    setIsFormChanged(true);
    if (!isEmpty(errors)){
      setErrors({});
      setIsSubmitting(false);
    }
  }

  function onSubmit(){
      const reqBody = {
        description:updatableForm.description,
        icon: updatableForm.icon,
        web_banner: updatableForm.web_banner,
        mobile_banner: updatableForm.mobile_banner
        
      }
      dispatch(updateCategoryData(id,reqBody));
      setIsFormChanged(false);



  }

  useEffect(() => {
    setUpdatableForm(record)
  }, [record])


  useEffect(() => {
    if(coursePage>1) fetchCategoryCourseData(id,coursePage)
  }, [coursePage,record,id])

  return (
    <div>
        <span>
            <Edit3 onClick={OpenModel}  className={styles.editIcon} />
        </span>
        {/* Model open */}
        <ModelContainer width={800} visible={isVisible} onCancel={closeModel} heading={<h1>Update Category</h1>} footer >
        {updateCategoryFormData.map(({ type, label, name, ...props }, index) => {
        return (
          <div className={styles.contactInput} key={name}>
            <InputController type="label" name={name}>
              {label}
            </InputController>
            <InputController
              errMsg={errors?.[name]}
              onChange={handleChange}
              type={type}
              value={updatableForm[name]}
              name={name}
              {...props}
            />
            <Spacer size={10} />
          </div>
          
        )
      })}
      <div className={styles.btnContainer}>
          <button className={styles.btn} onClick={handleSubmit} disabled={!isFormChanged} >
            {loading?.updateCategory ? (
              <Spin indicator={antIcon} />
            ) : (
              <SendOutlined className={styles.btnIcon} />
            )}
            Submit
          </button>
        </div>
       <Spacer size={10} />

        <Table
        rowKey="code"
        columns={courseCategoryColumns}
        dataSource={categoryCourseList}
        scroll={{ x: 1024, y: 300 }}
        loading={loading?.fetchCollectionList}
        page={coursePage}
        pagination={{
        totalCourse,
          onChange: (page) => {
            dispatch(pageChangeCategoryCouseTable(page))
          },
          showSizeChanger: false,
          current: coursePage,
        }}
      />
      </ModelContainer>
    </div>
  )
}


export default EditCategory