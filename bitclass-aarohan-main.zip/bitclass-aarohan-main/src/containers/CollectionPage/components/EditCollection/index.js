import React, { useState } from 'react'
import {  Edit3 } from 'react-feather'
import { AddRecordingSeries, SearchComponent } from '..'
import { fetchCollectionCourseData, fetchCollectionData, setSelectedSlug } from '../../../../actions/collection'
import useRedux from '../../../../helpers/useRedux'
import { queryConstructor } from '../../../../utils'
import { ModelContainer } from '../../../TeacherDetails/components'
import AddCollection from '../AddCollection'
import styles from './styles.module.scss'

const EditCollection = ({slug,record}) => {
  const [isVisible, setisVisible] = useState(false)
    const [{page}, dispatch] = useRedux('collection');
  const OpenModel = ()=>{
    setisVisible(true)
    // api call to fetch collection course information
    dispatch(fetchCollectionCourseData(slug,1))
    dispatch(setSelectedSlug(slug))
  }
  const closeModel =()=>{
    const query = queryConstructor({page:page||1,limit:10,...(record?.type==='recording'? {type:'recording'}: {type:'generic'})})
    dispatch(fetchCollectionData(query))
    setisVisible(false)
    dispatch(setSelectedSlug(''))

  }
  return (
    <div>
        <span>
            <Edit3 onClick={OpenModel}  className={styles.editIcon} />
        </span>
        {/* Model open */}
        <ModelContainer width={1120} visible={isVisible} onCancel={closeModel} heading={<h1>Update Collection</h1>} footer >
          <AddCollection isUpdatable slug={slug} isRecording={record.type==='recording'} rowData={record} />
          {record.type==='recording'?<AddRecordingSeries record={record} slug={slug} />:<SearchComponent slug={slug} record={record}  />}
      </ModelContainer>
    </div>
  )
}


export default EditCollection