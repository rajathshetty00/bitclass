

import React, { useState } from "react"
import { useEffect } from "react"
import { updateCategoryData, updateFeaturedCategory } from "../../../../actions/category"
import { updateFeaturedCollection } from "../../../../actions/collection"
import useRedux from "../../../../helpers/useRedux"
import { SwitchComponent } from "../../../TeacherDetails/components"

const FeatureSwitch = ({ id, isActive,isCategory,record,entity }) => {
  const [localIsActive, setLocalIsActive] = useState(false)
  const [{ coursePage,selectedCategory }, dispatch] = useRedux("category")
  const [{selectedSlug}] = useRedux('collection');


  const updateStatusWithApi = (value) => {
    if (isCategory) {
      
      dispatch(updateFeaturedCategory(selectedCategory, { code: id }, coursePage,value ,id))
    }else{
      dispatch(updateFeaturedCollection(selectedSlug, {code:entity?.code,type:entity?.type}, coursePage,value ,entity?.code))
    }

  }
  const handleChangeSwitch = (e) => {
    const { value } = e.target
    setLocalIsActive(value)
    updateStatusWithApi(value)
  }

  useEffect(() => {
    setLocalIsActive(isActive);
  }, [isActive])
  

  return (
    <div>
      <SwitchComponent
        value={localIsActive}
        onChange={handleChangeSwitch}
      />
    </div>
  )
}

export default FeatureSwitch