import { AutoComplete, Checkbox,  message, Select, Spin, Tag } from 'antd'
import { debounce } from 'lodash-es'
import React from 'react'
import { useCallback } from 'react'
import { useState } from 'react'
import { UpdateCourseTable } from '..'
import { addCourseToCollection, searchCollectionCourse, searchCourse } from '../../../../utils/api'
import { Spacer } from '../../../Curriculum/components'
import { DropDownComponent } from '../../../TeacherDetails/components'
import styles from './styles.module.scss'
import { useDispatch } from 'react-redux'
import { fetchCollectionCourseData } from '../../../../actions/collection'
import useRedux from '../../../../helpers/useRedux'
import dayjs from 'dayjs'
const { Option } = AutoComplete;
const optionList =[{abb:'course',name:'Course'}]
const queryConstruct =(filtersObject) =>{
  const query = new URLSearchParams()
  Object.entries(filtersObject).forEach(filter =>query.set(filter[0],filter[1])
  )
  return query.toString()
}

const CourseLabel = ({
  start_ts,
  end_ts,
  heading,
  teacher_name,
  currency,
  amount,
}) => {
  return (
    <span className={styles.label}>
     
      {`${heading?.substring(0, 35)}...`}
      <span class={styles.vDiv}>&nbsp;|&nbsp;</span>

      <span>{teacher_name}</span>
      <span class={styles.vDiv}>&nbsp;|&nbsp;</span>
      <Tag color="#87d068" >
        {dayjs.unix(start_ts).format("DD MMM,YYYY")}-{dayjs.unix(end_ts).format("DD MMM,YYYY")}
      </Tag>
      <span class={styles.vDiv}>&nbsp;|&nbsp;</span>
      <span>{currency}</span> <span>{amount}</span>
     
    </span>
  );
};

const SearchComponent = ({slug,record}) => {

  const [selectedFilter, setSelectedFilter] = useState('course');
  const [selectedCourse, setSelectedFCourse] = useState({free:false,full:false});
  const [options, setOptions] = useState([]);
  const [fetching, setFetching] = useState(false);
  const dispatch = useDispatch();

  const debouncSearchData = useCallback(
    debounce(async (query) => {
      const searchQuery ={ended:false,is_active:true,...(selectedCourse.free&&!selectedCourse.full && {upsell: false}),...(!selectedCourse.free&&selectedCourse.full && {upsell: true})};
      try {
        const {data}= await searchCollectionCourse({q:query,page:1,limit:10,other:queryConstruct(searchQuery)});
        const valueLabelCourse =Array.isArray(data) ? data.map(({currency,teacher_name,code,heading,start_ts,end_ts,amount,entity})=>({value:code,label:<CourseLabel entity={entity} currency={currency}teacher_name={teacher_name}heading={heading}start_ts={start_ts}end_ts={end_ts}amount={amount} />})):[];
              setOptions(valueLabelCourse)
              setFetching(false)
      } catch (error) {
        setFetching(false)
        message.error("Error while fetching courses")
      }
    }, 1000),
    [selectedCourse],
  );
  
  const handleSearch = (value) => {
    debouncSearchData(value);
    setFetching(true)
    setOptions([]);
  };

  const onSelect = async (value,query) => {
    console.log("The valuen is",value,query.children?.props?.entity);
    const {entity} = query.children?.props;
    // api called to append table list 
    try {
      const response = await addCourseToCollection(slug,entity);
      if (response.success) {
         dispatch(fetchCollectionCourseData(slug,1))
      }else{
      message.error(`Error while adding course into collection:`,[2])

      }
    } catch (error) {
      message.error(`Error while adding course into collection: ${error}`,[2])
    }
  };

  const handleChange = (e)=>{
    setSelectedFilter(e.target.value);
  }
  const handleChangeCheckbox = useCallback( (e)=>{
    const {name,checked} = e.target;
    setSelectedFCourse((preState)=>({...preState,[name]:checked}))
  },[])

  
  return (
    <section id="search_section" className="search_section">
    <div className={styles.searchContainer}>
     <DropDownComponent value={selectedFilter} onChange={handleChange} optionList={optionList} placeholder="Plese select status"  />
     <Checkbox name='free' checked={selectedCourse.free} className={styles.categroycheckbox} onChange={handleChangeCheckbox}>FREE</Checkbox>
     <Checkbox  name="full" checked={selectedCourse.full} className={styles.categroycheckbox} onChange={handleChangeCheckbox}>FULL COURSE</Checkbox>
      <Select
    showSearch
    placeholder="Search the course"
    filterOption={false}
    onSearch={handleSearch}
    onSelect={onSelect}
    notFoundContent={fetching ? <Spin size="small" /> : null}
    className={styles.searchFilter}
  >
    {options.map(({value,label})=>{
      return <Option key={value} value={value}>{label}</Option>
    })}
  </Select>
    
  
    </div>
    <Spacer size={30} />
    <UpdateCourseTable slug={slug} record={record} isRecording={false} />
      </section>

  )
}

export default SearchComponent