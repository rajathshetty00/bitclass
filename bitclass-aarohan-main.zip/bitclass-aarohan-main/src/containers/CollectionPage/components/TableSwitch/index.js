import React, { useState } from "react"
import { updateCollectionData } from "../../../../actions/collection"
import useRedux from "../../../../helpers/useRedux"
import { SwitchComponent } from "../../../TeacherDetails/components"

const TableSwitch = ({ slug, isActive }) => {
  const [localIsActive, setLocalIsActive] = useState(isActive)
  const [{ page }, dispatch] = useRedux("collection")

  const updateStatusWithApi = (value) => {
    dispatch(updateCollectionData(slug, { active: value }, page))
  }
  const handleChangeSwitch = (e) => {
    const { name, value } = e.target
    setLocalIsActive(value)
    updateStatusWithApi(value)
  }
  return (
    <div>
      <SwitchComponent
        value={localIsActive}
        onChange={handleChangeSwitch}
        checkedChildren={"Active"}
        unCheckedChildren={"InActive"}
        defaultChecked
      />
    </div>
  )
}

export default TableSwitch
