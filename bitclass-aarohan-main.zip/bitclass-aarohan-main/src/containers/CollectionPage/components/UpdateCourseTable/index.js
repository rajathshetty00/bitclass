import { Table } from "antd"
import React from "react"
import { useEffect } from "react"
import { fetchCollectionCourseData, pageChangeCollectionCourseTable } from "../../../../actions/collection"
import useRedux from "../../../../helpers/useRedux"
import { courseColumns, recordingSeriesColumns } from "../../helper"

const UpdateCourseTable = ({isRecording=false}) => {
  const [{  loading,collectionCoursePage,collectionCourseListTotal,
    collectionCourseList,selectedSlug}, dispatch] =useRedux("collection")

    // fetch the latest collection
    useEffect(() => {
      if(collectionCoursePage>1){dispatch(fetchCollectionCourseData(selectedSlug,collectionCoursePage || 1))}
    }, [dispatch, collectionCoursePage])
  return (
    <div>
      <Table
        rowKey="code"
        columns={isRecording?recordingSeriesColumns:courseColumns}
        dataSource={collectionCourseList}
        scroll={{ x: 1024, y: 300 }}
        loading={loading?.fetchCollectionCourses}
        page={collectionCoursePage}
        // pagination={{
        //   collectionCourseListTotal,
        //   onChange: (page) => {
        //     dispatch(pageChangeCollectionCourseTable(page))
        //   },
        //   showSizeChanger: false,
        //   current: collectionCoursePage,
        // }}
        pagination ={false}
      />
    </div>
  )
}

export default UpdateCourseTable
