export {default as TableSwitch} from './TableSwitch'
export {default as EditCollection} from './EditCollection'
export {default as SearchComponent} from './SearchComponent'
export {default as UpdateCourseTable} from './UpdateCourseTable'
export {default as DeleteCourseIcon} from './DeleteCourse'
export {default as DeleteCollection} from './DeleteCollection'
export {default as Collection} from './Collection'
export {default as Category} from './Category'
export {default as CategorySwitch} from './CategorySwitch'
export {default as EditCategory} from './EditCategory'
export {default as FeatureSwitch} from './FeatureSwitch'
export {default as AddRecordingSeries} from './AddRecordingSeries'












