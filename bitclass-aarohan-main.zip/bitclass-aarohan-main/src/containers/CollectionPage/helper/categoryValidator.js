


import { isEmpty } from 'lodash-es';
import { checkURL } from '../../Curriculum/validators/helper';
const invalidUrlErroMsg ="Please enter  valid URL"

export const categoryValidator =(values) =>{
    const errors = {};
    if(isEmpty(values?.display_text))
    errors.display_text="Please add category name ";
    if(isEmpty(values?.description))
        errors.description="please add description ";
    // if(isEmpty(values?.web))
    //     errors.web="please enter link to web Banner";
    // if (!isEmpty(values?.web)&& !checkURL(values?.web)) 
    //     errors.web=invalidUrlErroMsg;

    //  if(isEmpty(values?.mobile))
    //     errors.mobile="please enter link to mobile Banner";
    // if (!isEmpty(values?.mobile)&& !checkURL(values?.mobile)) 
    //     errors.mobile=invalidUrlErroMsg;
     if(isEmpty(values?.icon))
        errors.icon="please enter link to categtory icon";
    if (!isEmpty(values?.icon)&& !checkURL(values?.icon)) 
        errors.icon=invalidUrlErroMsg;
    return errors;
    
}