


import { isEmpty } from 'lodash-es';
import { returnMediaTypeByUrl } from '.';
import { checkURL } from '../../Curriculum/validators/helper';
const invalidUrlErroMsg ="Please enter valid video or image URL"
const slugValidotor = /^[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*$/;

export default function collectionValidator(values) {
    console.log("The value si",values?.mobile,checkURL(values?.mobile),returnMediaTypeByUrl(values?.web),!returnMediaTypeByUrl(values?.mobile));
    const errors = {};
    if(isEmpty(values?.slug))
    errors.slug="Please add slug ";
    if (!isEmpty(values?.slug)&&!values.isSlugAvailable) 
    errors.slug='Slug is not available!!!';
    if(isEmpty(values?.name))
        errors.name="Please add heading ";
    if (!isEmpty(values?.slug)&&!slugValidotor.test(values?.slug))
    errors.slug='Allowed characters for slug are alphabets(a-z,A-Z),number(0-9)and minus(-)';
    if(isEmpty(values?.description))
        errors.description="please add description ";
    if(isEmpty(values?.web))
        errors.web="please enter link to Web Banner";
    if ((!isEmpty(values?.web)&&!returnMediaTypeByUrl(values?.web))|| !checkURL(values?.web) ) 
        errors.web=invalidUrlErroMsg;
    if(isEmpty(values?.mobile))
        errors.mobile="please enter link to mobile Banner";
    if ((!isEmpty(values?.mobile)&&!returnMediaTypeByUrl(values?.mobile))||!checkURL(values?.mobile)) 
        errors.mobile=invalidUrlErroMsg;
        if(isEmpty(values?.circular_icon))
        errors.circular_icon="please enter collection icon";
        if (!isEmpty(values?.circular_icon)&&!checkURL(values?.circular_icon)) 
        errors.circular_icon='Enter valid URL for collection icon';
    
    
    return errors;
    
}