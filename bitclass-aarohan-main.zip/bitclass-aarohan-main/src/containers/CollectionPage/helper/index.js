import { CloseOutlined, CheckOutlined } from '@ant-design/icons';
import { Typography } from 'antd';
import dayjs from 'dayjs';
import { WEB_URL } from '../../../constants';
import { checkURL } from '../../Curriculum/validators/helper';
import {  CategorySwitch, DeleteCollection, DeleteCourseIcon, EditCategory, EditCollection, FeatureSwitch, TableSwitch } from '../components';
const { Paragraph } = Typography;


const initialCollectionState =[{ 
  title: "Created On",
  dataIndex: "created_at",
  key: "created_at",
  width:'220px',
  render: createdDate=> <span>{dayjs(createdDate).format('DD MMM YYYY h:mm A')}</span>
},
{
  title: "Collection Name",
  dataIndex: 'slug',
  key: "slug",
  render:(slug,record)=><div style={{display: 'flex',alignItems:'center'}}>
    
    <a href={`${WEB_URL}/live-classes/collection/${slug}`} target="_blank" rel="noopener noreferrer" title="Collection URL" >{record?.details?.name} </a>
    <Paragraph style={{marginLeft:'0.5rem',marginBottom:0}}  copyable={{ text: `${WEB_URL}/live-classes/collection/${slug}` }} />
    </div>
},

{ 
  title: "Status",
  dataIndex: "active",
  key: "status",
  render:(isActive,record)=><TableSwitch slug={record?.slug} isActive={isActive}  />
},
{ 
  title: "Edit",
  dataIndex: "",
  key: "action",
  render:(data,record)=><EditCollection slug={record?.slug} record={record}   />
},
{ 
  title: "Delete",
  dataIndex: "",
  key: "action",
  render:(_,record)=><DeleteCollection slug={record?.slug} />
}
]
const collectionInitalState = [...initialCollectionState];
collectionInitalState.splice(parseInt((initialCollectionState.length-1)/2), 0, { 
  title: "Courses",
  dataIndex: "entity_count",
  key: "courses",
})
export const collectionColumns = collectionInitalState;
initialCollectionState.splice(parseInt((initialCollectionState.length-1)/2), 0, { 
  title: "Series Count",
  dataIndex: "entity_count",
  key: "series_count",
})
export const collectionRecordingColumns = initialCollectionState
export const categoryColumns = [
{
  title: "Category Name",
  dataIndex: 'display_text',
  key: "display_text",
  render:(_,record)=><div style={{display: 'flex',alignItems:'center'}}>
    
    <a href={`${WEB_URL}/live-classes/category/${record?.display_text}`} target="_blank" rel="noopener noreferrer" title="Category URL" >{record?.display_text} </a>
    <Paragraph style={{marginLeft:'0.5rem',marginBottom:0}}  copyable={{ text: `${WEB_URL}/live-classes/category/${record?.display_text}` }} />
    </div>
},
{ 
  title: "Courses",
  dataIndex: "course_count",
  key: "course_count",
},
{ 
  title: "Status",
  dataIndex: "is_active",
  key: "is_active",
  render:(isActive,record)=><CategorySwitch id={record?.display_text} isActive={isActive}  />
},
{ 
  title: "Edit",
  dataIndex: "",
  key: "action",
  render:(data,record)=><EditCategory id={record?.display_text} record={record}   />
}
]

export const courseColumns = [
  {
    title: "Course Name",
    dataIndex: 'course_url',
    key: "course_url",
    render: (url,record)=><a href={record?.entity.type==="tmpr"?`${WEB_URL}/live-classes/${record?.entity?.code}`:url} target='_blank' rel="noreferrer"  >{record?.heading}</a>
  },
{
  title: "Teacher Name",
  dataIndex: 'teacher',
  key: "teacher_name",
  render: (_,record) => <span>{record?.teacher?.name}</span>
},

{ 
  title: "Start Date",
  dataIndex: "start_date",
  key: "start_date",
  render: createdDate=> <span>{dayjs(createdDate).format('DD MMM YYYY')}</span>
},
{ 
  title: "End Date",
  dataIndex: "end_date",
  key: "end_date",
  render: date => <span>{dayjs(date).format('DD MMM YYYY')}</span>
},
{ 
  title: "Price",
  dataIndex: "amount",
  key: "amount",
  render: (price,record)=> <span>{record?.currency}{" "}{price}</span>
},
{ 
  title: "Feature course",
  dataIndex: "featured",
  key: "featured",
  render:(featured,record)=><FeatureSwitch isCategory={false} isActive={featured||false} record={record}  id={record?.code} entity={record?.entity} />
},
{ 
  title: "Delete",
  dataIndex: "",
  key: "delete",
  render:(_,record)=><DeleteCourseIcon record={record}  slug={record?.slug} />
},
]


export const recordingSeriesColumns = [
  {
    title: "Series Name",
    dataIndex: 'title',
    key: "title",
  },
{
  title: "Teacher Name",
  dataIndex: 'teacher_name',
  key: "teacher_name",
},
{ 
  title: "Duration",
  dataIndex: "duration",
  key: "duration",
},

{ 
  title: "Created",
  dataIndex: "created_at",
  key: "created_at",
  render: createdDate=> <span>{dayjs(createdDate).format('DD MMM YYYY')}</span>
},
{ 
  title: "Feature course",
  dataIndex: "featured",
  key: "featured",
  render:(featured,record)=><FeatureSwitch isCategory={false} isActive={featured||false} record={record}  id={record?.code} entity={record?.entity} />
},
{ 
  title: "Delete",
  dataIndex: "",
  key: "delete",
  render:(_,record)=><DeleteCourseIcon record={record}  slug={record?.slug} isRecording={true} />
},
]

export const courseCategoryColumns = [
{
  title: "Course Name",
  dataIndex: 'course_url',
  key: "course_url",
  render: (url,record)=><a href={url} target='_blank' rel="noreferrer"  >{record?.heading}</a>
},
{ 
  title: "Start Date",
  dataIndex: "start_date",
  key: "start_date",
},
{ 
  title: "End Date",
  dataIndex: "end_date",
  key: "end_date",
},
{ 
  title: "Price",
  dataIndex: "amount",
  key: "amount",
  render: (price,record)=> <span>{record?.currency}{" "}{price}</span>
},
{ 
  title: "Feature course",
  dataIndex: "featured",
  key: "featured",
  render:(featured,record)=><FeatureSwitch isCategory={true}  isActive={featured} record={record}  id={record?.code} />
},
]


export const addCollectionFormlData =[
  
    {
      label: "Heading",
      name: "name",
      type: "text",
      placeholder: "Please add a heading",
    },
    {
      label: "Slug",
      name: "slug",
      type: "text",
      placeholder: "Please add available slug",
    },
    {
      label: "Description",
      name: "description",
      type: "textArea",

    
      placeholder: "Please enter description",
    },
    {
      label: "Web Banner",
      name: "web",
      type: "text",
    
      placeholder: "Please enter link to web banner [Dimensions - 1440x260]",
    },
    {
      label: "Mobile Banner",
      name: "mobile",
      type: "text",
    
      placeholder: "Please enter link to mobile banner [Dimensions - 400 x 80]",
    },
    {
      label: "Collection Icon",
      name: "circular_icon",
      type: "text",
      placeholder: "Please enter link to collection icon [Dimensions - 260x260]",
    },
    {
        label: "Show on homepage",
        name: "discoverable",
        type: "switch",
        checkedChildren:<CheckOutlined />,
      unCheckedChildren:<CloseOutlined />,
      defaultChecked:false
      },
      
  ]

  export const updateCategoryFormData =[
  
    {
      label: "Heading",
      name: "display_text",
      type: "text",
      placeholder: "Please add a heading",
      disabled: true
    },
    
    {
      label: "Description",
      name: "description",
      type: "textArea",

    
      placeholder: "Please enter description",
    },
    {
      label: "Web Banner",
      name: "web_banner",
      type: "text",
    
      placeholder: "Please enter link to web banner [Dimensions - 1440x260]",
    },
    {
      label: "Mobile Banner",
      name: "mobile_banner",
      type: "text",
    
      placeholder: "Please enter link to mobile banner [Dimensions - 400 x 80]",
    },
    {
      label: "Category Icon",
      name: "icon",
      type: "text",
    
      placeholder: "Please enter link to category icon [Dimensions - 260x260]",
    },
      
  ]


  export const returnMediaTypeByUrl = (enteredurl) =>{
    const images = ["jpg", "gif", "png","svg","jpeg","webp"]
    const videos = ["mp4", "3gp", "ogg"]
    if (checkURL(enteredurl)) {
      const url =  new URL(enteredurl);
      const extension = url.pathname.split(".")[1]
      if (images.includes(extension)) return 'image'  
      if (videos.includes(extension)) return 'video'
      return null
    }
    return null;
      
  }

  export const convertTextToSlug =value=>{
      return value.toString().replace(/\s+/g,"-");
  }