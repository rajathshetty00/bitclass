import React from 'react'
import { Tabs } from 'antd';
import { CopyrightOutlined, ClusterOutlined } from '@ant-design/icons';
import { Category, Collection } from './components';

const { TabPane } = Tabs;

const CollectionCategoryPage = () => {
  return (
    <main id="Collection_and_category" className="collection_container" >
        <Tabs defaultActiveKey="1">
    <TabPane tab={
        <span>
         <CopyrightOutlined />
         Collection
        </span>
      }
      key="1"
    >
      <Collection />
    </TabPane>
    <TabPane
      tab={
        <span>
          <ClusterOutlined />
          Category
        </span>
      }
      key="2"
    >
        <Category />
    </TabPane>
  </Tabs>
    </main>
  )
}

export default CollectionCategoryPage