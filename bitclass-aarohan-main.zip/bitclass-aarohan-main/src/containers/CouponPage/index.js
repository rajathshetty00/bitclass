/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect, useRef } from "react"
import { useDispatch, useSelector } from "react-redux"
import {
  Card,
  Input,
  Button,
  Table,
  Tag,
  Tooltip,
  message,
  Popconfirm,
  Modal,
  Form,
  Select,
  DatePicker,
  InputNumber,
  Row,
  Col,
} from "antd"
import { LoadingOutlined, CopyOutlined, SettingOutlined } from "@ant-design/icons"
import clsx from "clsx"
import moment from "moment"

import styles from "./styles.module.scss"
import { fetchData } from "../../actions/coupon"
import {  copyText, exists, generateRandomWord } from "../../utils"
import { addCoupon, deleteCoupon } from "../../utils/api"
import { READABLE_DATE_FORMAT, WEB_URL } from "../../constants"
import { Copy, Settings } from "react-feather"
import { ReactComponent as SuccessTick } from '../../assets/svg/successTick.svg'

const { Option } = Select
const COUPON_LENGTH = 5

const CouponDashboard = () => {
  //states
  const [courseCode, setCourseCode] = useState("")
  const [course, setCourse] = useState("")

  const [generatedCouponCode, setGeneratedCouponCode] = useState("")

  const [showAddPopUp, setShowAddPopup] = useState(false)
  const [isGlobal, setIsGlobal] = useState(false)
  const [showCouponSuccessModal, setShowCouponSuccessModal] = useState(false)
  // refs
  const showCouponBtnRef = useRef()
  const addCouponFormRef = useRef()

  //redux
  const dispatch = useDispatch()
  const { data, loading } = useSelector((state) => ({
    data: state.coupon.data,
    loading: state.coupon.loading,
  }))

  const _deleteCoupon = (code) => {
    if (!exists(code)) {
      message.error("Code not found")
      return
    }
    const loading = message.loading("Deleting data...")
    deleteCoupon(code)
      .then((res) => {
        loading()
        if (exists(res.success) && res.success) {
          if (courseCode) dispatch(fetchData(courseCode))
          message.success("Successfully deleted")
        } else {
          message.error("Failed to delete coupon")
        }
      })
      .catch((err) => {
        console.log(err)
        message.error("Failed to delete coupon")
      })
  }

  // Generate random coupon
  const generateRandomCoupon = () => {
    const randomWord = generateRandomWord(COUPON_LENGTH)
    setGeneratedCouponCode(randomWord)
    addCouponFormRef.current.setFields([{name:'discountCode',value:randomWord}])
  }

  const TableModel = [
    {
      title: "Coupon Code",
      align: "center",
      dataIndex: "discount_code",
      width: 200,
      render: (tag) => (
        <Tooltip
          title="Click to copy"
          onClick={() => {
            copyText(tag)
            message.info("Coupon copied")
          }}
        >
          <Tag className={styles.tag} color="#108ee9" icon={<CopyOutlined />}>
            {tag}
          </Tag>
        </Tooltip>
      ),
    },
    {
      title: "Type",
      align: "center",
      dataIndex: "discount_type",
      width: 100,
    },
    {
      title: "Discount",
      align: "center",
      dataIndex: "discount_value",
      width: 200,
    },
    {
      title: "Currency",
      align: "center",
      dataIndex: "discount_currency",
      width: 100,
    },
    {
      title: "Maximum Usage Limit",
      align: "center",
      dataIndex: "max_usage_count",
      width: 200,
    },
    {
      title: "Expiry Date",
      align: "center",
      dataIndex: "expiry",
      width: 200,
      render: (exp) => (
        <span>
          {exists(exp) ? moment.unix(exp).format(READABLE_DATE_FORMAT) : ""}
        </span>
      ),
    },
    {
      title: "Action",
      align: "center",
      dataIndex: "code",
      width: 200,
      render: (code) => (
        <Popconfirm
          placement="topRight"
          title="Are you sure to delete this coupon?"
          onConfirm={() => _deleteCoupon(code)}
          okText="Yes"
          cancelText="No"
        >
          <a href="#">Delete</a>
        </Popconfirm>
      ),
    },
  ]

  const showCouponBtnHandler = () => {
    if (!courseCode) return
    dispatch(fetchData(courseCode))
  }

  const removeWhiteSpace = (string) => string.replace(/\s/g, "")

  const addCouponFormHandler = async (data) => {
    const _couponData = { ...data }
    try {
      _couponData.expiry = _couponData.expiry.unix()
      _couponData.discountCode = removeWhiteSpace(
        _couponData.discountCode.toUpperCase()
      )
      if (_couponData.category !== "global") {
        _couponData.productCode = removeWhiteSpace(_couponData.productCode)
      }
      if (_couponData.discountValue <= 0) {
        message.error("Discount value should be greater than 0")
        return
      }
      if (_couponData.category === "global") {
        _couponData.productCode = null
      }
      let loading = message.loading("Adding coupon...")
      let res = await addCoupon(_couponData)
      loading()
      if (exists(res.success) && res.success) {
        if (courseCode) dispatch(fetchData(courseCode))
        message.success("Successfully added coupon")
        setShowAddPopup(false)
        setShowCouponSuccessModal(true)
        addCouponFormRef.current.resetFields()
      } else {
        message.error("Failed to add coupon")
      }
    } catch (err) {
      console.log(err)
      message.error("Failed to add coupon")
    }
  }

  const validateValue = (rule, value, callback) => {
    try {
      let output = Number(value)

      if (
        (output < 1 || output > 100 || isNaN(output)) &&
        addCouponFormRef?.current?.getFieldValue("discountType") ===
          "percentage"
      ) {
        return Promise.reject("Please enter percentage between 1 to 100")
      }
      return Promise.resolve()
    } catch (err) {
      return Promise.reject(err)
    }
  }
   const validateCoupon = (rule, value, callback) => {
    try {
      let output = String(value)
      if (output.length===0||output==="undefined") {
        return Promise.reject("Coupon code is mandatory");

      }
      else if (output.indexOf(' ') >= 0) {
        return Promise.reject("Please remove white space")
      }
      return Promise.resolve()
    } catch (err) {
      return Promise.reject(err)
    }
  }

  const valueChangeHandler = (data) => {
    const formData = { ...data }
    if (formData && formData.category) {
      if (formData.category === "global") {
        setIsGlobal(true)
      } else setIsGlobal(false)
    }
    if (formData && formData.productCode) {
      setCourse(formData.productCode)
    }
  }
  

  return (
    <div className={styles.mainContainer}>
      {/* Filter Section */}
      <Card
        className={clsx(styles.filters, "roundedCard")}
        bodyStyle={{
          display: "flex",
          alignItems: "center",
          flexDirection: "row",
        }}
      >
        <Input
          placeholder="Search by course code"
          value={courseCode}
          className={styles.inputs}
          onChange={(e) => {
            setCourseCode(e.currentTarget.value)
          }}
          onKeyPress={(e) => {
            if (e?.code === "Enter") {
              showCouponBtnRef?.current?.click()
            }
          }}
        />
        <Button
          type={"default"}
          onClick={showCouponBtnHandler}
          ref={showCouponBtnRef}
        >
          Show Coupons
        </Button>

        <Button
          type={"primary"}
          className={styles.addCouponBtn}
          onClick={() => setShowAddPopup(true)}
        >
          Add Coupon
        </Button>
      </Card>
      {/* Filter Section Ends */}

      {/* Table Section */}
      <Table
        columns={TableModel}
        size={"small"}
        dataSource={data}
        bordered
        loading={{
          spinning: loading,
          indicator: <LoadingOutlined type="loading" />,
        }}
      />
      {/* Table Section Ends */}

      {/* add modal */}
      <Modal
        title="Add Coupon"
        centered
        visible={showAddPopUp}
        onCancel={() => {
          addCouponFormRef.current.resetFields()
          setShowAddPopup(false)
        }}
        footer={null}
      >
        <Form
          ref={addCouponFormRef}
          className={styles.addCouponForm}
          onFinish={addCouponFormHandler}
          onValuesChange={valueChangeHandler}
        >
          <Form.Item
            name="category"
            rules={[
              {
                required: false,
                // message: "Discount type is mandatory"
              },
            ]}
            className={styles.couponInput}
          >
            <Select placeholder={"Category Type"}>
              {/* <Option value={"user"}>
                USER{" "}
                <span style={{ color: "#888888" }}>
                  (For a particular user)
                </span>{" "}
              </Option> */}
              <Option value={"course"}>
                COURSE{" "}
                <span style={{ color: "#888888" }}>
                  (For a particular course, any user)
                </span>{" "}
              </Option>
              <Option value={"tmpr"}>
                TMPR{" "}
                <span style={{ color: "#888888" }}>
                  (For all the demos of a course)
                </span>
              </Option>
              <Option value={"global"}>
                GLOBAL{" "}
                <span style={{ color: "#888888" }}>(Anyone, any course)</span>
              </Option>
            </Select>
          </Form.Item>
          {!isGlobal && (
            <Form.Item
              name="productCode"
              rules={[
                {
                  required: true,
                  message: "Course code is mandatory",
                },
              ]}
              className={styles.couponInput}
            >
              <Input placeholder="Course Code" />
            </Form.Item>
          )}
          <Form.Item className={styles.randomCouponGenerator}>
            <Form.Item
              name="discountCode"
              rules={[
                {
                  validator: validateCoupon,
                }
              ]}
            
              className={clsx(styles.couponInput, styles.couponInputField)}
            >
              <Input
                placeholder="Coupon - FLAT500.."
                value={generatedCouponCode}
                onChange={e=>setGeneratedCouponCode(e.target.value)}
              />
            </Form.Item>
            <Button
              type="primary"
              icon={<SettingOutlined />}
              onClick={generateRandomCoupon}
            >
              Generate
            </Button>
          </Form.Item>

          <Form.Item
            name="discountType"
            rules={[
              {
                required: true,
                message: "Discount type is mandatory",
              },
            ]}
            className={styles.couponInput}
          >
            <Select placeholder={"Type"}>
              <Option value={"flat"}>Flat</Option>
              <Option value={"percentage"}>Percentage</Option>
            </Select>
          </Form.Item>
          <Form.Item
            name="discountValue"
            rules={[
              {
                required: true,
                message: "Discount value is mandatory",
              },
              {
                validator: validateValue,
              },
            ]}
            className={styles.couponInput}
          >
            <InputNumber placeholder="Discount Value" min={1} />
          </Form.Item>
          <Form.Item
            name="expiry"
            rules={[
              {
                required: true,
                message: "Expiry is mandatory",
              },
            ]}
            className={styles.couponInput}
          >
            <DatePicker placeholder="Expiry Date" />
          </Form.Item>
          <Form.Item
            name="maxUsageCount"
            rules={[
              {
                required: true,
                message: "Max count is mandatory",
              },
            ]}
            className={styles.couponInput}
          >
            <InputNumber placeholder="Max Usage Count" min={1} max={1000} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Add coupon
            </Button>
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        title=""
        centered
        visible={showCouponSuccessModal}
        onCancel={() => setShowCouponSuccessModal(false)}
        footer={null}
      >
        <div className={styles.couponSuccess}>
          <SuccessTick />
          <h3 className={styles.title}>Your coupon is ready </h3>
          <div className={styles.copy}>
            <span className={styles.code}>{generatedCouponCode}</span>
            <button
              onClick={() =>{
                message.success('Coupon code copied')
                copyText(generatedCouponCode)}}
              className={styles.copyBtn}
            >
              <Copy className={styles.copyIcon} width="20px" color='white'/>
              <span>Copy Coupon</span>
            </button>
          </div>
          <br/>
          {course&&<div className={styles.copy}>
            <span className={styles.code}>{`${WEB_URL}/live-classes/${course}?couponCode=${generatedCouponCode}#checkout`}</span>
            <button
              onClick={() =>{
                message.success('Coupon code copied')
                copyText(`${WEB_URL}/live-classes/${course}?couponCode=${generatedCouponCode}#checkout`)}}
              className={styles.copyBtn}
            >
              <Copy className={styles.copyIcon} width="20px" color='white'/>
              <span>Copy discount URL</span>
            </button>
          </div>}
        </div>
      </Modal>
    </div>
  )
}

export default CouponDashboard