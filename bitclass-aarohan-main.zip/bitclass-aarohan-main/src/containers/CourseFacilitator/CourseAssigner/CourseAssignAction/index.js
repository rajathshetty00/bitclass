import { Button } from "antd"
import Modal from "antd/lib/modal/Modal"
import { useState } from "react"
import { Clock, Watch } from "react-feather"
import { initializeAutoAssignCourseFacilitators } from "../../../../actions/courseFacilitatorAction"
import useRedux from "../../../../helpers/useRedux"

import styles from "./styles.module.scss"

const CourseAssignerActions = () => {
  const [{ filters,autoAssignStatus }, dispatch] = useRedux("cf")
  const handleAutoAssign = () => {
    const { pageNum, ...restFilters } = filters
    dispatch(initializeAutoAssignCourseFacilitators(restFilters))
    setShowModal(true)
  }

  const [showModal, setShowModal] = useState(false)
  return (
    <div className={styles.buttons}>
      <Button type="primary" onClick={handleAutoAssign}>
        Auto Assign
      </Button>
      {/* <Button>Send Invites</Button> */}

      <Modal visible={showModal} footer={null} onCancel={()=>setShowModal(false)}>
        <center style={{marginTop:'1rem'}}><Clock size="40px" /></center>
        <h3 className={styles.autoAssignMsg}>
          Auto assign task {autoAssignStatus===false?"started":"is currently running"}.
          <br /> Please check back after 10 minutes.
        </h3>
      </Modal>
    </div>
  )
}

export default CourseAssignerActions
