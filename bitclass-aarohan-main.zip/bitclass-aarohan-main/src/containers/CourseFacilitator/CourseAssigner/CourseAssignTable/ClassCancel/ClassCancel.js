import { Modal, Button, Input } from 'antd';
import { useContext, useEffect, useState } from 'react';
import { setClassCancelData } from '../../../../../actions/courseFacilitatorAction';
import useRedux from '../../../../../helpers/useRedux';
import useFormValidator from '../../../../LaunchpadPage/Helper/useFormValidator';
import reasonValidator from '../../../helper/reasonValidator';
import styles from './style.module.scss'
// import useFormValidator from '../.';
const { TextArea } = Input;
const ClassCancel = ({ record, data, heading }) => {
    const [visible, setVisible] = useState(false);
    const [{ loadingupdateReson }, dispatch] = useRedux('cf');

    const [resonValue, setResonValue] = useState("")
    const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
        submitResonDataToServer,
        { resonValue },
        reasonValidator
    )


    function submitResonDataToServer() {
        const body = { reason: resonValue };
        const courseCode = record.code;
        dispatch(setClassCancelData(body, courseCode))
        setResonValue("");
        setVisible(false);
    }

    const onChangeResonField = (e) => {
        setErrors({})
        setIsSubmitting(false)
        setResonValue(e.target.value)

    }


    return (
        <>
            <div onClick={() => { setVisible(true) }} className={styles.cell_disp} >
                {data ? <p>{"Cancelled"}</p> :
                    <Button type="primary" >
                        Mark as 'Cancelled'
                    </Button>}
            </div>
            <Modal

                centeredradio_content
                visible={visible}
                onOk={handleSubmit}
                onCancel={() => setVisible(false)}
                width={700}
                okButtonProps={{ type: "primary" }}
                okText={<p>Submit</p>}
                className={styles.modelWrapper}
                confirmLoading={loadingupdateReson}
                closable={false}
            >
                <div className={styles.model_body}>
                    <h1>{heading} </h1>
                    <div className={styles.modelContent} >
                        <TextArea autoSize={{ minRows: 2, maxRows: 4 }} value={resonValue} placeholder="Please Enter the reson " allowClear onChange={onChangeResonField} />
                        {errors['resonValue'] && <p className={styles.error}>{errors['resonValue']}</p>}
                    </div>
                </div>
            </Modal>

        </>
    )
}

export default ClassCancel