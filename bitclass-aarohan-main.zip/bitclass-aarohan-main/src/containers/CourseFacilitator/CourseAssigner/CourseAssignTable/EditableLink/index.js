import { Edit3 } from "react-feather"
import styles from "./style.module.scss"
import { Input, Popover } from "antd"
import { useEffect, useState } from "react"
import { updateMetaOfCourse } from "../../../../../utils/api"
import useRedux from "../../../../../helpers/useRedux"
import { getCourseAssignerDetails } from "../../../../../actions/courseFacilitatorAction"

const { Search } = Input

const EditableLink = ({ data, record }) => {
  const [
    { 
      filters
    },
    dispatch,
  ] = useRedux("cf")

  const [editorClicked, setEditorClicked] = useState(false)
  const [link, setLink] = useState()

  useEffect(() => {
    setLink(data)
  }, [data])


  const editorClickHandler = () => {
    setEditorClicked(!editorClicked)
  }

  const onLinkEnterHandler =async(record, value)=>{
    setEditorClicked(false)
    await updateMetaOfCourse(record.code, {
      ppt_link: value.replace(/\s/g, '')
    })
    setLink(null)
    await dispatch(getCourseAssignerDetails(filters))
    setEditorClicked(false)
  }



  return (
    <div>
        <div
         className={styles.editablelinkWrapper}>
          <a href={link} target="_blank" disabled={link === null || link === ''}>
            PPT Link
          </a>
          <Popover

          visible = {editorClicked}
           content = {
           <Search
            onChange = {(e)=>setLink(e.target.value)}
            placeholder="Enter PPT Link"
            allowClear
            enterButton="OK"
            size="small"
            onSearch={(e)=>onLinkEnterHandler(record, e)}
            value = {link}
          />       
        }
        styles = {{
          zIndex: '1'
        }}
        >
          <Edit3 
            onClick={editorClickHandler} 
          />
          </Popover>
        </div>       
    </div>
  )
}

export default EditableLink
