import { Select } from "antd"
import { useEffect, useState } from "react"
import {
  getAvailableCfsByCourseCode,
  getCourseAssignerDetails,
  setCourseFacilitatorForCourse,
  unsetCourseFacilitatorFromCourse,
} from "../../../../../actions/courseFacilitatorAction"
import useRedux from "../../../../../helpers/useRedux"
import styles from "./styles.module.scss"

const { Option } = Select
const FacilitatorsDropdown = ({ data, record }) => {
  const [{ availableCourseFacilitators, filters }, dispatch] = useRedux("cf")
  const [selectedValue, setSelectedValue] = useState()
  useEffect(() => {
    setSelectedValue(data?.username)
  }, [data?.username])

  const onClearHandler = async () => {
    let res = await dispatch(
      unsetCourseFacilitatorFromCourse(record.code, data.id)
    )
    if (res) {
      setSelectedValue(null)
      dispatch(getCourseAssignerDetails(filters))
    }
  }

  const onselectCfHandler = async (code, id) => {
    let res = await dispatch(
      setCourseFacilitatorForCourse(code, id)
    )
    if (res) {
      setSelectedValue(null)
      dispatch(getCourseAssignerDetails(filters))
    }
  }

  return (
    <Select
      style={{ width: "100%" }}
      value={selectedValue}
      placeholder="Assign CF"
      onClick={(e) => {
        e.preventDefault()
        e.stopPropagation()
        dispatch(getAvailableCfsByCourseCode(record.code))
      }}
      onClear={() => onClearHandler()}
      optionFilterProp="children"
      filterOption={(input, option) => {
        return option?.value?.toLowerCase()?.indexOf(input.toLowerCase()) >= 0
      }}
      showSearch
      allowClear
      optionLabelProp="label"
    >
      <Option className={styles.separator} disabled>
        Available CFS
      </Option>

      {availableCourseFacilitators?.available_cfs?.map((facilitator) => (
        <Option value={facilitator.username} label={facilitator.username}>
          <div
            className={styles.option}
            onClick={()=>onselectCfHandler(record.code, facilitator.id)}
          >
            <span>{facilitator.username}</span>
            <div className={styles.available} />
          </div>
        </Option>
      ))}
      <Option className={styles.separator} disabled>
        Booked CFS
      </Option>
      {availableCourseFacilitators?.booked_cfs?.map((facilitator) => (
        <Option value={facilitator.username}>
          <div
            className={styles.option}
            onClick={()=>onselectCfHandler(record.code, facilitator.id)}
          >
            <span>{facilitator.username}</span>
            <div className={styles.booked} />
          </div>
        </Option>
      ))}
    </Select>
  )
}

export default FacilitatorsDropdown
