import { message, Tooltip } from "antd"
import { SET_LOADING_COURSE_FACILITATOR } from "../../../../../actions/types"
import { WEB_URL } from "../../../../../constants"
import useRedux from "../../../../../helpers/useRedux"
import { getDateFormat } from "../../../../../utils"
import { getUpsellLinkFromCourse } from "../../../../../utils/api"
import styles from "./style.module.scss"

const UpsellLink = ({ upsellCourses }) => {
  const openUpsellLink = (link) => {
    window.open(`${WEB_URL}/${link}`)
  }

  return (
    <ul className={styles.upsellLinkContainer}>
      {Array.isArray(upsellCourses) &&
        upsellCourses.map((item) => {
          return (
            <Tooltip
              overlayClassName={styles.tooltipClassname}
              title={
                <>
                  {getDateFormat(item["start_ts"], "DD/MMM/YYYY")}
                  &nbsp;to&nbsp;
                  {getDateFormat(item["end_ts"], "DD/MMM/YYYY")}
                  <br />
                  <a
                    target="_blank"
                    rel="noreferrer"
                    href={`${WEB_URL}/live-classes/${item["code"]}`}
                  >
                    {item["heading"]}
                  </a>
                </>
              }
              color="blue"
            >
              <li
                className={styles.upsellLink}
                onClick={() => openUpsellLink(item["relative_course_url"])}
              >
                {getDateFormat(item["start_ts"], "DD/MMM/YYYY")} to
                {getDateFormat(item["end_ts"], "DD/MMM/YYYY")}
                <br />
                {item["heading"].substring(0, 20)}
                {item["heading"].length > 20 && "..."}
              </li>
            </Tooltip>
          )
        })}
    </ul>
  )
}

export default UpsellLink
