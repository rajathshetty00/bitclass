import { Table } from "antd"
import { SAVE_SELECTED_ROW, SET_CURRENT_PAGE, SET_CURRENT_PAGE_LIMIT } from "../../../../actions/types"
import useRedux from "../../../../helpers/useRedux"
import { courseAssignerColumn } from "./table"

const CourseAssignTable = () => {
  const [{ totalRecords, courseAssignerData,loading,currentPage }, dispatch] = useRedux("cf")

  return (
    <Table
      columns={courseAssignerColumn}
      dataSource={courseAssignerData}
      bordered
      scroll={{ x: "max-width" }}
      loading={loading}
      pagination={{
        current:currentPage,
        onChange: (pageCount, limit = 10) => {
            dispatch({ type: SET_CURRENT_PAGE, payload: pageCount })
            dispatch({type: SET_CURRENT_PAGE_LIMIT, payload: limit})
          },
        total: totalRecords,
        defaultCurrent: 1,
      }}
      onRow={(record) => {
        return {
          onClick: () => {
            dispatch({ type: SAVE_SELECTED_ROW, payload: record })
          },
        }
      }}
    />
  )
}

export default CourseAssignTable
