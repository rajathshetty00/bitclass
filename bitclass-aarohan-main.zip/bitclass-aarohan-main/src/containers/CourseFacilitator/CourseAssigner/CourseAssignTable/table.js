import dayjs from "dayjs"

import ClassCancel from "./ClassCancel/ClassCancel"
import EditableLink from "./EditableLink"
// import EditableLink from "./EditableLink"
import FacilitatorsDropdown from "./Facilitators"
import UpsellLink from "./UpsellLink"
import styles from "./styles.module.scss"

const BIT_CLASS_URL = `https://www.bitclass.live`
const cancelheading = "Are you sure the class is to be cancelled...?"
const checkIsPastCourse = (endDate) => {
  const currentMiliSecTime = dayjs(new Date()).unix()
  if (endDate < currentMiliSecTime) return true
  return false
}
const renderSwitch = (isCancel, tableData) => {
  switch (isCancel) {
    case true:
      return <h1 className={styles.cancelText}> Cancelled</h1>
    case false:
      return (
        <ClassCancel
          heading={cancelheading}
          data={isCancel}
          record={tableData}
        />
      )
    default:
      return <h1 className={styles.cancelText}> Cancelled</h1>
  }
}
const CellLink = ({ data, record }) => (
  <a
    href={`https://www.bitclass.live/live-courses/${record.code}`}
    target="_blank"
  >
    {data}
  </a>
)

const getFormattedDate = (date = "") => {
  const newDate = dayjs.unix(date)
  const formattedDate = newDate.format("DD MMM YYYY, hh:mm A")
  return `${formattedDate}`
}

export const courseAssignerColumn = [
  {
    title: "Course Name",
    dataIndex: "heading",
    key: "heading",
    width: 400,
    fixed: "left",
    sorter: (a, b) => {
      if (a.heading < b.heading) return -1
      if (a.heading > b.heading) return 1
      return 0
    },
    render: (data, record) => <CellLink data={data} record={record} />,
  },
  {
    title: "Teacher name",
    dataIndex: "teacher",
    key: "teacher",
    width: 200,
    sorter: (a, b) => {
      if (a.teacher.teacher_name < b.teacher.teacher_name) return -1
      if (a.teacher.teacher_name > b.teacher.teacher_name) return 1
      return 0
    },
    render: (data) => <>{data.teacher_name}</>,
  },
  {
    title: "Dates",
    dataIndex: "start_ts",
    key: "start_ts",
    width: 200,
    sorter: (a, b) => a.start_ts - b.start_ts,
    render: (date) => <>{getFormattedDate(date)}</>,
  },
  {
    title: "Course Duration (Minutes)",
    dataIndex: "duration",
    key: "duration",
    width: 120,
    sorter: (a, b) => a.duration - b.duration,
  },
  {
    title: "Amount",
    dataIndex: "amount",
    key: "amount",
    width: 120,
    sorter: (a, b) => a.amount - b.amount,
  },
  {
    title: "Registered Students",
    dataIndex: "registration_count",
    key: "registration_count",
    sorter: (a, b) => a.registration_count - b.registration_count,
    // render: (data) => <Actions data={data} />,
    width: 120,
  },
  {
    title: "Course Facilitator",
    dataIndex: "course_facilitator",
    key: "course_facilitator",
    render: (data, record) => (
      <FacilitatorsDropdown data={data} record={record} />
    ),
    width: 250,
  },
  {
    title: "Upsell Link",
    dataIndex: "upsell_link",
    key: "upsell_link",
    width: 200,
    render: (data, record) => (
      <UpsellLink upsellCourses={record["upsell_courses"]} />
    ),
  },
  {
    title: "PPT Link",
    dataIndex: "ppt_link",
    key: "ppt_link",
    render: (data, record) => <EditableLink data={data} record={record} />,
    width: 140,
  },
  {
    title: "Live Class",
    dataIndex: "go_live",
    key: "go_live",
    render: (_, record) => (
      <a href={`${BIT_CLASS_URL}/live-classes/classroom/${record.code}`} target="_blank">
        GO LIVE
      </a>
    ),
    width: 140,
  },
  {
    title: "Cancel Class",
    dataIndex: "is_deleted",
    key: "cancelClass",
    render: (data, record) => {
      return checkIsPastCourse(record.end_ts) ? (
        <h1 className={styles.cancelText}> Past Class</h1>
      ) : (
        renderSwitch(data, record)
      )
    },
    width: 190,
  },
]
