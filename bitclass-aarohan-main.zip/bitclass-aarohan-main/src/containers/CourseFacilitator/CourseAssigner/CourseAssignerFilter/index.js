import { Button, DatePicker, Select, Checkbox } from "antd"
import Search from "antd/lib/input/Search"
import { useDispatch } from "react-redux"
import { getCourseAssignerDetails } from "../../../../actions/courseFacilitatorAction"
import moment from "moment"
import {
  SET_DATE_RANGE,
  SAVE_SEARCH,
  SAVE_SELECTED_COURSE_FACILITATOR,
  SAVE_SEARCH_TYPE,
  SET_FILTERED_CF_NAME,
  SAVE_PRICE_FILTER,
  FILTER_PPT_LINK,
  FILTER_UPSELL_LINK,
  FILTER_BY_ASSIGN,
} from "../../../../actions/types"
import useRedux from "../../../../helpers/useRedux"
import {
  getDateRange,
  RANGE,
  THIS_WEEK,
  TODAY,
  TOMORROW,
  YESTERDAY,
} from "../../helper"
import styles from "./styles.module.scss"
import { ASSIGNED, PPT, PRICE, UPSELL } from "../constants"
import { getDateFormat } from "../../../../utils"

const { RangePicker } = DatePicker
const { Option } = Select
const CourseAssignerFilters = () => {
  const [
    {
      currentCourseFacilitator,
      selectedDateType,
      allCourseFacilitators,
      searchType,
      filters,
      filteredCfName,
      currentPrice,
      filterByPptLink,
      filterByUpsellLink,
      filterByAssign,
    },
    dispatch,
  ] = useRedux("cf")

  const saveDateRange = (moment = []) => {
    if (moment === null || moment.length < 1) return
    dispatch({
      type: SET_DATE_RANGE,
      payload: {
        startDate: moment[0].set({ hour: 0, minute: 0, seconds: 0 }).unix(),
        endDate: moment[1].set({ hour: 23, minute: 59, seconds: 59 }).unix(),
        dateType: RANGE,
      },
    })
  }
  const handleSearch = (value) => {
    dispatch({ type: SAVE_SEARCH, payload: value })
  }
  const saveSearchType = (value) => {
    dispatch({ type: SAVE_SEARCH_TYPE, payload: value })
  }
  const handleSearchCourseFacilitator = (value = "", obj) => {
    dispatch({ type: SAVE_SELECTED_COURSE_FACILITATOR, payload: value })
    dispatch({
      type: SET_FILTERED_CF_NAME,
      payload: obj?.children,
    })
  }
  const handleFilter = (value = "", type) => {
    switch (type) {
      case PRICE:
        return dispatch({ type: SAVE_PRICE_FILTER, payload: value })
      case PPT:
        return dispatch({ type: FILTER_PPT_LINK, payload: value })
      case UPSELL:
        return dispatch({ type: FILTER_UPSELL_LINK, payload: value })
      case ASSIGNED:
        return dispatch({ type: FILTER_BY_ASSIGN, payload: value })
      default:
        break
    }
  }

  const handleDateChange = (period) => {
    getDateRange(period, dispatch)
  }

  const handleCheckboxClick = (e, type) => {
    switch (type) {
      case PPT:
        return dispatch({ type: FILTER_PPT_LINK, payload: e.target.checked })
      case UPSELL:
        return dispatch({ type: FILTER_UPSELL_LINK, payload: e.target.checked })
      case ASSIGNED:
        return dispatch({ type: FILTER_BY_ASSIGN, payload: e.target.checked })
      default:
        break
    }
  }

  const getButtonType = (period) =>
    selectedDateType === period ? "primary" : "default"
  return (
    <div className={styles.filters}>
      <div className={styles.courseAssignerFilter}>
        <span>Select date range</span>
        <Button
          onClick={() => handleDateChange(YESTERDAY)}
          type={getButtonType(YESTERDAY)}
        >
          Yesterday
        </Button>
        <Button
          onClick={() => handleDateChange(TODAY)}
          type={getButtonType(TODAY)}
        >
          Today
        </Button>
        <Button
          onClick={() => handleDateChange(TOMORROW)}
          type={getButtonType(TOMORROW)}
        >
          Tomorrow
        </Button>
        <Button
          onClick={() => handleDateChange(THIS_WEEK)}
          type={getButtonType(THIS_WEEK)}
        >
          This Week
        </Button>
        <RangePicker
          className={styles.inputs}
          style={{ maxWidth: 250, width: 250 }}
          onChange={(moments, dates) => {
            if (!moments) {
              handleDateChange(TODAY)
              getButtonType(TODAY)
            } else {
              saveDateRange(moments)
            }
          }}
          type={getButtonType(RANGE)}
          format="DD/MM/YYYY"
          defaultValue={
            selectedDateType === RANGE
              ? [
                  moment(getDateFormat(filters?.start_ts, "MM/DD/YYYY")),
                  moment(getDateFormat(filters?.end_ts, "MM/DD/YYYY")),
                ]
              : null
          }
          onPanelChange={() => console.log("trigerred")}
          allowClear
        />
      </div>
      <div className={styles.courseAssignerSearch}>
        <Select
          placeholder="Search by"
          onChange={saveSearchType}
          value={searchType}
          allowClear
          onClear={saveSearchType}
        >
          <Option value="course">By course name</Option>
          <Option value="teacher">By teacher name</Option>
          <Option value="course_code">By course code</Option>
        </Select>
        <Search
          placeholder="Type here to search"
          allowClear
          enterButton="Search"
          onSearch={handleSearch}
          onClear={handleSearch}
          defaultValue={filters?.q}
        />
        <Select
          placeholder="Filter by Course Facilitator"
          onChange={handleSearchCourseFacilitator}
          showSearch
          allowClear
          onClear={handleSearchCourseFacilitator}
          optionFilterProp="children"
          filterOption={(input, option) => {
            return (
              option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            )
          }}
          filterSort={(optionA, optionB) => {
            return optionA.children
              .toLowerCase()
              .localeCompare(optionB.children.toLowerCase())
          }}
          defaultValue={filteredCfName}
        >
          {allCourseFacilitators.map((facilitator) => (
            <Option value={facilitator.id}>{facilitator.username}</Option>
          ))}
        </Select>
      </div>
      <div className={styles.courseAssignerThirdRowFilter}>
        <Select
          placeholder="Filter by Price"
          onChange={(value) => handleFilter(value, PRICE)}
          showSearch
          allowClear
          onClear={() => handleFilter(null, PRICE)}
          optionFilterProp="children"
          defaultValue={currentPrice}
          width="120"
        >
          <Option value="0">Free</Option>
          <Option value="99">99</Option>
        </Select>

        <Select
          placeholder="Filter by PPT Link"
          onChange={(value) => handleFilter(value, PPT)}
          showSearch
          allowClear
          onClear={() => handleFilter(null, PPT)}
          optionFilterProp="children"
          defaultValue={filterByPptLink}
          width="120"
        >
          <Option value={true}>Yes</Option>
          <Option value={false}>No</Option>
        </Select>

        <Select
          placeholder="Filter by Assigned/Unassigned"
          onChange={(value) => handleFilter(value, ASSIGNED)}
          showSearch
          allowClear
          onClear={() => handleFilter(null, ASSIGNED)}
          optionFilterProp="children"
          defaultValue={filterByAssign}
          className={styles.assignSelect}
        >
          <Option value={true}>Yes</Option>
          <Option value={false}>No</Option>
        </Select>
      </div>
    </div>
  )
}

export default CourseAssignerFilters
