export const PPT = 'PPT'
export const UPSELL = 'UPSELL'
export const ASSIGNED = 'ASSIGNED'
export const PRICE = 'PRICE'