import CourseAssignerFilters from "./CourseAssignerFilter"
import CourseAssignerActions from "./CourseAssignAction"
import styles from "./styles.module.scss"
import CourseAssignTable from "./CourseAssignTable"
import useRedux from "../../../helpers/useRedux"
const CourseAssigner = () => {
  const [{ totalAssignedCfs, totalRecords }] = useRedux("cf")
  return (
    <div className={styles.courseAssigner}>
      <div className={styles.filters}>
        <CourseAssignerFilters />
        <CourseAssignerActions />
      </div>
      <div className={styles.tableDetails}>
        {totalRecords} Upcoming courses (Assigned: {totalAssignedCfs},
        Unassigned: {totalRecords - totalAssignedCfs})
      </div>
      <CourseAssignTable />
    </div>
  )
}

export default CourseAssigner
