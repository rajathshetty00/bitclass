import { Select, DatePicker } from "antd"
import Search from "antd/lib/input/Search"
import styles from "./styles.module.scss"

const { Option } = Select
const { RangePicker } = DatePicker

const CourseCalendarFilters = () => {
  return (
    <div>
      <div className={styles.courseCalendarFilters}>
        <Select placeholder="View by" className={styles.viewSelect}>
          <Option value="date">Date</Option>
          <Option value="course_facilitator">Course Facilitator</Option>
          <Option value="category">Category</Option>
          <Option value="teacher">Teacher</Option>
        </Select>
        <RangePicker
          className={styles.inputs}
          style={{ maxWidth: 250, width: 250 }}
          // value={dateRange}
          // onChange={(d, v) => searchHandler("date_range", v, d)}
        />
        <Search placeholder="Type here to search" className={styles.search} />
      </div>
    </div>
  )
}

export default CourseCalendarFilters
