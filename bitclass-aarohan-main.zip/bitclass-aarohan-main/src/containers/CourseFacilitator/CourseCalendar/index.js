import { Table } from "antd"
import { useDispatch } from "react-redux"
import { SAVE_SELECTED_ROW } from "../../../actions/types"
import { getTableColumns } from "../../../helpers/tableColumn"
import CourseCalendarFilters from "./CourseCalendarFilters"
import styles from "./styles.module.scss"
import { dummyDataSource } from "./tableDummyData"

const CourseCalendar = () => {
  const dispatch = useDispatch()
  return (
    <div>
      <CourseCalendarFilters />
      <div className={styles.table}>
        <Table
          columns={getTableColumns(dummyDataSource[0])}
          dataSource={dummyDataSource}
          bordered
          scroll={{ x: "max-width" }}
          onRow={(record) => {
            return {
              onClick: () => {
                dispatch({ type: SAVE_SELECTED_ROW, payload: record })
              },
            }
          }}
        />
      </div>
    </div>
  )
}

export default CourseCalendar
