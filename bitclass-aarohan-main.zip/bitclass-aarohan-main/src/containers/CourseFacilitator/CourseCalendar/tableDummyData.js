export const dummyDataSource = [
  {
    category_name:"Test Category",
    '10 June': {
      date: "Go Live",
      link: "#",
    },
    '10 June': {
      date: "Go Live",
      link: "#",
    },
    '10 June': {
      date: "Go Live",
      link: "#",
    },
    '10 June': {
      date: "Go Live",
      link: "#",
    },
    '10 June': {
      date: "Go Live",
      link: "#",
    },
  },
]
