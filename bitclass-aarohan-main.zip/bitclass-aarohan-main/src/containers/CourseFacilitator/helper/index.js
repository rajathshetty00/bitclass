import dayjs from "dayjs"
import { SET_DATE_RANGE } from "../../../actions/types"

export const TODAY = "TODAY"
export const YESTERDAY = "YESTERDAY"
export const TOMORROW = "TOMORROW"
export const THIS_WEEK = "THIS_WEEK"
export const RANGE = "RANGE"

export const constructFilterParams =(filters)=>{
  let filterParams=''
  Object.entries(filters).forEach(filter=>filterParams+=`&${filter[0]}=${filter[1]}`)
  return filterParams
}

export const getDateRange = (period, dispatch) => {
  const date = dayjs()
  let startDate, endDate
  const day = date.get("date"),
    month = date.get("month"),
    year = date.get("year")

  switch (period) {
    case TODAY:
      startDate = dayjs(new Date(year, month, day)).unix()
      endDate = dayjs(new Date(year, month, day, 23, 59, 59)).unix()
      break

    case YESTERDAY:
      startDate = dayjs(new Date(year, month, day - 1)).unix()
      endDate = dayjs(new Date(year, month, day - 1, 23, 59, 59)).unix()
      break

    case TOMORROW:
      startDate = dayjs(new Date(year, month, day + 1)).unix()
      endDate = dayjs(new Date(year, month, day + 1, 23, 59, 59)).unix()
      break
    case THIS_WEEK:
      startDate = dayjs(new Date(year, month, day)).unix()
      endDate = dayjs(new Date(year, month, day + 7, 23, 59, 59)).unix()
      break
  }
  dispatch({
    type: SET_DATE_RANGE,
    payload: { startDate, endDate, dateType: period },
  })
}
