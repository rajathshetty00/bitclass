import { isEmpty } from 'lodash-es';
export default function reasonValidator(values) {
    const errors = {};
    if (isEmpty(values['resonValue'])) {

        errors['resonValue'] = "Please enter the reason";
    }


    return errors;
}