import { Card, Tabs } from "antd"
import clsx from "clsx"
import { useEffect } from "react"
import {
  getCourseAssignerDetails,
  saveAllCourseFacilitators,
} from "../../actions/courseFacilitatorAction"
import { cardBodyStyle } from "../../helpers/cardBodyStyle"
import CourseAssigner from "./CourseAssigner"
import CourseCalendar from "./CourseCalendar"
import useRedux from "../../helpers/useRedux"
import styles from "./styles.module.scss"
import Loader from "../../atoms/Loader"
import { SUCCESS_CANCEL_TEACHER } from "../../actions/types"

const { TabPane } = Tabs
const CourseFacilitator = () => {
  const [
    {
      filters,
      startDate,
      endDate,
      currentCourseFacilitator,
      searchValue,
      currentPage,
      currentPageLimit,
      currentPrice,
      filterByPptLink,
      filterByUpsellLink,
      filterByAssign,
      errorMessage,
      loading,
      isResonUpdated,
    },
    dispatch,
  ] = useRedux("cf")

  useEffect(() => {
    dispatch(getCourseAssignerDetails(filters))
  }, [
    startDate,
    endDate,
    currentCourseFacilitator,
    searchValue,
    currentPage,
    currentPageLimit,
    currentPrice,
    filterByPptLink,
    filterByUpsellLink,
    filterByAssign,
  ])

  useEffect(() => {
    if (isResonUpdated) {
      dispatch(getCourseAssignerDetails(filters))
      dispatch({ type: SUCCESS_CANCEL_TEACHER, payload: false })
    }
  }, [isResonUpdated])

  useEffect(() => {
    dispatch(saveAllCourseFacilitators())
  }, [])

  return (
    <>
      <Card
        className={clsx("roundedCard", styles.courseFacilitator)}
        bodyStyle={cardBodyStyle}
      >
        <Tabs defaultActiveKey="1" onChange={() => {}} className={styles.tabs}>
          <TabPane tab="Course Assigner" key="1">
            <CourseAssigner />
          </TabPane>
          <TabPane tab="Course Calendar" key="2">
            <CourseCalendar />
          </TabPane>
        </Tabs>
      </Card>
    </>
  )
}

export default CourseFacilitator
