import { message } from "antd";
import React, { useEffect, useState } from "react";
import { ImageUrl, InputDescription, InputTitle,Spacer } from "..";
import {
  handleChangeTab,
  submitAboutCourseData,
} from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import { TabKeyList } from "../../tabConfig";
import aboutCourseValidator from "../../validators/about";
import SaveBtn from "../shared/SaveBtn";
import styles from "./styles.module.scss";

// Actually this is Banner section in the curriculum cdp
const AboutCourse = () => {
  const [
    {
      curriculumData: { heading, goal, intro_video, intro_video_thumbnail },
    },
    dispatch,
  ] = useRedux("curriculumReducer");
  const [banner, setBanner] = useState({
    heading: "",
    goal: "",
    intro_video: "",
    intro_video_thumbnail: "",
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...banner },
    aboutCourseValidator
  );
// called while click the save button 
  function onSubmit() {
    dispatch(
      submitAboutCourseData({
        heading: banner.heading,
        goal: banner.goal,
        intro_video: banner.intro_video,
        intro_video_thumbnail: banner.intro_video_thumbnail,
      })
    );
    message.success("Successfully save your data to store");
    dispatch(handleChangeTab(TabKeyList[1])); //going to the next tab
  }

  const handleAboutCourse = (e) => {
    const { name, value } = e.target;
    setBanner((preState) => {
      return { ...preState, [name]: value };
    });
    if (name!=='goal'){
      setErrors({});
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    setBanner({
      heading: heading || "",
      goal: goal || "",
      intro_video: intro_video || "",
      intro_video_thumbnail: intro_video_thumbnail || "",
    });
  }, [heading, goal, intro_video, intro_video_thumbnail]);
  return (
    <div>
      <Spacer size={20} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Title"
        size="large"
        placeholder="Enter course title here"
        errorMsg={errors.heading}
        name="heading"
        value={banner.heading}
        onChange={handleAboutCourse}
      />
      <Spacer size={40} classes={styles.spacerAxis} />
      <InputDescription
        isHtml={true}
        isLabel="Description"
        placeholder="Enter the course description here"
        name="goal"
        errorMsg={errors.goal}
        value={banner.goal}
        onChange={handleAboutCourse}
      />
      <Spacer size={40} classes={styles.spacerAxis} />
      <ImageUrl
        isLabel="Intro Video Thumbnail "
        errorMsg={errors.thumnail}
        placeholder="Enter video thumbnail here url"
        name="intro_video_thumbnail"
        value={banner.intro_video_thumbnail}
        onChange={handleAboutCourse}
      />
      <Spacer size={40} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Intro Video"
        size="large"
        placeholder="Enter course intro video url"
        name="intro_video"
        value={banner.intro_video}
        onChange={handleAboutCourse}
        errorMsg={errors.video}
      />
      <Spacer size={40} classes={styles.spacerAxis} />
      <SaveBtn handleClick={handleSubmit} />
    </div>
  );
};

export default AboutCourse;
