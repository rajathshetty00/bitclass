import { Table } from "antd";
import clsx from "clsx";
import React from "react";
import { Edit, Plus } from "react-feather";
import { useHistory } from "react-router-dom";
import {
  AddFreeClassBatch,
  ButtonIcon,
  CurriculumModel,
  Spacer,
  AddFullCourse,
} from "..";
import { WEB_URL } from "../../../../constants";
import useRedux from "../../../../helpers/useRedux";
import {
  freeClassColumData,
  fullCourseColumData,
} from "../../validators/helper";
import styles from "./styles.module.scss";
import { useState } from "react";
import Text from "antd/lib/typography/Text";
import InputLabel from "../shared/InputLabel";
import { useEffect } from "react";
import { fetchCurriculumByCourseCode } from "../../../../actions/curriculum";
import { SET_IS_ADDED } from "../../../../actions/types";


const CurriculumLayout = () => {
  const history = useHistory();
  const [visible, setVisible] = useState(false);
  const [isFullCourseContent, setIsFullCourseContent] = useState(false);

  const [
    {
      curriculumTableData: { heading, code,workshop_batches,course_batches },
      isAdded
    },
    dispatch,
  ] = useRedux("curriculumReducer");
  const previewUrl = `${WEB_URL}/live-classes/cdp/curriculum/${code}`;

  const gotoEditCurriculumPage = () => {
    history.push(`/curriculum/edit/${code}`);
  };
  const OpenModel = (isContent) => {
    setVisible(true);
    setIsFullCourseContent(isContent);
  };

  useEffect(() => {
        if (isAdded) {
           dispatch(fetchCurriculumByCourseCode(code))
           setVisible(false)
           setIsFullCourseContent(false);
           dispatch({type:SET_IS_ADDED,payload:false})
        }
  },[isAdded,code,dispatch]);

  return (
    <>
    {code?<div className={styles.layoutContainer}>
      <a
        href={previewUrl}
        target="_blank"
        rel="noreferrer"
        className={styles.link}
      >
        Preview Link
      </a>
      <div className={styles.editHeading}>
        <Text type="success">Course Name :{heading}</Text>
        <ButtonIcon onClick={gotoEditCurriculumPage}>
          <Edit style={{ width: "15px", marginRight: "7px" }} />
          Edit curriculum{" "}
        </ButtonIcon>
      </div>
      <div className={styles.freeContainer}>
        <div className={styles.freeCourseHeading}>
          <h2 className={styles.title}>Upcomming Free class</h2>
          <ButtonIcon onClick={() => OpenModel(false)}>
            <Plus style={{ width: "15px", marginRight: "7px" }} />
            Add Free Class{" "}
          </ButtonIcon>
        </div>
        <Spacer size={30} />
        <Table scroll={{ y: 240, x: 400 }}  rowKey="course_code" columns={freeClassColumData} dataSource={workshop_batches} />
        <Spacer size={30} />
        <div className={styles.freeCourseHeading}>
          <h2 className={styles.title}>Upcomming Full Course Batch</h2>
          <ButtonIcon onClick={() => OpenModel(true)}>
            <Plus style={{ width: "15px", marginRight: "7px" }} />
            Add Full course{" "}
          </ButtonIcon>
        </div>
        <Table scroll={{ y: 240, x: 400 }} rowKey="course_code" columns={fullCourseColumData} dataSource={course_batches} />
      </div>
      <CurriculumModel
        visible={visible}
        handleVisible={setVisible}
        heading={isFullCourseContent?"Add a new full course batch":'Add a new free slot'}
        width={isFullCourseContent?800:450}
        isfooter={false}
      >
        {isFullCourseContent ? <AddFullCourse courseCode ={code} setIsVisible={setVisible} /> : <AddFreeClassBatch setIsVisible={setVisible} courseCode ={code} />}
      </CurriculumModel>
    </div>:
    <>
    <Spacer size={30} />
    <InputLabel label="Search by course Name to fetch Data" />
    </>
  }
    </>

  );
};

export default CurriculumLayout;
