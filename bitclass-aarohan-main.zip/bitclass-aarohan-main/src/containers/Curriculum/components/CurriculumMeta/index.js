import { message } from "antd";
import React, { useEffect, useState } from "react";
import { Spacer, InputDescription, InputTitle } from "..";
import {
  handleChangeTab,
  submitFullCourseMetaData,
} from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import { TabKeyList } from "../../tabConfig";
import metaValidator from "../../validators/metaValidation";
import SaveBtn from "../shared/SaveBtn";

import styles from "./styles.module.scss";
// Actually this is certificate section
const CurriculumMeta = () => {
  const [
    {
      curriculumData: { sections },
    },
    dispatch,
  ] = useRedux("curriculumReducer");
  const [meta, setMeta] = useState({
    title: "",
    description: "",
    keyword: "",
    thumbnail: "",
  });

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...meta },
    metaValidator
  );
  // called when click to save button.
  function onSubmit() {
    message.success("Successfully save your data to store");
    dispatch(submitFullCourseMetaData(meta));
    dispatch(handleChangeTab(TabKeyList[8]));
  }

  const handleChangeMetaInput = (e) => {
    const { name, value } = e.target;
    setMeta({ ...meta, [name]: value });
    setErrors({});
    setIsSubmitting(false);
  };
  useEffect(() => {
    if (sections?.meta) {
      setMeta({ ...sections?.meta });
    }
  }, [sections?.meta]);
  return (
    <div>
      <Spacer size={20}  />
      <InputTitle
        isLabel="Title"
        size="large"
        placeholder="Enter curriculum meta title"
        errorMsg={errors.title}
        name="title"
        value={meta.title}
        onChange={handleChangeMetaInput}
      />
      <Spacer size={20}  />
      <InputTitle
        isLabel="Thumbnail"
        size="large"
        placeholder="Enter meta thumbnail"
        errorMsg={errors.thumbnail}
        name="thumbnail"
        value={meta.thumbnail}
        onChange={handleChangeMetaInput}
      />
      <Spacer size={40} />
      <InputDescription
        isLabel="Description"
        placeholder="Enter curriculum meta description"
        name="description"
        errorMsg={errors.description}
        value={meta.description}
        onChange={handleChangeMetaInput}
      />
      <Spacer size={40} />
      <InputTitle
        isLabel="Keyword"
        size="large"
        placeholder="Enter curriculum meta keywords"
        name="keyword"
        errorMsg={errors.keyword}
        value={meta.keyword}
        onChange={handleChangeMetaInput}
      />
      <Spacer size={40}  />
      <SaveBtn handleClick={handleSubmit} />
    </div>
  );
};

export default CurriculumMeta;
