import React from 'react';
import { CurriculumLayout, CurriculumSearchInput } from '..';

const CurriculumSearch = () => {
  return <div>
        <CurriculumSearchInput />
        <CurriculumLayout />
  </div>;
};

export default CurriculumSearch;
