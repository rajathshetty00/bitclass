import { Modal } from 'antd';
import React from 'react';
import { ExclamationCircleOutlined } from '@ant-design/icons';
import { Trash } from 'react-feather';
import { deleteCurriculumBatch } from '../../../../actions/curriculum';
import { useDispatch } from 'react-redux';



function confirm(props) {
  console.log("the props: " , props);
    
    Modal.confirm({
      title: 'Confirm',
      icon: <ExclamationCircleOutlined />,
      content: 'Are you sure you want to delete',
      okText: 'Yes',
      okType: 'danger',
      cancelText: 'No',
      onOk() {
        props()
      },
      onCancel() {
          console.log("Called cancel");
      },

    });
  }

const DeleteModel = ({code,type}) => {
  const dispatch = useDispatch()
  const onSubmit =()=>{
    dispatch(deleteCurriculumBatch(code,type))
  }
  return <div>
    <Trash style={{width: '25px' ,color:'var(--redColor)',cursor:'pointer'}}  onClick={()=>confirm(onSubmit)} />
  </div>;
};

export default DeleteModel;
