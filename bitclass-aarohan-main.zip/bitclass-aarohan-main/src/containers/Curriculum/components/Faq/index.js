import { Collapse, message } from "antd";
import React, { useEffect, useState } from "react";
import { CaretRightOutlined } from "@ant-design/icons";

import styles from "./styles.module.scss";
import {
  ButtonIcon,
  DeleteIcon,
  InputDescription,
  InputTitle,Spacer
} from "..";
import { Plus } from "react-feather";
import faqValidator from "../../validators/faqValidator";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import SaveBtn from "../shared/SaveBtn";
import { isEmptyObject } from "../../validators/helper";
import { TabKeyList } from "../../tabConfig";
import {
  handleChangeTab,
  submitCurriculumFaqData,
} from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import clsx from "clsx";
const { Panel } = Collapse;
const PanelItem = ({ tvalue, ansErrorMsg, handleText, ...props }) => {
  return (
    <div>
      <InputTitle isLabel="Curriculum Question" {...props} />
      <Spacer size={10}/>
      <InputDescription
        isHtml={true}
        errorMsg={ansErrorMsg}
        isLabel="Curriculum Answer"
        placeholder="Enter the answer "
        name="ans"
        value={tvalue}
        onChange={handleText}
      />
    </div>
  );
};
const CurriculumFaq = () => {
  const [
    {
      curriculumData: { sections },
    },
    dispatch,
  ] = useRedux("curriculumReducer");

  const [faq, setFaq] = useState({
    order: "9",
    content: [{ ans: "", que: "" }],
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    SaveDataToStore,
    { titleList: faq.content },
    faqValidator
  );

  function SaveDataToStore() {
    message.success("Successfully save your data to store");
    dispatch(submitCurriculumFaqData(faq));
    dispatch(handleChangeTab(TabKeyList[7]));
  }

  const handleChangeContentItem = (index, name, text) => {
    setFaq((preState) => {
      return {
        ...preState,
        content: preState.content.map((item, ind) =>
          ind === index ? { ...item, [name]: text } : item
        ),
      };
    });
  };

  const removeArrItem = (index) => {
    console.log("remove called",index);

    let array = [...faq.content]; // make a separate copy of the array
    array.splice(index, 1);
    setFaq({ ...faq, content: array });
  };
  const addItemArray = () => {
    console.log("add called");

    setFaq({ ...faq, content: [...faq.content, { ans: "", que: "" }] });
  };

  useEffect(() => {
    if (sections?.faqs) {
      setFaq((preState)=>{return{...preState, ...sections?.faqs}})
    
    }
  }, [sections?.faqs]);

  return (
    <div className={styles.mainContainer}>
      <div style={{ textAlign: "right" }}>
        <ButtonIcon className={styles.addItem} onClick={addItemArray}>
          <Plus style={{ width: "15px", marginRight: "7px" }} />
          Add FAQ
        </ButtonIcon>
      </div>
      <Spacer size={20} />

      <Collapse
        collapsible="header"
        bordered={false}
        defaultActiveKey={["0"]}
        expandIcon={({ isActive }) => (
          <CaretRightOutlined rotate={isActive ? 90 : 0} />
        )}
        className={styles.curriculumCollapse}
      >
        {faq.content &&
          faq.content.map((content, ind) => {
            return (
              <Panel
                header={
                  <h1 className={styles.heading}>FAQ item - {ind + 1} </h1>
                }
                key={ind}
                className={clsx(styles.customPanel, styles.isSucessClassColor, {
                  [styles.isfailureClassColor]: isEmptyObject(content),
                })}
                extra={<DeleteIcon ind={ind} removeItem={removeArrItem} />}
              >
                <PanelItem
                  errorMsg={
                    Number(errors?.que?.split(":")[0]) === ind
                      ? errors?.que?.split(":")[1]
                      : null
                  }
                  ansErrorMsg={
                   Number(errors?.ans?.split(":")[0]) === ind
                      ? errors?.ans?.split(":")[1]
                      : null
                  }
                  name="que"
                  value={content.que}
                  onChange={(e) =>
                    handleChangeContentItem(ind, e.target.name, e.target.value)
                  }
                  placeholder="Enter the question"
                  tvalue={content.ans}
                  handleText={(e) =>
                    handleChangeContentItem(ind, e.target.name, e.target.value)
                  }
                />
              </Panel>
            );
          })}
      </Collapse>
      <SaveBtn handleClick={handleSubmit} />
    </div>
  );
};

export default CurriculumFaq;
