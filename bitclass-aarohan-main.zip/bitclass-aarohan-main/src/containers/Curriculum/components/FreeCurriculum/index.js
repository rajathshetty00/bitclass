import { message } from "antd";
import React, { useEffect, useState } from "react";
import { InputTitle, ListCurriculum } from "..";
import {
  handleChangeTab,
  submitFreeCurriculumData,
} from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import Spacer from "../../../PayoutsPage/components/Spacer/Spacer";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import { TabKeyList } from "../../tabConfig";
import freeCurriculumValidator from "../../validators/freeCurriculumValidator";
import { arrayToliString } from "../../validators/helper";
import SaveBtn from "../shared/SaveBtn";
import styles from "./styles.module.scss";

const FreeCurriculum = () => {
  const [
    {
      curriculumData: { sections },
    },
    dispatch,
  ] = useRedux("curriculumReducer");
  const [titleList, setTitleList] = useState([""]);
  const [freeClass, setFreeClass] = useState({
    order: 3,
    title: "",
    description: "",
  });

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    SaveDataToStore,
    { titleList: titleList, title: freeClass.title },
    freeCurriculumValidator
  );

  // onChange free class input
  const handleFreeClassChange = (e) => {
    const { name, value } = e.target;
    setFreeClass((preState) => {
      return { ...preState, [name]: value };
    });
    setErrors({});
    setIsSubmitting(false);
  };

  // called when validation successfully passed.
  function SaveDataToStore() {
    const actualObject = {
      ...freeClass,
      description: arrayToliString(titleList),
    };
    message.success("Successfully save your data to store");
    dispatch(submitFreeCurriculumData(actualObject));
    dispatch(handleChangeTab(TabKeyList[3]));
  }

  useEffect(() => {
    if (sections?.freeclass_curriculum) {
      const listOfText = sections?.freeclass_curriculum.description
        .replace(/<\/?[^>]+(>|$)/g, ".")
        .split(".")
        .filter((item) => item);
      setTitleList(listOfText);
      setFreeClass({ ...sections?.freeclass_curriculum });
    }
  }, [sections?.freeclass_curriculum]);

  return (
    <section className={styles.freeCurriculum}>
      <h1 className={styles.freeCurriculumTitle}>
        List of Topics to be covered in the free class{" "}
      </h1>

      <Spacer size={20} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Free course title"
        name="title"
        errorMsg={errors.title}
        placeholder={"Free curriculum title"}
        value={freeClass.title}
        onChange={handleFreeClassChange}
      />
      <Spacer size={20} classes={styles.spacerAxis} />

      <ListCurriculum
        errorMsg={errors?.titleList?.split(":")[1]}
        setErrors={setErrors}
        setIsSubmitting={setIsSubmitting}
        errorInd={errors?.titleList?.split(":")[0]}
        setListItem={setTitleList}
        listItems={titleList}
      />

      <SaveBtn handleClick={handleSubmit} />
    </section>
  );
};

export default FreeCurriculum;
