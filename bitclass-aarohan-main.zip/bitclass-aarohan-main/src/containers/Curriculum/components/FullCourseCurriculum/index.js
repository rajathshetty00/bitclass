import { Collapse, message } from "antd";
import React, { useEffect, useState } from "react";
import { Plus} from "react-feather";
import {
  ButtonIcon,
  DeleteIcon,
  FullcoursePanel,
  InputTitle,
  ListCurriculum,Spacer
} from "..";
import { CaretRightOutlined } from "@ant-design/icons";

import styles from "./styles.module.scss";
import clsx from "clsx";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import fullCourseValidator from "../../validators/fullCourseValidator";
import SaveBtn from "../shared/SaveBtn";
import { isEmptyObject, saveToStore } from "../../validators/helper";
import {
  handleChangeTab,
  submitFullCourseCurriculumData,
} from "../../../../actions/curriculum";
import { TabKeyList } from "../../tabConfig";
import useRedux from "../../../../helpers/useRedux";
const { Panel } = Collapse;


const FullCourseCurriculum = () => {
  const [
    {
      curriculumData: { sections },
    },
    dispatch,
  ] = useRedux("curriculumReducer");

  const [summeryTopic, setSummeryTopic] = useState(["", "", ""]);
  const [summeryTitle, setSummeryTitle] = useState("");
  const [curriculum, setCurriculum] = useState({
    title: "",
    subtitle: "",
    duration: "",
    order: "5",
    content: [{ thumbnail_text: "", title: "", items: [""] }],
  });

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    SaveDataToStore,
    {
      titleList: curriculum.content,
      duration: curriculum.duration,
      title: curriculum.title,
      subtitle: curriculum.subtitle,
      summeryTitle,
      summeryTopic,
    },
    fullCourseValidator
  );

  function SaveDataToStore() {
    saveToStore("curriculum_details", {
      title: summeryTitle,
      content: summeryTopic,
    });
    saveToStore("curriculum", curriculum);
    message.success("Successfully save your data to store");
    dispatch(
      submitFullCourseCurriculumData({
        curriculum_details: {
          title: summeryTitle,
          content: summeryTopic,
        },
        curriculum: curriculum,
      })
    );

    dispatch(handleChangeTab(TabKeyList[4]));
  }

  const handleTile = (e) => {
    setSummeryTitle(e.target.value);
    setErrors({});
    setIsSubmitting(false);
  };

  const handleChangeCurriculumContent = (index, arr) => {
    const array = [...curriculum.content]; // make a separate copy of the array
    const newArr = array.map((el, ind) =>
      ind === index ? { ...el, items: arr } : el
    );
    setCurriculum({ ...curriculum, content: newArr });
    setErrors({});
    setIsSubmitting(false);
  };
  const handleChangeCurriculumInput = (index, name, text) => {
    const newArr = curriculum.content.map((item, ind) =>
      ind === index ? { ...item, [name]: text } : item
    );
    setCurriculum({ ...curriculum, content: newArr });
    setErrors({});
    setIsSubmitting(false);
  };

  const addCurriculumItem = () => {
    setCurriculum({
      ...curriculum,
      content: [
        ...curriculum.content,
        { thumbnail_text: "", title: "", items: [""] },
      ],
    });
  };
  const removeCurriculumItem = (index) => {
    let array = [...curriculum.content]; // make a separate copy of the array
    array.splice(index, 1);
    setCurriculum({ ...curriculum, content: array });
  };

  const handleChangeCurriculum = (e) => {
    const { name, value } = e.target;
    setCurriculum({ ...curriculum, [name]: value });
    setErrors({});
    setIsSubmitting(false);
  };

  useEffect(() => {
    if (sections?.curriculum_details) {
      setSummeryTopic(sections?.curriculum_details?.content);
      setSummeryTitle(sections?.curriculum_details?.title);
    }
    if (sections?.curriculum) {
      setCurriculum({ ...sections?.curriculum });
    }
  }, [sections?.curriculum, sections?.curriculum_details]);

  return (
    <div className={styles.mainContainer}>
      <Spacer size={20} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Main Heading"
        name="title"
        errorMsg={errors?.title}
        size="large"
        value={curriculum.title}
        onChange={handleChangeCurriculum}
      />
      <Spacer size={20} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Main SubHeading"
        name="subtitle"
        errorMsg={errors?.subtitle}
        size="large"
        value={curriculum.subtitle}
        onChange={handleChangeCurriculum}
      />
      <Spacer size={40} classes={styles.spacerAxis} />
      <h1 className={styles.titleText}>Curriculum Summary</h1>
      <InputTitle
        isLabel="Heading"
        placeholder="Curriculum Summary heading"
        size="large"
        errorMsg={errors.summeryTitle}
        value={summeryTitle}
        onChange={handleTile}
      />
      <Spacer size={20} classes={styles.spacerAxis} />
      <ListCurriculum
        errorMsg={errors?.summeryTopic?.split(":")[1]}
        setErrors={setErrors}
        setIsSubmitting={setIsSubmitting}
        errorInd={errors?.summeryTopic?.split(":")[0]}
        isBtnVisible={false}
        setListItem={setSummeryTopic}
        listItems={summeryTopic}
      />

      <Spacer size={40} classes={styles.spacerAxis} />

      <h1 className={styles.titleText}>Detail Curriculum </h1>
      <Spacer size={20} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Duration"
        name="duration"
        placeholder="Enter curriculum duration"
        errorMsg={errors?.duration}
        size="large"
        value={curriculum.duration}
        onChange={handleChangeCurriculum}
      />
      <Spacer size={20} classes={styles.spacerAxis} />
      <div style={{ textAlign: "right" }}>
        <ButtonIcon className={styles.addItem} onClick={addCurriculumItem}>
          <Plus style={{ width: "15px", marginRight: "7px" }} />
          Add Curriculum
        </ButtonIcon>
      </div>
      <Spacer size={20} classes={styles.spacerAxis} />
      <Collapse
        collapsible="header"
        bordered={false}
        defaultActiveKey={["0"]}
        expandIcon={({ isActive }) => (
          <CaretRightOutlined rotate={isActive ? 90 : 0} />
        )}
        className={styles.curriculumCollapse}
      >
        {curriculum.content &&
          curriculum.content.map((content, ind) => {
            return (
              <Panel
                header={
                  <h1 className={styles.heading}>
                    Detail curriculum - {ind + 1}
                  </h1>
                }
                key={ind}
                className={clsx(styles.customPanel, styles.isSucessClass, {
                  [styles.isEmptyClass]: isEmptyObject(content),
                })}
                extra={<DeleteIcon ind={ind} removeItem={removeCurriculumItem} />}
              >
                <FullcoursePanel
                  setErrors={setErrors}
                  setIsSubmitting={setIsSubmitting}
                  errorMsg={
                    Number(errors?.name?.split(":")[0]) === ind
                      ? errors?.name?.split(":")[1]
                      : null
                  }
                  thumbnailErrorMsg={
                    Number(errors?.thumbnail_text?.split(":")[0]) === ind
                      ? errors?.thumbnail_text?.split(":")[1]
                      : null
                  }
                  topicErrorMsg={
                    Number(errors?.contentTopic?.split(":")[0]) === ind
                      ? errors?.contentTopic?.split(":")[1]
                      : null
                  }
                  topic={content.items}
                  setTopic={(arr) => handleChangeCurriculumContent(ind, arr)}
                  index={ind}
                  key={ind}
                  name="title"
                  value={content.title}
                  onChange={(e) =>
                    handleChangeCurriculumInput(ind, e.target.name, e.target.value)
                  }
                  placeholder="Enter Curriculum detail heading"
                  tvalue={content.thumbnail_text}
                  handleText={(e) =>
                    handleChangeCurriculumInput(ind, e.target.name, e.target.value)
                  }
                />
              </Panel>
            );
          })}
      </Collapse>

      <SaveBtn handleClick={handleSubmit} />
    </div>
  );
};

export default FullCourseCurriculum;
