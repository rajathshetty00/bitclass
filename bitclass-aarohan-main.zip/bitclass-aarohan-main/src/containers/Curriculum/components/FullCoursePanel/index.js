import React from 'react';
import { InputTitle ,ListCurriculum,Spacer} from '..';

const FullcoursePanel = ({
    setTopic,
    topic,
    tvalue,
    index,
    topicErrorMsg,
    setErrors,
    setIsSubmitting,
    thumbnailErrorMsg,
    handleText,
    ...props
  }) => {
    return (
        <div>
          <InputTitle {...props} />
          <Spacer size={10} />
          <InputTitle
            isLabel="Thumbnail Text"
            placeholder="Enter Thumbnail Text"
            errorMsg={thumbnailErrorMsg}
            name="thumbnail_text"
            value={tvalue}
            onChange={handleText}
          />
          <Spacer size={20}  />
          <ListCurriculum
            errorMsg={topicErrorMsg?.split(",")[1]}
            setErrors={setErrors}
            setIsSubmitting={setIsSubmitting}
            errorInd={topicErrorMsg?.split(",")[0]}
            setListItem={setTopic}
            listItems={topic}
          />
        </div>
      );
    }



export default FullcoursePanel;
