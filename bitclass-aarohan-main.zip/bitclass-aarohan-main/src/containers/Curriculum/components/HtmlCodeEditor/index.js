import React from "react";
import ReactQuill from "react-quill";
import styles from "./styles.module.scss";
import "react-quill/dist/quill.snow.css";

const HtmlCodeEditor = ({ name, ...props }) => {
  const { onChange } = props;
  const handleEditorChange = (value) => {
    const event = {
      target: {
        name,
        value,
      },
    };
    onChange(event);
  };
  return (
    <div id="editor_Contaner" className={styles.mainContainer}>
      <ReactQuill
        {...props}
        onChange={handleEditorChange}
        className={styles.editorContainer}
      />
    </div>
  );
};

export default HtmlCodeEditor;
