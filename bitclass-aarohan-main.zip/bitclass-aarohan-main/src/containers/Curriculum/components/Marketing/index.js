import {  Menu, message, Radio } from "antd";
import React, { useState } from "react";
import {
  CurriculumDropDown,
  InputDescription,
  Spacer,
  IsError,
} from "..";
import InputLabel from "../shared/InputLabel";
import styles from "./styles.module.scss";
import SaveBtn from "../shared/SaveBtn";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import marketingValidator from "../../validators/marketingValidation";
import { useEffect } from "react";
import { fetchCategories, fetchCourseCategory, handleChangeTab, submitFullCourseMaketingData } from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import { isEmpty } from "lodash-es";
import { TabKeyList } from "../../tabConfig";

const courseStatusItems = [
  { display_text: "Draft", keyword: "draft" },
  { display_text: "Published", keyword: "published" },
  { display_text: "Deleted", keyword: "deleted" },
];
const marketingTypeItems = [
  { display_text: "Internal Marketing", keyword: "internal_marketing" },
  { display_text: "External Marketing", keyword: "external_marketing" },
];

const options = [
  { display_text: "Beginner", keyword: "beginner" },
  { display_text: "Intermediate", keyword: "intermediate" },
  { display_text: "Advance", keyword: "advance" },
];

const DropdownMenu = ({ menuItem, handleButtonClick, ...props }) => {
  return (
    <Menu onClick={handleButtonClick}>
      {menuItem&&menuItem.length>0&&menuItem.map((item) => {
        return (
          <Menu.Item key={item.keyword} {...props}>
            {item.display_text}
          </Menu.Item>
        );
      })}
    </Menu>
  );
};

const MarketingSection = () => {
  const [{ categoryList,curriculumData: { sections } }, dispatch] = useRedux("curriculumReducer");
  const [categoryMenus2, setCategoryMenus2] = useState([]);
  const [categoryMenus3, setCategoryMenus3] = useState([]);

  const [marketingData, setMarketingData] = useState({
    categories:["","",""],
    course_level: "",
    course_status: "",
    marketing_type: "",
    description: "",
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...marketingData },
    marketingValidator
  );

  function onSubmit() {
    message.success("Successfully save your data to store");
    dispatch(submitFullCourseMaketingData(marketingData));
    dispatch(handleChangeTab(TabKeyList[9])); //going to the next tab
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setMarketingData((preState) => {
      return { ...preState, [name]: value };
    });
    setErrors({});
    setIsSubmitting(false);
  };

  const handleChangeCategory = (e,ind) => {
    let clonseCategories =[...marketingData.categories];
    clonseCategories[ind] =e.key;
    setMarketingData((preState) => {
      return { ...preState, [e.item.props.name]: clonseCategories };
    });
    setErrors({});
    setIsSubmitting(false);
  };
  const handleChangeMenu =(e)=>{
    setMarketingData((preState) => {
      return { ...preState, [e.item.props.name]: e.key };
    });
    setErrors({});
    setIsSubmitting(false);
  }

  const extractMenus =(index)=>{
      let menuObj ={
        1:categoryList,
        2:categoryMenus2,
        3:categoryMenus3
      }
      return menuObj[index]
  } 
  const fetchCategory =()=>{
      dispatch(fetchCourseCategory())
  }
  const  fetchCategory1 = async ()=> {
    const categoryData =  await fetchCategories(marketingData.categories[0])
    setCategoryMenus2(categoryData)

}
const  fetchCategory2 = async ()=> {
  const categoryData =  await fetchCategories(marketingData.categories[1])
  setCategoryMenus3(categoryData)
}
  useEffect(() => {
    fetchCategory()
    setCategoryMenus2([])
    setCategoryMenus3([])
  },[])

  useEffect(() => {
    if (!isEmpty(marketingData.categories[0])) 
      fetchCategory1()
    setCategoryMenus3([])
      let cloneCategories =[...marketingData.categories];
      cloneCategories[1]="";
      cloneCategories[2]="";
    setMarketingData((preState)=>{return{...preState,categories:cloneCategories}})
  },[marketingData.categories[0]])

  useEffect(() => {
    if (!isEmpty(marketingData.categories[1])) 
      fetchCategory2()
      let cloneCategories =[...marketingData.categories];
      cloneCategories[2]="";
    setMarketingData((preState)=>{return{...preState,categories:cloneCategories}})
  },[marketingData.categories[1]])

  useEffect(() => {
    if (!isEmpty(sections.marketing)) {
      setMarketingData(sections.marketing);
    }
  },[sections.marketing])

  return (
    <section id="marketing-section" className={styles.marketingSection}>
      <div className={styles.categoryContainer}>
        <InputLabel label="Add course category" />
        {
          marketingData.categories.map((category,ind)=>{
              return  <div className={styles.dropdown} key={ind} >
              <CurriculumDropDown
                selected={category}
                menu={
                  <DropdownMenu
                    menuItem={extractMenus(ind+1)}
                    handleButtonClick={(e)=>handleChangeCategory(e,ind)}
                    name="categories"
                  />
                }
              />
              {errors[`courseCategory${ind+1}`] && (
                <IsError>{errors[`courseCategory${ind+1}`]}</IsError>
              )}
            </div>
          })
        }
      </div>

      <Spacer size={30} />
      <div>
        <InputLabel label="Level of Course" />
        <div className={styles.checkboxContainer}>
          <Radio.Group
            onChange={handleInputChange}
            name="course_level"
            value={marketingData.course_level}
          >
            {options.map((opt) => {
              return (
                <Radio key={opt.keyword} value={opt.keyword}>
                  {opt.display_text}
                </Radio>
              );
            })}
          </Radio.Group>
        </div>
        {errors["course_level"] && <IsError>{errors["course_level"]}</IsError>}
      </div>
      <Spacer size={30} />
      <InputDescription
        name="description"
        placeholder="Comma seperated ,Please avoid space"
        value={marketingData.description}
        onChange={handleInputChange}
        isLabel="Targeted Audience"
      />
      {errors["description"] && <IsError>{errors["description"]}</IsError>}

      <Spacer size={30} />
      <div className={styles.categoryContainer}>
        <InputLabel label="Marketing Type" />

        <div className={styles.dropdown}>
          <CurriculumDropDown
            selected={marketingData.marketing_type}
            menu={
              <DropdownMenu
                name="marketing_type"
                menuItem={marketingTypeItems}
                handleButtonClick={handleChangeMenu}
              />
            }
          />
          {errors["marketing_type"] && (
            <IsError>{errors["marketing_type"]}</IsError>
          )}
        </div>
      </div>

      <Spacer size={30} />
      <div className={styles.categoryContainer}>
        <InputLabel label="Course Status" />
        <div className={styles.dropdown}>
          <CurriculumDropDown
            selected={marketingData.course_status}
            menu={
              <DropdownMenu
                name="course_status"
                menuItem={courseStatusItems}
                handleButtonClick={handleChangeMenu}
              />
            }
          />
          {errors["course_status"] && (
            <IsError>{errors["course_status"]}</IsError>
          )}
        </div>
      </div>

      <Spacer size={30} />
      <SaveBtn handleClick={handleSubmit} />
    </section>
  );
};

export default MarketingSection;
