import clsx from "clsx";
import React, { useEffect, useState } from "react";
import { useRef } from "react";
import { Globe, Send } from "react-feather";
import ReactJson from "react-json-view";
import { useParams } from "react-router-dom";
import { ButtonIcon } from "..";
import { updateCurriculumByApi } from "../../../../actions/curriculum";
import { WEB_URL } from "../../../../constants";
import useRedux from "../../../../helpers/useRedux";
import SimpleAlert from "../../../PayoutsPage/components/alertComponent/AlertComponent";
import Spacer from "../../../PayoutsPage/components/Spacer/Spacer";
import { getStoreData } from "../../validators/helper";
import styles from "./styles.module.scss";

const PreviewCurriculum = () => {
  const [actualObj, setActualObj] = useState({});
  const [{ curriculumData }, dispatch] = useRedux("curriculumReducer");
  const notifyRef = useRef();
  const { courseCode } = useParams();

  useEffect(() => {
    // Perform localStorage action
    const actualJsObject = {
          ...curriculumData,
         sections:{...curriculumData.sections, freeclass_curriculum:{...curriculumData?.sections?.freeclass_curriculum,materials_required:curriculumData?.sections?.warm_up_plan?.material_list}}
    };
    setActualObj({ ...actualJsObject });
  }, [curriculumData]);

  const updateCurriculumCdpData = () => {
    dispatch(updateCurriculumByApi(courseCode, actualObj, notifyRef));
  };

  const previewUrl =`${WEB_URL}/live-classes/cdp/curriculum/${courseCode}`

  const gotoLivePreview =()=>{
    window.open(
      previewUrl, "_blank");
  }
  return (
    <div>
      <div className={styles.liveBtnContainer}>

       <ButtonIcon href={previewUrl} 
          className={clsx(styles.addItem ,styles.liveBtn)}
          onClick={gotoLivePreview}
        >
          <Globe style={{ width: "15px", marginRight: "7px" }} />
         Live Preview
        </ButtonIcon>
      </div>
      <ReactJson displayDataTypes={false} name="Section" src={actualObj} collapsed={true} />

      <Spacer size={40} classes={styles.spacerAxis} />
      <hr className={styles.hr} />
      <div className={styles.buttonContainer}>
        <ButtonIcon
          className={styles.addItem}
          onClick={updateCurriculumCdpData}
        >
          <Send style={{ width: "15px", marginRight: "7px" }} />
          Submit Json
        </ButtonIcon>
      </div>
      <SimpleAlert ref={notifyRef} />
    </div>
  );
};

export default PreviewCurriculum;
