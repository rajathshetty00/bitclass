import { Collapse, message } from "antd";
import React, { useEffect, useState } from "react";
import { CaretRightOutlined } from "@ant-design/icons";

import styles from "./styles.module.scss";
import { ButtonIcon, DeleteIcon, ImageUrl, InputTitle,Spacer } from "..";
import { Plus } from "react-feather";
import SaveBtn from "../shared/SaveBtn";
import showcaseValidator from "../../validators/showcaseValidator";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import { isEmptyObject, saveToStore } from "../../validators/helper";
import { TabKeyList } from "../../tabConfig";
import {
  handleChangeTab,
  submitstudentShowCaseData,
} from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import clsx from "clsx";
const { Panel } = Collapse;

const PanelItem = ({
  setImage,
  img,
  tvalue,
  index,
  subtitleErrorMsg,
  imgErrorMsg,
  handleText,
  ...props
}) => {
  return (
    <div>
       <Spacer size={30} />
      <InputTitle isLabel="Student name" {...props} />
      <Spacer size={10}  />
      <InputTitle
        isLabel="Showcase text"
        errorMsg={subtitleErrorMsg}
        placeholder="Enter the showcase text"
        name="subtitle"
        value={tvalue}
        onChange={handleText}
      />
      <Spacer size={20}  />
      <ImageUrl
        name="image"
        errorMsg={imgErrorMsg}
        placeholder="Enter url of student profile "
        onChange={setImage}
        value={img}
      />
    </div>
  );
};

const StudentShowCase = () => {
  const [
    {
      curriculumData: { sections },
    },
    dispatch,
  ] = useRedux("curriculumReducer");

  const [showCase, setShowCase] = useState({
    title: "",
    subtitle: "",
    order: "2",
    content: [{ subtitle: "", title: "", image: "" }],
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    SaveDataToStore,
    {
      titleList: showCase.content,
      title: showCase.title,
      subtitle: showCase.subtitle,
    },
    showcaseValidator
  );

  function SaveDataToStore() {
    saveToStore("showcase", showCase);
    message.success("Successfully save your data to store");
    dispatch(submitstudentShowCaseData(showCase));
    dispatch(handleChangeTab(TabKeyList[5]));
  }

  const handleChangeShowCase = (e) => {
    const { name, value } = e.target;
    setShowCase({ ...showCase, [name]: value });
    setErrors({});
    setIsSubmitting(false);
  };

  const handleContentItem = (index, name, text) => {
    const newArr = showCase.content.map((item, ind) =>
      ind === index ? { ...item, [name]: text } : item
    );
    setShowCase({ ...showCase, content: newArr });
    setErrors({});
    setIsSubmitting(false);
  };

  const removeArrItem = (index) => {
    let array = [...showCase.content]; // make a separate copy of the array
    array.splice(index, 1);
    setShowCase({ ...showCase, content: array });
  };
  const addItemArray = () => {
    setShowCase({
      ...showCase,
      content: [...showCase.content, { subtitle: "", title: "", image: "" }],
    });
  };

  useEffect(() => {
    if (sections?.showcase) {
      setShowCase({ ...sections?.showcase });
    }
  }, [sections?.showcase]);


  return (
    <div className={styles.mainContainer}>
      <Spacer size={20}  />
      <InputTitle
        isLabel="Main Heading"
        placeholder="Enter main heading"
        name="title"
        errorMsg={errors.title}
        size="large"
        value={showCase.title}
        onChange={handleChangeShowCase}
      />
      <Spacer size={20}  />
      <InputTitle
        isLabel="Main SubHeading"
        placeholder="Enter main subheading"
        name="subtitle"
        errorMsg={errors.subtitle}
        size="large"
        value={showCase.subtitle}
        onChange={handleChangeShowCase}
      />
      <Spacer size={40}  />
      <div style={{ textAlign: "right" }}>
        <ButtonIcon className={styles.addItem} onClick={addItemArray}>
          <Plus style={{ width: "15px", marginRight: "7px" }} />
          Add Showcase
        </ButtonIcon>
      </div>
      <Spacer size={20}  />

      <Collapse
        collapsible="header"
        bordered={false}
        defaultActiveKey={["0"]}
        expandIcon={({ isActive }) => (
          <CaretRightOutlined rotate={isActive ? 90 : 0} />
        )}
        className={styles.curriculumCollapse}
      >
        {showCase.content &&
          showCase.content.map((content, ind) => {
            return (
              <Panel
                header={
                  <h1 className={styles.heading}>Showcase item - {ind + 1}</h1>
                }
                key={ind}
                className={clsx(styles.customPanel, styles.isSucessClass, {
                  [styles.isEmptyClass]: isEmptyObject(content),
                })}
                extra={<DeleteIcon ind={ind} removeItem={removeArrItem} />}
              >
                <PanelItem
                  errorMsg={
                    Number(errors?.name?.split(":")[0]) === ind
                      ? errors?.name?.split(":")[1]
                      : null
                  }
                  subtitleErrorMsg={
                    Number(errors?.description?.split(":")[0]) === ind
                      ? errors?.description?.split(":")[1]
                      : null
                  }
                  imgErrorMsg={
                    Number(errors?.video_thumbnail?.split(":")[0]) === ind
                      ? errors?.video_thumbnail?.split(":")[1]
                      : null
                  }
                  img={content.image}
                  setImage={(e) =>
                    handleContentItem(ind, e.target.name, e.target.value)
                  }
                  index={ind}
                  key={ind}
                  name="title"
                  value={content.title}
                  onChange={(e) =>
                    handleContentItem(ind, e.target.name, e.target.value)
                  }
                  placeholder="Enter student name"
                  tvalue={content.subtitle}
                  handleText={(e) =>
                    handleContentItem(ind, e.target.name, e.target.value)
                  }
                />
              </Panel>
            );
          })}
      </Collapse>
      <SaveBtn handleClick={handleSubmit} />
    </div>
  );
};

export default StudentShowCase;
