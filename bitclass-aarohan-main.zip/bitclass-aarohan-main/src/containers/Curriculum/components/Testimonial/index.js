import { Collapse, message } from "antd";
import React, { useEffect, useState } from "react";
import { CaretRightOutlined } from "@ant-design/icons";

import styles from "./styles.module.scss";
import {
  ButtonIcon,
  DeleteIcon,
  ImageUrl,
  InputDescription,
  InputTitle,
  Spacer,
} from "..";
import { Plus } from "react-feather";
import testimonialValidator from "../../validators/testimonialValidation";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import SaveBtn from "../shared/SaveBtn";
import { isEmptyObject, saveToStore } from "../../validators/helper";
import { TabKeyList } from "../../tabConfig";
import {
  handleChangeTab,
  submitTestimonialData,
} from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import clsx from "clsx";
const { Panel } = Collapse;

const PanelItem = ({
  setImage,
  img,
  tvalue,
  titleValue,
  index,
  imgErrorMsg,
  videoErrorMsg,
  titleErrorMsg,
  handleText,
  ...props
}) => {
  return (
    <div>
      <InputDescription isLabel="Testimonial" {...props} />
      <Spacer size={10} />
      <InputTitle
        isLabel="Testimonial Media (optional)"
        errorMsg={videoErrorMsg}
        placeholder="Enter the Video Link "
        name="video"
        value={tvalue}
        onChange={handleText}
      />
      <Spacer size={10} />
      <InputTitle
        isLabel="Student Name"
        placeholder="Enter the student name"
        name="title"
        errorMsg={titleErrorMsg}
        value={titleValue}
        onChange={handleText}
      />
      <Spacer size={20} />
      <ImageUrl
        isLabel="Student photo link"
        errorMsg={imgErrorMsg}
        placeholder="Enter the Student photo link "
        name="video_thumbnail"
        onChange={setImage}
        value={img}
      />
    </div>
  );
};

const Testimonial = () => {
  const [
    {
      curriculumData: { sections },
    },
    dispatch,
  ] = useRedux("curriculumReducer");

  const [testimonial, setTestimonial] = useState({
    title: "",
    subtitle: "",
    order: "6",
    content: [{ description: "", title: "", video_thumbnail: "", video: "" }],
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    SaveDataToStore,
    {
      titleList: testimonial.content,
      title: testimonial.title,
      subtitle: testimonial.subtitle,
    },
    testimonialValidator
  );

  function SaveDataToStore() {
    saveToStore("testimonials", testimonial);
    message.success("Successfully save your data to store");
    dispatch(submitTestimonialData(testimonial));

    dispatch(handleChangeTab(TabKeyList[6]));
  }
  const handleChangeShowCase = (e) => {
    const { name, value } = e.target;
    setTestimonial({ ...testimonial, [name]: value });
    setIsSubmitting(false);
    setErrors({});
  };

  const handleContentItem = (index, name, text) => {
    const newArr = testimonial.content.map((item, ind) =>
      ind === index ? { ...item, [name]: text } : item
    );
    setTestimonial({ ...testimonial, content: newArr });
    setIsSubmitting(false);
    setErrors({});
  };

  const removeArrItem = (index) => {
    let array = [...testimonial.content]; // make a separate copy of the array
    array.splice(index, 1);
    setTestimonial({ ...testimonial, content: array });
  };
  const addItemArray = () => {
    setTestimonial({
      ...testimonial,
      content: [
        ...testimonial.content,
        { description: "", title: "", video_thumbnail: "", video: "" },
      ],
    });
  };

  useEffect(() => {
    if (sections?.testimonials) {
      setTestimonial({ ...sections?.testimonials });
    }
  }, [sections?.testimonials]);

  return (
    <div className={styles.mainContainer}>
      <Spacer size={20} />
      <InputTitle
        isLabel="Main Heading"
        errorMsg={errors.title}
        name="title"
        size="large"
        value={testimonial.title}
        onChange={handleChangeShowCase}
      />
      <Spacer size={20} />
      <InputTitle
        isLabel="Main SubHeading"
        name="subtitle"
        errorMsg={errors.subtitle}
        size="large"
        value={testimonial.subtitle}
        onChange={handleChangeShowCase}
      />
      <Spacer size={40} />
      <div style={{ textAlign: "right" }}>
        <ButtonIcon className={styles.addItem} onClick={addItemArray}>
          <Plus style={{ width: "15px", marginRight: "7px" }} />
          Add Testimonial
        </ButtonIcon>
      </div>
      <Spacer size={20} />

      <Collapse
        collapsible="header"
        bordered={false}
        defaultActiveKey={["0"]}
        expandIcon={({ isActive }) => (
          <CaretRightOutlined rotate={isActive ? 90 : 0} />
        )}
        className={styles.curriculumCollapse}
      >
        {testimonial.content &&
          testimonial.content.map((content, ind) => {
            return (
              <Panel
                header={
                  <h1 className={styles.heading}>
                    Testimonial Item - {ind + 1}
                  </h1>
                }
                key={ind}
                className={clsx(styles.customPanel, styles.isSucessClass, {
                  [styles.isEmptyClass]: isEmptyObject(content),
                })}
                extra={<DeleteIcon ind={ind} removeItem={removeArrItem} />}
              >
                <PanelItem
                  errorMsg={
                    Number(errors?.description?.split(":")[0]) === ind
                      ? errors?.description?.split(":")[1]
                      : null
                  }
                  titleErrorMsg={
                    Number(errors?.name?.split(":")[0]) === ind
                      ? errors?.name?.split(":")[1]
                      : null
                  }
                  imgErrorMsg={
                   Number(errors?.video_thumbnail?.split(":")[0]) === ind
                      ? errors?.video_thumbnail?.split(":")[1]
                      : null
                  }
                  videoErrorMsg={
                    Number(errors?.video?.split(":")[0]) === ind
                      ? errors?.video?.split(":")[1]
                      : null
                  }
                  img={content.video_thumbnail}
                  setImage={(e) =>
                    handleContentItem(ind, e.target.name, e.target.value)
                  }
                  index={ind}
                  key={ind}
                  name="description"
                  titleValue={content.title}
                  value={content.description}
                  onChange={(e) =>
                    handleContentItem(ind, e.target.name, e.target.value)
                  }
                  placeholder="Enter testimonial text"
                  tvalue={content.video}
                  handleText={(e) =>
                    handleContentItem(ind, e.target.name, e.target.value)
                  }
                />
              </Panel>
            );
          })}
      </Collapse>
      <SaveBtn handleClick={handleSubmit} />
    </div>
  );
};

export default Testimonial;
