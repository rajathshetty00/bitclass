import { message } from "antd";
import React, { useEffect, useState } from "react";
import { ImageUrl, InputDescription, InputTitle, ListCurriculum, Spacer } from "..";
import { handleChangeTab, submitWarmUpPlanData } from "../../../../actions/curriculum";
import useRedux from "../../../../helpers/useRedux";
import useFormValidator from "../../../PayoutsPage/helper/useFormValidator";
import { TabKeyList } from "../../tabConfig";
import warnUpValidator from "../../validators/warmUpValidator";
import InputLabel from "../shared/InputLabel";
import SaveBtn from "../shared/SaveBtn";

import styles from "./styles.module.scss";

const WarmUpPlanSection = () => {
  const [{ curriculumData: { sections } }, dispatch] = useRedux("curriculumReducer");

  const [materialList, setMaterialList] = useState([""]);
  const [warmUpData, setWarmUpData] = useState({
    push_notification:"",
    warmup_message:"",
    media_link:''
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...warmUpData,materialList },
    warnUpValidator
  );

  function onSubmit () {
    const actualObject = {
      ...warmUpData,
      material_list:materialList
    };
    message.success("Successfully save your data to store");
    dispatch(submitWarmUpPlanData(actualObject))
    dispatch(handleChangeTab(TabKeyList[10])); //going to the next tab

  }
  const handleChangeInput = (e) => {
    const { name, value } = e.target;
    setWarmUpData((preState) => {
      return { ...preState, [name]: value };
    });
    if (name!=='goal'){
      setErrors({});
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    if (sections?.warm_up_plan) {
      setMaterialList(sections?.warm_up_plan?.material_list);
      setWarmUpData({
        push_notification:sections?.warm_up_plan?.push_notification,
        warmup_message:sections?.warm_up_plan?.warmup_message,
        media_link:sections?.warm_up_plan?.media_link
      });
    }
   
  }, [sections?.warm_up_plan]);

  return (
    <section id="warm-up-section" className={styles.warmUpSection}>
     <h1 className={styles.freeCurriculumTitle}>
        List of Material which is Required
      </h1>
      <ListCurriculum
        errorMsg={errors?.materialList?.split(":")[1]}
        setErrors={setErrors}
        setIsSubmitting={setIsSubmitting}
        label="Material"
        placeholder="Type the Material required here"
        errorInd={errors?.materialList?.split(":")[0]}
        setListItem={setMaterialList}
        listItems={materialList}
      />
      <Spacer size={20} classes={styles.spacerAxis} />
      <InputDescription
        isLabel="Today you will learn .."
        placeholder="Enter what will student lean here"
        name="warmup_message"
        errorMsg={errors.warmup_message}
        value={warmUpData.warmup_message}
        onChange={handleChangeInput}
      />
      <Spacer size={20} classes={styles.spacerAxis} />
      <InputTitle
        isLabel="Push Notification Banner"
        name="push_notification"
        errorMsg={errors.push_notification}
        placeholder="Enter a valid URL"
        value={warmUpData.push_notification}
        onChange={handleChangeInput}
      />
      
      <Spacer size={20} classes={styles.spacerAxis} />

      <ImageUrl
        isLabel="Image/video what you learn"
        errorMsg={errors.media_link}
        placeholder="Enter valid cloudinary URL"
        name="media_link"
        value={warmUpData.media_link}
        onChange={handleChangeInput}
      />
      <Spacer size={40} classes={styles.spacerAxis} />

      <SaveBtn handleClick={handleSubmit} />
    </section>
  );
};

export default WarmUpPlanSection;
