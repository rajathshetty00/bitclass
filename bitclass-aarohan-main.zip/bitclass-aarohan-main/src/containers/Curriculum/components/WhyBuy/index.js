import { message } from 'antd'
import React, { useEffect, useState } from 'react'
import {  ImageUrl, InputDescription, InputTitle,Spacer } from '..'
import { handleChangeTab, submitWhyBuyData } from '../../../../actions/curriculum'
import useRedux from '../../../../helpers/useRedux'
import useFormValidator from '../../../PayoutsPage/helper/useFormValidator'
import { TabKeyList } from '../../tabConfig'
import { saveToStore } from '../../validators/helper'
import whyBuyValidator from '../../validators/whyBuy'
import SaveBtn from '../shared/SaveBtn'
import styles from './styles.module.scss'

const WhyBuy = () => {
    const [{curriculumData:{sections}}, dispatch] = useRedux('curriculumReducer');

    const [whybuy, setWhybuy] = useState({
        title:'',
        subtitle:'',
        description:'',
        image:'',
        order:1

    })
    const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
        onSubmit,
        { ...whybuy },
        whyBuyValidator
      )

      function onSubmit (){
    saveToStore('why_buy',whybuy)
    message.success('Successfully save your data to store');
    dispatch(submitWhyBuyData(whybuy))
    dispatch(handleChangeTab(TabKeyList[2]));

      }

    const handleChangeWhyBuy= (e)=>{
        const {name,value} = e.target;
        setWhybuy((preState)=>{return{...preState,[name]:value}})
        if (name!=='description'){
            setErrors({});
            setIsSubmitting(false);
          }
       
    }

    useEffect(() => {
        if (sections?.why_buy) {
            setWhybuy({...sections?.why_buy})        
        }
    },[sections?.why_buy])
    return (
        <div >
        <Spacer size={20}   />
       <InputTitle isLabel="Title" size="large" name="title" placeholder="Enter title here" errorMsg={errors.title} value={whybuy.title} onChange={handleChangeWhyBuy} />
       <Spacer size={40}  />
           <InputDescription isHtml={true} isLabel="Description" placeholder="Enter the description here" name="description" errorMsg={errors.description} value={whybuy.description}  onChange={handleChangeWhyBuy} />
     
           <Spacer size={40}  />
           <InputDescription isLabel="Why choose this course (Quotation)?"  placeholder="why choose this course text" name="subtitle" errorMsg={errors.subtitle} value={whybuy.subtitle} onChange={handleChangeWhyBuy} />
       <Spacer size={40}   />
       <ImageUrl isLabel="Why(Image)" placeholder="Enter valid image url" errorMsg={errors.image} name="image" value={whybuy.image} onChange={handleChangeWhyBuy} />

       <Spacer size={40}  />
       <SaveBtn handleClick={handleSubmit} />
   </div>
    )
}

export default WhyBuy
