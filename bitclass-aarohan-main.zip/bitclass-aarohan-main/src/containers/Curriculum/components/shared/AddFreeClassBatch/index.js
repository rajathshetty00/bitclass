import { DatePicker, InputNumber, Spin, TimePicker } from "antd";
import React, { useState } from "react";
import { Send } from "react-feather";
import { Spacer } from "../../";
import { addFreeClassBatch } from "../../../../../actions/curriculum";
import useRedux from "../../../../../helpers/useRedux";
import useFormValidator from "../../../../PayoutsPage/helper/useFormValidator";
import addFreeSlotValidator from "../../../validators/addFreSlotValidator";
import ButtonIcon from "../ButtonIcon";
import IsError from "../Error";
import styles from "./styles.module.scss";
import { LoadingOutlined } from "@ant-design/icons";

const AddFreClassBatch = ({ courseCode }) => {
  const [
    {
      loading: { addBatch },
    },
    dispatch,
  ] = useRedux("curriculumReducer");
  const antIcon = <LoadingOutlined className={styles.spinStyle} spin />;

  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [day, setDay] = useState(null);



  const [addSlot, setAddSlot] = useState({
    date: "",
    time: "",
    duration: null,
  });

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...addSlot },
    addFreeSlotValidator
  );
  function onSubmit() {
    let daywithDowSchedule =["","","","","","",""];
      daywithDowSchedule[day] = addSlot.time;
    const reqBody = {
      type: "workshop",
      course_schedule: {
        lesson_duration: addSlot.duration,
        start_date: addSlot.date,
        end_date: addSlot.date,
        timezone: "+0530",
        dow_schedule:daywithDowSchedule,
      },
    };
    dispatch(addFreeClassBatch(courseCode,reqBody));
  }

  const handleChangeDuration = (e) => {
    setAddSlot((preState) => {
      return { ...preState, duration: e };
    });
  };

  const handleStartDate = (date, dateStr) => {
    setStartDate(date);
    setAddSlot({ ...addSlot, date: dateStr });
    changeDowSchedule(date?.day())
    setErrors({});
    setIsSubmitting(false);
  };
  const handleStartTime = (time, timeStr) => {
    setStartTime(time);
    setAddSlot({ ...addSlot, time:time?time?.format("HH:mm"):'' });
    setErrors({});
    setIsSubmitting(false);
  };
  const disabledPastStartDate = (current) => {
    return current && current.valueOf() < Date.now() - 86400000;
  };

  const changeDowSchedule = (day)=>{
    // rocket.splice(index, 1, e.target.value)
    if(day===0)
      setDay(6);
    else
    setDay(day- 1);
  }
  return (
    <div className={styles.addFreClass}>
      <label className={styles.label}>Date: </label>
      <DatePicker
        disabledDate={disabledPastStartDate}
        value={startDate}
        onChange={handleStartDate}
      />
      {errors?.["date"] && <IsError>{errors["date"]}</IsError>}
      <Spacer size={10} />
      <label className={styles.label}>Time: </label>
      <TimePicker
        className={styles.timeSLot}
        value={startTime}
        onChange={handleStartTime}
        format="h:mm a"
        placeholder="Time"
        minuteStep={15}
        use12Hours
        inputReadOnly
      />
      {errors?.["time"] && <IsError>{errors["time"]}</IsError>}
      <Spacer size={10} />
      <label className={styles.label}>Duration: </label>
      <InputNumber
        placeholder="duration"
        onChange={handleChangeDuration}
        value={addSlot.duration}
      />
      {errors?.["duration"] && <IsError>{errors?.["duration"]}</IsError>}
      <Spacer size={10} />

      <ButtonIcon onClick={handleSubmit} disabled={addBatch}>
        {addBatch ? (
          <Spin style={{ color: "white" }} indicator={antIcon} />
        ) : (
          <Send style={{ width: "15px", marginRight: "7px" }} />
        )}
        Sumbit
      </ButtonIcon>
    </div>
  );
};

export default AddFreClassBatch;
