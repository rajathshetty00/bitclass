import { Checkbox, DatePicker,  InputNumber, Spin, TimePicker } from "antd";
import clsx from "clsx";
import { isEmpty } from "lodash-es";
import moment from "moment";
import React from "react";
import { useState } from "react";
import { Send } from "react-feather";
import { addFullCourseBatch } from "../../../../../actions/curriculum";
import useRedux from "../../../../../helpers/useRedux";
import useFormValidator from "../../../../PayoutsPage/helper/useFormValidator";
import fullCourseBatchValidator from "../../../validators/fullCourseBatchValidator";
import ButtonIcon from "../ButtonIcon";
import IsError from "../Error";
import Spacer from "../Spacer";
import styles from "./styles.module.scss";
import { LoadingOutlined } from '@ant-design/icons';

const inputList = ["course_price", "floor_price", "duration"];
const initialWeeksDays = [
  { label: "monday", value: "", checked: false, disabled: true },
  { label: "tuesday", value: "", checked: false, disabled: true },
  { label: "wednesday", value: "", checked: false, disabled: true },
  { label: "thursday", value: "", checked: false, disabled: true },
  { label: "friday", value: "", checked: false, disabled: true },
  { label: "saturday", value: "", checked: false, disabled: true },
  { label: "sunday", value: "", checked: false, disabled: true },
];

const RenderTimePicker = ({
  checkBoxLabel,
  label,
  isChecked,
  isDisabled,
  onChangeCheckbox,
  onChange,
  index,
  errorMsg,
  ...props
}) => {
  return (
    <>
      <Spacer size={20} />
      <Checkbox
        checked={isChecked}
        disabled={isDisabled}
        onChange={(e) => onChangeCheckbox(e, index)}
        name={checkBoxLabel}
      >
        <label
          className={clsx(styles.label, { [styles.disabledText]: isDisabled })}
        >
          {label}{" "}
        </label>
      </Checkbox>
      <TimePicker
 format="h:mm a"
 placeholder="Time"
 minuteStep={15}

 use12Hours
 inputReadOnly

        disabled={isDisabled}
        onChange={(val, valStr) => onChange(val, valStr, label)}
        {...props}
      />
      {errorMsg && <IsError>{errorMsg}</IsError>}
    </>
  );
};

const RenderInputIField = ({ label, errorMsg, onChange, ...props }) => {
  return (
    <>
      <label className={styles.label}>{label} </label>
      <InputNumber
        placeholder={`Enter ${label}`}
        onChange={(val) => onChange({ target: { value: val, name: label } })}
        {...props}
      />
      {errorMsg && <IsError>{errorMsg}</IsError>}

      <Spacer size={20} />
    </>
  );
};

const AddFullCourse = ({ courseCode, setIsVisible }) => {
  const [
    {
      loading:{fullCourseBatch}
    },
    dispatch,
  ] = useRedux("curriculumReducer");
  const antIcon = <LoadingOutlined className={styles.spinStyle}  spin />
  const [editCourse, setEditCourse] = useState({
    start_date: "",
    end_date: "",
    monday: "",
    tuesday: "",
    wednesday: "",
    thursday: "",
    friday: "",
    saturday: "",
    sunday: "",
  });
  const [weekDays, setWeekDays] = useState(initialWeeksDays);

  const [editCourseData, setEditCourseData] = useState({
    start_date: "",
    end_date: "",
    course_price: "",
    floor_price: "",
    duration: "",
    monday: "",
    tuesday: "",
    wednesday: "",
    thursday: "",
    friday: "",
    saturday: "",
    sunday: "",
  });
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    onSubmit,
    { ...editCourseData, weekDays, editCourse },
    fullCourseBatchValidator
  );
  function onSubmit() {
    const reqBody = {
      type: "full_course",
      course_price: editCourseData.course_price,
      floor_price: editCourseData.floor_price,
      course_schedule: {
        lesson_duration: editCourseData.duration,
        start_date: editCourseData.start_date,
        end_date:editCourseData.end_date,
        timezone: "+0530",
        dow_schedule: [editCourseData.monday,editCourseData.tuesday,editCourseData.wednesday,editCourseData.thursday,editCourseData.friday,editCourseData.saturday,editCourseData.sunday],
      },
    };
    dispatch(addFullCourseBatch(courseCode,reqBody))
  }

  const onChangeInput = (e) => {
    const { name, value } = e.target;
    setEditCourseData((preState) => {
      return { ...preState, [name]: value };
    });
    setIsSubmitting(false);
    setErrors({});
  };

  const enumerateDaysBetweenDates = (startDate, endDate) => {
    let dates = [];
    const currDate = moment(startDate).startOf("day");
    const lastDate = moment(endDate).startOf("day");
    while (currDate.add(1, "days").diff(lastDate) <= 0) {
      const fullDayName = currDate.clone().format("dddd").toLowerCase();
      dates.push(fullDayName);
    }
    return [startDate.format("dddd").toLowerCase(), ...dates];
  };

  const clearTimeValue =()=>{
    initialWeeksDays.forEach((item)=>{
      onChangeInput({target:{name:item.label,value:''}})
    })
  }
  
  const handleVisiblityOfDays = (startD, endD) => {
    const sDate = moment(startD);
    const eDate = moment(endD);
    if (eDate.diff(sDate, "days") >= 7) {
      const notDisabledTime = weekDays.map((days) => {
        days.disabled = false;
        days.checked=true;
        return days;
      });
      setWeekDays(notDisabledTime);
    } else {
      if (endD) {
        const disabledTimes = enumerateDaysBetweenDates(sDate, eDate);
        const newWeekDays = weekDays.map((item) => {
          if (disabledTimes.includes(item.label)) {
            item.disabled = false;
            item.checked=true;
            return item;
          }
          item.disabled = true;
          item.checked=false;
          return item;
        });
        setWeekDays([...newWeekDays]);
      } else {
        const cloneWeeks = weekDays.map((item) => {
          return { ...item, disabled: true,checked:false };
        });
        setWeekDays(cloneWeeks);
      }
    }
  };

  const onChangeEditCourse = (value, strValue, name) => {
    setEditCourse((preState) => {
      return { ...preState, [name]: value };
    });
    if (name!=='start_date'&&name!=='end_date') {
     onChangeInput({ target: { name, value: value?value.format("HH:mm"):'' } });
    }else{
      onChangeInput({ target: { name, value: strValue } });
      clearTimeValue();
      
    }
    if (name === "start_date") {
      setEditCourse((preState) => {
        return { ...preState, end_date: "" };
      });
      const cloneWeeks = weekDays.map((item) => {
        return { ...item,checked:false, disabled: true };
      });
      setWeekDays(cloneWeeks);
    }
    if (!isEmpty(editCourse["start_date"]) && name === "end_date") {
      handleVisiblityOfDays(editCourse["start_date"], value);
    }
    setIsSubmitting(false);
    setErrors({});
  };

  const handleChecked = (e, index) => {
    const { checked } = e.target;
    const cloneWeekDays = [...weekDays];
    cloneWeekDays[index] = { ...cloneWeekDays[index], checked };
    setWeekDays(cloneWeekDays);
  };
  const disabledPastStartDate = (current) => {
    return current && current.valueOf() < Date.now() - 86400000;
  };
  const disabledPastEndDate = (current) => {
    return (
      current &&
      current.valueOf() < editCourse.start_date &&
      editCourse.start_date.valueOf()
    );
  };

  return (
    <div>
      <div className={styles.fullCourseContainer}>
        <div className={styles.col_1}>
          <label className={styles.label}>Start Date </label>
          <DatePicker
            value={editCourse.start_date}
            disabledDate={disabledPastStartDate}
            onChange={(val, valStr) =>
              onChangeEditCourse(val, valStr, "start_date")
            }
          />
          {errors?.["startDate"] && <IsError>{errors["startDate"]}</IsError>}
          <Spacer size={20} />
          <label className={styles.label}>End Date </label>
          <DatePicker
            value={editCourse.end_date}
            disabledDate={disabledPastEndDate}
            onChange={(val, valStr) =>
              onChangeEditCourse(val, valStr, "end_date")
            }
          />
          {errors?.["endDate"] && <IsError>{errors["endDate"]}</IsError>}
          {weekDays.map((weekDay, i) => {
            return (
              <RenderTimePicker
                key={i}
                index={i}
                type="number"
                label={weekDay.label}
                name={weekDay.label}
                value={editCourse[weekDay.label]}
                onChange={onChangeEditCourse}
                onChangeCheckbox={handleChecked}
                isChecked={weekDay.checked}
                isDisabled={weekDay.disabled}
                checkBoxLabel={weekDay.label}
                errorMsg={errors[weekDay.label]}
              />
            );
          })}
        </div>
        <div className={styles.col_2}>
          {inputList.map((data, i) => {
            return (
              <RenderInputIField
                key={i}
                label={data}
                name={data}
                value={editCourseData[data]}
                onChange={onChangeInput}
                errorMsg={errors[data]}
              />
            );
          })}
        </div>
      </div>
      <Spacer size={20} />

      <div className={styles.footer}>
        <ButtonIcon onClick={handleSubmit} disabled ={fullCourseBatch} >
          {fullCourseBatch?<Spin style={{color: 'white'}} indicator={antIcon} />:<Send style={{ width: "15px", marginRight: "7px" }} />}
          Sumbit
        </ButtonIcon>
      </div>
    </div>
  );
};

export default AddFullCourse;
