import clsx from 'clsx'
import React from 'react'
import styles from './styles.module.scss'

const ButtonIcon = ({children,isOutlined=false,className,...props}) => {
    return (
        <button {...props} className={ clsx(styles.button, styles.buttonPulse,className,{[styles.outLinebtn]:isOutlined})}>
            {children}
        </button>
    )
}

export default ButtonIcon
