import { Button, Dropdown } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import React from 'react';
import styles from './styles.module.scss'

const CurriculumDropdown = ({menu,selected}) => {
  return<Dropdown overlay={menu} className={styles.curriculumDropdown} >
      <Button>
        {selected||'Choose field'} <DownOutlined />
      </Button>
    </Dropdown>
};

export default CurriculumDropdown;
