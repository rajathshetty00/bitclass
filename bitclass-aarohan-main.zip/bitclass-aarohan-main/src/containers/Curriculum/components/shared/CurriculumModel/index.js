import {  Modal} from 'antd';
import styles from './styles.module.scss'
const CurriculumModel =({isFooter=false,children,heading,count,width,handleOnOk,visible,handleVisible})=> {
    return (
        <>
          <Modal
centeredradio_content
visible={visible}
onOk={handleOnOk}
onCancel={() => handleVisible(false)}
width={width||500}
okButtonProps={{ type: 'primary'}}
okText={<p>Sumbit</p>}
footer={isFooter}
className={styles.modelWrapper}
>
          <div className={styles.model_body}>
            <h1>{heading} </h1>
            {children}
          </div>
        </Modal>
 
  </>
    )
}

export default CurriculumModel