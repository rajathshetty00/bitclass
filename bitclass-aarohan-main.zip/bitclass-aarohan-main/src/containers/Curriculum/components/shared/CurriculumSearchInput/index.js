import { AutoComplete, Input, message, Skeleton } from "antd";
import React from "react";
import { useEffect } from "react";
import { useRef } from "react";
import { useState } from "react";
import { ArrowRight } from "react-feather";
import _ from "lodash-es";
import styles from "./styles.module.scss";
import { searchCurriculum } from "../../../../../utils/api";
import { useDispatch } from "react-redux";
import { fetchCurriculumByCourseCode } from "../../../../../actions/curriculum";

const CurriculumSearchInput = () => {
  const dispatch = useDispatch()
  const [searchTerm, setSearchTerm] = useState("");
  const [isListVisible, setIsListVisible] = useState(false);
  const [isSelected, setIsSelected] = useState(true);

  const [results, setResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
// when focus out in input search
  const handleInputFocus = () => {
    setIsListVisible(false);
  };
// called when input field data changed
  const handleChangeSearchTerm = (e) => {
    setSearchTerm(e.target.value);
    setIsSelected(true);
  };
// called While searching the  data via api 
  const searchCourseByHeading = async (heading) => {
    try {
      const response = await searchCurriculum(heading); //api call and send query of search term
      setIsSearching(false);
      if (response.success) {
        setResults([...response.data]);
      } else {
        message.error("Error while searching course");
      }
    } catch (error) {
      setIsSearching(false);
      setResults([]);
      message.error("Error while searching course", error);
    }
  };
// api called when user click any of the course heading
  const searchByCourseCode = (code, heading) => {
    setSearchTerm(heading);
    setIsSelected(false);
    dispatch(fetchCurriculumByCourseCode(code))
  };
// debouncing function using lodash
  const debounceSearch = useRef(
    _.debounce((searchTerm) => {
      searchCourseByHeading(searchTerm);
    }, 1000)
  );

  useEffect(
    () => {
      if (searchTerm&&isSelected) {
        setIsSearching(true);
        setIsListVisible(true);
        debounceSearch.current(searchTerm);
      } else {
        setResults([]);
        setIsListVisible(false);

      }
    },
    [searchTerm] // Only call effect if debounced search term changes
  );

  return (
    <div>
      <div className={styles.autoCompleteContainer}>
        <Input
        onKeyPress={handleInputFocus}
          value={searchTerm}
          onChange={handleChangeSearchTerm}
          className={styles.autoComplete}
          allowClear
          placeholder="Search by course name .."
        />
        {isListVisible && (
          <div className={styles.autoCompleteList}>
            <Skeleton active loading={isSearching}>
              {results.length > 0 ? (
                results.map((item) => {
                  return (
                    <div
                      className={styles.listitem}
                      key={item.code}
                      onClick={() =>
                        searchByCourseCode(item.code, item.heading)
                      }
                    >
                      <p>{item.heading}</p>
                      <ArrowRight className={styles.listicon} />
                    </div>
                  );
                })
              ) : (
                <div>No Data</div>
              )}
            </Skeleton>
          </div>
        )}
      </div>
    </div>
  );
};

export default CurriculumSearchInput;
