import React from 'react'
import { Trash } from 'react-feather'
import ButtonIcon from '../ButtonIcon'
import styles from './styles.module.scss'

const DeleteIcon = ({ind,removeItem}) => {
        return  <ButtonIcon className={styles.deletebtn} onClick={(e)=>removeItem(ind)
        }>
              <Trash style={{ width: "15px", marginRight: "7px" }} />
            </ButtonIcon>
    
}

export default DeleteIcon
