import React from 'react'
import styles from './styles.module.scss';

const IsError = ({children}) => {
    return (
        <p className={styles.iserror}>
           {children} 
        </p>
    )
}

export default IsError
