import { Image } from "antd";
import React, { useEffect, useState } from "react";
import IsError from "../Error";
import InputTitle from "../InputTitle";
import Spacer from "../Spacer";
import styles from "./styles.module.scss";

const ImageUrl = ({ errorMsg, value, onChange, ...props }) => {
  const [visible, setVisible] = useState(true);
  const [imgUrl, setImageUrl] = useState("");

  const checkImage = async (url) => {
    try {
      const res = await fetch(url);
      const buff = await res.blob();
      const exists = await buff.type.startsWith("image/");
      if (exists) {
        // Success code
        setVisible(true);

        setImageUrl(url);
      } else {
        // Fail code
        setVisible(false);
      }
    } catch (error) {
      console.log("Error while fetch image ");
    }
  };

  const handleChangeImageUrl = (e) => {
    onChange(e);
    checkImage(e.target.value);
  };

  useEffect(() => {
    setImageUrl(value);
  }, [value]);
  return (
    <div>
      <InputTitle
        isLabel="Image Url"
        {...props}
        value={value}
        onChange={(e) => handleChangeImageUrl(e)}
      />
      <Spacer size={20} />
      {visible && (
        <Image width={200} src={imgUrl} className={styles.previewImage} />
      )}
      {errorMsg && <IsError>{errorMsg}</IsError>}
    </div>
  );
};

export default ImageUrl;
