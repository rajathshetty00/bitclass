import React from "react";
import { Input } from "antd";

import styles from "./styles.module.scss";
import InputLabel from "../InputLabel";
import IsError from "../Error";
import HtmlCodeEditor from "../../HtmlCodeEditor";
const { TextArea } = Input;

const InputDescription = ({
  isHtml = false,
  isLabel,
  errorMsg,
  maxrow,
  name,
  ...props
}) => {
  return (
    <div className={styles.descriptionContainer}>
      {isLabel && <InputLabel label={isLabel} />}
      {isHtml ? (
        <HtmlCodeEditor name={name} {...props} />
      ) : (
        <TextArea
          name={name}
          className={styles.inputDescription}
          {...props}
          autoSize={{ minRows: 3, maxRows: maxrow || 5 }}
        />
      )}
      {errorMsg && <IsError>{errorMsg}</IsError>}
    </div>
  );
};

export default InputDescription;
