import React from 'react'
import styles from './styles.module.scss';

const InputLabel = ({label}) => {
    return (
        <label className={styles.inputLabel}>{label}</label>
    )
}

export default InputLabel
