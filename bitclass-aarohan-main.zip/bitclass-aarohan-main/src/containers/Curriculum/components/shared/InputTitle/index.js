import React from 'react'
import { Input } from 'antd'
import styles from './styles.module.scss'
import InputLabel from '../InputLabel'
import IsError from '../Error'

const InputTitle = ({isLabel,errorMsg,...props}) => {
    return (
        <div className={styles.mainInputContainer}>
            {isLabel&&<InputLabel label={isLabel} />}
            <Input className={styles.inputField}   {...props} />
            {errorMsg&&<IsError>{errorMsg}</IsError>}
        </div>
    )
}

export default InputTitle
