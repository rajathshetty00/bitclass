import React from "react";
import { Plus, Trash } from "react-feather";
import { ButtonIcon, InputTitle } from "../..";
import styles from "./styles.module.scss";

const ListCurriculum = ({
  isBtnVisible = true,
  errorMsg,
  errorInd,
  setErrors,
  setIsSubmitting,
  placeholder=null,
  label=null,
  listItems,
  setListItem,
}) => {
  const handleChangeTitle = (e, ind) => {
    const value = e.target.value;
    let cloneArr = [...listItems];
    cloneArr[ind] = value;
    setListItem(cloneArr);
    setIsSubmitting(false);
    setErrors({});
  };

  const addItemArray = () => {
    setListItem([...listItems, ""]);
  };
  const removeItem = (index) => {
    let array = [...listItems]; // make a separate copy of the array
    array.splice(index, 1);
    setListItem(array);
  };
  return (
    <div className={styles.listItems}>
      {listItems.length > 0 && isBtnVisible && (
        <div className={styles.isRight}>
          <ButtonIcon className={styles.addItem} onClick={addItemArray}>
            <Plus style={{ width: "15px", marginRight: "7px" }} />
            Add {label||'Topic'}
          </ButtonIcon>
        </div>
      )}
      {listItems &&
        listItems.map((title, ind) => {
          return (
            <div className={styles.listItem} key={ind}>
              <label style={{ color: "blue", marginRight: "10px" }}>{`${label||'Topic'} #${
                ind + 1
              } `}</label>
              <InputTitle
                size="large"
                value={title}
                errorMsg={ind === Number(errorInd) ? errorMsg : null}
                onChange={(e) => handleChangeTitle(e, ind)}
                placeholder={`${placeholder||'Titte of topic'} #${ind + 1}`}
              />
              {listItems.length > 1 && isBtnVisible && (
                <ButtonIcon
                  className={styles.isError}
                  onClick={() => removeItem(ind)}
                >
                  <Trash style={{ width: "15px" }} />
                </ButtonIcon>
              )}
            </div>
          );
        })}
    </div>
  );
};

export default ListCurriculum;
