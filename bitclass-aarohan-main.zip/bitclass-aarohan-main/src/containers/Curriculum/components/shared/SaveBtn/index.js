import React from 'react'
import { Save } from 'react-feather'
import ButtonIcon from '../ButtonIcon'
import styles from './styles.module.scss'

const SaveBtn = ({handleClick}) => {
    return (
        <div className={styles.buttonContainer}>
        <ButtonIcon onClick={handleClick}>
        <Save  style={{ width: "15px",marginRight:'7px' }} />Save </ButtonIcon>
        </div>
    )
}

export default SaveBtn
