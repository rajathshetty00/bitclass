import styles from './styles.module.scss'
const Spacer = ({
    size,
    axis,
    classes,
    delegated,
  }) => {
    const width = axis === 'vertical' ? 1 : size;
    const height = axis === 'horizontal' ? 1 : size;
    return (
      <span
        style={{
          width,
          minWidth: width,
          height,
          minHeight: height,
        }}
        className={`${styles.spacer} ${classes}`}
      >
        {delegated}
      </span>
    );
  };
  export default Spacer;