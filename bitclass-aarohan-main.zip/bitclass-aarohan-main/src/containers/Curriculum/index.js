import React, { useEffect } from "react";
import { Spin, Tabs } from "antd";
import { tabConfig } from "./tabConfig";
import styles from "./styles.module.scss";
import useRedux from "../../helpers/useRedux";
import {
  fetchCurriculumByApi,
  handleChangeTab,
} from "../../actions/curriculum";
import { useHistory, useParams } from "react-router-dom";
import { ButtonIcon } from "./components";
import { ArrowLeft } from "react-feather";
const { TabPane } = Tabs;

const CurriculumPage = () => {
  const history = useHistory()
  const [{ activeKey, loading }, dispatch] = useRedux("curriculumReducer");
  const { courseCode } = useParams();

  const onTabChange = (key) => {
    dispatch(handleChangeTab(key));
  };

  useEffect(() => {
    dispatch(fetchCurriculumByApi(courseCode));
  }, []);
  const backToCurriculumSearchPage =()=>{
    history.goBack()
  }

  return (
    <Spin spinning={loading.curriculum}>
      <main className={styles.mainContainer}>
      <ButtonIcon  isOutlined={true} onClick={backToCurriculumSearchPage}>
        <ArrowLeft  style={{ width: "15px",marginRight:'7px' }} />Back to search</ButtonIcon>
        <Tabs
          tabPosition="top"
          className={styles.curriculum_tabs}
          activeKey={activeKey}
          onChange={onTabChange}
        >
          {tabConfig.map(({ title, key, component }) => {
            return (
              <TabPane
                style={{ color: "white" }}
                className={styles.curriculum_tab}
                tab={title}
                key={key}
              >
                {component}
              </TabPane>
            );
          })}
        </Tabs>
      </main>
    </Spin>
  );
};

export default CurriculumPage;
