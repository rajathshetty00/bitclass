import { AboutCourse, CurriculumFaq, CurriculumMeta, FreeCurriculum, FullCourseCurriculum, Marketing, PreviewCurriculum, StudentShowCase, Testimonial, WarmUpPlan, WhyBuy } from "./components";
export const TabKeyList =[
    'about_the_course',
    'why_this_course',
    'free_curriculum',
    'full_course',
    'student_showcase',
    'testimonial',
    'faq',
    'meta',
    'marketing',
    'warm_up_plan',
    'preview'
]
export const tabConfig =[
    {
        title:'ABOUT THE COURSE',
        key:TabKeyList[0],
        component:<AboutCourse/>
    },
    {
        title:'WHY BUY THIS COURSE?',
        key:TabKeyList[1],
        component:<WhyBuy/>
    },
    {
        title:'FREE CLASS CURRICULUM',
        key:TabKeyList[2],
        component:<FreeCurriculum/>
    },
    {
        title:'FULL CLASS CURRICULUM',
        key:TabKeyList[3],
        component:<FullCourseCurriculum/>
    },
    {
        title:'STUDENT SHOWCASE',
        key:TabKeyList[4],
        component:<StudentShowCase/>
    },
    {
        title:'TESTIMONIAL',
        key:TabKeyList[5],
        component:<Testimonial/>
    },
    {
        title:'FAQ',
        key:TabKeyList[6],
        component:<CurriculumFaq/>
    },
    {
        title:'META',
        key:TabKeyList[7],
        component:<CurriculumMeta/>
    },
    {
        title:'MARKETING',
        key:TabKeyList[8],
        component:<Marketing/>
    },
    {
        title:'WARM-UP PLAN',
        key:TabKeyList[9],
        component:<WarmUpPlan/>
    },
    
    {
        title:'PREVIEW',
        key:TabKeyList[10],
        component:<PreviewCurriculum/>
    },
]

