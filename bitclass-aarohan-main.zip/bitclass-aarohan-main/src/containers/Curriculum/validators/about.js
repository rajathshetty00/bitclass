import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function aboutCourseValidator(values) {
    const errors = {};
   
    if(isEmpty(values['heading'])){
        errors['heading']="Please Add course title";
    }
    if(!isEmpty(values['heading'])&& values['heading'].length>200){
        errors['heading']="Title text should not greater than 200 characters";

    }
    if(isEmpty(values['goal'])){
        errors['goal']="Description is required";
    }

    if(!isEmpty(values['goal'])&&values['goal']==="<p><br></p>"){
        errors['goal']="Description is required";
    }

    
    if(!isEmpty(values['goal'])&& values['goal'].length>750){
        errors['goal']="Description text should not greater than 750 characters";

    }    

    
    if(isEmpty(values['intro_video_thumbnail'])){
        errors['thumnail']="Video Thumbnail is required";
    }
    if (!isEmpty(values['intro_video_thumbnail'])&&!checkURL(values['intro_video_thumbnail'])) {
        errors['thumnail']="Please enter the valid URl";
        
    }
    if (!isEmpty(values['intro_video'])&&!checkURL(values['intro_video'])) {
        errors['video']="Please enter the valid URl";
        
    }

    
    return errors;
}