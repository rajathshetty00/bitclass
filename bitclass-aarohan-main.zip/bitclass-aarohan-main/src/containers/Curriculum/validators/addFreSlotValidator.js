import { isEmpty } from 'lodash-es';

export default function addFreeSlotValidator(values) {
    const errors = {};
    if(isEmpty(values['date'])){
        errors['date']="Date is required";
    }
    if(isEmpty(values['time'])){
        errors['time']="Time is required";
    }
    if(values['duration']===null|| isEmpty(values['duration'].toString())){
        errors['duration']="Duration is required";
    }
    if(values['duration']!==null&&values['duration']<30){
        errors['duration']="Minimum duration is 30 mints";
    }

    return errors;
}
