import { isEmpty } from 'lodash-es';

export default function faqValidator(values) {
    const errors = {};
    for (let i = 0; i < values.titleList.length; i++) {
        const {ans,que} =  values.titleList[i];
        if(isEmpty(que)){
            errors['que']=`${i}:Please Add Quetion  #${i+1}`;
            break;
        }
        if(!isEmpty(que)&& que.length>150){
            errors['que']=`${i}:Title #${i+1} text should not greater than 150 characters`;
            break;
        }

        if(isEmpty(ans)){
            errors['ans']=`${i}:Please enter answer  #${i+1}`;
            break;
        }
        if (!isEmpty(ans)&& ans==="<p><br></p>") {
            errors['ans']=`${i}:Please enter answer  #${i+1}`;
            
        }
        
    }
    return errors;
}