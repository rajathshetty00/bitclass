import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function freeCurriculumValidator(values) {
    const errors = {};
    if(isEmpty(values.title)){
        errors['title']=`Please Add title `;
    }
    if(!isEmpty(values.title)&& values.title.length>200){
        errors['title']=`Title text should not greater than 200 characters`;
    }
    for (let i = 0; i < values.titleList.length; i++) {
        const topic =  values.titleList[i];
       
        if(isEmpty(topic)){
            errors['titleList']=`${i}:Please Add Topic #${i+1}`;
            break;
        }
        if(!isEmpty(topic)&& topic.length>65){
            errors['titleList']=`${i}:Topic #${i+1} text should not greater than 65 characters`;
            break;
        }
    }
    return errors;
}