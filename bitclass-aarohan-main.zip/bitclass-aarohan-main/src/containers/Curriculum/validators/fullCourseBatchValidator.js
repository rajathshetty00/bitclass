import { isEmpty } from 'lodash-es';

export default function fullCourseBatchValidator(values) {
    const errors = {};
   
    if(isEmpty(values['start_date'])){
        errors['startDate']="Start Date is required";
    }
    if(isEmpty(values['end_date'])){
        errors['endDate']="End Date is required";
    }
    if(values['course_price']===null||isEmpty(values['course_price'].toString())){
        errors['course_price']="Course price is required";
    }
    if(values['course_price']===0){
        errors['course_price']="Minimum amount should not greater than 0";
    }
    if(values['floor_price']===null||isEmpty(values['floor_price'].toString())){
        errors['floor_price']="Floor price is required";
    }
    if(values['floor_price']===0){
        errors['floor_price']="Minimum floor price should not greater than 0";
    }

    if(values['duration']===null|| isEmpty(values['duration'].toString())){
        errors['duration']="Duration is required";
    }
    if(values['duration']<30){
        errors['duration']="Minimum duration is 30 mints";
    }
    for (let i = 0; i < values.weekDays.length; i++) {
        const weekElement =  values.weekDays[i];
        if(!weekElement.disabled&&weekElement.checked&& isEmpty(values[weekElement.label])){
            errors[weekElement.label]=`Please select time for ${weekElement.label} class`;
            break;
        }
    }


    return errors;
}
