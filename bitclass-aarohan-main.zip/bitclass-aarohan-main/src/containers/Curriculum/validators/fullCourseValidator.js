import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function fullCourseValidator(values) {
    const errors = {};
    if(isEmpty(values['title'])){
        errors['title']="Please Add  title";
    }
    if(!isEmpty(values['title'])&& values['title'].length>200){
        errors['title']="Title text should not greater than 200 characters";

    }
    if(isEmpty(values['summeryTitle'])){
        errors['summeryTitle']="Please Add  Summery title";
    }
    if(!isEmpty(values['summeryTitle'])&& values['summeryTitle'].length>200){
        errors['summeryTitle']="Summery Title text should not greater than 200 characters";

    }
    if(isEmpty(values['duration'])){
        errors['duration']="Please Add  Duration";
    }
    if(!isEmpty(values['duration'])&& values['duration'].length>100){
        errors['duration']="Duration text should not greater than 100 characters";

    }
    
    if(isEmpty(values['subtitle'])){
        errors['subtitle']="Subtitle is required";
    }
    if(!isEmpty(values['subtitle'])&& values['subtitle'].length>200){
        errors['subtitle']="SubTitle text should not greater than 200 characters";

    }
    for (let i = 0; i < values.summeryTopic.length; i++) {
        const element =  values.summeryTopic[i];
        if(isEmpty(element)){
            errors['summeryTopic']=`${i}:Please enter Summery topic #${i+1}`;
            break;
        }
        if(!isEmpty(element)&& element.length>40){
            errors['summeryTopic']=`${i}:Summery topic #${i+1} should not greater than 40 characters`;
            break;
        }
    }

    for (let i = 0; i < values.titleList.length; i++) {
        const {title,thumbnail_text,items} =  values.titleList[i];
        if(isEmpty(title)){
            errors['name']=`${i}:Please enter Curriculum Heading #${i+1}`;
            break;
        }
        if(!isEmpty(title)&& title.length>200){
            errors['name']=`${i}:Curriculum Heading  #${i+1} should not greater than 200 characters`;
            break;
        }
        if(isEmpty(thumbnail_text)){
            errors['thumbnail_text']=`${i}:Please Add Thumbnail text  #${i+1}`;
            break;
        }
        if(!isEmpty(thumbnail_text)&& thumbnail_text.length>2){
            errors['thumbnail_text']=`${i}:Thumbnail #${i+1} text should not greater than 2 characters`;
            break;
        }
        for (let j = 0; j < items.length; j++){
            const content =  items[j];
            
            if(isEmpty(content)){
                errors['contentTopic']=`${i}: ${j},Please enter content Topic  #${j+1}`;
                break;
            }
            if(!isEmpty(content)&& content.length>200){
                errors['contentTopic']=`${i}:Content topoic #${i+1} text should not greater than 200 characters`;
                break;
            }
        }
       
       
    }
    return errors;
}