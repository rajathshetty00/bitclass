import { Space, Tag } from "antd";
import dayjs from "dayjs";
import { isEmpty } from "lodash-es";
import { Trash, Trash2 } from "react-feather";
import { WEB_URL } from "../../../constants";
import { DeleteModel } from "../components";

export const checkURL=(url) =>{
    return(url.match(/^https?:\/\/.+\/.+$/) != null);
}

export const saveToStore =(name,value)=>{
        localStorage.setItem(name,JSON.stringify(value));
}
export const getStoreData =(name)=>{
    return JSON.parse(localStorage.getItem(name));
} 

export const arrayToliString =(stringList)=>{
const listString = "<li>" + stringList.join("</li><li>") + "</li>";
    return listString;
}

export   const isEmptyObject=(obj)=> {
    return Object.keys(obj).every(function(key) {
            if (Array.isArray(obj[key])) {
                return obj[key].length>0?true:false;
            }
        return isEmpty(obj[key]);  // or just "return o[x];" for falsy values
    });
}

export const freeClassColumData =[
    {
      title: 'Start Date',
      dataIndex: 'start_date',
      key: 'start_date',
      render: text => <span>{dayjs(text).format('DD MMM YYYY')}</span>,
    },
    {
      title: 'End Date',
      dataIndex: 'end_date',
      key: 'end_date',
      render: text => <span>{dayjs(text).format('DD MMM YYYY')}</span>,
    },
    {
      title: 'Regsiteration',
      key: 'regsiter',
      dataIndex: 'registration_count',
      render: tag => (
        <>
         <Tag color={Number(tag)===0?'red':'green'} >
                {tag}
              </Tag>
        </>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (text, record) => (
          <DeleteModel type="free" code={record['batch_code']}  />
      ),
    },
  ];
  export const fullCourseColumData =[
    {
      title: 'Link',
      dataIndex: 'link',
      key: 'link',
      width: '400px',
      render: (link,record) => <a target="_blank" rel="noreferrer" href={link} >{link}</a>,
    },
    {
        title: 'Start Date',
        dataIndex: 'start_date',
        key: 'start_date',
        render: text => <span>{dayjs(text).format('DD MMM YYYY')}</span>,
      },
    {
      title: 'End Date',
      dataIndex: 'end_date',
      key: 'end_date',
      render: text => <span>{dayjs(text).format('DD MMM YYYY')}</span>, 
    },
    {
        title: 'Amount',
        dataIndex: 'amount',
        key: 'amount',
        render: (amount,record) => <span> {record['currency']}-{amount} /-</span>, 
      },
      {
        title: 'Floor Price',
        dataIndex: 'floor_price',
        key: 'floorPrice',
        render: (amount,record) => <span> {record['currency']}-{amount} /-</span>, 
      },
    {
      title: 'Registed',
      key: 'registered',
      dataIndex: 'registration_count',
      render: tags => (
        <>
          <Tag color={Number(tags)===0?'red':'green'} >{tags}</Tag>
        </>
      ),
    },
    {
      title: 'Action',
      key: 'action',
      render: (text, record) => (
          <DeleteModel type="full_course" code={record['batch_code']} />
      ),
    },
  ];
