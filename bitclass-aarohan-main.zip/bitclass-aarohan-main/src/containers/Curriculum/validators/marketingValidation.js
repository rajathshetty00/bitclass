import { isEmpty } from 'lodash-es';

export default function marketingValidator(values) {
    const errors = {};
   
    if(isEmpty(values['description'])){
        errors['description']="Target Audience description is required.";
    }
    if(!isEmpty(values['description'])&&values['description'].length>400){
        errors['description']="Target Audience description text should not greater than 400 characters";
    }
    if(isEmpty(values['marketing_type'])){
        errors['marketing_type']="Marketing Type is required.";
    }
    if(isEmpty(values['course_status'])){
        errors['course_status']="Course status is required.";
    }
    if(isEmpty(values['course_level'])){
        errors['course_level']="Course level is required.";
    }

    for (let i = 0; i < values.categories.length; i++) {
        const category =  values.categories[i];
        if(isEmpty(category)){
            errors[`courseCategory${i+1}`]=`category ${i+1} is required`;
            break;
        }
    }
    return errors;
}