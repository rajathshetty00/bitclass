import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function metaValidator(values) {
    const errors = {};
   
    if(isEmpty(values['title'])){
        errors['title']="Please Add course title";
    }
    if(!isEmpty(values['title'])&& values['title'].length>200){
        errors['title']="Title text should not greater than 200 characters";

    }
    if(isEmpty(values['thumbnail'])){
        errors['thumbnail']="Please Add thumbnail";
    }
    if (!isEmpty(values['thumbnail'])&&!checkURL(values['thumbnail'])) {
        errors['thumbnail']="Please enter the valid URl";
        
    }
    if(isEmpty(values['description'])){
        errors['description']="Description is required";
    }
    if(!isEmpty(values['description'])&& values['description'].length>500){
        errors['description']="Description text should not greater than 500 characters";

    }
    
    if(isEmpty(values['keyword'])){
        errors['keyword']="Keyword is required";
    }
    if(!isEmpty(values['keyword'])&& values['keyword'].length>2000){
        errors['keyword']="Keyword text should not greater than 2000 characters";

    }
   

    
    return errors;
}