import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function showcaseValidator(values) {
    const errors = {};
    if(isEmpty(values['title'])){
        errors['title']="Please Add  title";
    }
    if(!isEmpty(values['title'])&& values['title'].length>200){
        errors['title']="Title text should not greater than 200 characters";

    }
    if(isEmpty(values['subtitle'])){
        errors['subtitle']="Subtitle is required";
    }
    if(!isEmpty(values['subtitle'])&& values['subtitle'].length>200){
        errors['subtitle']="SubTitle text should not greater than 200 characters";

    }
    for (let i = 0; i < values.titleList.length; i++) {
        const {title,subtitle,image} =  values.titleList[i];
        if(isEmpty(title)){
            errors['name']=`${i}:Please enter Student Name  #${i+1}`;
            break;
        }
        if(!isEmpty(title)&& title.length>30){
            errors['name']=`${i}:Student name #${i+1} should not greater than 30 characters`;
            break;
        }
        if(isEmpty(subtitle)){
            errors['description']=`${i}:Please Add Showcase text  #${i+1}`;
            break;
        }
        if(!isEmpty(subtitle)&& subtitle.length>300){
            errors['description']=`${i}:Showcase #${i+1} text should not greater than 300 characters`;
            break;
        }
       
        if(isEmpty(image)){
            errors['video_thumbnail']=`${i}:Student profile image #${i+1} is required`;
            break;
        }
        if (!isEmpty(image)&&!checkURL(image)) {
            errors['video_thumbnail']=`${i}:Please enter the valid URl #${i+1}`;
            break;
            
        }
       
    }
    return errors;
}