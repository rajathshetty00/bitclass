import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function testimonialValidator(values) {
    const errors = {};
    if(isEmpty(values['title'])){
        errors['title']="Please Add  title";
    }
    if(!isEmpty(values['title'])&& values['title'].length>200){
        errors['title']="Title text should not greater than 200 characters";

    }
    if(isEmpty(values['subtitle'])){
        errors['subtitle']="Subtitle is required";
    }
    if(!isEmpty(values['subtitle'])&& values['subtitle'].length>200){
        errors['subtitle']="SubTitle text should not greater than 200 characters";

    }
    for (let i = 0; i < values.titleList.length; i++) {
        const {title,description,video_thumbnail,video} =  values.titleList[i];
        if(isEmpty(description)){
            errors['description']=`${i}:Please Add Quetion  #${i+1}`;
            break;
        }
        if(!isEmpty(description)&& description.length>750){
            errors['description']=`${i}:Description #${i+1} text should not greater than 750 characters`;
            break;
        }
        if(isEmpty(title)){
            errors['name']=`${i}:Please enter Student Name  #${i+1}`;
            break;
        }
        if(!isEmpty(title)&& title.length>30){
            errors['name']=`${i}:Student name #${i+1} should not greater than 30 characters`;
            break;
        }
        if(isEmpty(video_thumbnail)){
            errors['video_thumbnail']=`${i}:Student profile image #${i+1} is required`;
            break;
        }
        if (!isEmpty(video_thumbnail)&&!checkURL(video_thumbnail)) {
            errors['video_thumbnail']=`${i}:Please enter the valid URl #${i+1}`;
            break;
            
        }
        if (!isEmpty(video)&&!checkURL(video)) {
            errors['video']=`${i}:Please enter the valid URl #${i+1}`;
            break;
            
        }
    }
    return errors;
}