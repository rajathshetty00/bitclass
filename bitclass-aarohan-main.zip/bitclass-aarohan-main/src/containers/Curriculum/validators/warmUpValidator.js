import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function warnUpValidator(values) {
    const errors = {};
   
    if(isEmpty(values['push_notification'])){
        errors['push_notification']="Push notification banner Field is required";
    }
    if (!isEmpty(values['push_notification'])&&!checkURL(values['push_notification'])) {
        errors['push_notification']="Please enter the valid URL";
        
    }
    if(isEmpty(values['warmup_message'])){
        errors['warmup_message']="Field is required";
    }
    if (!isEmpty(values['warmup_message'])&&values['warmup_message'].length>200) {
        errors['warmup_message']="Messgae text should not greater than 200 characters";
    }
   
    if(isEmpty(values['media_link'])){
        errors['media_link']="Image / video is required";
    }
    if (!isEmpty(values['media_link'])&&!checkURL(values['media_link'])) {
        errors['media_link']="Please enter the valid URL";
        
    }
    for (let i = 0; i < values.materialList.length; i++) {
        const topic =  values.materialList[i];
       
        if(isEmpty(topic)){
            errors['materialList']=`${i}:Please enter material name  #${i+1}`;
            break;
        }
        if(!isEmpty(topic)&& topic.length>100){
            errors['materialList']=`${i}:Material #${i+1} name should not greater than 100 characters`;
            break;
        }
    }
    return errors;
}