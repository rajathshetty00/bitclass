import { isEmpty } from 'lodash-es';
import { checkURL } from './helper';

export default function whyBuyValidator(values) {
    const errors = {};
   
    if(isEmpty(values['title'])){
        errors['title']="Please Add  title";
    }
    if(!isEmpty(values['title'])&& values['title'].length>200){
        errors['title']="Title text should not greater than 200 characters";

    }
    if(isEmpty(values['subtitle'])){
        errors['subtitle']="Subtitle is required";
    }
    if(!isEmpty(values['subtitle'])&& values['subtitle'].length>500){
        errors['subtitle']="SubTitle text should not greater than 500 characters";

    }
    
    if(isEmpty(values['description'])){
        errors['description']="Description is required";
    }
    
    if(!isEmpty(values['description'])&&values['description']==="<p><br></p>"){
        errors['description']="Description is required";
    }
 
    if(isEmpty(values['image'])){
        errors['image']="Image is required";
    }
    if (!isEmpty(values['image'])&&!checkURL(values['image'])) {
        errors['image']="Please enter the valid URl";
        
    }

    
    return errors;
}