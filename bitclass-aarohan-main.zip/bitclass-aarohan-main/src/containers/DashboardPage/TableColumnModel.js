
import { Tooltip } from "antd";
import moment from "moment";
import { READABLE_DATE_FORMAT } from '../../constants'
// import { exists, setCookie } from "../../utils";
// import { getTokenForTenant } from "../../utils/api";

const fetchEditToken = (teacherCode, link) => {
  // getTokenForTenant(teacherCode)
  //   .then(r => {
  //     if(exists(r.data) && exists(r.data.auth_token)) {
  //       let token = r.data.auth_token
  //       setCookie('_auth', token, 1)
  //       if(link)
          window.open(link)
    //   } else {
    //     message.error("Failed to get teacher login access")
    //   }
    //   // window.open(link)
    // })
}

const DashboardTableModel = [
  {
    title: 'Teacher Name',
    dataIndex: 'teacherName',
    render: (data) => (<a
        rel="noreferrer"
        target="_blank"
        href={data.link}
        onClick={(e) => {
          e.stopPropagation()
          e.preventDefault()
          fetchEditToken(data.teacherUserCode, `${data.link}`)
        }}
      >
        {data.label}
      </a>
    ),
    align: 'center',
    fixed: 'left',
    width: 200,
    sorter: (a, b) => (a.teacherName.label || "").toLowerCase() > (b.teacherName.label || "").toLowerCase() ? 1 : -1,
  },
  {
    title: 'Assigned To',
    align: 'center',
    dataIndex: 'assignedTo',
    width: 200,
    editable: false,
    fieldType: 'select',
    sorter: (a, b) => a.assignedTo > b.assignedTo ? 1 : -1,
  },
  {
    title: 'Paid On',
    align: 'center',
    dataIndex: 'paidOn',
    width: 150,
    sorter: (a, b) => a.paidOn > b.paidOn ? 1 : -1,
    render: (val) => (moment.isMoment(val) ? val.format(READABLE_DATE_FORMAT) : ""),
  },
  {
    title: 'Type',
    dataIndex: 'planType',
    align: 'center',
    width: 150,
    sorter: (a, b) => a.planType > b.planType ? 1 : -1,
  },
  {
    title: 'Discovery Call Date',
    dataIndex: 'discoveryCallDate',
    align: 'center',
    editable: false,
    fieldType: 'date',
    sorter: (a, b) => a.discoveryCallDate > b.discoveryCallDate ? 1 : -1,
    render: (val) => (moment.isMoment(val) ? val.format(READABLE_DATE_FORMAT) : ""),
    width: 200,
  },
  {
    title: 'Demo Course Details',
    align: 'center',
    dataIndex: 'demoCourseDetails',
    width: 200,
    editable: false,
    fieldType: 'link',
    render: (data) => (<a
        rel="noreferrer"
        target="_blank"
        href={data.link}
        onClick={(e) => {
          e.preventDefault()
          e.stopPropagation()
          fetchEditToken(data.teacherUserCode, data.link)
        }}
      >
        {data.label}
      </a>
    ),
    sorter: (a, b) => (a.demoCourseDetails.label || "").toLowerCase() > (b.demoCourseDetails.label || "").toLowerCase() ? 1 : -1,
  },
  {
    title: 'Demo Type',
    align: 'center',
    dataIndex: 'demoCourseType',
    width: 200,
    editable: false,
    fieldType: 'select',
    sorter: (a, b) => a.demoCourseType > b.demoCourseType ? 1 : -1,
  },
  {
    title: 'Demo Earnings',
    align: 'center',
    dataIndex: 'demoEarning',
    render: (val) => (
      val.amount ? val.currency + ' ' + val.amount.toLocaleString() : 0
    ),
    width: 150,
    sorter: (a, b) => a.demoEarning.amount > b.demoEarning.amount ? 1 : -1,
  },
  {
    title: 'Demo Registration Count',
    align: 'center',
    dataIndex: 'demoRegCount',
    width: 150,
    sorter: (a, b) => a.demoRegCount > b.demoRegCount ? 1 : -1,
  },
  {
    title: 'Upsell Course Details',
    align: 'center',
    dataIndex: 'upsellCourseDetails',
    width: 200,
    editable: false,
    fieldType: 'link',
    render: (data) => (<a
        rel="noreferrer"
        target="_blank"
        href={data.link}
        onClick={(e) => {
          e.preventDefault()
          e.stopPropagation()
          fetchEditToken(data.teacherUserCode, data.link)
        }}
      >
        {data.label}
      </a>
    ),
    sorter: (a, b) => (a.upsellCourseDetails.label || "").toLowerCase() > (b.upsellCourseDetails.label || "").toLowerCase() ? 1 : -1,
  },
  {
    title: 'Upsell Earnings',
    align: 'center',
    dataIndex: 'upsellEarning',
    render: (val) => (
      val.amount ? val.currency + ' ' + val.amount.toLocaleString() : 0
    ),
    width: 150,
    sorter: (a, b) => a.upsellEarning.amount > b.upsellEarning.amount ? 1 : -1,
  },
  {
    title: 'Upsell Registration Count',
    align: 'center',
    dataIndex: 'upsellRegCount',
    width: 150,
    sorter: (a, b) => a.upsellRegCount > b.upsellRegCount ? 1 : -1
  },
  {
    title: 'Internal Notes / Notes',
    align: 'center',
    dataIndex: 'internalNotes',
    width: 200,
    editable: false,
    fieldType: 'textarea',
    ellipsis: {
      showTitle: false,
    },
    render: address => (
      <Tooltip placement="topLeft" title={address}>
        {address}
      </Tooltip>
    ),
  },
  {
    title: 'Facebook Ads Spent',
    align: 'center',
    dataIndex: 'facebook_ads_spent',
    width: 200,
    editable: false,
    fieldType: 'textarea',
    ellipsis: {
      showTitle: false,
    },
    render: facebook_ads_spent => (
      <Tooltip placement="topLeft" title={facebook_ads_spent}>
        {facebook_ads_spent}
      </Tooltip>
    ),
  },
  {
    title: 'Status',
    align: 'center',
    dataIndex: 'overallStatus',
    width: 200,
    fixed: 'right',
    editable: false,
    fieldType: 'select',
    sorter: (a, b) => a.overallStatus > b.overallStatus ? 1 : -1,
  },
]

export default DashboardTableModel
