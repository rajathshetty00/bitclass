import React, { useCallback, useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import moment from 'moment'
import {
  message,
  Card,
  Input,
  Select,
  Button,
  Modal,
  Form,
  DatePicker,
  Empty,
} from 'antd'
import { get, includes, isEmpty, uniq, debounce } from 'lodash-es'
import clsx from 'clsx'

import styles from './style.module.scss'
import DashboardTableModel from './TableColumnModel'
import EditableTable from '../../components/EditableTable'
import Loader from '../../atoms/Loader'
import {
  fetchData,
  hideLoader,
  init,
  updateData,
  clearData,
} from '../../actions/dashboard'
import {
  addCampaignCourse,
  updateCampaignCourse,
  updateCampaignStageAndDiscovery,
  addBitSelectCampaign,
} from '../../utils/api'
import { exists } from '../../utils/index'
import CountryCodes from '../../assets/json/CountryCodes.json'
import DataCard from '../../components/TeachersDataCard'
import ErrorComponent from '../../components/ErrorComponent'

const { Option } = Select
const { RangePicker } = DatePicker

const DashboardPage = ({ ...props }) => {
  const dispatch = useDispatch()
  const {
    rawData,
    loading,
    demoTypes,
    campaignStatus,
    internalUsers,
    error
  } = useSelector((state) => ({
    rawData: state.dashboard.data,
    loading: state.dashboard.loading,
    demoTypes: state.dashboard.demoTypes,
    campaignStatus: state.dashboard.campaignStatus,
    internalUsers: state.dashboard.internalUsers,
    error: state.dashboard.error
  }))
  const [data, setData] = useState([])
  const [planFilters, setPlanFilter] = useState([])
  const [filteredPlans, setFilteredPlans] = useState([])
  const [filteredStatus, setFilteredStatus] = useState([])
  const [search, setSearch] = useState('')
  const [tableView, setTableView] = useState(
    props.match.params.view === 'edit' ? false : true
  )
  const [addBitSelectUserVisible, setAddBitSelectUserVisible] = useState(false)
  const [dateRange, setDateRange] = useState([])
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [refreshData, setRefreshData] = useState(0)
  const _editableFields = [
    'discoveryCallDate',
    'overallStatus',
    'demoCourseType',
    'demoCourseDetails',
    'demoCourseType',
    'upsellCourseDetails',
    'internalNotes',
    'assignedTo',
    'demoWaLink',
    'upsellWaLink',
  ]

  useEffect(() => {
    ;(async () => {
      try {
        await dispatch(init())
        // dispatch(fetchData(moment().day(0).unix(), moment().unix())) //hide loader will happen inside the api call
        dispatch(hideLoader())
      } catch (e) {
        console.log(e)
        message.error('Failed to initialize page')
      }
    })()
  }, [])

  useEffect(() => {
    if (refreshData > 0) dispatch(fetchData(startDate, endDate, search))
  }, [refreshData])

  useEffect(() => {
    dataPopulateAdapter(rawData, filteredPlans, planFilters, filteredStatus)
  }, [filteredPlans, rawData, filteredStatus])

  const refetchData = () => {
    setRefreshData(refreshData + 1)
  }

  const dataPopulateAdapter = (
    rawData,
    filter = [],
    planFilters,
    filteredStatus = []
  ) => {
    let _data = []
    let _planFilters = []
    if (!isEmpty(rawData)) {
      for (let i = 0; i < rawData.length; i++) {
        let ele = rawData[i]

        if (!exists(ele.code)) continue
        //plan filter
        if (!isEmpty(filter) && !includes(filter, ele.plan_type)) continue
        //search
        // if (
        //   exists(search) &&
        //   !ele.teacher_name.toLowerCase().includes(search.toLowerCase())
        // )
        //   continue;
        //status filter
        if (!isEmpty(filteredStatus) && !includes(filteredStatus, ele.stage))
          continue

        _planFilters.push(ele.plan_type)
        let _formattedData = {}
        if (tableView) {
          _formattedData = {
            id: ele.code,
            teacherName: {
              label: ele.teacher_name,
              link: ele.profile_completion.profile_url,
              teacherUserCode: ele.teacher_user_code,
            },
            planType: ele.plan_type,
            discoveryCallDate: exists(ele.discovery_call_date)
              ? new moment.unix(ele.discovery_call_date)
              : '',
            profileCompletionPercentage: {
              percentage: ele.profile_completion.percentage,
              missing: exists(ele.profile_completion.missing_attributes)
                ? ele.profile_completion.missing_attributes.join(', ')
                : '',
            },
            leadEngagement: '',
            overallStatus: ele.stage,
            demoCourseDetails:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].demo_course)
                ? {
                    label: ele.courses[0].demo_course.heading,
                    link: ele.courses[0].demo_course.course_update_url,
                    editValue: ele.courses[0].demo_course.course_code,
                    teacherUserCode: ele.teacher_user_code,
                  }
                : '',
            demoCourseType:
              !isEmpty(ele.courses) && exists(ele.courses[0].demo_type)
                ? ele.courses[0].demo_type
                : '',
            upsellCourseDetails:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].upsell_course)
                ? {
                    label: ele.courses[0].upsell_course.heading,
                    link: ele.courses[0].upsell_course.course_update_url,
                    editValue: ele.courses[0].upsell_course.course_code,
                    teacherUserCode: ele.teacher_user_code,
                  }
                : '',
            extraParams: {
              tmpc_code:
                !isEmpty(ele.courses) && exists(ele.courses[0].tmpc_code)
                  ? ele.courses[0].tmpc_code
                  : '',
              demoCourseCode:
                !isEmpty(ele.courses) && !isEmpty(ele.courses[0].demo_course)
                  ? ele.courses[0].demo_course.course_code
                  : '',
              upsellCourseCode:
                !isEmpty(ele.courses) && !isEmpty(ele.courses[0].upsell_course)
                  ? ele.courses[0].upsell_course.course_code
                  : '',
            },
            paidOn: exists(ele.created_at)
              ? new moment.unix(ele.created_at)
              : '',
            internalNotes: ele.notes,
            assignedTo: exists(ele.account_owner)
              ? ele.account_owner.username
              : '',
            demoEarning:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].demo_course)
                ? ele.courses[0].demo_course.earning
                : { amount: 0, currency: 'INR' },
            upsellEarning:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].upsell_course)
                ? ele.courses[0].upsell_course.earning
                : { amount: 0, currency: 'INR' },
            demoWaLink:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].demo_course)
                ? ele.courses[0].demo_course.wa_group_invite_code
                : '',
            upsellWaLink:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].upsell_course)
                ? ele.courses[0].upsell_course.wa_group_invite_code
                : '',
            demoRegCount:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].demo_course)
                ? ele.courses[0].demo_course.registration_count
                : 0,
            upsellRegCount:
              !isEmpty(ele.courses) && !isEmpty(ele.courses[0].upsell_course)
                ? ele.courses[0].upsell_course.registration_count
                : 0,
            facebook_ads_spent: ele.facebook_ads_spent || 0,
            demo_external_campaign_ids: get(
              ele,
              'demo_course.external_campaign_ids',
              []
            ),
            upsell_external_campaign_ids: get(
              ele,
              'upsell_course.external_campaign_ids',
              []
            ),
          }
        } else {
          _formattedData = {
            id: ele.code,
            teacherName: {
              label: ele.teacher_name,
              link: ele.profile_completion.profile_url,
              teacherUserCode: ele.teacher_user_code,
            },
            planType: ele.plan_type,
            discoveryCallDate: exists(ele.discovery_call_date)
              ? new moment.unix(ele.discovery_call_date)
              : '',
            profileCompletionPercentage: {
              percentage: ele.profile_completion.percentage,
              missing: exists(ele.profile_completion.missing_attributes)
                ? ele.profile_completion.missing_attributes.join(', ')
                : '',
            },
            leadEngagement: '',
            overallStatus: ele.stage,
            paidOn: exists(ele.created_at)
              ? new moment.unix(ele.created_at)
              : '',
            internalNotes: ele.notes,
            assignedTo: exists(ele.account_owner)
              ? ele.account_owner.username
              : '',
            assignedToVal: exists(ele.account_owner)
              ? ele.account_owner.code
              : '',
            courses: !isEmpty(ele.courses) ? ele.courses : [],
            teacherCountryCode: ele.teacher_country_code,
            teacherPhone: ele.teacher_phone,
            facebook_ads_spent: ele.facebook_ads_spent || 0,
            demo_external_campaign_ids: get(
              ele,
              'demo_course.external_campaign_ids',
              []
            ),
            upsell_external_campaign_ids: get(
              ele,
              'upsell_course.external_campaign_ids',
              []
            ),
          }
        }
        _data.push(_formattedData)
      }
    }
    setData(_data)
    setPlanFilter(uniq([...planFilters, ..._planFilters]))
  }

  const updateRawData = (id, data) => {
    if (!exists(id)) {
      return
    }

    let _newRawData = rawData.map((v, i) => {
      if (v.code === id) {
        v = { ...v, ...data }
      }
      return v
    })

    dispatch(updateData(_newRawData))
  }

  const saveData = async (data) => {
    if (!exists(data.id)) {
      message.error('TMPR code not found')
      return
    }

    let updateToApi = {}

    if (typeof data.discoveryCallDate !== 'undefined') {
      let dcd = moment.isMoment(data.discoveryCallDate)
        ? data.discoveryCallDate.format('YYYY-MM-DD')
        : ''
      updateToApi.key = 'discovery_call_date'
      updateToApi.val = dcd
    } else if (exists(data.overallStatus)) {
      updateToApi.key = 'stage'
      updateToApi.val = data.overallStatus
    } else if (exists(data.external_campaign_ids)) {
      updateToApi.key = 'external_campaign_ids'
      updateToApi.val = {
        course_code: data.extraParams.demoCourseCode,
        external_campaign_ids: data.external_campaign_ids.split(','),
      }
    } else if (exists(data.assignedTo)) {
      updateToApi.key = 'account_owner'
      updateToApi.val = data.assignedTo
    } else if (typeof data.internalNotes !== 'undefined') {
      updateToApi.key = 'notes'
      updateToApi.val = data.internalNotes
    } else if (typeof data.demoWaLink !== 'undefined') {
      if (!exists(data.extraParams.demoCourseCode)) {
        message.error('Demo course not found')
        return
      }
      updateToApi.key = 'wa_group_invite_code'
      updateToApi.val = {
        course_code: data.extraParams.demoCourseCode,
        wa_group_invite_code: data.demoWaLink,
      }
    } else if (typeof data.upsellWaLink !== 'undefined') {
      if (!exists(data.extraParams.upsellCourseCode)) {
        message.error('Upsell course not found')
        return
      }
      updateToApi.key = 'wa_group_invite_code'
      updateToApi.val = {
        course_code: data.extraParams.upsellCourseCode,
        wa_group_invite_code: data.upsellWaLink,
      }
    }

    if (!isEmpty(updateToApi)) {
      let loadMessage = message.loading('Saving data...', 0)
      try {
        let res = await updateCampaignStageAndDiscovery(
          data.id,
          updateToApi.key,
          updateToApi.val
        )
        if (!exists(res.error)) {
          updateRawData(data.id, res.data)
          loadMessage()
          message.success('Updated successfully')
        } else {
          loadMessage()
          message.error(res.error)
        }
      } catch (e) {
        loadMessage()
        message.error('Something went wrong')
      }
    }

    updateToApi = {}
    if (
      exists(data.demoCourseDetails) ||
      exists(data.upsellCourseDetails) ||
      exists(data.demoCourseType)
    ) {
      if (
        !isEmpty(data.extraParams) &&
        exists(data.extraParams.tmpc_code) &&
        data.extraParams.tmpc_code !== ''
      ) {
        updateToApi.tmpc_code = data.extraParams.tmpc_code
      } else {
        updateToApi.tmpc_code = ''
      }
      if (exists(data.demoCourseDetails))
        updateToApi.demo_course_code =
          data.demoCourseDetails === -1 ? '' : data.demoCourseDetails
      if (exists(data.upsellCourseDetails))
        updateToApi.upsell_course_code =
          data.upsellCourseDetails === -1 ? '' : data.upsellCourseDetails
      if (exists(data.demoCourseType))
        updateToApi.demo_type = data.demoCourseType

      let loadMessage = message.loading('Saving data...', 0)
      try {
        let res = ''
        if (exists(updateToApi.tmpc_code)) {
          res = await updateCampaignCourse(data.id, updateToApi)
        } else {
          res = await addCampaignCourse(data.id, updateToApi)
        }
        if (!exists(res.error)) {
          updateRawData(data.id, res.data)
          await loadMessage()
          message.success('Updated successfully')
        } else {
          await loadMessage()
          message.error(res.error)
        }
      } catch (e) {
        await loadMessage()
        message.error('Something went wrong')
      }
    }
  }

  const clearAllFilters = () => {
    setFilteredPlans([])
    setFilteredStatus([])
    let _search = search
    let _dateRange = dateRange
    setSearch('')
    setDateRange([])
    setStartDate('')
    setEndDate('')
    if (exists(_search) || _dateRange.length > 0) {
      dispatch(clearData())
    }
  }

  // add filter state to columns...
  //if model is changed this also needs to taken care
  // DashboardTableModel[1].filteredValue = planTypeFilter.planType || null
  // attach handle save function to the column model
  // attach only to editable fields
  // key should be handle save
  DashboardTableModel.forEach((v, i) => {
    if (includes(_editableFields, v.dataIndex)) {
      v.handleSave = saveData
    }

    //set demo type dropdown
    if (v.dataIndex === 'demoCourseType') {
      v.selectOptions = demoTypes.map((vi) => ({ label: vi, value: vi }))
    }

    //set status dropdown
    if (v.dataIndex === 'overallStatus') {
      v.selectOptions = campaignStatus.map((vi) => ({ label: vi, value: vi }))
    }

    //set internal users dropdown
    if (v.dataIndex === 'assignedTo') {
      v.selectOptions = internalUsers.map((vi) => ({
        label: vi.username,
        value: vi.code,
      }))
    }

    return v
  })

  const countryToFlag = (isoCode) => {
    return typeof String.fromCodePoint !== 'undefined'
      ? isoCode
          .toUpperCase()
          .replace(/./g, (char) =>
            String.fromCodePoint(char.charCodeAt(0) + 127397)
          )
      : isoCode
  }

  const BitSelectFormSubmit = (data) => {
    if (!exists(data.countryCode)) {
      message.error('Please select country code!!!')
      return
    }
    let countryCode = data.countryCode.split('###')[0]
    if (!exists(data.mobile) || isNaN(data.mobile)) {
      message.error('Invalid mobile number!!!')
      return
    }
    let loadMessage = message.loading('Saving data...', 0)
    addBitSelectCampaign(countryCode, data.mobile,data.email).then((res) => {
      loadMessage()
      if (res.success) {
        message.success('Added successfully')
        dispatch(fetchData())
        setAddBitSelectUserVisible(false)
      } else {
        message.error(res.error)
      }
    })
  }
  const delayedRefreshData = useCallback(debounce((value) =>setRefreshData(value + 1),1000),[])
  const searchHandler = (type, val, extraVal = null) => {
    if (!type) return

    if (type === 'date_range') {
      setDateRange(extraVal)
      setStartDate(exists(val[0]) ? moment(val[0]).unix() : '')
      setEndDate(exists(val[1]) ? moment(val[1]).unix() : '')
    }
    if (type === 'teacher_name') {
      setSearch(val)
    }
    delayedRefreshData(refreshData)
  }

  let _internalUsers = internalUsers.map((vi) => ({
    label: vi.username,
    value: vi.code,
  }))
  let _campaignStatuses = campaignStatus.map((vi) => ({ label: vi, value: vi }))
  let _demoTypes = demoTypes.map((vi) => ({ label: vi, value: vi }))

  console.log(error, 'error')


  return loading ? (
    <Loader />
  ) : 
  (
    <div className={styles.dashboardContainer}>
      <Card
        className={clsx(styles.filters, 'roundedCard')}
        bodyStyle={{
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'row',
        }}
      >
        <RangePicker
          className={styles.inputs}
          style={{ maxWidth: 250, width: 250 }}
          value={dateRange}
          onChange={(d, v) => searchHandler('date_range', v, d)}
        />
        <Input
          placeholder="Search by name"
          className={styles.inputs}
          value={search}
          onChange={(e) => searchHandler('teacher_name', e.target.value)}
        />
        <Select
          mode="multiple"
          allowClear
          className={styles.inputs}
          placeholder="Filter by type"
          value={filteredPlans}
          onChange={(val) => {
            setFilteredPlans(val)
          }}
        >
          {planFilters.map((v, i) => (
            <Option key={i.toString()} value={v}>
              {v}
            </Option>
          ))}
        </Select>
        <Select
          mode="multiple"
          allowClear
          className={styles.inputs}
          placeholder="Filter by status"
          value={filteredStatus}
          onChange={(val) => {
            setFilteredStatus(val)
          }}
          style={{
            width: '13vw',
            minWidth: '13vw',
          }}
        >
          {campaignStatus.map((v, i) => (
            <Option key={i.toString()} value={v}>
              {v}
            </Option>
          ))}
        </Select>
        <Button onClick={clearAllFilters}>clear all</Button>
        <Button
          style={{
            position: 'absolute',
            right: '24px',
          }}
          onClick={() => setAddBitSelectUserVisible(true)}
          className={styles.bitSelectAdd}
          type="primary"
        >
          Add BitSelect Campaign
        </Button>
      </Card>

      {tableView && (
        <EditableTable
          columns={DashboardTableModel}
          dataSource={data}
          bordered
          size="small"
          scroll={{ x: 1300 }}
          locale={{
            emptyText: (
              <Empty description="No data found. Please adjust date range." />
            ),
          }}
        />
      )}

      {!tableView &&
        data &&
        data.map((iData, i) => {
          return(
          <DataCard
            data={iData}
            key={i.toString()}
            moment={moment}
            internalUsers={_internalUsers}
            campaignStatuses={_campaignStatuses}
            demoTypes={_demoTypes}
            handleSave={saveData}
            updateRawData={updateRawData}
            refetchData={refetchData}
          />
        )})}

      {!tableView && data.length === 0 && (
        <Empty
          style={{ marginTop: '60px' }}
          description="No data found. Please adjust date range."
        />
      )}

      <Modal
        title="Add BitSelect Campaign"
        centered
        visible={addBitSelectUserVisible}
        onOk={() => {
          setTimeout(() => {
            document.body.style.overflow = 'auto'
          }, 1000)
          // setAddBitSelectUserVisible(false)
        }}
        onCancel={() => {
          setTimeout(() => {
            document.body.style.overflow = 'auto'
          }, 1000)
          setAddBitSelectUserVisible(false)
        }}
        okText="Add User"
        okButtonProps={{ form: 'bitSelectForm', htmlType: 'submit' }}
      >
        <Form
          onFinish={BitSelectFormSubmit}
          id="bitSelectForm"
          initialValues={{
            countryCode: `+91###India`,
          }}
        >
          <Form.Item
            name="countryCode"
            rules={[
              {
                required: true,
                message: 'Country code cannot be empty',
              },
            ]}
          >
            <Select showSearch>
              {CountryCodes.map((option, index) => (
                <Option
                  value={`${option.dial_code}###${option.name}`}
                  key={index.toString()}
                >
                  {/* added ### for searchable select */}
                  <span>{countryToFlag(option.code)}</span>
                  <span style={{ marginLeft: '8px' }}>
                    {option.name} ({option.dial_code})
                  </span>
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item
            name="mobile"
            rules={[
              {
                required: true,
                message: 'Invalid or Empty Mobile Number',
              },
            ]}
          >
            <Input placeholder="Mobile Number" type="number" />
          </Form.Item>
          <Form.Item
            name="email"
            rules={[
              {
                required: true,
                message: 'Invalid or Empty Email',
              },
            ]}
          >
            <Input placeholder="Email" type="email" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default DashboardPage
