import React, { useState, useEffect } from 'react'
import clsx from 'clsx'
import {
  Button,
  Card,
  Drawer,
  Input,
  Table,
} from 'antd'
import { LoadingOutlined } from '@ant-design/icons'
import { useSelector, useDispatch } from "react-redux"

import styles from './styles.module.scss'
import { downloadCSV, exists } from '../../utils/index';
import {
  fetchData,
  clearData,
  hideLoader,
  fetchAggregateData,
  fetchDataWithRange,
} from '../../actions/feedback'
import { CSVLink } from 'react-csv'

const TableModel = [
  {
    title: 'Name',
    align: 'center',
    dataIndex: 'name',
    width: 200,
  },
  {
    title: 'Phone No.',
    align: 'center',
    dataIndex: 'phone',
    width: 200,
  },
  {
    title: 'Email',
    align: 'center',
    dataIndex: 'email',
    width: 200,
  },
  {
    title: 'Reg. for Advanced Course',
    align: 'center',
    dataIndex: 'regForAdvCourse',
    width: 200,
  },
  {
    title: 'Learnings From The Course',
    align: 'center',
    dataIndex: 'learningFromCourse',
    width: 200,
  },
  {
    title: 'Rating on Experience',
    align: 'center',
    dataIndex: 'ratingOnExperience',
    width: 200,
  },
  {
    title: 'Rating on Skills After',
    align: 'center',
    dataIndex: 'ratingOnSkillsAfter',
    width: 200,
  },
  {
    title: 'Rating on Skills Before',
    align: 'center',
    dataIndex: 'ratingOnSkillsBefore',
    width: 200,
  },
  {
    title: 'Courses Want to Explore',
    align: 'center',
    dataIndex: 'coursesToExplore',
    width: 200,
  },
  {
    title: 'Will Recommend to Friends?',
    align: 'center',
    dataIndex: 'recommendationToFriends',
    width: 200,
  },
]


const FeedbackPage = () => {
  const alphabeticalSort = (a,b) => {
    if (a < b) return -1
    if (a > b)return 1
    return 0;
  }
  
  const primaryTableModal = [
    {
      title: "Course Code",
      align: "center",
      dataIndex: "code",
      width: 200,
      sorter: (a, b) => alphabeticalSort(a.code, b.code),
      render: (text) => (
        <a
          onClick={() => {
            setCourseCode(text)
            setOpenDrawer(true)
          }}
        >
          {text}
        </a>
      ),
    },
    {
      title: "Course Heading",
      align: "center",
      dataIndex: "heading",
      width: 200,
      sorter: (a, b) => alphabeticalSort(a.code, b.code),
    },
    {
      title: "End Date",
      align: "center",
      dataIndex: "end_date",
      width: 200,
      sorter: (a, b) => alphabeticalSort(a.code, b.code),
    },
    {
      title: "Price",
      align: "center",
      dataIndex: "amount",
      width: 200,
      sorter: (a, b) => a.amount - b.amount,
    },
    {
      title: "Registrations",
      align: "center",
      dataIndex: "registrations",
      width: 200,
      sorter: (a, b) => a.registrations - b.registrations,
    },
  ]
  const [openDrawer, setOpenDrawer] = useState(false)
  const initialCSVData= [
    "Name",
    "Phone No.",
    "Email",
    "Reg. for Advanced Course",
    "Learnings From The Course",
    "Rating on Experience",
    "Rating on Skills After",
    "Rating on Skills Before",
    "Courses Want to Explore",
    "Will Recommend to Friends?",
  ]
  const [csvData, setCsvData] = useState([
    initialCSVData
  ])
  const [tableData, setTableData] = useState([])
  const [courseCode, setCourseCode] = useState('')
  const [searchText, setSearchKey] = useState('')


  const dispatch = useDispatch()
  const { data, loading,rangeFeedbacks } = useSelector((state) => ({
    rangeFeedbacks:state.feedback.rangeFeedbackData,
    aggregateData: state.feedback.aggregateData,
    data: state.feedback.data,
    loading: state.feedback.loading,
  }))


  useEffect(() => {
    dispatch(hideLoader())
  }, [])

  useEffect(() => {
    if(exists(courseCode)) {
      dispatch(fetchData(courseCode))
      setCsvData([initialCSVData])
    } else {
      dispatch(clearData())
    }
  }, [courseCode])

  useEffect(() => {
      dispatch(fetchDataWithRange(5))
  }, [])

  useEffect(() => {
    if(exists(data)) {
      const _tableData = data.map(v => ({
          name: v?.user?.username || '-',
          phone: v?.user?.phone || '-',
          email: v?.user?.email || '-',
          regForAdvCourse: v?.feedback["Have you registered for the Advanced Course?"] || '',
          learningFromCourse: v?.feedback["Key Learnings from the course"] || '',
          ratingOnExperience: v?.feedback["Rate your experience about the course"] || '',
          ratingOnSkillsAfter: v?.feedback["Rate your skills after this course"] || '',
          ratingOnSkillsBefore: v?.feedback["Rate your skills before this course"] || '',
          coursesToExplore: v?.feedback["What other courses would you like to explore at BitClass?"] || '',
          recommendationToFriends: v?.feedback["Would you recommend this experience to your friends? (1=Not at all, 10=Definitely)"] || '',
        }))
      setTableData(_tableData)
      addNewDataToCsv(_tableData)
    } else {
      setTableData([])
    }
  }, [data])

  const addNewDataToCsv = (_tableData) => {
    const output = _tableData.map(rowData=>Object.values(rowData))
    setCsvData([...csvData,...output])
  }
  
  const handleEnterPress = (e) => {
    const searchKey=e.currentTarget.value.split(" ").join("")
    setCourseCode(searchKey);
    setOpenDrawer(true)
  }
  return (
    <div className={styles.studentProfileContainer}>
      {/* Filter Section */}
      <Card
        className={clsx(styles.filters, "roundedCard")}
        bodyStyle={{
          display: "flex",
          alignItems: "center",
          flexDirection: "row",
        }}
      >
        <Input
          placeholder="Search by course code"
          value={searchText}
          className={styles.inputs}
          onChange={(e) => setSearchKey(e.target.value)}
          onPressEnter={handleEnterPress}
        />
      </Card>
      {/* Filter Section Ends */}

      {/* Table Section */}

      <Table
        columns={primaryTableModal}
        size={"small"}
        dataSource={rangeFeedbacks}
        bordered
        loading={{
          spinning: loading,
          indicator: <LoadingOutlined type="loading" />,
        }}
      />
      {/* Table Section Ends */}

      {/* Drawer Section Starts */}
      <Drawer
        title="Student Feedback"
        placement={"right"}
        closable={true}
        onClose={() => setOpenDrawer(false)}
        visible={openDrawer}
        key={"right"}
        width="95vw"
      >
        <>
          <div className={styles.csvDownloadBtn}>
            <Button>
              <CSVLink
                data={csvData}
                filename={`Feedback Report - ${courseCode}.csv`}
                separator={";"}
              >
                Download
              </CSVLink>
            </Button>
          </div>
          <Table
            columns={TableModel}
            size={"small"}
            dataSource={tableData}
            bordered
            loading={{
              spinning: loading,
              indicator: <LoadingOutlined type="loading" />,
            }}
          />
        </>
      </Drawer>
      {/* Drawer Section ends */}
    </div>
  )
}

export default FeedbackPage
