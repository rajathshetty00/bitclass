import React, { useEffect, useState } from 'react'
import { useSelector, useDispatch } from "react-redux";
import Loader from '../../atoms/Loader';

import styles from './style.module.scss'
import { fetchGenieData } from '../../actions/genie';
import { Table } from 'antd';
import ErrorComponent from '../../components/ErrorComponent'

const GeniePage = () => {

  const dispatch = useDispatch()
  const [tableData, setTableData] = useState([])
  const {
    data,
    loading,
    error
  } = useSelector(
    (state) => ({
      data: state.genie.data,
      loading: state.genie.loading,
      error: state.genie.error
    })
  );

  console.log(error,'error')

  useEffect(() => {
    dispatch(fetchGenieData())
  }, [])

  useEffect(() => {
    let _data = data.map((v, i) => {
      let _t = { ...v }
      _t = { ..._t, ...v.intent }
      delete _t.intent
      return _t
    })
    setTableData(_data)
  }, [data])

  const columns = [
    {
      title: 'Code',
      dataIndex: 'code',
      align: 'center',
    },
    {
      title: 'Name',
      dataIndex: 'name',
      align: 'center',
    },
    {
      title: 'Email',
      dataIndex: 'email',
      align: 'center',
    },
    {
      title: 'Phone',
      dataIndex: 'phone',
      align: 'center',
    },
    {
      title: 'Intent',
      align: 'center',
      children: [
        {
          title: 'How',
          align: 'center',
          dataIndex: 'how',
        },
        {
          title: 'Price',
          align: 'center',
          dataIndex: 'price',
        },
        {
          title: 'Subject',
          align: 'center',
          dataIndex: 'subject',
        }
      ]
    },
  ];

  return loading ? (
    <Loader />
  ) :
  (
    <div className={styles.mainContainer}>
      <Table
        dataSource={tableData}
        
        columns={columns}
        bordered
        size="small"
      />
    </div>
  )
}

export default GeniePage
