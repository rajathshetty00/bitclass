import { Select } from 'antd'
import Checkbox from 'antd/lib/checkbox/Checkbox'
import styles from './styles.module.scss'

const ItemList = ({ leadList }) => {

  const { Option } = Select


  return (
    <div className={styles.itemListContainer}>
      {leadList && leadList?.map((item, index) => {
        return (
          <div className={styles.itemListBody}>
            <div>{item?.username}</div>
            <div className={styles.itemList}>
              <div>{item?.phone}</div>
              <div>{item?.email}</div>
              <div>
                <Checkbox> Calling Done?</Checkbox>
              </div>
              {
                item?.is_registered ?
                  <p className={styles.greenContainer}>Registered</p> :
                  <p className={styles.redContainer}>Not registered </p>
              }

              {
                item?.remark && (
                  <p className={styles.remark}>
                    <span>Remark:</span> {item.remark}
                  </p>
                )
              }
            </div>
          </div>
        )
      })}
      {leadList !== null && leadList?.length === 0 && (
        <h2>No Leads Present</h2>
      )}
    </div>
  )
}

export default ItemList