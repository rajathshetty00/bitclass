import { Button, Collapse, message, Modal, Tooltip } from "antd"
import clsx from "clsx"
import { useEffect, useState } from "react"
import { Book, Check, Phone, Sun, Video } from "react-feather"
import { API_URL, WEB_URL } from "../../constants"
import { getDateFormat } from "../../utils"
import {
  getHotLeads,
  getISTCourseDetails,
  postMarkAsDone,
} from "../../utils/api"
import ItemList from "./ItemList"
import styles from "./styles.module.scss"

const GigEconomy = () => {
  const [visible, setVisible] = useState(false)
  const [leadList, setLeadList] = useState(null)
  const [feedback, setFeedback] = useState(null)
  const [istCourseList, setIstCourseList] = useState(null)
  const [loading, setLoading] = useState(false)
  const [toggleMarkAsDone, setToggleMarkAsDone] = useState(false)

  useEffect(() => {
    ; (async () => {
      try {
        setLoading(true)
        const { data } = await getISTCourseDetails()
        if (data?.length > 0) {
          setIstCourseList(data)
        }
      } catch (e) { }
      finally {
        setLoading(false)
      }
    })()
  }, [toggleMarkAsDone])

  const showLeads = async (courseCode) => {
    try {
      setVisible(true)
      const { data, success } = await getHotLeads(courseCode)
      if (success) {
        const { lead_list, feedback } = data
        setLeadList(lead_list)
        setFeedback(feedback)
      }
    } catch {
    } finally {
    }
  }

  const markAsDoneHandler = async (course) => {
    try {
      const { data, success } = await postMarkAsDone(course)
      if (success) {
        message.success('success')
        setToggleMarkAsDone(!toggleMarkAsDone)
      } else message.error('Failed to update! Please try again...')
    } catch {
      message.error('Failed to update! Please try again...')
    } finally {

    }
  }

  return (
    <div className={styles.gigEconomyContainer}>
      {istCourseList ?
        istCourseList.map((item, index) => (
          <>
            <div>
              <div className={styles.cardBody}>
                <div className={styles.gridContainer1}>
                  <div className={styles.firstItem}>
                    <h1>
                      <a
                        target="bitclass-workshop"
                        href={`${WEB_URL}/live-classes/${item?.course_code}`}
                        onClick={(e) => e.stopPropagation()}
                      >
                        {item?.heading}
                      </a>
                    </h1>
                    <p>
                      {item?.full_course_price !== null && (
                        <>
                          <b>Price -</b> <span>{item?.full_course_price} {item?.currency}
                          </span>
                        </>
                      )}
                    </p>
                    <p>
                      {
                        item?.teacher_name !== null && (
                          <>
                            <b>Teacher name -</b> <span>{item?.teacher_name}
                            </span>
                          </>
                        )
                      }
                    </p>
                  </div>
                  <div className={styles.secondItem}>
                    <h5>Course Starts from  </h5>
                    <p>{item?.date}</p>
                  </div>
                </div>
                <div className={styles.gridContainer2}>
                  <div className={styles.firstItem}>
                    <h5>Registrations so far: {item?.registrations_so_far}</h5>
                    <h6>Target registrations: -</h6>
                  </div>

                  <div className={styles.secondItem}>
                    <h3>Earnings so far: {item?.revenue_so_far}</h3>
                    <h4>Potential Earnings: {item?.potential_earnings || '-'}</h4>
                  </div>

                  <div className={styles.thirdItem}>
                    <div className={styles.buttonContainer}>
                      <Button
                        icon={<Phone />}
                        type="primary"
                        onClick={(e) => {
                          showLeads(item?.course_code)
                        }}
                      >
                        Start Calling
                      </Button>

                      <Button
                        icon={<Check />}
                        type="dashed"
                        onClick={(e) => {
                          markAsDoneHandler(item?.course_code)
                        }}
                        className={styles.markAsDoneBtn}
                      >
                        Mark as done
                      </Button>
                    </div>
                  </div>
                </div>
                {/* <div className={styles.gridContainer3}>
                  <h5>Target registrations: -</h5>
              </div> */}

              </div>
            </div>
          </>
        )) :
        loading ?
          <div style={{ textAlign: 'center' }}>Loading...</div> :
          <h2>No courses assigned!</h2>

      }

      <Modal
        visible={visible}
        footer={null}
        onCancel={() => setVisible(false)}
        title={
          <div className={styles.feedbackWrapper}>
            <h5>My leads</h5>
            {feedback && (
              <Tooltip
                color="black"
                overlayClassName={styles.feedbacktooltipWrapper}
                title={Object.entries(feedback).map(([key, val]) => (
                  <p>
                    Question: {key}
                    <p>Answer: {val}</p>
                  </p>
                ))}
              >
                <Button
                  icon={
                    <Sun
                      size={20}

                    />}
                  className={styles.salesTip}
                  type="primary">
                  Read sales tip
                  </Button>
              </Tooltip>
            )}
          </div>
        }
        className={styles.gigEconomyModal}
      >
        <div>
          <ItemList leadList={leadList} />
        </div>
      </Modal>
    </div>
  )
}

export default GigEconomy
