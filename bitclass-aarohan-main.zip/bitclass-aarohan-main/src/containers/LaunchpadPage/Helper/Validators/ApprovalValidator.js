import { isEmpty } from 'lodash-es';
export default function approvalValidator(values) {
    const errors = {};
    if (isEmpty(values['status'])) {

        errors['status'] = "Please click any status button";
    }


    return errors;
}