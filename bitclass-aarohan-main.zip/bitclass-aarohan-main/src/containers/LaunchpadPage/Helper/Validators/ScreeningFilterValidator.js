
export default function screeningFilterValidator(values) {
    const errors = {};
    if (values['searchTerm'].length > 0 && (values['searchFilter'] == "null" || values['searchFilter'] == "")) {

        errors['searchFilter'] = "Please select one field";
    }
    if (values['searchTerm'].length == 0 && values['searchFilter'].length > 0) {
        errors['searchTerm'] = "Search term is required";
    }
    if (Number.isNaN(values['endDate'])) {
        errors['dateRange'] = "Please enter valid end date";
    }
    if (Number.isNaN(values['startDate'])) {
        errors['dateRange'] = "Please enter valid start date";
    }


    return errors;
}