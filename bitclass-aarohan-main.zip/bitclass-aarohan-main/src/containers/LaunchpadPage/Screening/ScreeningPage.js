import React, { createContext, useRef } from 'react'
import AlertComponent from '../../../atoms/alertComponent/AlertComponent'
import ScreeningFilter from '../components/ScreeningFilter/ScreeningFilter'
import ScreeningTable from '../components/ScreeningTable/ScreeningTable'
export const ScreeningContext = createContext()

const ScreeningPage = () => {
const alertRef = useRef()
    
    return (
        <div>
            <ScreeningContext.Provider  value={alertRef}>
            <ScreeningFilter />
            <ScreeningTable />
            <AlertComponent ref={alertRef} />
            </ScreeningContext.Provider>

        </div>
    )
}

export default ScreeningPage
