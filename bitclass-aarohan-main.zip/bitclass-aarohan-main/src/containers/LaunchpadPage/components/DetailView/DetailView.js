import { Divider, Tag } from 'antd'
import TextArea from 'antd/lib/input/TextArea'
import React from 'react'
import { Fragment } from 'react'

const DetailView = ({ Obj }) => {
    const _renderObject = () => {
        
        return Obj&&Object.entries(Obj).map(([key, value], i) => {
            return (
                <div style={{width:"500px"}} key={key}>
                    <Divider orientation="left"><Tag color="success">{key}</Tag></Divider>

                    <TextArea
                        placeholder="Autosize height with minimum and maximum number of lines"
                        autoSize={{ minRows: 2, maxRows: 6 }}
                        value={value}
                    />
                </div>
            )
        })
    }
    return (
        <div>
            {_renderObject()}
        </div>
    )
}

export default DetailView
