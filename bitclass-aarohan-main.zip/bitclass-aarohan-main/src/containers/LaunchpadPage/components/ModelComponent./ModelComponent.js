import { Modal, Button } from 'antd';
import { useContext, useState } from 'react';
import styles from './style.module.scss'
import { CheckCircleOutlined, PauseCircleOutlined, DeleteOutlined } from '@ant-design/icons';
import TextArea from 'antd/lib/input/TextArea';
import clsx from 'clsx';
import useRedux from '../../../../helpers/useRedux';
import approvalValidator from '../../Helper/Validators/ApprovalValidator';
import useFormValidator from '../../Helper/useFormValidator';
import { LoadingOutlined } from '@ant-design/icons'
import { postApprovedData } from '../../../../actions/screening';
import { ScreeningContext } from '../../Screening/ScreeningPage'
import { Edit } from 'react-feather';
 const mapStatus=(data)=>{
   switch (data) {
     case 1:
       return 'approved';
     case 2:
       return 'reject';
     case 3:
       return 'hold';

     default:
       return "";
   }
}
const ModelComponent = ({ teacher_id, heading = false ,comment,statusData}) => {
  const [visible, setVisible] = useState(false);
  const [status, setStatus] = useState(mapStatus(statusData));
  const [comments, setcomments] = useState(comment);
  const notifyRef = useContext(ScreeningContext)

  const [{ approveLoading }, dispatch] = useRedux('screening');
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(SubmitData, { status, comments }, approvalValidator);
  const handleStatus = (status) => {
    setStatus(status)
    setErrors({});
    setIsSubmitting(false);
  }
  const handleComment = (e) => {
    setErrors({});
    setIsSubmitting(false);

    const value = e.target.value;
    if (value === undefined) {
      setcomments("")
    } else {
      setcomments(value)
    }

  }
  function SubmitData() {
    setErrors({});
    setIsSubmitting(false);

    // api call here 
    dispatch(postApprovedData(teacher_id, {
      "status": status,
      "comments": comments
    }, notifyRef, setVisible))
    setStatus(null);
  }
  return (
    <>
      <div onClick={() => { setVisible(true) }} className={styles.cell_disp} >
        <p className={styles.pencil_icon}><Edit size={25} color={"MediumSlateBlue"} /></p>
      </div>
      <Modal

        centeredradio_content
        visible={visible}
        onOk={handleSubmit}
        onCancel={() => setVisible(false)}
        width={1000}
        okButtonProps={{ disabled: approveLoading }}
        okText={<p>{approveLoading ? <span>loading...<LoadingOutlined type="loading" /></span> : "Submit"}</p>}

        className={styles.modelWrapper}
      >
        <div className={styles.model_body}>
          {heading && <h1>{heading} </h1>}
          <div>
            <div className={styles.button_wrapper}>
              <Button className={clsx(styles.btn, styles.button_success, status === "approved" && styles.btn_selected)} icon={<CheckCircleOutlined />} size={"large"} onClick={() => handleStatus('approved')} >
                Approve
              </Button>
              <Button className={clsx(styles.button_dangour, styles.btn, status === "reject" && styles.btn_selected)} icon={<DeleteOutlined />} size={"large"} onClick={() => handleStatus('reject')} >Reject</Button>
              <Button className={clsx(styles.button_warning, styles.btn, status === "hold" && styles.btn_selected)} icon={<PauseCircleOutlined />} size={"large"} onClick={() => handleStatus('hold')}>On Hold</Button>
              {errors['status'] && <p className={styles.errormsg}>{errors['status']}</p>}
            </div>

            <div className={styles.text_area_wrapper}>
              <TextArea placeholder="Please add comments" value={comments} onChange={handleComment} className={styles.textArea} allowClear autoSize={{ minRows: 3, maxRows: 5 }} />
              {errors['comments'] && <p className={styles.errormsg}>{errors['comments']}</p>}

            </div>
          </div>

        </div>
      </Modal>

    </>
  )
}

export default ModelComponent