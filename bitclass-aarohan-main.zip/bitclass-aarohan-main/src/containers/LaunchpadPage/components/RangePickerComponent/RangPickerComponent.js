import { DatePicker} from 'antd'

const { RangePicker } = DatePicker;
const RangPickerComponent = ({value,handleDataRange,validate}) => {
    return (
        <div stye={{position: 'relative'}}>
               
               <RangePicker
          value={value}
          onChange={handleDataRange}

     />
     {validate && <p style={{  position:'absolute',top:'35px',color:'tomato'}} >{validate}</p>}
        </div>
    )
}

export default RangPickerComponent
