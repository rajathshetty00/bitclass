import { Button, DatePicker } from 'antd'
import React, { useContext, useEffect, useState } from 'react'
import FilterSelector from '../../../../atoms/FilterSelector/FilterSelector'
import SearchInput from '../../../../atoms/Search/SearchInput'
import Spacer from '../../../../atoms/Spacer/Spacer'
import useRedux from '../../../../helpers/useRedux'
import useFormValidator from '../../Helper/useFormValidator'
import screeningFilterValidator from '../../Helper/Validators/ScreeningFilterValidator'

import styles from './style.module.scss'
import dayjs from 'dayjs'
import RangPickerComponent from '../RangePickerComponent/RangPickerComponent'
import { ScreeningContext } from '../../Screening/ScreeningPage'
import { getScreeningData } from '../../../../actions/screening'
import { queryConstructor } from '../../../../utils'


const { RangePicker } = DatePicker;
const searchFilterData = [{ value: "teacher_name", label: "Teacher Name" },
{ value: "course_name", label: "Course Name" }]

const statusFilterData = [{ value: 1, label: "Approved" },
{ value: 2, label: "Rejected" }, { value: 3, label: "On Hold" },]

const ScreeningFilter = () => {
    const [searchTerm, setSearchTerm] = useState("");

    const [searchFilter, setSearchFilter] = useState("");
    const [statusFilter, setStatusFilter] = useState("");

    const [{ screeningListPage, screeningListIsUpdate }, dispatch] = useRedux('screening');
    const [queryData, setqueryData] = useState("");
    const [dateRange, setDateRange] = useState([
        null,
        null,
    ])
    const [startDate, setStartDate] = useState(
        null
    )
    const [endDate, setEndDate] = useState(null)

    const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(handleSearch, { searchTerm, searchFilter, statusFilter, startDate, endDate }, screeningFilterValidator);

    const notifyRef = useContext(ScreeningContext)

    // const notifyRef = useContext(RefContext)

    // hnadling the search term 
    const handleSearchTerm = (e) => {
        const value = e.target.value;
        setSearchTerm(value);
    }
    const handleDatePicker = (date, val) => {
        setDateRange(date);
        setStartDate(val[0] ? dayjs(val[0]).unix() : '')
        setEndDate(val[1] ? dayjs(val[1]).set('second',84924).unix() : '')
    }

    // handle search
    function handleSearch() {
        const queryObj = {
            [searchFilter]: searchTerm,
            "startDate": startDate,
            "endDate": endDate,
            "statusID": statusFilter,
            "viewType": "screening"
        };
        const query = `&${queryConstructor(queryObj)}`
        dispatch(getScreeningData(query, 1, notifyRef))

        setqueryData(query);

    }
    const handleSearchFilter = (value) => {
        if (value === undefined) {
            setSearchFilter("");
            setSearchTerm("");
            setqueryData("");

        } else {
            setSearchFilter(value);
        }
    }

    const handleStatusFilter = (value) => {
        if (value === undefined) {
            setqueryData("");
            setStatusFilter(null);

        } else {
            setStatusFilter(value);
        }
    }

    //called useEffect when Page changed and isUpdated teacher_summary changed
    useEffect(() => {
        dispatch(getScreeningData(queryData, screeningListPage, notifyRef))
    }, [screeningListPage, screeningListIsUpdate])


    return (
        <div className={styles.wrapper}>
            <FilterSelector optArr={searchFilterData} value={searchFilter} onChange={handleSearchFilter} filtertext="Search by" validate={errors['searchFilter']} />
            <SearchInput value={searchTerm} searchError={errors['searchTerm']} onChange={handleSearchTerm} />
            <Spacer size={20} />
            <RangPickerComponent value={dateRange} handleDataRange={handleDatePicker} validate={errors['dateRange']} />
            {/* <RangePicker
          format="DD/MM/YYYY"
          className={styles.inputs}
          value={dateRange}
          onChange={(d, v) => handleDatePicker( v, d)}
     /> */}
            <Spacer size={20} />

            <FilterSelector optArr={statusFilterData} value={statusFilter} onChange={handleStatusFilter} validate={errors['statusFilter']} />

            <Button type="primary" className={styles.button} onClick={handleSubmit}>Search</Button>

        </div>
    )
}

export default ScreeningFilter
