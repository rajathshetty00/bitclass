import useRedux from "../../../../helpers/useRedux";

import styles from "./style.module.scss";
import TableComponent from "../TableComponent/TableComponent";

import { handleScreeningPagination } from "../../../../actions/screening";
import ModelComponent from "../ModelComponent./ModelComponent";
import VideoModelComponent from "../VideoScreen/VideoScreen";
import { Badge, Popover, Tag } from "antd";
import { ExternalLink, Maximize2 } from "react-feather";
import DetailView from "../DetailView/DetailView";
import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  ClockCircleOutlined,
} from '@ant-design/icons';
import dayjs from 'dayjs'
import TextArea from "antd/lib/input/TextArea";


const ScreeningTable = () => {
  const [{ screeningList, screeningListPage, screeningListLoading, screeningListTotal }, dispatch] = useRedux('screening');

  const dataSource = [{
    "teacher_name": "dsdsdasda",
    "phone_number": "32422424",
    "email": "sfsfsf@Aeffsf.com",
    "teacher_id": "1",
    "course_name": "sfsf",
    "status": "sfsfsfsfsf",
    "assigned_to": "sfsff",
    "mou_status": "sfsfs",
    "pointers": "sfsfsf", // E.g. : "['pointer1 description', 'pointer2 desc', 'pointer3 desc', 'pointer4 desc', 'pointer5 desc']"
    "video": "",
    "screening": "",
    "poc": "sfs",
    "vetting_call": "sfsf",
    "vetting_check": "sffs",
    "assets": "sdsds",
    "ct_call": "sfs",
    "ct_notes": "sfsf"
  }]
  const columns = [
    {
      title: "Teacher id",
      dataIndex: "teacher_id",
      key: "teacher_id",
    },
    {
      title: "Teacher Name",
      dataIndex: "teacher_name",
      key: "teacher_name",
    },
    {
      title: "Course Name ",
      dataIndex: "course_name",
      key: "course_name",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },

    {
      title: "Number",
      dataIndex: "phone_number",
      key: "phone_number",

    },
    {
      title: "Social",
      dataIndex: "social",
      key: "social",
    },
    {
      title: "Pointers",
      dataIndex: "pointers",
      key: "pointers",
      render: (data, record) => <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
        <Popover  content={<DetailView Obj={data} />} title="Pointer description Data" trigger="hover">
       <ExternalLink color="mediumslateblue" />
    </Popover>
      </div>
    },
    {
      title: "Video",
      dataIndex: "intro_video",
      key: "intro_video",
      render: (data, record) => <div className={styles.centerItem}>{data && <VideoModelComponent src={data || "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4"} heading={` Course History of ${record['name']}`} content={<p>ff</p>} />} </div>

    },
    {
      title: "Screening",
      dataIndex: "screening_status_id",
      key: "screening_status_id",
      render: (data, record) => <div className={styles.centerItem}>
          <>
          {mapStatus(data)}
          </>
          
          <ModelComponent statusData={data} comment={record['comment']}   teacher_id={record['teacher_id']} heading={` Screening for teacher- ${record['teacher_name']}`} />
        </div>


    },
    {
      title: "Availability",
      dataIndex: "availability",
      key: "availability",
      render: (data, record) =><div>{data&&<Tag className={styles.tagdiv} icon={<ClockCircleOutlined  />} color="magenta">
        <div className={styles.text}>
        <p>{data}</p>
        </div>
    </Tag>} </div>
    

    },
    {
      title: "Application Date",
      dataIndex: "application_date",
      key: "application_date",
    
     render: (data, record) => <Badge count={ <ClockCircleOutlined style={{ color: 'blue' }} />} >
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
     
      <Tag  color="blue">
      <Badge color={"blue"} text="" />
    {getTimStamp(data)}
     
    </Tag> 
      </div> 
      </Badge>
    

    },
    {
      title: "Comment",
      dataIndex: "comment",
      key: "comment",
      render:(data, record)=> <div className={styles.commentWrapper}>
        {data&&
      <TextArea
      value={data}
      bordered={false}
      autoSize={{ minRows: 2, maxRows: 2 }}
    />}
      </div> 
    }
    
  ];

  const mapStatus=(data)=>{
    switch (data) {
      case 1:
        return <Tag icon={<CheckCircleOutlined />} color="success">
          'Approved'
        </Tag>
      case 2:
        return <Tag icon={<CloseCircleOutlined />} color="error">
          Reject
        </Tag>
      case 3:
        return <Tag icon={<ClockCircleOutlined />} color="warning">
          Hold
        </Tag>

      default:
        return null;
    }
}

  const getTimStamp =(unixTime)=>{
    return dayjs.unix(unixTime).format('ddd, MMM D, YYYY h:mm A')
  }


  return (
    <div>

      <TableComponent uniqueKey={"teacher_id"} totalRecords={screeningListTotal} dataSource={screeningList} loading={screeningListLoading} page={screeningListPage} handlePage={(page) => dispatch(handleScreeningPagination(page))} columns={columns} />
    </div>
  );
};

export default ScreeningTable;