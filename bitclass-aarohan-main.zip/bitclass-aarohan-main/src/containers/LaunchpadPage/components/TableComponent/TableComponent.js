import {Table } from "antd"
import styles from './style.module.scss'
import { LoadingOutlined } from '@ant-design/icons'
      
const TableComponent = ({dataSource,columns,totalRecords=10,page=1,handlePage,loading=false, uniqueKey="user_code"}) => {
    return (
        <div className={styles.table_striped_rows}>
    
            <Table dataSource={dataSource} rowKey={uniqueKey}  scroll={{ x: 400 }} columns={columns} bordered={true} pagination={false} 
            pagination={{
                total: totalRecords,
                onChange: (page) => {
                    handlePage(page)
                },
              showSizeChanger:false,
                current: page,
              }}
              loading={{
                spinning: loading,
                indicator: <LoadingOutlined type="loading" />,
              }}
              scroll={{ x: 1300 }}
             
              

            />
        </div>
    )
}

export default TableComponent