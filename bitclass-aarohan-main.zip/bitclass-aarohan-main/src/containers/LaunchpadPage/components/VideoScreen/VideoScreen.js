
import { Modal } from 'antd';
import { useContext, useRef, useState } from 'react';
import styles from './style.module.scss'

import useRedux from '../../../../helpers/useRedux';

import { LoadingOutlined } from '@ant-design/icons'
import { Play } from 'react-feather';
const VideoModelComponent = ({ src, heading = false }) => {
    const [visible, setVisible] = useState(false);

    const [{ loading }, dispatch] = useRedux('screening');
    const vidRef = useRef(null);
    const handlePauseVideo = () => {
        vidRef.current.pause();
        setVisible(false)
    }

    return (
        <>
            <div onClick={() => { setVisible(true) }} className={styles.cell_disp} >
                <p className={styles.pencil_icon}><Play color="LightCoral" size={30} /></p>
            </div>
            <Modal

                centeredradio_content
                visible={visible}
                onOk={handlePauseVideo}
                onCancel={handlePauseVideo}
                width={1000}
                okText={<p>ok</p>}

                className={styles.modelWrapper}
            >
                <div className={styles.model_body}>
                    {/* {heading&& <h1>{heading} </h1>} */}
                    <div>
                        <video ref={vidRef} width="99%" height="500" controls >
                            <source src={src} type="video/mp4" />
                        </video>
                    </div>
                </div>
            </Modal>

        </>
    )
}

export default VideoModelComponent