import React from 'react'
import ScreeningPage from './Screening/ScreeningPage'

const LaunchpadPage = () => {
    return (
        <div>
            <ScreeningPage />
        </div>
    )
}

export default LaunchpadPage
