import React from "react"
import GoogleLogin from "react-google-login"
import { get } from "lodash-es"
import { useHistory } from "react-router-dom"
import { useDispatch } from "react-redux"
import { saveAuth } from "../../actions/auth"
import { loginUsingGoogleSSO } from "../../utils/api"
import { GOOGLE_SSO_CLIENT_ID } from "../../constants"
import styles from "./style.module.scss"
import { Card, message } from "antd"
import { setCookie } from "../../utils"

const LoginPage = () => {
  const history = useHistory()
  const dispatch = useDispatch()

  const responseGoogle = async (response) => {
    const basicProfile = response.getBasicProfile()
    const userEmail = basicProfile.getEmail()
    const token = get(response, "tokenObj.id_token", "")

    try {
      const { data } = await loginUsingGoogleSSO(token)
      const {
        auth_token,
        username,
        role,
        meta,
        id,
        email,
        code,
        chat_auth_token,
        adminAuth,
      } = data
      if (email === userEmail) {
        localStorage.setItem("Authorization", auth_token)
        localStorage.setItem("code", code)
        localStorage.setItem("email", email)
        localStorage.setItem("role", role)
        localStorage.setItem("username", username)
        localStorage.setItem("chatToken", chat_auth_token.auth_token)
        setCookie("_auth", adminAuth, 1)
        dispatch(saveAuth(auth_token))
        history.push("/dashboard/table")
      } else {
				message.error("Google Login failed")
			}
    } catch (err) {
      console.log(err)
      message.error("Login failed")
    }
  }

  return (
    <div className={styles.loginContainer}>
      <Card
        title="Aarohan | आरोहण  | アセンド"
        className={styles.loginCard}
        headStyle={{
          fontSize: "24px",
          fontWeight: 600,
          textTransform: "uppercase",
          backgroundColor: "var(--primaryColor)",
          color: "#fff",
        }}
      >
        <GoogleLogin
          clientId={GOOGLE_SSO_CLIENT_ID}
          buttonText="Login"
          onSuccess={responseGoogle}
          onFailure={responseGoogle}
          cookiePolicy={"single_host_origin"}
        />
      </Card>
    </div>
  )
}

export default LoginPage
