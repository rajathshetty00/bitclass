import { Button, Input, InputNumber, Select, Form } from "antd"
import styles from "./styles.module.scss"

const { Option } = Select

const AddPayoutForm = ({ addPayoutShareFormHandler, form }) => {
  const validatePayoutValue = (rule, value, _) => {
    try {
      const output = Number(value)

      if (
        (output < 1 || output > 100 || isNaN(output)) &&
        form.getFieldValue("payoutType") === "rev_share"
      ) {
        return Promise.reject("Please enter percentage between 1 to 100")
      }
      return Promise.resolve()
    } catch (err) {
      return Promise.reject(err)
    }
  }
  return (
    <Form
      form={form}
      className={styles.addPayoutShareForm}
      onFinish={addPayoutShareFormHandler}
    >
      <Form.Item
        name="courseCode"
        rules={[
          {
            required: true,
          },
          {
            pattern: new RegExp(/^[a-zA-Z0-9]*$/, "g"),
            message: "White spaces and special characters are not allowed",
          },
        ]}
        hasFeedback
        className={styles.paymentShareInput}
      >
        <Input placeholder="Course Code" />
      </Form.Item>

      <Form.Item
        name="payoutType"
        hasFeedback
        rules={[
          {
            required: true,
            message: "Payout type is mandatory",
          },
        ]}
        className={styles.paymentShareInput}
      >
        <Select placeholder={"Payout Type"}>
          <Option value={"per_student_flat"}>Per Student Fixed</Option>
          <Option value={"flat"}>Overall Fixed Amount</Option>
          <Option value={"rev_share"}>Overall Percentage</Option>
        </Select>
      </Form.Item>
      <Form.Item
        name="payoutValue"
        hasFeedback
        rules={[
          {
            required: true,
            message: "This field is mandatory",
          },
          {
            pattern: new RegExp(/^[0-9]*$/, "g"),
            message: "Please enter numbers only",
          },
          {
            validator: validatePayoutValue,
          },
        ]}
        className={styles.paymentShareInput}
      >
        <InputNumber placeholder="Value" min={1} />
      </Form.Item>
      <Form.Item
        name="maxPayout"
        rules={[
          {
            pattern: new RegExp(/^[0-9]*$/, "g"),
            message: "Please enter numbers only",
          },
        ]}
        className={styles.paymentShareInput}
      >
        <InputNumber placeholder="Max overall amount (optional)" min={1} />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">
          Add
        </Button>
      </Form.Item>
    </Form>
  )
}

export default AddPayoutForm
