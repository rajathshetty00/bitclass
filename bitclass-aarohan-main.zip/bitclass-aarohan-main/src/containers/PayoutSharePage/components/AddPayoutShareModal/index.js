import { Button, Input, InputNumber, Select, Form, message } from "antd"
import Modal from "antd/lib/modal/Modal"
import React, { useState } from "react"
import PayoutSuccessScreen from "../SuccessScreen"
import styles from "./styles.module.scss"
import AddPayoutForm from '../AddPayoutForm'
import { savePayoutTerms } from "../../../../utils/api"
import { useDispatch, useSelector } from "react-redux"
import { savePayoutShareTerms } from "../../../../actions/payoutShare"
import { PAYOUT_SHARE_CLOSE_SUCCESS_MODAL } from "../../../../actions/types"

const { Option } = Select

const AddPayoutShareModal = ({ showModal, closeModal }) => {
  const dispatch = useDispatch()
  const {showPayoutSuccessModal} = useSelector(state=>state.payoutShare)
  const [form] = Form.useForm()
  const addPayoutShareFormHandler = async(data) => {
    const { maxPayout, ...restData } = data
    const _payoutData = isNaN(maxPayout) ? { ...restData } : { ...data }
    dispatch(savePayoutShareTerms(_payoutData))
  }

  const handleModalClose = () => {
    form.resetFields()
    closeModal(false)
    dispatch({type: PAYOUT_SHARE_CLOSE_SUCCESS_MODAL})
  }
  return (
    <Modal
      title={showPayoutSuccessModal?'':"Add payout share for a course"}
      centered
      visible={showModal}
      onCancel={handleModalClose}
      footer={null}
    >
      {showPayoutSuccessModal ? (
        <PayoutSuccessScreen />
      ) : (
        <AddPayoutForm addPayoutShareFormHandler={addPayoutShareFormHandler} form={form}/>
      )}
    </Modal>
  )
}

export default AddPayoutShareModal
