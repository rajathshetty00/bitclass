import { Button, Card, InputNumber } from "antd"
import { useState } from "react"
import { useDispatch } from "react-redux"
import { fetchPayoutShareTerms } from "../../../../actions/payoutShare"
import AddPayoutShareModal from "../AddPayoutShareModal"
import styles from "./styles.module.scss"

const Filter = () => {
  const dispatch = useDispatch()
  const [showPayoutModal, setShowPayoutModal] = useState(false)
  const [phoneNumber, setPhoneNumber] = useState("")
  const [phoneNumberError, setPhoneNumberError] = useState("")
  
  const handlePhoneNumberChange = (value) => {
    if (isNaN(value) || value?.toString().length > 10||value<0)
      return setPhoneNumberError("Please enter a valid phone number")
    setPhoneNumber(value)
    setPhoneNumberError()
  }

  const handlePayoutSearch = ()=>{
    dispatch(fetchPayoutShareTerms(phoneNumber))
  }
  return (
    <Card
      className="roundedCard"
      bodyStyle={{
        display: "flex",
        alignItems: "center",
        flexDirection: "row",
      }}
    >
      <div className={styles.filters}>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ display: "grid" }}>
            <InputNumber
              value={phoneNumber}
              onChange={handlePhoneNumberChange}
              placeholder="Search by teacher phone number"
              className={styles.inputs}
            />
            {phoneNumberError && (
              <span style={{ color: "red" }}>{phoneNumberError}</span>
            )}
          </div>
          <Button type={"default"} onClick={handlePayoutSearch}>Show Payout Terms</Button>
        </div>
        <Button type="primary" onClick={() => setShowPayoutModal(true)}>
          Add Payout Share
        </Button>
      </div>
      <AddPayoutShareModal
        showModal={showPayoutModal}
        closeModal={setShowPayoutModal}
      />
    </Card>
  )
}

export default Filter
