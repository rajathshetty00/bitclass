import React from "react"
import { useSelector } from "react-redux"
import { ReactComponent as SuccessTick } from "../../../../assets/svg/successTick.svg"
import styles from "./styles.module.scss"

const PayoutSuccessScreen = () => {
  const {
    product_code: courseCode,
    max_amount: maxPayout,
    term_value: payoutValue,
    term_type: payoutType,
  } = useSelector((state) => state.payoutShare.savedPayoutData)

  const getPayoutType = () => {
    if (payoutType === "per_student_flat") return "Per Student Fixed"
    if (payoutType === "flat") return "Overall Fixed Amount"
    if (payoutType === "rev_share") return "Overall Percentage"
  }
  return (
    <div className={styles.successScreen}>
      <div className={styles.top}>
        <SuccessTick />
        <h3 className={styles.title}>
          Teacher's payout share details has been Successfully added
        </h3>
      </div>
      <div className={styles.details}>
        <table style={{ width: "100%" }}>
          <tbody>
          <tr>
            <td className={styles.title}>
              <strong>COURSE CODE </strong>
            </td>
            <td className={styles.value}>{courseCode}</td>
          </tr>
          <tr>
            <td className={styles.title}>
              <strong>PAYOUT TYPE</strong>
            </td>
            <td className={styles.value}>{getPayoutType()}</td>
          </tr>
          <tr>
            <td className={styles.title}>
              <strong>VALUE </strong>
            </td>
            <td className={styles.value}>{payoutValue}</td>
          </tr>
          {maxPayout>0 && (
            <tr>
              <td className={styles.title}>
                <strong>MAX AMOUNT </strong>
              </td>
              <td className={styles.value}>{maxPayout}</td>
            </tr>
          )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default PayoutSuccessScreen
