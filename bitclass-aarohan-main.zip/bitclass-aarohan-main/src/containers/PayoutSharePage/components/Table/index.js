import { Table } from 'antd'
import React from 'react'
import { useSelector } from 'react-redux'
import {PAYOUT_SHARE_TABLE_MODEL} from '../../helper/tableData'

const PayoutShareTable = () => {
  const {payoutShareTerms} = useSelector(state=>state.payoutShare)
  return (
    <div>
      <Table columns={PAYOUT_SHARE_TABLE_MODEL} dataSource={payoutShareTerms} bordered/>
    </div>
  )
}

export default PayoutShareTable
