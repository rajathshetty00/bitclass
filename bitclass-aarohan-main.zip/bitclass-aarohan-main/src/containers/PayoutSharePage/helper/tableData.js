export const PAYOUT_SHARE_TABLE_MODEL= [
  {
    title: 'Product Code',
    dataIndex: 'product_code',
    key: 'product_code',
    width:200,
  },
  {
    title: 'Teacher Code',
    dataIndex: 'teacher_code',
    key: 'teacher_code',
    width:200,
  },
  {
    title: 'Term Type',
    dataIndex: 'term_type',
    key: 'term_type',
    width:200,
    render: (term_type) => {
      if (term_type === "per_student_flat") return "Per Student Fixed"
      if (term_type === "flat") return "Overall Fixed Amount"
      if (term_type === "rev_share") return "Overall Percentage"
    }
  },
  {
    title: 'Term Value',
    dataIndex: 'term_value',
    key: 'term_value',
    width:200,
  },
  {
    title: 'Max Amount',
    dataIndex: 'max_amount',
    key: 'term_type',
    width:200,
  },
];