import PageLayout from "../../components/PageLayout"
import Filter from "./components/Filter"
import PayoutShareTable from "./components/Table"

const PayoutSharePage = () => {

  return (
    <PageLayout>
      <Filter/>
      <PayoutShareTable />
    </PageLayout>
  )
}

export default PayoutSharePage
