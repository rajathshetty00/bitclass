import { Tooltip } from 'antd'

export const MainTableModel = [
  {
    title: 'Course',
    align: 'center',
    dataIndex: 'courseName',
    width: 200,
    render: (data) => (<a
      rel="noreferrer"
      target="_blank"
      href={data.link}
    >
      {data.label}
    </a>
  )
  },
  {
    title: 'Teacher',
    align: 'center',
    dataIndex: 'teacherName',
    width: 200,
  },
  {
    title: 'RZP Account ID',
    align: 'center',
    dataIndex: 'razAccId',
    width: 120,
  },
  {
    title: 'Registrations',
    align: 'center',
    dataIndex: 'registrations',
    width: 120,
  },
  {
    title: 'Earnings',
    align: 'center',
    dataIndex: 'earnings',
    width: 120,
    render: data => data.toLocaleString(),
  },
  {
    title: 'Payouts So Far',
    align: 'center',
    dataIndex: 'payout',
    width: 120,
    render: data => data.toLocaleString(),
  },
  {
    title: 'Add Payout',
    align: 'center',
    dataIndex: 'addClick',
    width: 120,
    render: (data) => <a href="#" onClick={(e) => {e.preventDefault(); data()}}>Add</a>,
  },
  {
    title: 'All Payouts',
    align: 'center',
    dataIndex: 'allPayouts',
    width: 130,
    render: (data) => <a href="#" onClick={(e) => {e.preventDefault(); data()}}>View</a>,
  },
]

export const AllPayoutsModel = [
  {
    title: 'No.',
    align: 'center',
    dataIndex: 'slNo',
    width: 70,
  },
  {
    title: 'Amount',
    align: 'center',
    dataIndex: 'amount',
    width: 120,
    render: data => data.toLocaleString(),
  },
  {
    title: 'Reference ID',
    align: 'center',
    dataIndex: 'refID',
    width: 200,
  },
  {
    title: 'Payment Date',
    align: 'center',
    dataIndex: 'paymentDate',
    width: 150,
  },
  {
    title: 'Notes',
    align: 'center',
    dataIndex: 'notes',
    width: 200,
    ellipsis: {
      showTitle: false,
    },
    render: notes => (
      <Tooltip placement="topLeft" title={notes}>
        {notes}
      </Tooltip>
    ),
  },
]
