import React, { useState, useEffect, useCallback } from 'react'
import clsx from 'clsx'
import {
  Card,
  Input,
  Select,
  Button,
  Table,
  Modal,
  Form,
  Collapse,
  message,
  DatePicker,
  Empty,
} from 'antd'
import { LoadingOutlined } from '@ant-design/icons'
import { useSelector, useDispatch } from 'react-redux'
import { debounce } from 'lodash-es'
import dayjs from 'dayjs'

import styles from './style.module.scss'
import { MainTableModel, AllPayoutsModel } from './TableModel'
import CurrencyCodes from '../../assets/json/CurrencyCodes.json'
import { fetchPayoutsData, hideLoader, clearData } from '../../actions/payouts'
import { exists } from '../../utils'
import { addPayout } from '../../utils/api'

const { Option } = Select
const { TextArea } = Input
const { Panel } = Collapse
const { RangePicker } = DatePicker

const AddPayoutForm = ({ onFinish, formInstance }) => {
  const currencySelector = (
    <Form.Item name="currency" noStyle>
      <Select
        style={{
          width: 90,
        }}
        optionLabelProp="label"
        dropdownMatchSelectWidth={false}
      >
        {Object.values(CurrencyCodes).map((v, i) => (
          <Option key={i.toString()} value={v.code} label={v.code}>
            {`${v.name} (${v.code})`}
          </Option>
        ))}
      </Select>
    </Form.Item>
  )

  return (
    <Form
      form={formInstance}
      name="addPayoutForm"
      onFinish={onFinish}
      initialValues={{
        currency: 'INR',
      }}
      scrollToFirstError
      labelCol={{ span: 24 }}
    >
      <Form.Item
        name="amount"
        label="Amount"
        rules={[
          {
            required: true,
            message: 'Amount is mandatory',
          },
        ]}
      >
        <Input
          type="number"
          style={{ width: '100%' }}
          addonBefore={currencySelector}
        />
      </Form.Item>
      <Form.Item
        name="external_reference_id"
        label="Reference ID"
        rules={[
          {
            required: true,
            message: 'Reference ID is mandatory',
          },
        ]}
      >
        <Input style={{ width: '100%' }} />
      </Form.Item>
      <Form.Item
        name="transfer_date"
        label="Transfer Date"
        rules={[
          {
            required: true,
            message: 'Transfer Date is mandatory',
          },
        ]}
      >
        <DatePicker showTime use12Hours format="DD MMM YYYY hh:mm" />
      </Form.Item>
      <Form.Item name="notes" label="Notes">
        <TextArea
          style={{ width: '100%' }}
          autoSize={{ minRows: 4, maxRows: 6 }}
        />
      </Form.Item>
      <Form.Item style={{ textAlign: 'center' }}>
        <Button style={{ width: '100px' }} type="primary" htmlType="submit">
          Add
        </Button>
      </Form.Item>
    </Form>
  )
}

const Payouts = () => {
  const [showAddPayout, setShowAddPayout] = useState(false)
  const [showAllPayouts, setShowAllPayouts] = useState(false)
  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [teacherName, setTeacherName] = useState('')
  const [teacherPhone, setTeacherPhone] = useState('')
  const [courseHeading, setCourseHeading] = useState('')
  const [dateRange, setDateRange] = useState(null)
  const [startDate, setStartDate] = useState(null)
  const [endDate, setEndDate] = useState(null)
  const [payouts, setPayouts] = useState([])
  const [refreshData, setRefreshData] = useState(0)
  const [totalCourses, setTotalCourses] = useState(0)
  const [totalEarnings, setTotalEarnings] = useState(0)
  const [totalPayout, setTotalPayout] = useState(0)
  const [totalRegistrations, setTotalRegistrations] = useState(0)
  const [addPayoutTeacherCode, setAddPayoutTeacherCode] = useState(null)
  const [addPayoutCourseCode, setAddPayoutCourseCode] = useState(null)
  const [payoutHistory, setPayoutHistory] = useState(null)

  const [addPayoutForm] = Form.useForm()
  const dispatch = useDispatch()
  const { data, loading } = useSelector((state) => ({
    data: state.payouts.data,
    loading: state.payouts.loading,
  }))

  useEffect(() => {
    if (!startDate || !endDate) {
      dispatch(clearData())
      dispatch(hideLoader())
      return
    }
    dispatch(
      fetchPayoutsData({
        page,
        limit,
        teacherName,
        teacherPhone,
        courseHeading,
        startDate,
        endDate,
      })
    )
  }, [page, limit, refreshData])

  useEffect(() => {
    if (exists(data)) {
      if (exists(data.paginated_response)) {
        const _payouts = data.paginated_response.map((v) => {
          const _history = v.course_payout_history.map((h, i) => {
            let _date = new Date(0)
            _date.setSeconds(h.transfer_date)

            return {
              slNo: i + 1,
              amount: `${h.currency} ${h.amount.toLocaleString()}`,
              refID: h.external_reference_id,
              paymentDate: dayjs(_date).format('DD MMM YYYY'),
              notes: h.notes,
            }
          })

          return {
            courseName: {
              label: v.course_heading || '',
              link: v.course_url || '',
            },
            registrations: v.course_registrations || 0,
            earnings:
              exists(v.course_earnings) && v.course_earnings.amount > 0
                ? `${
                    v.course_earnings.currency
                  } ${v.course_earnings.amount.toLocaleString()}`
                : '-',
            bankAccount: v.bank_details_shared ? 'Yes' : 'No',
            razAccId: v.rzp_acc_id ? v.rzp_acc_id : '-',
            teacherName: v.teacher_name,
            payout:
              exists(v.course_payout) && v.course_payout.amount > 0
                ? `${
                    v.course_payout.currency
                  } ${v.course_payout.amount.toLocaleString()}`
                : '-',
            addClick: () => {
              setAddPayoutTeacherCode(v.teacher_code)
              setAddPayoutCourseCode(v.course_code)
              setShowAddPayout(true)
            },
            allPayouts: () => {
              setShowAllPayouts(_history)
            },
          }
        })
        setPayouts(_payouts)
      } else {
        setPayouts([])
      }

      if (exists(data.aggregated_response)) {
        setTotalCourses(data.aggregated_response.total_courses || 0)
        setTotalEarnings(data.aggregated_response.total_earnings || 0)
        setTotalPayout(data.aggregated_response.total_payouts || 0)
        setTotalRegistrations(data.aggregated_response.total_registrations || 0)
      } else {
        setTotalCourses(0)
        setTotalEarnings(0)
        setTotalPayout(0)
        setTotalRegistrations(0)
      }
    }
  }, [data])

  const SummaryItem = ({ label, data }) => (
    <>
      <label className={styles.summaryItemLabel}>{label}</label>
      <div className={styles.summaryItemData}>{data}</div>
    </>
  )

  const addPayoutFormSubmitHandler = async (data) => {
    if (
      !exists(data) ||
      !exists(addPayoutCourseCode) ||
      !exists(addPayoutTeacherCode)
    ) {
      message.error('Some data is missing')
      return
    }
    data.transfer_date = dayjs(data.transfer_date).unix()
    const _apiParams = { ...data, teacher_code: addPayoutTeacherCode }
    let res = await addPayout(addPayoutCourseCode, _apiParams)
    if (res.success) {
      message.success('Added payout successfully')
      setAddPayoutCourseCode(null)
      setAddPayoutTeacherCode(null)
      setShowAddPayout(false)
      setRefreshData(refreshData + 1)
      addPayoutForm.resetFields()
    } else {
      message.error('Failed to add payout')
    }
  }

  const delayedRefreshData=useCallback(debounce((value)=>setRefreshData(value + 1),500),[])
  const searchHandler = (type, val, extraVal = null) => {
    if (!type) return

    if (type === 'date_range') {
      setDateRange(extraVal)
      setStartDate(dayjs(val[0]).unix())
      setEndDate(dayjs(val[1]).unix())
    }
    if (type === 'teacher_name') {
      setTeacherName(val)
    }
    if (type === 'teacher_phone') {
      setTeacherPhone(val)
    }
    if (type === 'course') {
      setCourseHeading(val)
    }
    setPage(1)
    delayedRefreshData(refreshData)
  }

  const clearHandler = () => {
    setTeacherName('')
    setTeacherPhone('')
    setCourseHeading('')
    setDateRange(null)
    setStartDate(null)
    setEndDate(null)
    setPage(1)
    debounce(() => setRefreshData(refreshData + 1), 1000)()
  }

  return (
    <div className={styles.mainContainer}>
      {/* Filter Section */}
      <Card
        className={clsx(styles.filters, 'roundedCard')}
        bodyStyle={{
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'row',
        }}
      >
        <RangePicker
          className={styles.inputs}
          style={{ maxWidth: 250 }}
          value={dateRange}
          onChange={(d, v) => searchHandler('date_range', v, d)}
        />
        <Input
          placeholder="Search by teacher name"
          className={styles.inputs}
          value={teacherName}
          onChange={(e) => {
            searchHandler('teacher_name', e.currentTarget.value)
          }}
        />
        <Input
          type="number"
          placeholder="Search by teacher phone"
          className={styles.inputs}
          value={teacherPhone}
          onChange={(e) => {
            searchHandler('teacher_phone', e.currentTarget.value)
          }}
        />
        <Input
          placeholder="Search by course"
          className={styles.inputs}
          value={courseHeading}
          onChange={(e) => {
            searchHandler('course', e.currentTarget.value)
          }}
        />
        <Button onClick={clearHandler}>clear all</Button>
      </Card>
      {/* Filter Section End */}

      {/* Summary Block */}
      {/* <Collapse
        expandIcon={({ isActive }) => <CaretRightOutlined rotate={isActive ? 90 : 0} />}
        className={clsx(styles.summaryContainer, 'roundedCard')}
      >
        <Panel className={styles.summaryHead} header="Summary" key="1">
          <Row gutter={16}>
            <Col span={6}>
              <SummaryItem label="Courses" data={totalCourses.toLocaleString()} />
            </Col>
            <Col span={6}>
              <SummaryItem label="Registrations" data={totalRegistrations.toLocaleString()} />
            </Col>
            <Col span={6}>
              <SummaryItem label="Earnings" data={totalEarnings.toLocaleString()} />
            </Col>
            <Col span={6}>
              <SummaryItem label="Payout" data={totalPayout.toLocaleString()} />
            </Col>
          </Row>
        </Panel>
      </Collapse> */}
      {/* Summary Block End */}

      {/* Table Section */}
      <Table
        columns={MainTableModel}
        dataSource={payouts}
        bordered
        size="small"
        loading={{
          spinning: loading,
          indicator: <LoadingOutlined type="loading" />,
        }}
        locale={{
          emptyText: (
            <Empty description="No data found. Please adjust date range." />
          ),
        }}
        pagination={{
          total: totalCourses,
          onChange: (d) => setPage(d),
          current: page,
        }}
      />
      {/* Table Section End */}

      {/* Add Payout Modal */}
      <Modal
        title="Add Payout"
        centered={true}
        visible={showAddPayout}
        footer={null}
        onCancel={() => {
          setShowAddPayout(false)
          setAddPayoutTeacherCode(null)
          setAddPayoutCourseCode(null)
          addPayoutForm.resetFields()
        }}
      >
        <AddPayoutForm
          formInstance={addPayoutForm}
          onFinish={addPayoutFormSubmitHandler}
        />
      </Modal>
      {/* Add Payout Modal End */}

      {/* All Payouts Modal  */}
      <Modal
        title="All Payouts"
        centered={true}
        visible={showAllPayouts ? true : false}
        footer={null}
        onCancel={() => setShowAllPayouts(false)}
        width={850}
      >
        <Table
          columns={AllPayoutsModel}
          size={'small'}
          dataSource={showAllPayouts}
        />
      </Modal>
      {/* All Payouts Modal End */}
    </div>
  )
}

export default Payouts
