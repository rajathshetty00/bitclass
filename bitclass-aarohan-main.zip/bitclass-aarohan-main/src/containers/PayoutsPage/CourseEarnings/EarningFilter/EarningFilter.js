import { Input, DatePicker, Button } from 'antd'
import React, { useContext, useEffect, useState } from 'react'
import { EarningRefContext } from '..'
import { getTeacherEarningDataByFilter } from '../../../../actions/teacherPayout'
import useRedux from '../../../../helpers/useRedux'
import { queryConstructor } from '../../../../utils'
import FilterComponent from '../../components/FilterComponent/FilterComponent'
import MinMaxInput from '../../components/MinMaxInput/MinMaxInput'
import RefreshComponent from '../../components/RefreshComponent/RefreshComponent'
import SearchComponent from '../../components/SearchComponents/SearchComponent'
import Spacer from '../../components/Spacer/Spacer'
import earningFilterValidator from '../../helper/EarningFilterValidator'
import { minMaxValidator, searchValidation } from '../../helper/teacherPayoutHelper'
import useFormValidator from '../../helper/useFormValidator'
import styles from './style.module.scss'
const { RangePicker } = DatePicker;
const filterOptionArr = [
  { value: "revenue", label: "Revenue" },
  { value: "earnings", label: "Earnings" },

]

const SearchOptionArr = [
  { value: "course_name", label: "Course Name" },
  { value: "teacher_name", label: "Teacher Name" },
  { value: "course_code", label: "Course Code" },

]
const EarningFilter = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchFilter, setSearchFilter] = useState("");

  const [selectedFilter, setSelectedFilter] = useState("");
  const [courseTypeFilter, setcourseTypeFilter] = useState("");

  const [minAmount, setMinAmount] = useState("");
  const [maxAmount, setMaxAmount] = useState("");
  const [queryData, setQueryData] = useState("");

  const [{ page, isUpdated,course_category }, dispatch] = useRedux('tpayout');
  const notifyRef = useContext(EarningRefContext)


  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(handleSearch, { minAmount, maxAmount, selectedFilter, searchTerm, searchFilter }, earningFilterValidator);
  // handle filter search
  function handleSearch() {


    const queryObj = {
      [searchFilter]: searchTerm,
      "course_type": courseTypeFilter,
      [`${selectedFilter}_min`]: minAmount,
      [`${selectedFilter}_max`]: maxAmount,

    };
    const query = queryConstructor(queryObj) ? `${queryConstructor(queryObj)}` : ""
    dispatch(getTeacherEarningDataByFilter(query, 1, notifyRef));
    setQueryData(query);
  }

  // handle search value 
  const handleSearchTerm = (e) => {
    setErrors({});
    setIsSubmitting(false);
    setSearchTerm(e.target.value);
  }

  // min max value hanlder function
  const handleMinMaxValue = (e) => {
    setErrors({});
    setIsSubmitting(false);
    if (e.target.value.charAt(0) === "-" || e.target.value.charAt(0) === "+") {
      return;
    }
    else if (e.target.name === "min") {
      setMinAmount(e.target.value)
    } else {

      setMaxAmount(e.target.value)
    }
  }
  // called when the teacher and isUpdated teacerh earning changed
  useEffect(() => {
    dispatch(getTeacherEarningDataByFilter(queryData, page['teacher_earnings'], notifyRef));
  }, [page['teacher_earnings'], isUpdated['teacher_earnings']])

  const handleSearchFilter = value => {
    setErrors({});
    setIsSubmitting(false);
    setSearchFilter(value);

  }
  // handle course type filter
  const handlecourseTypeFilter = (value) => {
    setErrors({});
    setIsSubmitting(false);
    setcourseTypeFilter(value);

  }
  // when filter data changed
  const handleFilterPayment = (value) => {
    setErrors({});
    setIsSubmitting(false);
    setSelectedFilter(value);
  }
  const clearOptionhandler = () => {
    setcourseTypeFilter("")
  }
  const clearFilterPayment = () => {
    setMinAmount("");
    setMaxAmount("");
    setSelectedFilter("")
  }
  const clearFilterSearchOption = () => {
    setSearchFilter("")
    setSearchTerm("");
  }

  return (
    <div className={styles.earningFilterWrapper}>
      <FilterComponent handleClearOption={clearFilterSearchOption} value={searchFilter} onChange={handleSearchFilter} optArr={SearchOptionArr} filtertext="Search By" validate={errors['searchFilter']} />
      <SearchComponent value={searchTerm} searchError={errors['searchTerm']} onChange={handleSearchTerm} handleSearch={handleSearch} />
      <Spacer size={20} />
      <div className={styles.pay_filter}>

        <FilterComponent handleClearOption={clearOptionhandler} value={courseTypeFilter} onChange={handlecourseTypeFilter} optArr={course_category} filtertext="Filter by course type" />
      </div>
      <div className={styles.filter_div}>
        <FilterComponent handleClearOption={clearFilterPayment} validate={errors['selectedFilter']} value={selectedFilter} onChange={handleFilterPayment} optArr={filterOptionArr} />
      </div>
      <div className={styles.min_max_div} >
        <MinMaxInput onChange={handleMinMaxValue} valueMin={minAmount} validator={errors['minMaxValidErr']} valueMax={maxAmount} />
      </div>
      <Button type="primary" className={styles.button} onClick={handleSubmit}>Search</Button>
      <div className={styles.refresh}>


        <RefreshComponent notifyRef={notifyRef} />
      </div>
    </div>
  )
}

export default EarningFilter
