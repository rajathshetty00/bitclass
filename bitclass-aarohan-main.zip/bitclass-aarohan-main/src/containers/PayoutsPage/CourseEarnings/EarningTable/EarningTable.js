import { Input } from "antd";
import dayjs from "dayjs";
import { useContext, useState } from "react";
import { EarningRefContext } from "..";
import { handleEarningPagination } from "../../../../actions/teacherPayout";
import useRedux from "../../../../helpers/useRedux";
import PayoutTable from "../../components/PayoutTable/PayoutTable";
import PopOverInput from "../../components/PopOverInput/PopOverInput";
import RevenueSharingPopup from "../../components/RevenueSharingPopup/RevenueSharingPopup";
import ShareTypeSelect from "../../components/ShareTypeSelect/ShareTypeSelect";
import styles from "./style.module.scss";



const EarningTable = () => {

  const columns = [
    {
      title: "T_id",
      dataIndex: "teacher_id",
      key: "teacher_id",
    },
    {
      title: "Teacher Name",
      dataIndex: "teacher_name",
      key: "teacher_name",
      width: "150px"
    },
    {
      title: "Course Type",
      dataIndex: "course_type",
      key: "course_type",
    },
    {
      title: "Course Name",
      dataIndex: "course_name",
      key: "course_name",
      width: "250px",
    },
    {
      title: "Course Status",
      dataIndex: "course_status",
      key: "course_status",
    },
    {
      title: "Course Code",
      dataIndex: "course_code",
      key: "course_code",
    },
    {
      title: "Course Sharing Agreement",
      dataIndex: "course_share_agreement",
      key: "course_share_agreement",
      width: "250px",
      render: (data, record) => (
        <RevenueSharingPopup data={data} record={record} />
      ),
    },
    {
      title: "Payout Type",
      dataIndex: "payout_type",
      key: "payout_type",
      width: "200px",
      render: (data, record) =>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          {record["course_share_agreement"] !== "No Revenue Share" ? (
            <>
              <p>{data}</p>
              <PopOverInput
                content={
                  <ShareTypeSelect
                    data={data}
                    teacher_id={record["teacher_id"]}
                    course_id={record["course_code"]}
                  />
                }
              />
            </>
          ) : (
            <p>{data ? data : "N/A"}</p>
          )}
        </div>

    },
    {
      title: "Course Start Date",
      dataIndex: "course_start_date",
      key: "course_start_date",
      width: "150px",
      render: (startDate, record) => <p>{dayjs(startDate).format('DD MMM YYYY')}</p>
    },
    {
      title: "Course End Date",
      dataIndex: "course_end_date",
      key: "course_end_date",
      width: "150px",
      render: (endDate, record) => <p>{dayjs(endDate).format('DD MMM YYYY')}</p>
    },
    {
      title: "Revenue Generated",
      dataIndex: "revenue_generated",
      key: "revenue_generated",
      width: '140px'
    },
    {
      title: "Earning",
      dataIndex: "earnings",
      key: "earnings",
      width: '140px'

    },
  ];


  const [{ teacher_earnings, page, loading, totalRecords }, dispatch] =
    useRedux("tpayout");

  return (
    <div>
      <PayoutTable
        dataSource={teacher_earnings}
        totalRecords={totalRecords["teacher_earnings"]}
        loading={loading["teacher_earnings"]}
        page={page["teacher_earnings"]}
        handlePage={(page) => dispatch(handleEarningPagination(page))}
        columns={columns}
      />
    </div>
  );
};

export default EarningTable;
