import { DatePicker } from 'antd';

import EarningFilter from './EarningFilter/EarningFilter';
import EarningTable from './EarningTable/EarningTable';
import styles from './style.module.scss';
import { createContext, useRef } from 'react';
import SimpleAlert from '../components/alertComponent/AlertComponent';
const { RangePicker } = DatePicker;
export const EarningRefContext = createContext()

const CourseEarnings = () => {
const alertRef = useRef()

  return ( 
    <div className={styles.courseEarningsWrapper}>
       <EarningRefContext.Provider  value={alertRef} >
       <EarningFilter />
       <EarningTable />
       <SimpleAlert ref={alertRef} />
       </EarningRefContext.Provider>

    </div>
   )
}
 
export default CourseEarnings