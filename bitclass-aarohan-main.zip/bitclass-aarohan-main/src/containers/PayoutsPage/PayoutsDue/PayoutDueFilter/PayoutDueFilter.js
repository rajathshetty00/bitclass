import { DatePicker, Button, Tag } from "antd"
import React, { useContext, useEffect, useRef, useState } from "react"
import { PayoutAlertRefContext } from ".."
import { getTeacherPayoutDataByFilter, teacherPayoutRefreshData } from "../../../../actions/teacherPayout"
import useRedux from "../../../../helpers/useRedux"
import FilterComponent from "../../components/FilterComponent/FilterComponent"
import MinMaxInput from "../../components/MinMaxInput/MinMaxInput"
import RefreshComponent from "../../components/RefreshComponent/RefreshComponent"
import SearchComponent from "../../components/SearchComponents/SearchComponent"
import Spacer from "../../components/Spacer/Spacer"
import earningFilterValidator from "../../helper/EarningFilterValidator"
import {
  minMaxValidator,
  searchValidation,
} from "../../helper/teacherPayoutHelper"
import useFormValidator from "../../helper/useFormValidator"

import styles from "./style.module.scss"
const { RangePicker } = DatePicker
const filterOptionArr = [{ value: "payout_amount", label: "Payment amount" }]
const filterPaymentType = [
  { value: "Course Start 100", label: "Course start 100" },
  { value: "2P - 50_Start", label: "Course Start 50" },
  { value: "2P - 50_End", label: "Course End 50" },
  { value: "Flat Workshop", label: "Flat Workshop" },
  { value: "Flat", label: "Flat" },
]

const paymentStatusOptionArr = [
  { value: "Pending", label: "Pending" },
  { value: "Processed", label: "Processed" },
]

const SearchOptionArr = [
  { value: "teacher_name", label: "Teacher name" },
  { value: "teacher_id", label: "Teacher Id" },
  { value: "course_code", label: "Course Code" },
]
const PayoutDueFilter = (
  { queryData,
    setQueryData,
    ...props
  }) => {
  const [searchTerm, setSearchTerm] = useState("")
  const [searchFilter, setSearchFilter] = useState("")

  const [filterType, setFilterType] = useState("")
  const [courseTypeFilter, setcourseTypeFilter] = useState("")
  const [selectedFilter, setPayoutFilter] = useState("")
  const [paymentStatus, setPaymentStatus] = useState("")

  const [minAmount, setMinAmount] = useState("")
  const [maxAmount, setMaxAmount] = useState("")

  const [minDate, setMinDate] = useState("")

  const [maxDate, setMaxDate] = useState("")

  const notifyRef = useContext(PayoutAlertRefContext)
  const [{ page, isUpdated,course_category, loading, refreshTime }, dispatch] = useRedux("tpayout")
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    handleSearch,
    { minAmount, maxAmount, selectedFilter, searchTerm, searchFilter },
    earningFilterValidator
  )

  // handle search value
  const handleSearchTerm = (e) => {
    setErrors({})
    setIsSubmitting(false)
    setSearchTerm(e.target.value)
  }


  useEffect(() => {
    const queryData = queryMaker(
      searchFilter,
      searchTerm,
      courseTypeFilter,
      filterType,
      selectedFilter,
      minAmount,
      maxAmount,
      paymentStatus,
      minDate,
      maxDate
    )
    setQueryData(queryData)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    searchFilter,
    searchTerm,
    courseTypeFilter,
    filterType,
    selectedFilter,
    minAmount,
    maxAmount,
    paymentStatus,
    minDate,
    maxDate
  ])




  function handleSearch() {
    const queryData = queryMaker(
      searchFilter,
      searchTerm,
      courseTypeFilter,
      filterType,
      selectedFilter,
      minAmount,
      maxAmount,
      paymentStatus,
      minDate,
      maxDate
    )
    setQueryData(queryData)
    dispatch(getTeacherPayoutDataByFilter(queryData, 1, notifyRef))
  }

  const queryMaker = (
    searchType = "teacher_id",
    searchedData,
    courseType,
    payoutType,
    FilterType,
    minVal,
    maxVal,
    paymentStatus,
    minDate,
    maxDate
  ) => {
    let str = ""
    if (emptystate(searchedData)) {
      str.length == 0
        ? (str = `&${searchType}=${searchedData}`)
        : str.concat("&", `${searchType}=${searchedData}`)
    }
    if (courseType.length > 0) {
      str = str.concat("&", `course_type=${courseType}`)
    }
    if (minDate.length > 0) {
      str = str.concat("&", `payout_before_date=${minDate}`)
    }
    if (maxDate.length > 0) {
      str = str.concat("&", `payout_after_date=${maxDate}`)
    }
    if (paymentStatus.length > 0) {
      str = str.concat("&", `payment_status=${paymentStatus}`)
    }
    if (payoutType.length > 0) {
      str = str.concat("&", `payout_type=${payoutType}`)
    }
    if (FilterType.length > 0) {
      if (emptystate(minVal)) {
        if (emptystate(maxVal)) {
          str = str.concat(
            "&",
            `${FilterType}_min=${minVal}&${FilterType}_max=${maxVal}`
          )
        } else {
          str = str.concat("&", `${FilterType}_min=${minVal}`)
        }
      }
    }
    return str
  }
  // checking empty state
  const emptystate = (s) => {
    const output = String(s)
    if (output == "null" || output == "") {
      return false
    }
    return true
  }

  // handle min-max value changed with validation
  const handleMinMaxValue = (e) => {
    setErrors({})
    setIsSubmitting(false)

    if (e.target.value.charAt(0) === "-" || e.target.value.charAt(0) === "+") {
      return
    } else if (e.target.name === "min") {
      setMinAmount(e.target.value)
    } else {
      setMaxAmount(e.target.value)
    }
  }

  const handleSearchType = (value) => {
    setErrors({})
    setIsSubmitting(false)
    if (value === undefined) {
      setSearchTerm("")
      setSearchFilter("")
    } else {
      setSearchFilter(value)
    }
  }
  const handleCourseTypeFilter = (value) => {
    value === undefined ? setcourseTypeFilter("") : setcourseTypeFilter(value)
  }
  const handlFilterType = (value) => {
    value === undefined ? setFilterType("") : setFilterType(value)
  }
  // handle filter changed
  const handleFilterPayment = (value) => {
    setErrors({})
    setIsSubmitting(false)

    if (value === undefined) {
      setMinAmount("")
      setMaxAmount("")
      setPayoutFilter("")
    } else {
      setPayoutFilter(value)
    }
  }

  const handleFilterPaymentStatus = (value) => {
    value === undefined ? setPaymentStatus("") : setPaymentStatus(value)
  }

  const onDateChangeHandler = (value, dateString) => {
    if (dateString.length === 2) {
      setMinDate(dateString[0])
      setMaxDate(dateString[1])
    }
  }




  // called useEffect when Page changed andn is updated teacher_payout changed
  useEffect(() => {
    dispatch(
      getTeacherPayoutDataByFilter(queryData, page["teacher_payout"], notifyRef)
    )
  }, [page["teacher_payout"], isUpdated["teacher_payout"]])


  return (
    <div className={styles.payoutDueFilterWrapper}>
      <FilterComponent
        value={searchFilter}
        onChange={handleSearchType}
        optArr={SearchOptionArr}
        filtertext="Search By"
        validate={errors["searchFilter"]}
      />
      <SearchComponent
        value={searchTerm}
        searchError={errors["searchTerm"]}
        onChange={handleSearchTerm}
        handleSearch={handleSearch}
      />
      <Spacer size={10} />
      <FilterComponent
        value={courseTypeFilter}
        onChange={handleCourseTypeFilter}
        optArr={course_category}
        filtertext="Course By"
      />
      <div className={styles.filter_1}>
        <FilterComponent
          value={filterType}
          onChange={handlFilterType}
          optArr={filterPaymentType}
          filtertext="Payment By"
        />
      </div>
      <div className={styles.filter_2}>
        <FilterComponent
          value={selectedFilter}
          onChange={handleFilterPayment}
          optArr={filterOptionArr}
          filtertext="Payment amount"
          validate={errors["selectedFilter"]}
        />
      </div>
      <div className={styles.min_max_div}>
        <MinMaxInput
          onChange={handleMinMaxValue}
          valueMin={minAmount}
          validator={errors["minMaxValidErr"]}
          valueMax={maxAmount}
        />
      </div>
      <Spacer size={10} />
      <Button type="primary" className={styles.button} onClick={handleSubmit}>
        Search
      </Button>

      <div className={styles.secondRow}>
        {/* <FilterComponent
          value={paymentStatus}
          onChange={handleFilterPaymentStatus}
          optArr={paymentStatusOptionArr}
          filtertext="Payment Status"
          validate={errors["paymentStatus"]}
        /> */}

        <RangePicker
          format="YYYY-MM-DD"
          // onChange={onDateChangeHandler}
          onCalendarChange={onDateChangeHandler}
        />

        <RefreshComponent notifyRef={notifyRef} />


      </div>
    </div>
  )
}

export default PayoutDueFilter
