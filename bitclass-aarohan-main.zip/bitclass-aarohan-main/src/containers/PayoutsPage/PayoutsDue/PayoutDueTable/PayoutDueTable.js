import useRedux from "../../../../helpers/useRedux";
import PayoutTable from "../../components/PayoutTable/PayoutTable";
import PopOverInput from "../../components/PopOverInput/PopOverInput";
import styles from "./style.module.scss";
import { Input, Tag, Tooltip } from 'antd';
import { handlePayoutPagination, updateTeacherPayoutData } from "../../../../actions/teacherPayout";
import { useContext } from "react";
import { PayoutAlertRefContext } from "..";
import UtrEdit from "../../components/UtrEdit/UtrEdit";
import dayjs from "dayjs";
import Text from "antd/lib/typography/Text";
// import Text from "antd/lib/typography/Text";
const { Search } = Input;
const PayoutDueTable = () => {
  const [{ teacher_payout, page, loading, totalRecords }, dispatch] = useRedux('tpayout');
  const notifyRef = useContext(PayoutAlertRefContext)
  const columns = [
    {
      title: "T_id",
      dataIndex: "teacher_id",
      key: "teacher_id",
    },
    {
      title: "Teacher name",
      dataIndex: "teacher_name",
      key: "teacher_name",
      width: "180px"
    },
    {
      title: "Email id",
      dataIndex: "teacher_email",
      key: "teacher_email",
    },
    {
      title: "Benification Name",
      dataIndex: "beneficiary_name",
      key: "beneficiary_name",
    },
    {
      title: "Bank Account",
      dataIndex: "bank_acc_num",
      key: "bank_acc_num",
    },
    {
      title: "IFSC Code",
      dataIndex: "ifsc_code",
      key: "ifsc_code",

    }, {
      title: "Course Code",
      dataIndex: "course_code",
      key: "course_code",
    },
    {
      title: "Course Type",
      dataIndex: "course_type",
      key: "course_type",
    },
    {
      title: "Payout Amount",
      dataIndex: "payout_amount",
      key: "payout_amount",
      render: (data, record) => record['utr'] ? <p>{data}</p> : <div style={{ display: 'flex', justifyContent: 'space-between' }}><p>{data}</p><PopOverInput content={<Search
        placeholder="Enter value"
        allowClear
        enterButton="OK"
        size="small"
        defaultValue={data}
        onSearch={(value) => dispatch(updateTeacherPayoutData({ payout_id: record['id'], payout_amount: Number(value) }, notifyRef))}
      />} /></div>
    },
    {
      title: "Payout type ref",
      dataIndex: "payout_type_ref",
      key: "payout_type_ref",
      width: "150px",
      render: (type, record) => <div>{type.toLowerCase().includes("start") ? <Tag className={`${styles.cutomizeTag} ${styles.greentag}`}>{type}</Tag> : <Tag className={`${styles.cutomizeTag} ${styles.redtag} `}>{type}</Tag>}</div>
    },
    {
      title: "Tax deduction",
      dataIndex: "tax_deduction",
      key: "tax_deduction",
      render: (data, record) => record['utr'] ? <p>{data}</p> : <div style={{ display: 'flex', justifyContent: 'space-between' }}><p>{data}</p><PopOverInput content={<Search
        placeholder="Enter value"
        allowClear
        enterButton="OK"
        size="small"
        defaultValue={data}
        onSearch={(value) => dispatch(updateTeacherPayoutData({ payout_id: record['id'], tax_deduction: Number(value) }, notifyRef))}
      />} /></div>
    },
    {
      title: "Net Payable",
      dataIndex: "net_payable",
      key: "net_payable",
    },
    {
      title: "Payout due date",
      dataIndex: "payout_due_date",
      key: "payout_due_date",
      width: "200px",
      render: (data, record) => <p>{dayjs(data).format('DD MMM YYYY h:mm A')}</p>
      // width:"400px"
    },
    {
      title: "Utr Remark",
      dataIndex: "utr_remark",
      key: "utr_remark",
      render: (data, record) => <Tooltip title={data} >
       <Text className={styles.utrText}  ellipsis={true}>{data}</Text>
    </Tooltip>
    },
    {
      title: "Utr",
      dataIndex: "utr",
      key: "utr",
      render: (data, record) => <UtrEdit data={data} record={record} />
    }
  ];
  return (
    <div>
      <PayoutTable dataSource={teacher_payout} totalRecords={totalRecords['teacher_payout']} loading={loading['teacher_payout']} page={page['teacher_payout']} handlePage={(page) => dispatch(handlePayoutPagination(page))} columns={columns} />
    </div>
  );
};

export default PayoutDueTable;
