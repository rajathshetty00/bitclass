import { createContext, useRef, useState } from "react"
import SimpleAlert from "../components/alertComponent/AlertComponent"
import PayoutDueFilter from "./PayoutDueFilter/PayoutDueFilter"
import PayoutDueTable from "./PayoutDueTable/PayoutDueTable"
import { CloudDownloadOutlined, CloudUploadOutlined } from "@ant-design/icons"
import { Button, Input, Modal } from "antd"
import styles from "./style.module.scss"
import useRedux from "../../../helpers/useRedux"
import {
  downloadTransactionFile,
  uploadTransactionFile,
} from "../../../actions/teacherPayout"
import { PAYOUT_API_URL } from "../../../constants"
import earningFilterValidator from "../helper/EarningFilterValidator"
import useFormValidator from "../helper/useFormValidator"
import earningEmailValidator from "../helper/PayoutDueEmailValidator"
export const PayoutAlertRefContext = createContext()

const PayoutsDue = () => {
  const [uploadFile, setUploadFile] = useState("")
  const [queryData, setQueryData] = useState("")
  const [email, setEmail] = useState("")

  const [showEmailModel, setShowEmailModel] = useState("")
  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(
    sendCSVToEmail,
    {email},
    earningEmailValidator
  )

  const alertRef = useRef()
  const [{ loading, page }, dispatch] = useRedux("tpayout")
  
  const handleFileUpdate = (e) => {
    // check validation of csv file
    submitUploadedFile(e.target.files[0], alertRef)
  }

  const submitUploadedFile = (csvFile, alert) => {
    const formData = new FormData()
    formData.append("attachment", csvFile)
    // api call here
    dispatch(uploadTransactionFile(formData, alert))
    setUploadFile("")
  }
  // download csv files
  const sendCsvFile  =()=>{
    dispatch(downloadTransactionFile(`&csv=true&email=${email}`,alertRef,handleCancel));
  }
  const openEmailPopup =()=>{
    setShowEmailModel(true)
  }
  const handleOk = () => {
    handleSubmit()
  };

  const handleCancel = () => {
    setShowEmailModel(false);
    setEmail('')
    setErrors({})
    setIsSubmitting(false)
  };
  function sendCSVToEmail (){
    sendCsvFile()


  }

  const handleChangeEmail =(e)=>{
    setEmail(e.target.value)
    setErrors({})
    setIsSubmitting(false)

  }
  return (
    <div>
      <PayoutAlertRefContext.Provider value={alertRef}>
        <PayoutDueFilter queryData={queryData} setQueryData={setQueryData} />
        <PayoutDueTable />
        <SimpleAlert ref={alertRef} />
        <div className={styles.uploaderWrapper}>
          <input
            accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
            className={styles.input}
            id="contained-button-file"
            value={uploadFile}
            onChange={handleFileUpdate}
            type="file"
          />

          <Button
            className={styles.uploadBtn}
            loading={loading["uploadPayout"]}
            type="primary"
            icon={<CloudUploadOutlined />}
          >
            <label
              htmlFor="contained-button-file"
              style={{ paddingLeft: "5px" }}
            >{`${
              loading["uploadPayout"]
                ? "Uploading"
                : "Upload Processed Payments"
            }`}</label>
          </Button>
          <Button
            className={styles.uploadBtn}
            onClick={openEmailPopup}
            download
            type="link"
            icon={<CloudDownloadOutlined />}
          >
            {`${
              loading["uploadPayout"]
                ? "Downloading"
                : "Download Pending Payments"
            }`}
          </Button>
          <Modal title="Please enter email ,we will share the Csv on this email" confirmLoading={loading.downlaodPayout} visible={showEmailModel} okText="Send CSV" cancelText="close"  onOk={handleOk} onCancel={handleCancel}>
            <div className={styles.model_body}>
          <Input placeholder="Enter email" value={email} onChange={handleChangeEmail} className={styles.input} />
          {errors['email']&&<small className={styles.errorMsg}>{errors['email']}</small>}
          </div>
      </Modal>
        </div>
      </PayoutAlertRefContext.Provider>
    </div>
  )
}

export default PayoutsDue
