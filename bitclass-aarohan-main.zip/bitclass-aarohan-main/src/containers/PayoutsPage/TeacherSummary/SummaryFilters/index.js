import { Button, Select } from 'antd'
import { useContext, useEffect, useState } from 'react'
import { RefContext } from '..'
import { getTeacherSummaryDataByFilter } from '../../../../actions/teacherPayout'
import useRedux from '../../../../helpers/useRedux'
import { queryConstructor } from '../../../../utils'
import FilterComponent from '../../components/FilterComponent/FilterComponent'
import MinMaxInput from '../../components/MinMaxInput/MinMaxInput'
import SearchComponent from '../../components/SearchComponents/SearchComponent'
import Spacer from '../../components/Spacer/Spacer'
import summaryValidator from '../../helper/SummaryFilValidator'
import useFormValidator from '../../helper/useFormValidator'
import styles from './style.module.scss'
const filterOptionArr = [
  { value: "revenue", label: "Revenue" },
  { value: "earnings", label: "Earnings" },
  { value: "paid_till_date", label: "Paid Till Date" },
  { value: "next_due_amount", label: "Next Due Amount" },
  { value: "holding_amount", label: "Holding Amount" },
]
const { Option } = Select
const SummaryFilters = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("");
  const [minAmount, setMinAmount] = useState("");
  const [maxAmount, setMaxAmount] = useState("");
  const [{ page, isUpdated }, dispatch] = useRedux('tpayout');
  const [queryData, setQueryData] = useState("");
  const notifyRef = useContext(RefContext);

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(handleSearch, { minAmount, maxAmount, selectedFilter }, summaryValidator);

  // handle when search or filter data
  function handleSearch() {
    const queryObj = {
      "teacher_name": searchTerm,
      [`${selectedFilter}_min`]: minAmount,
      [`${selectedFilter}_max`]: maxAmount,

    };
    const query = queryConstructor(queryObj)
    dispatch(getTeacherSummaryDataByFilter(!query ? "" : `${query}`, 1, notifyRef));
    setQueryData(query);
  }


  // handle when search input field changed
  const handleSearchTerm = (e) => {
    setSearchTerm(e.target.value);
  }


  // handle when filter data change
  const handleFilter = (value) => {
    setErrors({});
    setIsSubmitting(false);
    if (value === undefined) {
      setSelectedFilter("");
      setMinAmount("");
      setMaxAmount("")
    } else {
      setSelectedFilter(value);
    }


  }
  // handle min max value with validation 
  const handleMinMaxValue = (e) => {
    setErrors({});
    setIsSubmitting(false);
    if (e.target.value.charAt(0) === "-" || e.target.value.charAt(0) === "+") {
      return;
    }
    else if (e.target.name === "min") {
      setMinAmount(e.target.value)
    } else {
      setMaxAmount(e.target.value)
    }
  }


  //called useEffect when Page changed and isUpdated teacher_summary changed
  useEffect(() => {
    dispatch(getTeacherSummaryDataByFilter(queryData, page['teacher_summary'], notifyRef));
  }, [page['teacher_summary'], isUpdated['teacher_summary']])

  return (
    <div className={styles.wrapper}>

      <SearchComponent value={searchTerm} onChange={handleSearchTerm} />
      <Spacer size={20} />
      <FilterComponent validate={errors['filtedErr']} value={selectedFilter} onChange={handleFilter} optArr={filterOptionArr} />
      <MinMaxInput onChange={handleMinMaxValue} valueMin={minAmount} validator={errors['minMaxValidErr']} valueMax={maxAmount} />
      <Button type="primary" className={styles.button} onClick={handleSubmit}>Search</Button>

    </div>
  )
}

export default SummaryFilters