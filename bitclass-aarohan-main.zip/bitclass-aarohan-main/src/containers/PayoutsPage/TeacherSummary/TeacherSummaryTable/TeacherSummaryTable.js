import { handleDetailPagination, updateTeacherDetail } from "../../../../actions/teacherPayout";
import useRedux from "../../../../helpers/useRedux";
import PayoutTable from "../../components/PayoutTable/PayoutTable";
import PopOverInput from "../../components/PopOverInput/PopOverInput";
import styles from "./style.module.scss";
import {  Input } from 'antd';
import { useContext } from "react";
import { RefContext } from "..";

const {Search} = Input;

const dataSource = [
  {
    key: '1',
    teacher_id: "1313",
    teacher_name: "asdsad",
    teacher_contact: "9991239123",
    teacher_email: "asdsa@asdad.com",
    beneficiary_name: "asdasd",
    bank_acc_num: "123123",
    ifsc_code: "asdsd12341",
    mou_link: "asdasd.com",
    total_revenue: 123,
    total_earnings: 12312,
    paid_till_date: 1000,
    next_due: 1000,
    balance: 1000,
    payment: "http://www.payment.in",
  },
  {
    key: '2',
    teacher_id: "asds",
    teacher_name: "asdsad",
    teacher_contact: "9991239123",
    teacher_email: "asdsa@asdad.com",
    beneficiary_name: "asdasd",
    bank_acc_num: "123123",
    ifsc_code: "asdsd12341",
    mou_link: "asdasd.com",
    total_revenue: 123,
    total_earnings: 12312,
    paid_till_date: 1000,
    next_due: 1000,
    balance: 1000,
  },
];

const TeacherSummaryTable = () => {
  const [{teacher_summary,page,loading,totalRecords},dispatch] = useRedux('tpayout');
  const notifyRef = useContext(RefContext)

const columns = [
  {
    title: "T_id",
    dataIndex: "teacher_id",
    key: "teacher_id",
  },
  {
    title: "Teacher Name",
    dataIndex: "teacher_name",
    key: "teacher_name",
  },
  {
    title: "Contact",
    dataIndex: "teacher_mobile",
    key: "teacher_mobile",
  },
  {
    title: "Email Id",
    dataIndex: "teacher_email",
    key: "teacher_email",
  },
  {
    title: "Benification Name",
    dataIndex: "teacher_beneficiary_name",
    key: "teacher_beneficiary_name",
    render:(data, record) => <div className={styles.cell_display} ><p>{data}</p><PopOverInput  content={<Search
      placeholder="Enter value"
      allowClear
      enterButton="OK"
      size="small"
      defaultValue={data}
      onSearch={(e)=>dispatch(updateTeacherDetail({teacher_id:record['teacher_id'],beneficiary_name:e},notifyRef))}
  />} /></div>
  },
  {
    title: "Bank Account #",
    dataIndex: "teacher_bank_account_number",
    key: "teacher_bank_account_number",
    render:(data, record) => <div className={styles.cell_display}><p>{data}</p><PopOverInput  content={<Search
      placeholder="Enter value"
      allowClear
      enterButton="OK"
      size="small"
      defaultValue={data}
      onSearch={(e)=>dispatch(updateTeacherDetail({teacher_id:record['teacher_id'],bank_acc_num:e},notifyRef))}
  />} /></div>
    
  },
  {
    title: "IFSC Code",
    dataIndex: "teacher_ifsc_code",
    key: "teacher_ifsc_code",
    render:(data, record) => <div className={styles.cell_display}><p>{data}</p><PopOverInput  content={<Search
      placeholder="Enter value"
      
      enterButton="OK"
      size="small"
      defaultValue={data}
      onSearch={(e)=>dispatch(updateTeacherDetail({teacher_id:record['teacher_id'],ifsc_code:e},notifyRef))}
  />} /></div>
  },
  {
    title: "Pan",
    dataIndex: "teacher_pan",
    key: "teacher_pan",
    render:(data, record) => <div className={styles.cell_display}><p>{data}</p><PopOverInput  content={<Search
      placeholder="Enter value"
      
      enterButton="OK"
      size="small"
      defaultValue={data}
      onSearch={(e)=>dispatch(updateTeacherDetail({teacher_id:record['teacher_id'],teacher_pan:e},notifyRef))}
  />} /></div>
  },
  {
    title: "MOU",
    dataIndex: "mou_link",
    key: "mou_link",
    render: (data, record) => (
        <a  href={data} target="_blank">Mou link</a>
      ),
  },
  {
    title: "Total Revenue",
    dataIndex: "total_revenue",
    key: "total_revenue",
  },
  {
    title: "Teacher Earning",
    dataIndex: "total_earnings",
    key: "total_earnings",
  },
  {
    title: "Paid Till Date",
    dataIndex: "paid_till_date",
    key: "paid_till_date",
  },
  {
    title: "Next Due",
    dataIndex: "next_due",
    key: "next_due",
  },
  {
    title: "Balance",
    dataIndex: "balance",
    key: "balance",
  },
  {
    title: "Payment",
    dataIndex: "payment",
    key: "payment",
    width: 200,
  },
];



  return (
    <div>
     
      <PayoutTable dataSource={teacher_summary} totalRecords={totalRecords['teacher_summary']} loading={loading['teacher_summary']} page={page['teacher_summary']} handlePage={(page)=>dispatch(handleDetailPagination(page))} columns={columns} />
    </div>
  );
};

export default TeacherSummaryTable;
