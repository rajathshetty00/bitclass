import { createContext } from "react"
import { useRef } from "react"
import SimpleAlert from "../components/alertComponent/AlertComponent"
import SummaryFilters from "./SummaryFilters"
import TeacherSummaryTable from "./TeacherSummaryTable/TeacherSummaryTable"
import styles from './style.module.scss'
export const RefContext = createContext()

const TeacherSummary = () => {
  const alertRef = useRef()

 

  return ( 
    <div className={styles.mainWrapper}>
      <RefContext.Provider value={alertRef}>
   <SummaryFilters />
   <TeacherSummaryTable alertRef ={alertRef}  />
   <SimpleAlert ref={alertRef} />
   </RefContext.Provider>

    </div>
   )
}
 
export default TeacherSummary