import { Select } from "antd"
import styles from './style.module.scss';

const { Option } = Select;
const FilterComponent = ({ value, onChange, allowClearnFun, optArr, filtertext = "Filter By", validate = false, handleClearOption }) => {
  return (
    <div className={styles.revenueFilter}>
      <Select
        placeholder={filtertext}
        value={value}
        allowClear
        onChange={onChange}
        onClear={handleClearOption}

      >
        <Option value="" disabled={true}>{filtertext}</Option>
        {optArr.map((item) => <Option value={item.value} key={item.value}>{item.label}</Option>)}

      </Select>
      {validate && <p className={styles.validationText}>Filter is required</p>}

    </div>
  )
}

export default FilterComponent
