import { Input } from 'antd';
import styles from './style.module.scss';
const MinMaxInput = ({valueMin,valueMax,onChange,keyDownEvent,validator=false}) => {
    return (
        <div>
        <div className={styles.min_max_wrapper}>
            <Input bordered={false}  pattern="^[1-9]\d*$"   type="number"  name="min" placeholder="min amount" value={valueMin} onChange={onChange}className={styles.min_max_field} />
            -
            <Input  bordered={false} pattern="[0-9]*"   type="number"   name="max" placeholder="max amount" value={valueMax} onChange={onChange} className={styles.min_max_field} />
        </div>
       {validator&&<p style={{position: 'absolute',color: 'tomato'}}>{validator}</p>}
        </div>
       
    )
}

export default MinMaxInput
