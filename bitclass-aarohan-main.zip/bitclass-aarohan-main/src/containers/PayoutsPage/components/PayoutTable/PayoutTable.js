import {Table } from "antd"
import { useEffect, useState } from "react";
import RevenueSharingPopup from "../RevenueSharingPopup/RevenueSharingPopup";
import styles from './style.module.scss'
import { LoadingOutlined } from '@ant-design/icons'
      
const PayoutTable = ({dataSource,columns,totalRecords=10,page,handlePage,loading}) => {
  //  const [limit, setLimit] = useState(10)
    return (
        <div className={styles.table_striped_rows}>
    
            <Table dataSource={dataSource}  rowKey="id"  scroll={{ x: 400 }} columns={columns} bordered={true} pagination={false} 
            pagination={{
                total: totalRecords,
                onChange: (d) => {
                    handlePage(d)
                },
                // onShowSizeChange: (d, l) => {
                //   setLimit(l)
                // },
              // defaultPageSize:10,
              showSizeChanger:false,
                current: page,
              }}
              loading={{
                spinning: loading,
                indicator: <LoadingOutlined type="loading" />,
              }}
              scroll={{ x: 1300 }}
             
              

            />
        </div>
    )
}

export default PayoutTable
