import { Popover } from "antd";

const PopOverInput = ({ content }) => {
  return (
    <Popover
      content={<div>{content}</div>}
      trigger="hover"
      title="want to change this"
    >
      <p
        style={{
          transform: "rotate(90deg)",
          fontSize: "15px",
          borderRight: "1px solid var(--blueColor)",
          cursor: "pointer",
          paddingRight: "1px",
          marginLeft: "10px",
          color: 'var(--blueColor)'
        }}
      >
        &#9998;
      </p>
    </Popover>
  );
};

export default PopOverInput;
