
import React from 'react'
import { teacherPayoutRefreshData } from '../../../../actions/teacherPayout';
import {  Button,Tag } from "antd"
import {

    ClockCircleOutlined,
    SyncOutlined
    
  } from '@ant-design/icons';
  import styles from './style.module.scss'
import useRedux from '../../../../helpers/useRedux';

const RefreshComponent = ({notifyRef}) => {
  const [{ loading,refreshTime }, dispatch] = useRedux("tpayout")

    const fetchRefreshData = ()=>{
        console.log("clicked",notifyRef);
        dispatch(teacherPayoutRefreshData(notifyRef))
      }
    return (
        <div className={styles.refreshWrapper}>
        <Tag  style={{fontSize:'17px'}} icon={<ClockCircleOutlined />} color="processing">
              {refreshTime?refreshTime:'time'}
            </Tag>
       <Button type="primary" icon={<SyncOutlined spin={loading.refreshPayout}  />} className={styles.button} onClick={fetchRefreshData}>Refresh</Button> 

     </div>
    )
}

export default RefreshComponent
