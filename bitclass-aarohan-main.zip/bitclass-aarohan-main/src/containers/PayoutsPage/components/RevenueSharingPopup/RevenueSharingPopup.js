import styles from './style.module.scss'
import { Modal, Radio, Input } from 'antd';
import { useContext, useEffect, useState } from 'react';
import clsx from 'clsx';
import { updateTeachersharedAmount } from '../../../../actions/teacherPayout';
import useRedux from '../../../../helpers/useRedux';
import { LoadingOutlined } from '@ant-design/icons'
import { EarningRefContext } from '../../CourseEarnings';
import revenuePopupValidator from '../../helper/RevenuePopupValidatior';
import useFormValidator from '../../helper/useFormValidator';
import { isEmpty } from 'lodash-es';

const { TextArea } = Input;
const initialInput = {
  register: null,
  amount: null,
  default: null,
  source: null,
  perc_share: null,
}
const RevenueSharingPopup = ({ data, record }) => {
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState(null);
  const [fixedShareValue, setfixedShareValue] = useState(null);
  const [inputValue, setInputValue] = useState(initialInput);
  const [remark, setRemark] = useState('');

  const [{ loading }, dispatch] = useRedux('tpayout');
  const alertRef = useContext(EarningRefContext);

  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(submitShareRevenueData, { value, fixedShareValue, inputValue,remark,isRemark:!isEmpty(record['payout_terms']) }, revenuePopupValidator);

  // 
const getUserCode =()=>{
  return localStorage.getItem('code');
}

  // when Any radio button checked handler
  const onChange = e => {
    setValue(e.target.value);

    setfixedShareValue(null);
    setInputValue(initialInput);
    setIsSubmitting(false);
    setErrors({});
  };
  const handleRemark =e=>{
    setRemark(e.target.value);
    setIsSubmitting(false);
    setErrors({});
  }
  // when the flat Revenue To Be Shared radio button changed
  const onChangeFixedShare = (e) => {
    setInputValue(initialInput)
    setfixedShareValue(e.target.value)
  }

  // when the clicked submit button check the validation and hit api
  function submitShareRevenueData() {
    setRemark('')
    let updateBody = {
      course_id: record['course_code'],
      teacher_id: record['teacher_id'],
      revenue_config: makingrevenueSharedObject(value),
      aarohan_user_code: getUserCode(),
      ...(!isEmpty(record['payout_terms'])&&{remark:remark}),
    }
    // api call
    dispatch(updateTeachersharedAmount(updateBody, alertRef))


  }

  const makingrevenueSharedObject = (value) => {
    if (value === "no_payout") {
      return {
        payout_type: "no_payout",
        course_share_agreement: "No Revenue Share"
      }
    } if (value === "flat") {
      if (fixedShareValue === "register") {
        return {
          payout_type: "flat",
          per_registration: Number(inputValue['register']),
          course_share_agreement: "Fixed"

        }
      } else if (fixedShareValue === "amount") {
        return {
          payout_type: "flat",
          flat_value: Number(inputValue['amount']),
          course_share_agreement: "Fixed"

        }
      }
    }
    if (value === "perc_share_source") {
      return {
        default_percentage: Number(inputValue['default']),
        source_percentage: Number(inputValue['source']),
        payout_type: "perc_share_source",
        course_share_agreement: "Share % By Source"
      }

    }
    if (value === "perc_share") {
      return {
        teacher_percentage: Number(inputValue['perc_share']),
        payout_type: "perc_share",
        course_share_agreement: "Share %"
      }

    }
  }


  // handle change of input field
  const handleInputChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;

    setIsSubmitting(false);
    setErrors({});
    setInputValue({ ...inputValue, [name]: value })
  }




  // preFilled value accroding to the data
  const changeValueAndRadioChecked = (recordData) => {

    if (recordData['payout_terms'] && recordData['payout_terms']['payout_type'] && recordData['payout_terms']['payout_type'] === "no_payout") {
      setValue("no_payout");
    } else if (recordData['payout_terms'] && recordData['payout_terms']['payout_type'] && recordData['payout_terms']['payout_type'] === "perc_share") {
      setValue("perc_share");
      setInputValue({ ...inputValue, 'perc_share': recordData['payout_terms']['teacher_percentage'] })
    } else if (recordData['payout_terms'] && recordData['payout_terms']['payout_type'] && recordData['payout_terms']['payout_type'] === "flat") {

      setValue("flat");
      if (recordData['payout_terms'] && recordData['payout_terms']['flat_value']) {
        setfixedShareValue("amount");
        setInputValue({ ...inputValue, 'amount': recordData['payout_terms']['flat_value'] });
      }
      else if (recordData['payout_terms'] && recordData['payout_terms']['per_registration']) {
        setfixedShareValue("register");
        setInputValue({ ...inputValue, 'register': recordData['payout_terms']['per_registration'] })

      }
    }
    else if (recordData['payout_terms'] && recordData['payout_terms']['payout_type'] && recordData['payout_terms']['payout_type'] === "perc_share_source") {
      setValue("perc_share_source");
      setInputValue({ ...inputValue, 'default': recordData['payout_terms']['default_percentage'] || null, 'source': recordData['payout_terms']['source_percentage'] || null })
    }
  }
  useEffect(() => {
    if (!loading['shared']) {
      setVisible(false)
    }
  }, [loading['shared']])
  useEffect(() => {
    changeValueAndRadioChecked(record);
    
  }, [data])


  return (
    <>
      <div onClick={() => setVisible(true)} className={styles.cell_disp} >
        <span>{data}</span>
        <p className={styles.pencil_icon}>&#9998;</p>
      </div>

      <Modal

        centeredradio_content
        visible={visible}
        onOk={() => handleSubmit()}
        onCancel={() => setVisible(false)}
        width={1000}
        okButtonProps={{ disabled: loading.shared }}
        okText={<p>{loading.shared ? <span>loading...<LoadingOutlined type="loading" /></span> : "Confirm Revenue Share"}</p>}
        className={styles.revenueSharingPopupWrapper}
      >
        <div className={styles.model_body}>

          <h1>Select Revenue share configuration for Earnings</h1>
          <Radio.Group onChange={onChange} value={value} className={styles.radio_group_wrapper}>
            <Radio value={"no_payout"}> <p className={styles.radio_label}>No Revenue to be shared</p></Radio>
            <Radio value={"flat"} className={styles.fixed_radio_wrapper}>
              <p className={styles.radio_label}>Fixed Revenue to be shared</p>
              <div className={styles.radio_content}>
                <Radio.Group onChange={onChangeFixedShare} value={fixedShareValue} className={styles.radio_group_content}>
                  <Radio value={"register"} disabled={value !== "flat"} className={clsx(styles.radio_disbaled_label, value === "flat" && styles.radio_content_sub_title)}>Per Registration</Radio>
                  <Radio value={"amount"} disabled={value !== "flat"} className={clsx(styles.radio_disbaled_label, value === "flat" && styles.radio_content_sub_title)}>Amount</Radio>
                </Radio.Group>
              </div>
              <div className={styles.radio_active_content}>
                <div>
                  <Input type="number" pattern="^[1-9]\d*$" value={inputValue['register']} disabled={fixedShareValue !== "register"} onChange={handleInputChange} name="register" placeholder="Enter amount per reginstration" className={styles.input_field} />
                  {errors['register'] && <p className={styles.error}>{errors['register']}</p>}

                </div>
                <div style={{ marginLeft: '1rem' }}>
                  <Input type="number" pattern="^[1-9]\d*$" value={inputValue['amount']} disabled={fixedShareValue !== "amount"} onChange={handleInputChange} name="amount" placeholder="Enter fixed amount" className={styles.input_field} />
                  {errors['amount'] && <p className={styles.error}>{errors['amount']}</p>}

                </div>
              </div>
              {errors['fixedShareValue'] && <p style={{ marginTop: '1rem', marginLeft: "1rem", color: "tomato", fontSize: '1rem' }}>{errors['fixedShareValue']}</p>}
            </Radio>
            <div className={styles.percentage_wrapper}>

              <Radio value={"perc_share"}><div style={{ display: 'flex', position: 'relative' }}>
                <p className={styles.radio_label}>% of Revenue to be shared</p>
                <Input type="number" min="0" max="100" pattern="^[1-9]\d*$" value={inputValue['perc_share']} disabled={value !== "perc_share"} onChange={handleInputChange} name="perc_share" placeholder="Enter amount of share in per" className={styles.input_field_per} />
                {errors['perc_share'] && <p className={styles.percentage_wrapperError}>{errors['perc_share']}</p>}

              </div>
              </Radio>
            </div>
            <Radio value={"perc_share_source"}> <p className={styles.radio_label}>% of Revenue share of source</p></Radio>

          </Radio.Group>
          <div className={styles.content_container_wrapper}>

            <div className={styles.content_container}>
              <p className={clsx(styles.default, value === "perc_share_source" && styles.default_active)} >Default</p>
              <div>
                <Input type="number" min="0" pattern="^[1-9]\d*$" disabled={value !== "perc_share_source"} value={inputValue['default']} name="default" onChange={handleInputChange} placeholder="Enter share %" className={styles.input_field} />
                {errors['default'] && <p className={styles.error}>{errors['default']}</p>}
              </div>

            </div>
            <div className={styles.content_container}>
              <p className={clsx(styles.default, value === "perc_share_source" && styles.default_active)} >Source</p>
              <div>
                <Input type="number" pattern="^[1-9]\d*$" disabled={value !== "perc_share_source"} value={inputValue['source']} name="source" onChange={handleInputChange} placeholder="Enter share %" className={styles.input_field} />
                {errors['source'] && <p className={styles.error}>{errors['source']}</p>}
              </div>

            </div>
          </div>
          {record['remark']&&<div style={{ margin: '24px 0 0',width: '70%' }} >
          <label>Older Remark</label>
          <TextArea autoSize={{ minRows: 2, maxRows: 3 }} placeholder="older remark" value={remark} readOnly value={record['remark']}  />
          </div>}
       {!isEmpty(record['payout_terms'])&& <div style={{ margin: '24px 0 0',width: '70%' }} >
            <label>Enter remark</label>
          <TextArea autoSize={{ minRows: 2, maxRows: 3 }} placeholder="Enter remark" value={remark} allowClear onChange={handleRemark}  />
          {errors['remark'] && <p className={styles.error}>{errors['remark']}</p>}
</div>}

          <div style={{ marginTop: '1rem', marginLeft: "1rem", color: "tomato", fontSize: '1rem' }}>{errors.value}</div>
        </div>
      </Modal>

    </>
  );
}

export default RevenueSharingPopup
