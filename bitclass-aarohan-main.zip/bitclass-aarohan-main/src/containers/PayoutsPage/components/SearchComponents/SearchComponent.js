import { Button, Input } from 'antd'
import Search from 'antd/lib/transfer/search'
import React from 'react'
import styles from './style.module.scss'
// const { Search } = Input;
const SearchComponent = ({ searchError = false, handleSearch, ...props }) => {
    return (
        <div>
            <div className={styles.search_field_wrapper}>
                <Search placeholder="Type here to search" enterButton {...props} />
                {/* <Search enterButton="search" placeholder="input search text" {...props} allowClear   /> */}
            </div>
            {searchError && searchError.length > 0 && <div className={styles.field_error}>{searchError}</div>}
        </div>
    )
}

export default SearchComponent
