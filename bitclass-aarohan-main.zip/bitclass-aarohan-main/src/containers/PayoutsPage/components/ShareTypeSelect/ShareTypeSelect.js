import { Select } from 'antd'
import { Option } from 'antd/lib/mentions';
import React, { useContext } from 'react'
import { teacherEarningPayTypeUpdate } from '../../../../actions/teacherPayout';
import useRedux from '../../../../helpers/useRedux';
import { EarningRefContext } from '../../CourseEarnings';

const ShareTypeSelect = ({data,teacher_id,course_id}) => {
  const [state,dispatch] = useRedux('tpayout');
  const notifyRef = useContext(EarningRefContext)

    const handleChange = (value) =>{
        dispatch(teacherEarningPayTypeUpdate({teacher_id:teacher_id,course_id:course_id,payout_type:value},notifyRef))
      }
    return (
        <div>
             <Select defaultValue={data} style={{ width: 100 }} onChange={handleChange}>
      <Option value="1P - 100">1P-100</Option>
      <Option value="2P - 50">2P-50</Option>
    </Select>
        </div>
    )
}

export default ShareTypeSelect
