import PopOverInput from "../PopOverInput/PopOverInput"
import {  Input,Button } from 'antd';
import { useDispatch } from "react-redux";
import { useContext } from "react";
import { PayoutAlertRefContext } from "../../PayoutsDue";
import useFormValidator from "../../helper/useFormValidator";
import { useState } from "react";
import payoutDueValidator from "../../helper/IsEmptyValidator";
import styles from './style.module.scss'
import { updatePayoutUTRData } from "../../../../actions/teacherPayout";
import Spacer from "../Spacer/Spacer";
const {Search} = Input;


const UtrEdit = ({record,data}) => {
    const dispatch = useDispatch()
    const code = localStorage.getItem('code')
  const notifyRef = useContext(PayoutAlertRefContext)
  const [inputValue, setinputValue] = useState(record?.utr);
  const [remark, setRemark] = useState('');


  const { handleSubmit, errors, setErrors, setIsSubmitting } = useFormValidator(submitUtrData, {utr:inputValue,...(record?.utr.length>0 && {remark})}, payoutDueValidator);

  function submitUtrData (){
    const reqBody ={
        id:record.id,
        teacher_id:record['teacher_id'],
        course_id:record['course_code'],
        utr:inputValue,
        remark,
        aarohan_user_code: code,

    }
     dispatch(updatePayoutUTRData(reqBody,notifyRef))
  }
const updateUtr =(e)=>{
   setinputValue(e.target.value)
   setErrors({})
   setIsSubmitting(false)
}
const onChangeRemarkData =(e)=>{
    setRemark(e.target.value)
    setErrors({})
    setIsSubmitting(false)
 }

    return (
        <div>
            <div className={styles.editIcon} ><p>{data}</p><PopOverInput  content={<div>
            <Input
        placeholder="Enter URT"
        allowClear
        size="small"
        value={inputValue}
        onChange={updateUtr}
        
    />
    {errors?.utr && <p className={styles.error}>{errors['utr']}</p>}

   <Spacer size={10}/>
    {record?.utr.length>0&&<Input
        placeholder="Enter Remark here"
        allowClear
        size="small"
        value={remark}
        onChange={onChangeRemarkData}
    />}
    {errors?.remark && <p className={styles.error}>{errors['remark']}</p>}
    <Spacer size={10}/>
    <Button onClick={handleSubmit} type="primary" >Ok</Button>
    </div>
    } /></div>
        </div>
    )
}

export default UtrEdit
