import React, { useImperativeHandle, forwardRef, useEffect } from 'react';

import { Alert } from 'antd';

const SimpleAlert =  forwardRef((props, ref) => {
  const [open, setOpen] = React.useState(false);
  const [msg, setMsg] = React.useState("Alert Message Text");
  const [type, setType] = React.useState("success");



  useImperativeHandle(ref, () => ({

     openToaster (msg,typeData="info",time) {
        setOpen(true);
        setMsg(msg);
        setType(typeData);
        setTimeout(() => {
            handleClose()
        },time?time:3000)
      }
  }));
  
useEffect(() => {
    // setTimeout(() => {setOpen(!open)},4000)
},[])
  const handleClose = (event, reason) => {
    // if (reason === 'clickaway') {
    //   return;
    // }
    setOpen(false)
    setMsg("");
    
  };

  return (
    <div style={{position: 'absolute',top: '0px',right: '15px',zIndex:99}}>
      {open ? (
        <Alert message={msg} type={type} closable afterClose={handleClose} />
      ) : null}
    </div>
  );
});
export default SimpleAlert;