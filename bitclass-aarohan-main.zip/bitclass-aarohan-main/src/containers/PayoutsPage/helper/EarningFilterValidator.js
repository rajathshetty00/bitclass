import { minMaxValidator } from "./teacherPayoutHelper";
import { isEmpty } from 'lodash-es';

export default function earningFilterValidator(values) {
    const errors = {};
    if (values['minAmount'].length>0&&values['maxAmount'].length>0 ) {
        if(!minMaxValidator(values['minAmount'],values['maxAmount'])){
            errors['minMaxValidErr']="Minimum amount should be less than  to maximum amount";
        }
        if(!values['selectedFilter'].length>0){
            errors['selectedFilter'] = "Filter is required for search"
        }
    } if (String(values['minAmount']).length==0&&String(values['maxAmount']).length>0) {
        errors['minMaxValidErr']="Minimum amount is required";
    }
    if (String(values['maxAmount']).length==0&&String(values['minAmount']).length>0) {
        errors['minMaxValidErr']="Maximum amount is required";
    }
    if(!isEmpty(values['searchTerm'])&&isEmpty(values['searchFilter'])){
        errors['searchFilter']="Please select one field";
    } 
    if(isEmpty(values['searchTerm'])&&!isEmpty(values['searchFilter'])){
        errors['searchTerm']="Search term is required";
    }
    
    return errors;
}