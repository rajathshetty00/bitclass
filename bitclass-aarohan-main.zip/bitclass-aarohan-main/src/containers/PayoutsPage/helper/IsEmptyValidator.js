import { isEmpty } from 'lodash-es';

export default function payoutDueValidator(values) {
    const errors = {};
 if(isEmpty(values?.utr)){
    errors.utr="required!"
}
if(values.hasOwnProperty('remark')&&isEmpty(values.remark)){
    errors.remark="required!"
}

return errors;

}