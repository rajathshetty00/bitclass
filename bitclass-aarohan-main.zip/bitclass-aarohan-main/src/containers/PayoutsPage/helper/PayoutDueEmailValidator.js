

import { isEmpty } from 'lodash-es';

export default function earningEmailValidator(values) {
    const errors = {};
    const  regexEmail = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

 if(isEmpty(values['email'])){
    errors['email']="Email is required!"
}
if(!isEmpty(values['email'])&&!String(values['email']).match(regexEmail)){
        errors['email'] ="Enter a valid email address"
}
return errors;

}