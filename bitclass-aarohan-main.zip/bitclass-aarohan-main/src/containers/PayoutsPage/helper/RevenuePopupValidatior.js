import { isEmpty } from 'lodash-es';
export default function revenuePopupValidator(values) {
    const errors = {};
    if (isEmpty(values['value'])) {
        errors.value = "Please select one radio button!"
    }
    if (values['isRemark']&&isEmpty(values['remark'])) {
        errors.value = "Please Enter the remark"
    }
    if (values['value']==="perc_share" ) {
        if(!values['inputValue']['perc_share']){
            errors['perc_share'] = "Percentage is required"
        }
        if(!isEmpty(values['inputValue']['perc_share'])&&percentLengthValid(values['inputValue']['perc_share'])){
            errors['perc_share'] = "Percentage should be 3 characters long"

        } if(percentMinMaxValidator(values['inputValue']['perc_share'])){
            errors['perc_share'] = "Percentage should lies between 0 and 100"
        }
    } if (values['value']==='flat') {
            if (isEmpty(values['fixedShareValue'])) {
                    errors['fixedShareValue']="Please select one radio button";
            }
            if(!isEmpty(values['fixedShareValue'])&& values['fixedShareValue']==="register"&&isEmpty(values['inputValue']['register'])){
                errors['register']="Please enter per registration amount ";
            }
            if(!isEmpty(values['fixedShareValue'])&& values['fixedShareValue']==="amount" &&isEmpty(values['inputValue']['amount'])){
                errors['amount']="please enter amount";

            }
    }
    if (values['value']==='perc_share_source') {
      
        if(isEmpty(values['inputValue']['default'])){
            errors['default']="Please enter default share amount";
        }
        if(!isEmpty(values['inputValue']['default'])&&percentLengthValid(values['inputValue']['default'])){
            errors['default'] = "Percentage should be 3 characters long"

        } if(percentMinMaxValidator(values['inputValue']['default'])){
            errors['default'] = "Percentage should lies between 0 and 100"
        }

        if(isEmpty(values['inputValue']['source'])){
            errors['source']="please enter source share amount";
        }
        if(!isEmpty(values['inputValue']['source'])&&percentLengthValid(values['inputValue']['source'])){
            errors['source'] = "Percentage should be 3 characters long"

        } if(percentMinMaxValidator(values['inputValue']['source'])){
            errors['source'] = "Percentage should lies between 0 and 100"
        }
}
    
    return errors;
}

const percentLengthValid = (perValue) => {
    if (perValue.length > 3) {
      return true
    }
    return false;
  }
  const percentMinMaxValidator = (perValue) => {
    if (perValue >= 0 && perValue <= 100) {
      return false;
    }
    return true;
  }