import { minMaxValidator } from "./teacherPayoutHelper";

export default function summaryValidator(values) {
    const errors = {};
    if (values['minAmount'].length>0&&values['maxAmount'].length>0 ) {
        if(!minMaxValidator(values['minAmount'],values['maxAmount'])){
            errors['minMaxValidErr']="Minimum amount should be less than  to maximum amount";
        }
        if(!values['selectedFilter'].length>0){
            errors['filtedErr'] = "Filter is required for search"
        }
    } if (String(values['minAmount']).length==0&&String(values['maxAmount']).length>0) {
        errors['minMaxValidErr']="Minimum amount is required";
    }
    if (String(values['maxAmount']).length==0&&String(values['minAmount']).length>0) {
        errors['minMaxValidErr']="Maximum amount is required";
    }
    
    return errors;
}