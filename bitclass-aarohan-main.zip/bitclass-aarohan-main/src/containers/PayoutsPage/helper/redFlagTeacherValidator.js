import { isEmpty } from 'lodash-es';

export default function redFlagTeacherValidator(values) {
    const errors = {};
    if (isEmpty(values['resonValue'])) {
        errors['resonValue'] = "Please enter the reson"
    }

    return errors;

}