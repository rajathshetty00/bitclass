 // validation check before pass acutal data
 export const minMaxValidator =(min,max)=>{
    const minValue = Number(min);
    const maxValue = Number(max);
    if (!isNaN(minValue)&&!isNaN(maxValue)&& minValue >= maxValue){
      return false;
    }
    return true;
}

//  length is required vlaidation
 export const searchValidation = (s) => {
  if (s.length === 0) {
    return false;
  }
  return true;
}