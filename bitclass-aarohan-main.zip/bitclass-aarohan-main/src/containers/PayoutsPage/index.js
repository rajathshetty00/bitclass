import { Card, Tabs } from "antd"
import clsx from "clsx"
import { useEffect } from "react"
import { useDispatch } from "react-redux"
import { fetchPayoutTeacherTypeData } from "../../actions/teacherPayout"
import CourseEarnings from "./CourseEarnings"
import PayoutsDue from "./PayoutsDue"
import styles from './style.module.scss'
import TeacherSummary from "./TeacherSummary"

const {TabPane} = Tabs

const PayoutsPage = () => {
const dispatch = useDispatch()
  useEffect(() => {
    dispatch(fetchPayoutTeacherTypeData())
  },[])
  return ( 
    <Card
      className={clsx("roundedCard", styles.courseFacilitator)}
    >
      <Tabs defaultActiveKey="1" onChange={() => {}} className={styles.tabs}>
        <TabPane tab="Teacher Summary" key="1">
          <TeacherSummary/>
        </TabPane>
        <TabPane tab="Course Earnings" key="2">
          <CourseEarnings/>
        </TabPane>
        <TabPane tab="Payouts Due" key="3">
          <PayoutsDue/>
        </TabPane>
      </Tabs>
    </Card>
   )
}
 
export default PayoutsPage