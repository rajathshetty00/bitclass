import { Card, Tabs } from "antd"
import clsx from "clsx"
import { cardBodyStyle } from "../../helpers/cardBodyStyle"
import useRedux from "../../helpers/useRedux"
import { SeriesCollection } from "./components"
import RecordingModal from "./components/RecordingModal/RecordingModal"
import Series from "./components/Series/Series"
// import Shorts from "./components/Shorts/Shorts"
import styles from "./styles.module.scss"
const { TabPane } = Tabs

export const CONTENT_KEY = {
  addShorts: "addShorts",
  addSeries: "addSeries",
  addVideo: "addVideo",
  watchVideo: "watchVideo",
}
const Recordings = () => {
  const [{ isModalVisible }] = useRedux("recordings")
  return (
    <Card
      className={clsx("roundedCard", styles.courseFacilitator)}
      bodyStyle={cardBodyStyle}
    >
      <Tabs defaultActiveKey="2" onChange={() => {}} className={styles.tabs}>
        {/* <TabPane tab="Shorts" key="1">
          <Shorts />
        </TabPane> */}
        <TabPane tab="Series" key="2">
          <Series />
        </TabPane>
        <TabPane tab="Series Collection" key="3">
          <SeriesCollection />
        </TabPane>
      </Tabs>
      {isModalVisible && <RecordingModal />}
    </Card>
  )
}

export default Recordings
