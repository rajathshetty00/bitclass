
import Paragraph from 'antd/lib/typography/Paragraph';
import styles from './styles.module.scss';
const CopyUrl = ({url}) => {
  return (
    <div className={styles.urlContainer}>
    <a href={url} target="_blank" rel="noopener noreferrer" title="URL" >{url}</a>
    <Paragraph className={styles.copyIcon}  copyable={{ text: url }} />
  </div>
  )
}

export default CopyUrl