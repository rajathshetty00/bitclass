import { Popconfirm } from 'antd';
import React from 'react'
import { useState } from 'react';
import { Trash } from 'react-feather';
import useRedux from '../../../../helpers/useRedux';
import { deleteCategroyData } from '../../../../redux/action/seriesAction';
import styles from './styles.module.scss'

const DeleteVideo = ({id}) => {
    const [isVisibile, setisVisibile] = useState(false)
    const [{loading,selectedSeries}, dispatch] = useRedux('series');
      
    const showPopconfirm = () => setisVisibile(true)
    const handleCancel = () =>   setisVisibile(false)
  
    const handleOk = () => {
        dispatch(deleteCategroyData(selectedSeries._id,id))
    };
   
  return (
         <Popconfirm
      title="Are you sure you want to delete"
      visible={isVisibile}
      onConfirm={handleOk}
      okButtonProps={{ loading: loading?.deletingVideo}}
      okText="Delete"
      onCancel={handleCancel}
    >
       <Trash role='button' size={30} className={styles.deleteBtn} onClick={showPopconfirm}/>
    </Popconfirm>
  )
}

export default DeleteVideo