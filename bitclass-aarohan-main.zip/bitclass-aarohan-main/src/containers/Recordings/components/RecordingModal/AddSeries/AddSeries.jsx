import { Switch, Table } from "antd"
import { isEmpty } from "lodash"
import { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import {
  getExternalCategories,
  getInternalCategories,
  openEditSeriesModal,
  openUploadVideoModal,
  pageChangeVideoTable,
  submitSeriesForm,
  updateFormData,
  updateInternalCategory,
} from "../../../../../redux/action/seriesAction"
import { CLEAR_FORM_DATA } from "../../../../../redux/types/series"

import { recordingTableColumns } from "../../Shorts/table"
import styles from "./styles.module.scss"

const AddSeries = () => {
  const {
    formData,
    videosTableVisibility,
    videosOfThisSeries,
    selectedSeries,
    categories,
    updatedFormData,
    seriesId,externalCategories,videoPage,totalVideo,loading
  } = useSelector((state) => state.series)

  const dispatch = useDispatch()

  const handleChange = (e) => dispatch(updateFormData(e.target))

  const clearSeriesForm = () => dispatch({ type: CLEAR_FORM_DATA })

  const handleSeriesFormSubmit = (e) => {
    e.preventDefault()
    dispatch(
      submitSeriesForm(
        selectedSeries?._id || seriesId,
        {...formData,is_active:formData.is_active===undefined?true:formData.is_active},
        {...updatedFormData,is_active:updatedFormData.is_active===undefined?true:updatedFormData.is_active}
      )
    )
   }

  const addNewVideoToSeries = () => dispatch(openUploadVideoModal())

  useEffect(
    () => dispatch(getInternalCategories(selectedSeries)),
    [dispatch, selectedSeries]
  )
  useEffect(
    () => dispatch(updateInternalCategory(formData)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dispatch, formData.c0, formData.c1, formData.c2]
  )
  useEffect(()=> dispatch(getExternalCategories()),[dispatch])
  
  useEffect(() => dispatch(openEditSeriesModal(selectedSeries,videoPage)), [dispatch,videoPage,selectedSeries])

  return (
    <div className={styles.container}>
      <form onSubmit={handleSeriesFormSubmit}>
        <div className={styles.inputContainer}>
          <label className={styles.label}>Title</label>
          <input
            type="text"
            name="title"
            required
            value={formData?.title || ""}
            onChange={handleChange}
            placeholder="Enter series name"
          />
        </div>
        <div className={styles.inputContainer}>
          <label className={styles.label}>Thumbnail URL</label>
          <input
            type="url"
            required
            placeholder="Enter series thumbnail url"
            name="thumbnail_url"
            value={formData?.thumbnail_url || ""}
            onChange={handleChange}
          />
        </div>

        <div className={styles.inputContainer}>
          <label className={styles.label}>External Category</label>
          <div>
          <select
                name="external_category"
                required
                value={ parseInt(formData?.external_category) || ""}
                className={styles.categoryDropdown}
                onChange={handleChange}
              >
                <option value={""} disabled >
                    select external category
                  </option>
                {externalCategories?.map((exCategory) => (
                  <option value={exCategory.id} key={exCategory.id||"external_category"}>
                    {exCategory.display_text}
                  </option>
                ))}
              </select>
          </div>
        </div>

        <div className={styles.inputContainer}>
          <label className={styles.label}>Teacher profile code</label>
          <input
            type="text"
            placeholder="Enter teacher code which belong to this series"
            name="teacher_id"
            value={formData?.teacher_id || ""}
            onChange={handleChange}
            required
          />
        </div>

        <div className={styles.inputContainer}>
          <label className={styles.label}>Is Series Active</label>
          <div>
           <Switch
           name="is_active"
      checkedChildren="Active"
      unCheckedChildren="Hidden"
      defaultChecked
      checked={formData.is_active}
      onChange={(checked)=>handleChange({target:{name:'is_active',value:checked}})} 
    />
          </div>
        </div>



        <div className={styles.categoryContainer}>
          <label className={styles.label}>Category Tagging</label>
          <div className={styles.categories}>
            <div className={styles.category}>
              <label>C0</label>
              <select
                name="c0"
                required
                value={formData?.c0 || ""}
                className={styles.categoryDropdown}
                onChange={handleChange}
              >
                {categories?.c0?.map((category) => (
                  <option value={category.id} key={category.id||"category_c0"}>
                    {category.display_text}
                  </option>
                ))}
              </select>
            </div>
            <div className={styles.category}>
              <label>C1</label>
              <select
                name="c1"
                required
                className={styles.categoryDropdown}
                value={formData?.c1 || ""}
                onChange={handleChange}
              >
                {categories?.c1?.map((category) => (
                  <option value={category.id} key={category.id||"category_c1"}>
                    {category.display_text}
                  </option>
                ))}
              </select>
            </div>
            <div className={styles.category}>
              <label>C2</label>
              <select
                name="c2"
                required
                className={styles.categoryDropdown}
                value={formData?.c2 || ""}
                onChange={handleChange}
              >
                {categories?.c2?.map((category) => (
                  <option value={category.id} key={category.id||"category_c2"}>
                    {category.display_text}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className={styles.tags}>
          <label className={styles.label}>Tags</label>
          <textarea
            rows="4"
            name="tags"
            value={formData?.tags || ""}
            onChange={handleChange}
            placeholder="Add tags (comma separated, no spaces)"
          />
        </div>
        {videosTableVisibility && (
          <div className={styles.newVideo}>
            <button type="button" onClick={addNewVideoToSeries}>
              Add New
            </button>
          </div>
        )}
        {videosTableVisibility && (
          <div className={styles.seriesTable}>
            <Table
              columns={recordingTableColumns}
              scroll={{ x: "max-width" ,y:400}}
              dataSource={videosOfThisSeries}
              bordered
              rowKey="_id"
              loading={loading?.fetchVideoList}
          page={videoPage}
          pagination={{
            total:totalVideo,
            onChange: (page) => {
              dispatch(pageChangeVideoTable(page))
            },
            showSizeChanger: false,
            current: videoPage,
          }}
            />
          </div>
        )}
        <div className={styles.btnContainer}>
          <button
            type="submit"
            disabled={isEmpty(updatedFormData) || isEmpty(formData)}
          >
            Submit
          </button>
          <button
            type="button"
            className={styles.cancelButton}
            onClick={clearSeriesForm}
          >
            Clear
          </button>
        </div>
      </form>
    </div>
  )
}

export default AddSeries
