import clsx from "clsx"
import styles from "./styles.module.scss"

const AddShorts = () => {
  return (
    <div className={styles.container}>
      <div className={styles.inputContainer}>
        <label className={styles.label}>Title</label>
        <input type="text" placeholder="Enter title for video" />
      </div>
      <div className={styles.inputContainer}>
        <label className={styles.label}>URL</label>
        <input type="text" placeholder="Enter link" />
      </div>

      <div className={styles.tags}>
        <label className={styles.label}>Tags</label>
        <textarea
          rows="4"
          placeholder="Add tags (comma separated, no spaces)"
        />
      </div>
      <div className={styles.categoryContainer}>
        <label className={styles.label}>Category Tagging</label>
        <div className={styles.categories}>
          <div className={styles.category}>
            <label>C0</label>
            <select name="category" className={styles.categoryDropdown}>
              <option value="cat1">Cat1</option>
            </select>
          </div>
          <div className={styles.category}>
            <label>C1</label>
            <select name="category" className={styles.categoryDropdown}>
              <option value="cat1">Cat1</option>
            </select>
          </div>
          <div className={styles.category}>
            <label>C2</label>
            <select name="category" className={styles.categoryDropdown}>
              <option value="cat1">Cat1</option>
            </select>
          </div>
        </div>
      </div>
      <div className={styles.viewingMode}>
        <label className={clsx(styles.label, styles.viewingModeLabel)}>
          Suggested Viewing Mode
        </label>
        <div className={styles.radioInput}>
          <input
            type="radio"
            name="suggestedViewingMode"
            id="portrait"
            value="portrait"
          />
          <label for="portrait">Portrait</label>
        </div>
        <div className={styles.radioInput}>
          <input
            type="radio"
            name="suggestedViewingMode"
            id="landscape"
            value="landscape"
          />
          <label for="landscape">Landscape</label>
        </div>
      </div>
      <div className={styles.btnContainer}>
        <button type="button">Submit</button>
        <button type="button" className={styles.cancelButton}>
          Cancel
        </button>
      </div>
    </div>
  )
}

export default AddShorts
