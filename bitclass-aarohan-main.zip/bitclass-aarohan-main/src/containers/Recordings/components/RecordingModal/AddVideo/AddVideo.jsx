import clsx from "clsx"
import { isEmpty } from "lodash"
import { useEffect, useState } from "react"
import ReactPlayer from "react-player"
import { useDispatch, useSelector } from "react-redux"
import { getDurationFromVideoURL, getVideoThumnailFromVideoURL } from "../../../../../helpers"
import {
  getInternalCategories,
  submitVideoForm,
  updateFormData,
  updateInternalCategory,
} from "../../../../../redux/action/seriesAction"
import { CLEAR_FORM_DATA } from "../../../../../redux/types/series"

import styles from "./styles.module.scss"

const AddVideo = () => {
  const [duration, setduration] = useState(null)
  const {
    formData,
    selectedSeries,
    categories,
    updatedFormData,
    selectedVideo,
  } = useSelector((state) => state.series)

  const dispatch = useDispatch()
  const handleChange = (e) => {
    if (e.target.name === 'url') {
      setduration(null)
    }
    dispatch(updateFormData(e.target))
  }
  const clearVideoForm = () => dispatch({ type: CLEAR_FORM_DATA })
  const handleDuration = (duration) =>setduration(parseInt(duration.toFixed(2),10))


  const handleVideoFormSubmit = async(e) => {
    e.preventDefault()
    const videoThumnail = getVideoThumnailFromVideoURL(formData?.url)
    dispatch(
      submitVideoForm(
        selectedSeries,
        selectedVideo?._id,
        {...formData,duration:duration.toString(),thumbnail_url:videoThumnail,...(formData?.default_view === undefined||formData?.default_view === 'portrait'?{default_view: "portrait"}:{default_view:"landscape"})},
        {...updatedFormData,duration:duration.toString(),thumbnail_url:videoThumnail,...(updatedFormData?.default_view === undefined||updatedFormData?.default_view === 'portrait'?{default_view: "portrait"}:{default_view:"landscape"})}
      )
    )
  }
  useEffect(
    () => dispatch(getInternalCategories(selectedVideo)),
    [dispatch, selectedVideo]
  )

  useEffect(
    () => dispatch(updateInternalCategory(formData)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [dispatch, formData.c0, formData.c1, formData.c2]
  )

  const playerReadyToPlay =(e)=>{
    const duration =e.getDuration();
    setduration(parseInt(duration.toFixed(2),10))
  }
  return (
    <div className={styles.container}>
      <form onSubmit={handleVideoFormSubmit}>
        <div className={styles.inputContainer}>
          <label className={styles.label}>Title</label>
          <input
            type="text"
            placeholder="Enter title for video"
            name="title"
            value={formData?.title || ""}
            onChange={handleChange}
          />
        </div>
        <div className={styles.inputContainer}>
          <label className={styles.label}>URL</label>
          <input
            type="text"
            placeholder="Enter video url"
            name="url"
            value={formData?.url || ""}
            onChange={handleChange}
          />
        </div>
        {duration&& <div className={styles.inputContainer}>
          <label className={styles.label}>Video Duration</label>
          <label className={styles.label}>{duration||"Loading Duration of video URL"}</label>
          
        </div>}
        <div className={styles.viewingMode}>
          <label className={clsx(styles.label, styles.viewingModeLabel)}>
            Suggested Viewing Mode
          </label>
          <div className={styles.radioInput}>
            <input
              type="radio"
              name="default_view"
              id="portrait"
              defaultChecked
              checked={formData?.default_view === undefined||formData?.default_view === 'portrait'? "portrait":false}
              onChange={handleChange}
            />
            <label htmlFor="portrait">Portrait</label>
          </div>
          <div className={styles.radioInput}>
            <input
              type="radio"
              name="default_view"
              id="landscape"
              checked={formData?.default_view === "landscape"}
              onChange={handleChange}
            />
            <label htmlFor="landscape">Landscape</label>
          </div>
        </div>
        <div className={styles.btnContainer}>
          <button
            type="submit"
            onClick={handleVideoFormSubmit}
            disabled={isEmpty(updatedFormData) || isEmpty(formData)||!duration}
            className={styles.primaryBtn}
          >
            Submit
          </button>
          <button
            type="button"
            className={styles.cancelButton}
            onClick={clearVideoForm}
          >
            Clear
          </button>
        </div>
      </form>
      <ReactPlayer style={{display:'none'}} url={formData?.url} onReady={playerReadyToPlay} onDuration={handleDuration}  />

    </div>
  )
}

export default AddVideo
