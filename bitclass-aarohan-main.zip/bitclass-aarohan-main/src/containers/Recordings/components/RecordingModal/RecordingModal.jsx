import { Modal } from "antd"
import useRedux from "../../../../helpers/useRedux"
import { changeContentKey, clearUpdateForm, saveSeriesList, setSelectedSeriesToForm } from "../../../../redux/action/seriesAction"
import { TOGGLE_MODAL } from "../../../../redux/types/recording"
import { CONTENT_KEY } from "../../Recordings"
import AddSeries from "./AddSeries/AddSeries"
import AddShorts from "./AddShorts/AddShorts"
import AddVideo from "./AddVideo/AddVideo"
import WatchVideo from "./WatchVideo/WatchVideo"

const RecordingModal = () => {
  const [{ isModalVisible }] = useRedux("recordings")
  const [{ contentKey }, dispatch] = useRedux("series")

  const handleOk = () => {
    dispatch({ type: TOGGLE_MODAL, payload: false })
  }
  const handleCancel = () => {
    switch (contentKey) {
      case 'addSeries':
        dispatch({ type: TOGGLE_MODAL, payload: false })
        dispatch(saveSeriesList())
        break;
      case 'addVideo': case 'watchVideo':
        dispatch(changeContentKey('addSeries'))
        dispatch(clearUpdateForm())
        dispatch(setSelectedSeriesToForm())
        break;
      default:
        dispatch({ type: TOGGLE_MODAL, payload: false })
        dispatch(changeContentKey(''))
        break;
    }
  }


  const MODAL_TITLE = {
    addShorts: "ADD NEW SHORTS / EDIT SHORTS",
    addSeries: "Add New Series / Edit Series",
    addVideo: "Add New Video / Edit Video",
  }[contentKey]

  return (
    <>
      <Modal
        width="max-content"
        title={
          contentKey === CONTENT_KEY.watchVideo ? null : (
            <div style={{ marginRight: "2rem" }}>{MODAL_TITLE}</div>
          )
        }
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
      >
        {
          {
            addShorts: <AddShorts />,
            addSeries: <AddSeries />,
            addVideo: <AddVideo />,
            watchVideo: <WatchVideo />,
          }[contentKey]
        }
      </Modal>
    </>
  )
}

export default RecordingModal
