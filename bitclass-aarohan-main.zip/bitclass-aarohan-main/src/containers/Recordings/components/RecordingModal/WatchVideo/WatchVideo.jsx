import { useSelector } from "react-redux"
import styles from "./styles.module.scss"

const WatchVideo = () => {
  const { videoUrl } = useSelector((state) => state.series)
  return (
    <div className={styles.watchVideo}>
      <video autoPlay width="800" controls className={styles.video}>
        <source src={videoUrl} type="video/mp4" />
        Your browser does not support HTML video.
      </video>
    </div>
  )
}

export default WatchVideo
