module.exports = {
  
  siteUrl: 'https://bitclass.live/',
  generateRobotsTxt: true, // (optional)
  sourceDir: './src/__next__/.next',
  outDir: './src/__next__/public',
  sitemapSize: 5000,
  // ...other options
  
}