// const withPlugins = require('next-compose-plugins')
const withLess = require("@zeit/next-less")
const dotenv = require("dotenv-webpack")
const withSass = require("@zeit/next-sass")
const withCSS = require("@zeit/next-css")

module.exports =
  // withImages({
  withCSS({
    ...withSass({
      cssModules: true,
      ...withLess({
        lessLoaderOptions: {
          javascriptEnabled: true,
          modifyVars: {
            "primary-color": "#079893",
            "link-color": "#1DA57A",
            "border-radius-base": "4px",
          }, // make your antd custom effective
          importLoaders: 0,
        },
        cssLoaderOptions: {
          importLoaders: 3,
          localIdentName: "[local]___[hash:base64:5]",
        },
        basePath: process.env.BASE_PATH,

        webpack: (config, { isServer }) => {
          //Make Ant styles work with less
          if (isServer) {
            const antStyles = /antd\/.*?\/style.*?/
            const origExternals = [...config.externals]
            config.externals = [
              (context, request, callback) => {
                if (request.match(antStyles)) return callback()
                if (typeof origExternals[0] === "function") {
                  origExternals[0](context, request, callback)
                } else {
                  callback()
                }
              },
              ...(typeof origExternals[0] === "function" ? [] : origExternals),
            ]
            config.module.rules.unshift({
              test: antStyles,
              use: "null-loader",
            })
          }
          config.plugins.push(new dotenv({ silent: true }))
          config.module.rules.push({
            test: /\.(svg|jpg)x?$/,
            use: ["@svgr/webpack"],
          })
          config.module.rules.push({
            test: /\.(png|jpeg|woff|woff2|ttf)$/,
            loader: "url-loader?limit=8192",
          })
          return config
        },
      }),
    }),
  })
// })
