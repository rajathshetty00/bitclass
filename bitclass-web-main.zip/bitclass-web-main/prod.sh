# git stash -u
# git checkout master
# git pull origin master
# npm install
pm2 delete prod
pm2 start "npm run server:prod" --name prod