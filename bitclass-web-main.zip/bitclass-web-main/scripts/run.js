const express = require("express")
const path = require("path")
const app = express()
const chalk = require("react-dev-utils/chalk")
console.log(chalk.yellow(`App directory...${__dirname}`))
// app.use(require('prerender-node').set('prerenderToken', '0Xf7nnR2XPgsLKxoW9IZ'));
app.use("/", express.static(path.join(__dirname, "../build")))
app.use("/static/", express.static(path.join(__dirname, "../build")))
app.get("/apple-app-site-association", (req, res) => {
  res.json({
    applinks: {
      apps: [],
      details: [
        {
          appID: "WM8KC9867L.com.livestreaminfratech.bitclass",
          paths: ["*"],
        },
      ],
    },
  })
})
app.get("/*", function (req, res) {
  console.log(chalk.cyan(`got request...${req.url}`))
  if (req.url.match("/classroom")) {
    console.log("Entered classroom  ")
    res.setHeader("Cross-origin-Embedder-Policy", "require-corp")
    res.setHeader("Cross-origin-Opener-Policy", "same-origin")
  }
  res.sendFile(path.join(__dirname, "../build", "index.html"))
})
app.listen(3000)
console.log(chalk.green(`listening on ...${3000}`))
console.log(chalk.green(`App ready...`))
