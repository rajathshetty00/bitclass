const express = require("express")
const next = require("next")
const wellKnowData = require("./wellKnow.json")
const port = parseInt(process.env.PORT, 10) || 3001
const dev = process.env.NODE_ENV !== "production"
const app = next({ dir: "src/__next__/", dev })
const handle = app.getRequestHandler()

app.prepare().then(() => {
  const server = express()
  server.use("/static", express.static("public"))

  server.get("/.well-known/assetlinks.json", (req, res) => {
    req.header("Content-Type", "application/json")
    res.json(wellKnowData)
  })

  server.get("/cdp", (req, res) => {
    const actualPage = "/cdp"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/referral", (req, res) => {
    var userCode = req.query.referred_by
    res.redirect(
      `https://bitclass.live/live-classes/signin?referred_by=${userCode}`
    )
  })

  server.get("/chat/:phone", (req, res) => {
    const userPhone = req.params.phone
    res.redirect(`https://web.whatsapp.com/send?phone=91${userPhone}`)
  })

  server.get("/classroom/:courseCode", (req, res) => {
    // const { courseCode } = req.params
    // const { _auth, utm_source, utm_medium } = req.query
    // `https://${baseUrl}/live-classes/classroom/${courseCode}?_auth=${_auth}&&utm_medium=${utm_medium}&&utm_source=${utm_source}`
    const baseUrl = req.headers.host
    res.redirect(`https://${baseUrl}/live-classes/${req.originalUrl}`)
  })
  server.get("/careers", (req, res) => {
    const actualPage = "/careers"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/contact", (req, res) => {
    const actualPage = "/contact"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/about", (req, res) => {
    const actualPage = "/about"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/app/policy", (req, res) => {
    const actualPage = "/app/policy"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/app/terms", (req, res) => {
    const actualPage = "/app/terms"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/terms-and-conditions", (req, res) => {
    const actualPage = "/terms-and-conditions"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/c/:categoryName", (req, res) => {
    const actualPage = "/category-page"
    const queryParams = { categoryName: req.params.categoryName }
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/teach-on-bitclass", (req, res) => {
    const actualPage = "/teach-on-bitclass"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/live-courses/search", (req, res) => {
    res.redirect("/")
  })

  server.get("/slot-selection/:token", (req, res) => {
    const actualPage = "/slot-selection"
    const queryParams = { token: req.params.token }
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/app/policy", (req, res) => {
    const actualPage = "/app/policy"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/partner-with-bitclass", (req, res) => {
    const actualPage = "/partner"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/course-not-found", (req, res) => {
    const actualPage = "/course-not-found"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/live-courses/summer-camp-2021", (req, res) => {
    const actualPage = "/live-courses/summer-camp-2021"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/content/feed", (req, res) => {
    const actualPage = "/feeds"
    const queryParams = {}
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/content/feed/:feedId", (req, res) => {
    const actualPage = "/feed"
    const queryParams = { feedId: req.params.feedId }
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/free-course/:courseCode", (req, res) => {
    const actualPage = "/free-course"
    const queryParams = { courseCode: req.params.courseCode }
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/freemium/:slug/:courseCode", (req, res) => {
    const actualPage = "/freemium"
    const queryParams = {
      courseCode: req.params.courseCode,
      slug: req.params.slug,
    }
    app.render(req, res, actualPage, queryParams)
  })

  server.get("/multi-course/:subject", (req, res) => {
    const actualPage = "/online-classes/multi-tmpr"
    const queryParams = { subject: req.params.subject }
    app.render(req, res, actualPage, queryParams)
  })
  server.get("/apple-app-site-association", (req, res) => {
    const file = `${__dirname}/apple-app-site-association`
    res.download(file) // Set disposition and send it
  })

  server.get("/amphitheatre/events/:id", (req, res) => {
    const actualPage = "/amphitheatre"
    const queryParams = { eventId: req.params.id }
    app.render(req, res, actualPage, queryParams)
  })

  server.all("*", (req, res) => {
    return handle(req, res)
  })
  server.listen(port, (err) => {
    if (err) throw err
    console.log(`> Ready on http://localhost:${port}`)
  })
})
