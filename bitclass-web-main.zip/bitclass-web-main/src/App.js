import React, { Suspense, useEffect } from "react"
import { Provider } from "react-redux"
import { createBrowserHistory } from "history"
import { Route, Router, Switch } from "react-router-dom"
import { store } from "./reducers"
import { exists, getCookie, setAuthToken, setCookie } from "./__utils__/index"
import { getCode, getRole } from "./__utils__/auth"
import { getSelf } from "./__utils__/api"
import * as firebase from "firebase/app"
import "firebase/analytics"
import * as Sentry from "@sentry/react"
import { singularSdk, SingularConfig } from "singular-sdk"
import {
  // AGORA_APP_ID,
  FIREBASE_CONFIG,
  SENTRY_DSN,
  FB_PIXEL_ID,
  MOENGAGE_ID,
  BASE_URL,
} from "./constants"
import "./App.scss"
import clsx from "clsx"
import ReactPixel from "react-facebook-pixel"
import CreateCourse from "./course/CreateNew"
// import ClassroomScreen from "./lesson/classroom/classroom"
import CertificateScreen from "./CertificateScreen"

import { SINGULAR_API_KEY, SINGULAR_SECRET_KEY } from "./constants"

const AppHeader = React.lazy(() => import("./__components__/AppHeader"))

const PrivateRoute = React.lazy(() => import("./auth/authWrapper"))
const FeedbackScreen = React.lazy(() => import("./lesson/Feedback"))
const EditProfile = React.lazy(() => import("./profile/Edit"))
const PrivateCourseDetails = React.lazy(() =>
  import("./profile/PrivateCourseDetails")
)
const PrivateCourseBuilder = React.lazy(() => import("./course/CourseBuilder"))
const CourseFeedback = React.lazy(() =>
  import("./course/CourseFeedbackForm/CourseFeedback")
)
const DummyCourseFeedback = React.lazy(() =>
  import("./course/DummyCourseFeedbackForm/CourseFeedback")
)

const GeniePreference = React.lazy(() =>
  import("./genie/GeniePreference/GeniePreference")
)

const TeacherIntent = React.lazy(() => import("./teacher_intent/index"))

const Dashboard = React.lazy(() => import("./dashboard"))

firebase.initializeApp(FIREBASE_CONFIG)

if (window.location.hostname.includes("bitclass.live")) {
  const advancedMatching = {}
  const options = {
    autoConfig: true, // set pixel's autoConfig
    debug: false, // enable logs
  }
  ReactPixel.init(FB_PIXEL_ID, advancedMatching, options)
  ReactPixel.pageView() // For tracking page view
  Sentry.init({
    dsn: SENTRY_DSN,
  })
}

export const Moengage = window.moe({
  app_id: MOENGAGE_ID,
  debug_logs: 0,
})

/***************************/

const history = createBrowserHistory()
history.listen((location, action) => {
  window.scrollTo(0, 0)
})

const appLayout = (props, Component, page = "") => {
  return (
    <>
      <div className="main-header">
        <AppHeader props={props} page={page} />
      </div>
      <div
        className={clsx(
          "main-container",
          props.fullWidth && "full-width-container"
        )}
      >
        <Component {...props}></Component>
      </div>
    </>
  )
}

const initSingular = () => {
  try {
    const config = new SingularConfig(
      SINGULAR_API_KEY,
      SINGULAR_SECRET_KEY,
      BASE_URL
    ).withCustomUserId(getCode())
    singularSdk.init(config)
  } catch (error) {
    console.log(error)
  }
}

function App() {
  // Cookie Login
  let _url = new URLSearchParams(history.location.search)
  let _authToken = _url.get("_auth")
  if (
    getCookie("is_apps")?.toLowerCase() === "yes" &&
    !exists(_url.get("is_apps"))
  ) {
    let currentUrl = history.location.pathname
    if (exists(history.location.search)) {
      currentUrl += history.location.search + "&is_apps=yes"
    } else {
      currentUrl += "?is_apps=yes"
    }
    history.push(currentUrl)
    setCookie("is_apps", null, 0)
  }

  if (!getCookie("auth-key") && exists(_authToken)) {
    // clear the userinfo in local storage befor setting the _auth cookie
    localStorage.removeItem("userInfo")
    const adminAuth = _authToken
    setAuthToken(adminAuth)
    getSelf().then((r) => {
      if (r["data"].error) {
        localStorage.clear()
        window.location.reload()
        return
      }

      const {
        id,
        username,
        code,
        image,
        chat_auth_token,
        admin,
        teacherHandle,
        phone,
        email,
        first_name: firstName,
      } = r.data

      const extractedInfo = {
        id,
        username,
        code,
        image,
        chat_auth_token,
        admin,
        teacherHandle,
        phone,
        email,
        firstName,
      }
      localStorage.setItem("userInfo", JSON.stringify(extractedInfo))
      localStorage.setItem("authenticated", true)
      localStorage.setItem("role", getRole() || "student")
    })
  }
  // Cookie Login End */

  /**********************************************************/

  useEffect(() => {
    initSingular()
  }, [])
  return (
    <Provider store={store}>
      <Router history={history}>
        <Suspense fallback={history.location.pathname !== "/" ? "" : ""}>
          <Switch>
            <Route
              exact
              path="/genie"
              render={(props) =>
                appLayout(
                  { ...props, fullWidth: true },
                  GeniePreference,
                  "Genie"
                )
              }
            />

            <Route
              exact
              path="/courses/feedback/:courseID"
              render={(props) => <CourseFeedback {...props} />}
            />

            <Route
              exact
              path="/mobile/feedback/:courseCode"
              render={(props) => <DummyCourseFeedback {...props} />}
            />

            <Route
              exact
              path="/mobile/certificate/:courseCode"
              render={(props) => <CertificateScreen {...props} />}
            />
            {/* <Route
              path="/classroom/:courseCode"
              component={(props) => (
                <ClassroomScreen appID={AGORA_APP_ID} {...props} />
              )}
            /> */}
            <PrivateRoute
              path="/profile"
              exact
              component={(props) => <Dashboard {...props} />}
            />
            <PrivateRoute
              path="/profile/apply"
              exact
              component={(props) =>
                appLayout(
                  { ...props, fullWidth: true },
                  TeacherIntent,
                  "teacher-apply"
                )
              }
            />

            <PrivateRoute
              path="/course/summary/:courseCode"
              exact
              component={(props) => <PrivateCourseDetails {...props} />}
            />

            <PrivateRoute
              exact
              path="/profile/:profileID/edit"
              component={(props) =>
                appLayout({ ...props, fullWidth: true }, EditProfile)
              }
            />
            <PrivateRoute
              path="/lessons/:lessonID/feedback"
              component={(props) => appLayout(props, FeedbackScreen)}
            />
            <Route
              exact
              path="/courses/new"
              render={(props) => appLayout(props, CreateCourse)}
            />

            <PrivateRoute
              path="/course/:profileID/:courseCode/edit"
              exact
              component={(props) => (
                <PrivateCourseBuilder role="TEACHER" {...props} />
              )}
            />
          </Switch>
        </Suspense>
      </Router>
    </Provider>
  )
}

export default App
