import { getDateFormat } from "../../__utils__/dateFns"
import styles from "./style.module.scss"
import BitclassLogo from "../../__assets__/BitClassLogos/appHeaderLogo.svg"
import CertificateOfAchievement from "../../__assets__/certificate-of-achievement.svg"
import CertificateLogo from "../../__assets__/certificate-logo.svg"

const Certificate = ({details}) => {

return (
  <div className={styles.certificateWrapper}>
    <div className={styles.certificateContainer}>
      <div className={styles.certificateHeader}>
        <img alt = "bitclass logo" className={styles.logo} src={BitclassLogo} />
        <img
          className={styles.achievement}
          src={CertificateOfAchievement}
          alt="stylized text"
        />
      </div>

      <div className={styles.certificateBody}>
        <h2>THIS CERTIFICATE IS PROUDLY PRESENTED TO</h2>
        <p className={styles.name}>{details?.student_name}</p>
        <hr className={styles.underline} />
        <p className={styles.content}>
          This is to certify that {details?.student_name} has successfully completed the
          course <b>{details?.course_name}</b> On
          <b> { getDateFormat(details?.end_date_ts, 'DD MMMM, YYYY') }</b>
        </p>
      </div>

      <div className={styles.certificateFooter}>
        <img
          src={CertificateLogo}
          className={styles.certificatelogo}
          alt="brand logo"
        />
        <div className={styles.signContainer}>
          {details?.signature ? 
           <img src={details?.signature} alt="teacher-signature" className={styles.signature} />
           : 
           <div>
             <p className={styles.specialSignedName}>
              {details?.teacher_name}
            </p>
           </div>
          }
          <hr className={styles.underline} />
          <p className={styles.signedName}>
            {details?.teacher_name}
          </p>
        </div>
      </div>
    </div>
  </div>
)
}

export default Certificate
