import { useEffect, useState } from "react"
import BitAntLoader from "../__components__/BitAntLoader"
import Certificate from "./Certificate"
import { getCertificateDetails } from "../__utils__/api"

const CertificateScreen = ({ ...props }) => {
  const [certiDetails, setCertiDetails] = useState(null)
  const [loading, setLoading] = useState(false)
  const [courseCode, setCoursecode] = useState(props?.match?.params?.courseCode)


  useEffect(() => {
    ;(async () => {
      if (courseCode) {
        setLoading(true)
        try {
          const { data, error } = await getCertificateDetails(courseCode)
          if (!error) {
            setCertiDetails(data)
          }
        } catch (e) {
          console.log(e, "error occured while fetching certificate details")
        } finally {
          setLoading(false)
        }
      }
    })()
  }, [])

  return (
    <div>
      {loading ? (
        <BitAntLoader />
      ) : certiDetails ? (
        <Certificate details={certiDetails} />
      ) : (
        <div>Certificate unavailable</div>
      )}
    </div>
  )
}



export default CertificateScreen