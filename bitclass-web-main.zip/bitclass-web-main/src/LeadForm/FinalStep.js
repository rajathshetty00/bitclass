import React, { useState } from 'react'
import { ErrorMessage, Formik } from 'formik'
import trackEvent from '../__utils__/analytics'
import styles from './style.module.scss'
import CountryCodes from '../__utils__/CountryCodes.json'
import Select from 'react-dropdown-select'
import OtpInput from 'react-otp-input'
import { createCourseOrder, generateOTP, login, registerStudentForCourse, getCommunityLinks } from '../__utils__/api'
import { getTeacherHandle, setRole } from '../__utils__/auth'
import clsx from 'clsx'
import CircularProgress from '../__components__/CircularProgress'
// import WhatsappIcon from '../home-old/__assets__/whatsapp.svg'
// import FacebookIcon from '../home-old/__assets__/facebook.svg'
import { freeCourseCheckout } from '../payment/workflow'
import { Link } from 'react-router-dom'
import { saveAuth } from '../actions'

const FinalStep = ({initialValues, sellerLeadId, onSubmit, validationSchema, btnText, onSuccess, history, ...props}) => {
  const [loading, setLoading]       = useState(false)
  const [otpSent, setOtpSent]       = useState(false)
  const [wrongOtp, setWrongOtp]     = useState(false)
  const [registered, setRegistered] = useState(false)
  const [otpTries, setOtpTries]     = useState(0)
  const [communityLinks, setCommunityLinks] = useState({})
  // const [webinarCode, setWebinarCode] = useState(null)
  // Testing
  // const [otpSent, setOtpSent] = useState(true)
  // const [wrongOtp, setWrongOtp] = useState(true)
  // const [otpTries, setOtpTries] = useState(2)

  // test
  // useEffect(() => {
  //   async function fetch() {
  //     const communityLinks = await getCommunityLinks()
  //     setCommunityLinks(communityLinks['data'])
  //   }

  //   fetch()
  // }, [])

  const countryToFlag = isoCode => {
    return typeof String.fromCodePoint !== 'undefined'
      ? isoCode
        .toUpperCase()
        .replace(/./g, (char) => String.fromCodePoint(char.charCodeAt(0) + 127397))
      : isoCode
  }

  const dropdownRenderer = ({ props, state, methods }) => {
    const escapeRegExp = string => {
      return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') // $& means the whole matched string
    }
    const regexp = new RegExp(escapeRegExp(state.search), "i")

    return (
      props.options
        .filter(item => regexp.test(item.dial_code) || regexp.test(item.name))
        .map((option, index) => (
          <div key={`${option.name}-${index}`} className="item" onClick={() => methods.addItem(option)}>
            <span className="icon">{countryToFlag(option.code)}</span>
            <span className="text">{option.name} ({option.dial_code})</span>
          </div>
        ))
    )
  }

  const postPayment = async (razorpay_payment_id, orderID, courseCode) => {
    const courseRegistration = await registerStudentForCourse(courseCode, orderID, razorpay_payment_id)
    if (!courseRegistration['success']) {
      setRegistered(true)
    } else {
      // handle if registration failure
      setRegistered(false)
    }

    // setTimeout(() => {
    //   console.log('redirect user to course page')
    //   window.location.reload()
    // }, 500)
  }

  const sendOtp = async (values) => {
    setLoading(true)
    try {
      const _resp = await generateOTP({phone: values.phone, countryCode: values.country_code[0].dial_code})
      setOtpSent(true)
      trackEvent("signupOTPSent", {
        page: 'EntryForm'
      })
    } catch (e) {
    } finally {
      setLoading(false)
    }
  }

  const registerUserToWebinar = async (uid, courseCode) => {
    setLoading(true)

    try {
      // pre payment
      const _orderID = await createCourseOrder(courseCode)
      const orderID = _orderID['data']

      // postpayment
      await postPayment(null, orderID, courseCode)
    } catch (e) {
    } finally {
      setLoading(false)
    }
  }

  const submitOtp = async ({phone, otp, name, email, country_code}) => {
    setLoading(true)

    try {
      const response = await login({
        phone,
        countryCode: country_code[0].dial_code,
        otp,
        username: name,
        email,
        sellerLeadId,
      })
  
      if (response['data']['success']) {
        const _token = response['data']
        localStorage.setItem('Authorization', _token.auth_token)
        localStorage.setItem('uid', _token.uid)
        localStorage.setItem('code', _token.code)
        localStorage.setItem('username', _token.username)
        localStorage.setItem('role', 'teacher')
        localStorage.setItem('phone', _token.phone)
        localStorage.setItem('teacherHandle', _token.teacherHandle)
        setRole('teacher')
        setRegistered(true)
        onSuccess(true)
        trackEvent("signupSuccess", {
          page: 'EntryForm'
        })
      } else {
        setOtpTries(otpTries + 1)
        setWrongOtp(true)
      }
      const communityLinks = await getCommunityLinks()
      setCommunityLinks(communityLinks['data'])
    } catch (e) {
    } finally {
      setLoading(false)
    }
  }

  const onChangePhoneNumber = () => {
    setOtpSent(false)
    setOtpTries(0)
    setWrongOtp(false)
  }

  const goToWebinar = () => {
    window.location.href = `https://www.bitclass.live/biztech/Cc85e41`
  }

  const goToDashboard = () => {
    trackEvent("signupToDashboard", {
      page: 'EntryForm'
    })
    const _handle = getTeacherHandle()
    //route change
    // window.location.href = `https://www.bitclass.live/${_handle}/profile`
    window.location.href = `https://www.bitclass.live/profile`
  }

  return (
    <Formik
      validateOnChange
      initialValues={initialValues}
      onSubmit={sendOtp}
      validationSchema={validationSchema}
    >
      {({values, goBack, handleSubmit, handleChange, setFieldValue, ...props}) => {
        return (
          <form onSubmit={handleSubmit} className={styles.finalFormWrapper}>
            {loading ? (
              <CircularProgress />
            ) : (
              !registered ? (
                otpSent ? (
                  <>
                    <div className={styles.inputBlock}>
                      <p className={styles.displayPhoneNo}>{values.phone}</p>
                      <p className={styles.displayPhoneNo}>
                        <span
                          className={styles.editPhoneNo}
                          onClick={e => {
                            onChangePhoneNumber(e)
                            setFieldValue('otp', '')
                        }}>(change phone number)</span>
                      </p>
                    </div>
                    <div className={clsx(styles.inputBlock, styles.otpWrapper)}>
                      <p className={styles.label}>OTP</p>
                      <OtpInput
                        onChange={val => {
                          setWrongOtp(false)
                          setFieldValue('otp', val)
                        }}
                        name="otp"
                        numInputs={4}
                        inputStyle={styles.otpInputStyle}
                        containerStyle={styles.otpInput}
                        value={values.otp}
                      />
                      <div className={styles.otpInfoBlock}>
                        <p className={styles.otpRetries}>({3 - otpTries} attempts left)</p>
                        {otpTries < 3 && <p className={styles.resendOtpLink} onClick={e => sendOtp(values)}>Resend OTP</p>}
                      </div>
                      {wrongOtp && <p className={styles.errorInfo}>Wrong OTP</p>}
                    </div>
                    <button className={styles.button} type="button" onClick={e => submitOtp(values)} disabled={otpTries >= 3}>Submit OTP</button>
                  </>
                ) : (
                  <>
                    <div className={styles.inputBlock}>
                      <p className={styles.label}>Name</p>
                      <input
                        className={styles.input}
                        type="text"
                        name="name"
                        placeholder="Enter Your Name"
                        value={values.name}
                        onChange={handleChange}
                      />
                      <ErrorMessage name="name" />
                    </div>
    
                    <div className={styles.inputBlock}>
                      <p className={styles.label}>Email</p>
                      <input
                        className={styles.input}
                        type="email"
                        name="email"
                        placeholder="Enter Your email"
                        value={values.email}
                        onChange={e=>setFieldValue('email',e.target.value.toLowerCase())}
                      />
                      <ErrorMessage name="email" />
                    </div>

                    <div className={styles.inputBlockGroup}>
                      <div className={clsx(styles.inputBlock, styles.inputBlockCountryCode)}>
                        <p className={styles.label}>Country Code</p>
                        <div style={{display: 'block'}}>
                          <Select
                            className={styles.countryCodeInputBlock}
                            clearOnBlur={true}
                            options={CountryCodes}
                            values={values.country_code}
                            onChange={(value) => {
                              setFieldValue('country_code', value)
                            }}
                            placeholder="Country Code"
                            labelField="dial_code"
                            valueField="dial_code"
                            portal={document.body}
                            dropdownRenderer={dropdownRenderer}
                            searchable={false}
                          />
                        </div>
                        <ErrorMessage name="country_code" />
                      </div>
      
                      <div className={styles.inputBlock}>
                        <p className={styles.label}>Phone</p>
                        <input type="tel"
                          name="phone"
                          className={clsx(styles.input, styles.inputFieldText)}
                          placeholder="Phone number"
                          value={values.phone}
                          onChange={handleChange}
                          style={{ fontFamily: 'poppins' }}
                        />
                        <ErrorMessage name="phone" />
                      </div>
                    </div>
                    <button className={styles.button} type="submit">{btnText}</button>
                  </>
                )
              ) : (
                <div className={styles.successMessageWrapper}>
                  <p className={styles.successMsg}>You are now a teacher on BitClass!</p>
                  {Object.keys(communityLinks).length > 0 && (
                    <>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 28 }}>
                        <div className={styles.checkAccountText}>Check out your dashboard</div>
                        <div>
                          <button className={styles.button} type="button" onClick={goToDashboard} style={{
                            height: 44,
                            maxWidth: 180,
                            fontSize: 22,
                            background: 'white',
                            color: '#2aa39a',
                            fontWeight: 400,
                            textTransform: 'lowercase',
                          }}> <strong> here </strong></button>
                        </div>
                      </div>
                      <div className={styles.communityText}>
                        <div className={styles.joinCommunityText}>
                          And join the BitClass community
                        </div>
                        <div className={styles.communityBlock}>
                        {Object.keys(communityLinks).map(community => {
                          return (
                            <div className={styles.socialBlock}>
                                <a href={communityLinks[community]} target="_blank" rel="noopener noreferrer" alt={`Bitclass ${community} Community`}>
                                </a>
                            </div>
                          )
                        })}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )
            )}
          </form>
        )
      }}
    </Formik>
  )
}

// const mapStateToProps = ({ authReducer }) => {
//   return authReducer
// }
// const mapDispatchToProps = dispatch => ({
//   saveAuthToken: token => dispatch(saveAuth(token)),
// })

// const FinalStep = connect(mapStateToProps, mapDispatchToProps)(_FinalStep)
export default FinalStep