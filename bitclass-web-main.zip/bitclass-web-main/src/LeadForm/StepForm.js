import React from 'react'
import { ErrorMessage, Formik } from 'formik'
import { getStep2Questions, getStep3Questions, STEPS } from './utils'
import styles from './style.module.scss'
import GreenCheckbox from '../__components__/GreenCheckbox'
import GreenRadio from '../__components__/GreenRadio'
import clsx from 'clsx'

const StepForm = ({initialValues, btnText, currentStep, onSubmit, goBack, validationSchema, ...props}) => {
  return (
    <Formik
      validateOnChange
      initialValues={initialValues}
      onSubmit={onSubmit}
      validationSchema={validationSchema}
    >
      {({values, handleSubmit, handleChange, setFieldValue, submitCount, isValid, ...props}) => {
        return (
          <form onSubmit={handleSubmit} className={styles.modalContent}>
            {Object.keys(initialValues).map(step => {
              const obj = initialValues[step]
              return (
                !obj.hidden ? (
                  <div key={step} className={styles.questionBlock}>
                    {<p className={styles.question}>{obj.question}</p>}
                    <div className={styles.options}>
                      {obj.type === 'text' && (
                        <input
                          className={styles.input}
                          name={step}
                          type="text"
                          value={obj.answer}
                          onChange={e => {
                            obj.answer = e.target.value
                            setFieldValue(step, obj)
                          }}
                          placeholder={obj.placeholder}
                        />
                      )}

                      {obj.type === 'checkbox' && (
                        obj.options.map(option => {
                          return (
                            <GreenCheckbox
                              key={option}
                              className={styles.singleOption}
                              checked={obj.answers.includes(option)}
                              onChange={e => {
                                const idx = obj.answers.findIndex(ans => ans === e.target.value)
                                if (idx > -1) {
                                  obj.answers.splice(idx, 1)
                                } else {
                                  obj.answers.push(e.target.value)
                                }

                                obj.answer = obj.answers.join(',')
                                setFieldValue(step, obj)
                              }}
                              id={option}
                              name={step}
                              label={option}
                              value={option}
                            />
                          )
                        })
                      )}
                      {obj.type === 'radio' && (
                        obj.options.map(option => {
                          return (
                            <GreenRadio
                              key={option}
                              checked={option === obj.answer}
                              className={styles.singleOption}
                              onChange={e => {
                                obj.answer = e.target.value
                                if (currentStep === STEPS.STEP_1) {
                                  values[STEPS.STEP_2] = getStep2Questions()
                                  values[STEPS.STEP_3] = getStep3Questions()
                                }

                                obj.resetHidden && obj.resetHidden.forEach(hid => {
                                  initialValues[hid].hidden = true
                                  initialValues[hid].answer = ''
                                })

                                if (obj.showWhen && obj.showWhen[obj.answer]) {
                                  initialValues[obj.showWhen[obj.answer]].hidden = false
                                }

                                setFieldValue(step, obj)
                              }}
                              name={step}
                              id={step+option}
                              label={option}
                              value={option}
                            />
                          )
                        })
                      )}
                      <ErrorMessage name={step} />
                    </div>
                  </div>
                ) : null
              )
            })}

            {!isValid && submitCount > 0 && <div className={styles.errorInfo}>Please check if all the details are filled</div>}

            <div className={styles.btnBlock}>
              {goBack && (<button className={clsx(styles.button, styles.secondaryBtn)} type="button" onClick={goBack}>Back</button>)}
              <button className={styles.button} type="submit">Next</button>
            </div>
          </form>
        )
      }}
    </Formik>
  )
}

export default StepForm
