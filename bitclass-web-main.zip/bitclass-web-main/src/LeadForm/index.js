import React, { useState } from 'react'
import trackEvent from '../__utils__/analytics'
import styles from './style.module.scss'
import { STEPS, leadQuestionsForm, getLeadsJson} from './utils'
import StepForm from './StepForm'
import FinalStep from './FinalStep'
import { leadFormSchema, leadFormStep1Schema, leadFormStep2Schema, leadFormStep3Schema } from '../course/__components__/validations'
import { createSellerLead, updateSellerLead } from '../__utils__/api'
import CircularProgress from '../__components__/CircularProgress'
import CountryCodes from '../__utils__/CountryCodes.json'

const LeadForm = ({history, title, ...props}) => {
  const defaultCountryCode = CountryCodes.find(e => e.dial_code === "+91")

  const [activeStep, setActiveStep] = useState(STEPS.STEP_1)
  const [isLoading, setIsLoading] = useState(false)
  const [sellerLeadId, setSellerLeadId] = useState(null)
  const [hasRegistered, setHasRegistered] = useState(false)
  
  const createLead = async () => {
    setIsLoading(true)
    const json = getLeadsJson(leadQuestionsForm)
    try {
      const _resp = await createSellerLead(json)
      setSellerLeadId(_resp.data.seller_lead_id)
    } catch (e) {
    } finally {
      setIsLoading(false)
    }
  }

  const updateLead = async () => {
    setIsLoading(true)
    const json = getLeadsJson(leadQuestionsForm)
    try {
      const _resp = await updateSellerLead(sellerLeadId, json)
    } catch (e) {
    } finally {
      setIsLoading(false)
    }
  }

  const registerSeller = async () => {
    const json = getLeadsJson(leadQuestionsForm)
  }

  const onStep1Done = values => {
    // const isCurrentlyTeaching = values.CURRENTLY_SELLING_ONLINE.answer === 'Yes'
    trackEvent("leadStep1Done", {
      page: 'EntryForm'
    })
    setActiveStep(STEPS.STEP_4)

    if (sellerLeadId) {
      updateLead()
    } else {
      createLead()
    }
  }

  const onStep2Done = values => {
    trackEvent("leadStep1Done", {
      page: 'EntryForm'
    })
    setActiveStep(STEPS.STEP_4)
    updateLead()
  }

  const onStep2Back = values => {
    setActiveStep(STEPS.STEP_1)
  }

  const onStep3Done = values => {
    setActiveStep(STEPS.STEP_4)
    updateLead()
  }

  const onStep3Back = values => {
    setActiveStep(STEPS.STEP_1)
  }
  
  const onFinishLeadCapture = values => {
  }

  const finalFormValues = {
    name: '',
    email: '',
    phone: '',
    country_code: [defaultCountryCode],
    otp: ''
  }

  return (
    <div className={styles.leadsFormWrapper}>
      {<p className={styles.title} style={{ textAlign: hasRegistered ? 'center' : 'left' }}>{hasRegistered ? "Congratulations 🎉" : "Let's create your account"}</p>}
      {isLoading ? (
        <CircularProgress />
      ) : (
        <>
          {(activeStep === STEPS.STEP_1) && (
            <StepForm
              currentStep={STEPS.STEP_1}
              initialValues={leadQuestionsForm[STEPS.STEP_1]}
              validationSchema={leadFormStep1Schema}
              onSubmit={onStep1Done}
              />
              )}
          {(activeStep === STEPS.STEP_2) && (
            <StepForm
              currentStep={STEPS.STEP_2}
              initialValues={leadQuestionsForm[STEPS.STEP_2]}
              goBack={onStep2Back}
              validationSchema={leadFormStep2Schema}
              onSubmit={onStep2Done}
              />
              )}
          {(activeStep === STEPS.STEP_3) && (
            <StepForm
              currentStep={STEPS.STEP_3}
              initialValues={leadQuestionsForm[STEPS.STEP_3]}
              goBack={onStep3Back}
              validationSchema={leadFormStep3Schema}
              onSubmit={onStep3Done}
            />
          )}
          {(activeStep === STEPS.STEP_4) && (
            <FinalStep
              history={history}
              sellerLeadId={sellerLeadId}
              btnText="Submit"
              initialValues={finalFormValues}
              validationSchema={leadFormSchema}
              onSubmit={onFinishLeadCapture}
              onSuccess={setHasRegistered}
            />
          )}
        </>
      )}
    </div>
  )
}

export default LeadForm
