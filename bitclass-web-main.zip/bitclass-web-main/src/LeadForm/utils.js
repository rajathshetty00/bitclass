export const STEPS = {
  STEP_1: 'STEP_1',
  STEP_2: 'STEP_2',
  STEP_3: 'STEP_3',
  STEP_4: 'STEP_4',
}

export const getLeadsJson = leadsForm => {
  const jsonResult = {}

  Object.keys(leadsForm).forEach(step => {
    const formStep = leadsForm[step]

    Object.keys(formStep).forEach(elem => {
      const elm = formStep[elem]
      jsonResult[elm.question] = elm.answer
    })
  })

  return jsonResult
}

export const getStep2Questions = e => {
  return ({
    'CURRENTLY_LOOKING_FOR': {
      question: 'What are you currently looking for?',
      type: 'checkbox',
      options: [
        'An all-in-one platform to manage and grow my online teaching business',
        'Help with Ads & getting the best ROI for my marketing budget',
        'Additional capital to scale my business'
      ],
      answer: '',
      answers: []
    },
  })
}

export const getStep1Questions = e => {
  return ({
    'WHAT_TEACH': { 
      question: 'What do you teach ?',
      type: 'text',
      options: [],
      answer: '',
      placeholder: '',
    },
    'CURRENTLY_SELLING_ONLINE': {
      question: 'Are you currently teaching & selling online courses?',
      type: 'radio',
      options: [
        'Yes',
        'No'
      ],
      answer: '',
    }
  })
}

export const getStep3Questions = e => {
  return ({
    'HAVE_FOLLOWERS': {
      question: 'Do you have followers/subscribers or an engaged social community?',
      type: 'radio',
      options: [
        'Yes',
        'No'
      ],
      showWhen: {
        'Yes': 'HOW_MANY_FOLLOWERS'
      },
      resetHidden: ['HOW_MANY_FOLLOWERS'],
      answer: '',
    },
    'HOW_MANY_FOLLOWERS': {
      question: 'How many followers/subscribers do you have in your community?',
      type: 'text',
      options: [],
      answer: '',
      hidden: true,
    },
    'TELL_DETAILS': {
      question: 'Tell us in detail about what you want to start teaching:',
      type: 'text',
      options: [],
      answer: '',
    }
  })
}

export const leadQuestionsForm = {
  [STEPS.STEP_1]: getStep1Questions(),
  [STEPS.STEP_2]: getStep2Questions(),
  [STEPS.STEP_3]: getStep3Questions(),
}
