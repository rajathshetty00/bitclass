import React from 'react'
import { Carousel } from 'antd'
import clsx from 'clsx'

import styles from './style.module.scss'

const AntCarousal = ({
  customClass,
  ...props
}) => {
  return(
    <Carousel
      swipeToSlide={true}
      dots={true}
      swipe={true}
      draggable={true}
      className={clsx(styles.carousalMainDiv, customClass)}
      {...props}
    >
      { props.children }
    </Carousel>
  )
}

export default AntCarousal
