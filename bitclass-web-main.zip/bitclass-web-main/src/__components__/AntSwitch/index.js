import React from 'react'
import styles from './style.module.scss'

const AntSwitch = ({ checked, onChange, id, checkedColor = '#2AA39E' }) => {
  return (
    <>
      <input
        checked={checked}
        onChange={onChange}
        className={styles.antSwitchCheckbox}
        id={id}
        type="checkbox"
      />
      <label
        style={{ background: checked && checkedColor }}
        className={styles.antSwitchLabel}
        htmlFor={id}
      >
        <span className={styles.antSwitchButton} />
      </label>
    </>
  )
}

export default AntSwitch
