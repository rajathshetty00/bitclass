import React from 'react'
import Logo from '../../__assets__/BitClassLogos/LogoForWhiteBg.svg'
import styles from './style.module.scss'
import IosBannerSvg from '../../__assets__/iosDownloadBanner.svg'
import AndroidBannerSvg from "../../__assets__/googleplay-1.svg"

import clsx from 'clsx'
import { getAppDownloadLink } from '../../__utils__'
import { getRole } from '../../__utils__/auth'

export const AndroidBanner = ({
  role = 'student',
  logo = true,
  message = `For an amazing classroom experience on mobile, please download our app`,
  className = '',
  trackEvnt = () => {},
  ...props
}) => {
  return (
    <div className={clsx(styles.bannerWrapper, className)}>
      {logo && <img className={styles.logo} src={Logo} alt="BitClass" />}
      <div className={styles.bannerContent}>
        <p
          className={styles.info}
          dangerouslySetInnerHTML={{ __html: message }}
        ></p>
        <a
          onClick={trackEvnt}
          className={styles.banner}
          href={getAppDownloadLink({
            type: "android",
            isMobile: true,
            source: "classroom",
            comp: getRole() === "teacher" ? "teacher" : "student",
          })}
        >
          <img alt="Get it on Google Play" src={AndroidBannerSvg} />
        </a>
      </div>
    </div>
  )
}

export const IosBanner = ({
  role = 'student',
  logo = true,
  message = `For an amazing classroom experience on mobile, please download our app`,
  trackEvnt = () => {},
  className = '',
  ...props
}) => {
  return (
    <div className={clsx(styles.bannerWrapper, className)}>
      {logo && <img className={styles.logo} src={Logo} alt="BitClass" />}

      <div className={styles.bannerContent}>
        <p
          className={styles.info}
          dangerouslySetInnerHTML={{ __html: message }}
        ></p>
        <a
          onClick={trackEvnt}
          className={styles.banner}
          href={getAppDownloadLink({
            type: "ios",
            isMobile: true,
            source: "classroom",
            comp: getRole() === 'teacher' ? 'teacher' : 'student',
          })}
        >
          <img src={IosBannerSvg} alt="Get it on App Store" />
        </a>
      </div>
    </div>
  )
}
