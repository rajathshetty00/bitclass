import React, { useState } from "react"
import { Popover } from "react-tiny-popover"
import {
  getRole,
  getDefaultRouteForLoggedIn,
  getUserInfo,
} from "../../__utils__/auth"
import { connect } from "react-redux"
import { wipeAuth } from "../../actions"
import styles from "./style.module.scss"
import { setRole } from "../../__utils__/auth"
import { analyticsLogout } from "../../__utils__/analytics"
import trackEvent from "../../__utils__/analytics"
import clsx from "clsx"
import { ChevronDown } from "react-feather"
import { isMobile, isTablet } from "react-device-detect"
import BigLogoForDark from "../../__assets__/BitClassLogos/LogoForDarkBG.svg"
import BigLogoForWhite from "../../__assets__/BitClassLogos/LogoForWhiteBg.svg"
import SmallLogoForDark from "../../__assets__/BitClassLogos/LogoSmallForDarkBG.svg"
import SmallLogoForWhite from "../../__assets__/BitClassLogos/LogoSmallForWhiteBG.svg"
import { WithAuthLogin as Login } from "../../auth"
import { BASE_URL } from "../../constants"
import { deleteAuthToken, deleteCookie, getHrefLink } from "../../__utils__/index"
import LoggedInAvatar from "../../profile/__components__/LoggedInAvatar"
import { useLocation } from "react-router"

const _BaseHeader = ({
  props,
  clearAuth,
  opened,
  headerStyles,
  opts,
  showRole = false,
  page = "",
  className = "",
  darkMode = false,
}) => {
  const [isMenuOpened, setIsMenuOpened] = useState(false)

  const _urlParams = new URLSearchParams(props.history.location.search)

  const userInfo = getUserInfo()
  const {search} = useLocation()

  const handleLogoClick = async () => {
    trackEvent("head_logo_clicked", {
      payload:`${BASE_URL}${props.history.location.pathname}`,
    })
    window.location.href = getHrefLink(`${BASE_URL}`,search)
  }

  return (
    <div
      className={clsx(styles.menuWrapper, className, darkMode && styles.dark)}
    >
      <div className={styles.menuLeft}>
        <div className={styles.bitclassLogo}>
          <img
            onClick={handleLogoClick}
            src={
              isMobile || isTablet
                ? darkMode
                  ? SmallLogoForDark
                  : SmallLogoForWhite
                : darkMode
                ? BigLogoForDark
                : BigLogoForWhite
            }
            alt="Bitclass Logo"
            style={
              isMobile || isTablet
                ? { width: 30 }
                : { width: 132, paddingLeft: "8px" }
            }
          />
        </div>
        {props.showRole && (
          <div className={styles.roleContainer}>
            <div className={styles.roleBlock}>
              <div
                className={clsx(
                  styles.role,
                  getRole() === "teacher" && styles.active
                )}
                onClick={async () => {
                  trackEvent("Profile_Switch_Click_Switch", {
                    page: "Profile_Switch",
                    action: "Click",
                    prev_profile: "student",
                    new_profile: "teacher",
                  })
                  setRole("teacher")
                  let _r = await getDefaultRouteForLoggedIn()
                  if (props.history.location.pathname !== _r)
                    if (_r === "/") window.location.href = getHrefLink("/",search)
                    else props.history.push(_r)
                }}
              >
                Courses I am teaching
              </div>
              <div
                className={clsx(
                  styles.role,
                  getRole() === "student" && styles.active
                )}
                onClick={() => {
                  trackEvent("Profile_Switch_Click_Switch", {
                    page: "Profile_Switch",
                    action: "Click",
                    prev_profile: "teacher",
                    new_profile: "student",
                  })
                  setRole("student")
                  props.history.push(getHrefLink(`/profile`,search))
                }}
              >
                Courses I am attending
              </div>
            </div>
          </div>
        )}
      </div>
      {!(_urlParams.get("is_apps")?.toLowerCase() === "yes") && (
        <div className={styles.menuRight}>
          {userInfo ? (
            <>
              <Popover
                isOpen={isMenuOpened}
                onClickOutside={(e) => setIsMenuOpened(false)}
                positions={["bottom"]}
                content={() => {
                  return (
                    <div className={styles.siteMenuDropdownContent}>
                      {page !== "teacher-apply" && (
                        <p
                          onClick={(e) => {
                            setIsMenuOpened(false)
                            window.location.href = getHrefLink(`${BASE_URL}/profile`,search)
                          }}
                        >
                          My Classes
                        </p>
                      )}

                      {page === "teacher-apply" && (
                        <p
                          onClick={(e) => {
                            setIsMenuOpened(false)
                            setTimeout(() => {
                              if (getRole() === "teacher") {
                                setRole("student")
                              } else {
                                setRole("teacher")
                              }
                              window.location.href = getHrefLink(`${BASE_URL}/profile`,search)
                            }, 300)
                          }}
                        >
                          Switch to{" "}
                          {getRole() === "teacher" ? `Student` : `Teacher`}
                        </p>
                      )}

                      <p
                        onClick={(e) => {
                          setIsMenuOpened(false)
                          analyticsLogout()
                          localStorage.clear()
                          deleteCookie("auth-key")
                          deleteAuthToken()
                          window.location.reload()
                        }}
                      >
                        Logout
                      </p>
                    </div>
                  )
                }}
              >
                <p
                  onClick={(e) => setIsMenuOpened(true)}
                  style={{ cursor: "pointer" }}
                >
                  <LoggedInAvatar userInfo={userInfo} />
                  <ChevronDown color="#3C3C3C" size="16" />
                </p>
              </Popover>
            </>
          ) : (
            <div style={{ display: "flex", alignItems: "center" }}>
              {page === "home" && (
                <div
                  onClick={(e) => {
                    window.location.href = getHrefLink(`${BASE_URL}/`,search)
                    trackEvent("homepage_liveCourses_search_button_clicked", {})
                  }}
                  className={styles.headerDiscoveryBtn}
                >
                  <div class={styles.new}>NEW</div>
                  <div>Discover Courses</div>
                </div>
              )}

              <div
                onClick={(e) => {
                  if (page === "home") {
                    trackEvent("SplashScreen_Click_Login", {
                      page: "SplashScreen",
                      action: "Click",
                    })
                  }
                  trackEvent("login_click_Login", {
                    page: "Login",
                    action: "Click",
                  })
                  window.location.href =getHrefLink("/live-classes/signin",search) 
                }}
                className={styles.headerLoginButton}
              >
                {" "}
                Login
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

const mapDispatchToProps = (dispatch) => ({
  clearAuth: () => dispatch(wipeAuth()),
})
const AppHeader = connect(null, mapDispatchToProps)(_BaseHeader)
export default AppHeader
