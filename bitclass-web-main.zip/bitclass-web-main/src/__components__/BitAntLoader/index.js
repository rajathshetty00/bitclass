import React from 'react'
import { Spin } from 'antd'
import { LoadingOutlined } from '@ant-design/icons'

import styles from './style.module.scss'

const BitAntLoader = ({style, ...props}) => {

  const antIcon = <LoadingOutlined style={{ fontSize: 24, ...style}} spin />

  return (
    <div className={styles.bitAntLoader}>
      <Spin indicator={antIcon} />
    </div>
  )
}

export default BitAntLoader
