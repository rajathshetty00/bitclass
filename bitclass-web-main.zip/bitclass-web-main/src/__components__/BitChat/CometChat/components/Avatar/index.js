import React from "react";

/** @jsxRuntime classic */
/** @jsx jsx */
import { jsx } from '@emotion/core';
import {
  imgStyle
} from "./style";

import srcIcon from "./resources/1px.png";
import { exists } from '../../../../../__utils__/index'

class Avatar extends React.Component {

  constructor(props) {
    
    super(props);
    this.imgRef = React.createRef();
  }

  render() {

    const borderWidth = this.props.borderWidth || '1px';
    const borderColor = this.props.borderColor || '#AAA';
    const cornerRadius = this.props.cornerRadius || '50%';
    let image = this.props.image;

    let img = new Image();
    img.src = image;
    img.onload = () => {

      if (this.imgRef) {
        //covert base64 to svg and add style
        // 1. split and remove file type from base64
        let imageSplit = image.split(',')
        let cleanedBase64 = imageSplit[1]
        if(exists(cleanedBase64)) {
          // 2. covert base64 to html string
          cleanedBase64 = window.atob(cleanedBase64)
          let div = document.createElement('div')
          if(div) {
            div.innerHTML = cleanedBase64.trim()
            if(div.firstElementChild) {
              div.firstElementChild.firstElementChild.setAttribute('fill', 'orange')
              image = imageSplit[0] + ',' + window.btoa(div.firstElementChild.outerHTML)
              div.remove()
            }
          }
        }
        this.imgRef.src = image;
      }
    }

    const getStyle = () => ({ borderWidth: borderWidth, borderStyle: 'solid', borderColor: borderColor, 'borderRadius': cornerRadius });

    return (
      <img src={srcIcon} data-src={image} css={imgStyle()} alt="Avatar" style={getStyle()} ref={el => { this.imgRef = el;}} />
      // <div className={styles.profilePic}>
      //   {!profile.image && <span>{profile.username[0]}</span>}
      // </div>
    )
  }
}

export default Avatar;