export const callMessageStyle = () => {

    return {
        padding: "8px 12px",
        marginBottom: "16px",
        textAlign: "center",
    }
}

export const callMessageTxtStyle = () => {

    return {
        fontSize: "13px",
        fontWeight: "500",
        margin: "0",
    }
}