export const msgTimestampStyle = () => {

    return {
        display: "inline-block",
        fontSize: "11px",
        fontWeight: "500",
        lineHeight: "12px",
        textTransform: "uppercase",
        ' > img': {
            marginLeft: "3px",
            display: "inline-block",
            verticalAlign: "bottom",
        }
    }
}