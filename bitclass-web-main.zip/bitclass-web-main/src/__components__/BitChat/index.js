import React, { useEffect, useState } from 'react'
import clsx from 'clsx'
import {
  CHAT_APP_ID, CHAT_APP_REGION,
} from '../../constants'
import { getStudentChatAuthToken, getTeacherChatAuthToken } from '../../__utils__/auth'
import CircularProgress from '../CircularProgress'
import styles from './style.module.scss'
import { CometChat } from '@cometchat-pro/chat'
import { BitChatConversationListScreen, BitChatMessageListScreen, BitCometChatUI, CometChatUnified } from './CometChat'
import BitChatGroupListScreen from './CometChat/components/BitChatGroupListScreen'

const BitChat = ({
  role = 'student',
  type,
  defaultView,
  viewDetails = true,
  showDownloadBanner = false,
  className='',
  backButton=false,
  ...props
}) => {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cometChatSettings = new CometChat.AppSettingsBuilder().subscribePresenceForAllUsers().setRegion(CHAT_APP_REGION).build()
    CometChat.init(CHAT_APP_ID, cometChatSettings)
    .then(
      () => {
        //You can now call login function.
        CometChat.login({
          authToken: role === 'teacher' ? getTeacherChatAuthToken() : getStudentChatAuthToken()
        }).then(response => {
          setLoading(false)
        })
       },
       error => {
        console.log("Initialization failed with error:", error)
        //Check the reason for error and take appropriate action.
      }
    )

    return () => {
    }
  }, [])

  return (
    <div className={clsx(styles.mainDivWrapper, className)}>
      {loading ? <CircularProgress /> : (
        <>
          {type === 'FRIENDS_CONVERSATION_LIST' && (
            <BitChatConversationListScreen backButton={backButton} />
          )}
          {type === 'SINGLE_CONVERSATION' && (
            <BitChatMessageListScreen
              viewDetails={viewDetails}
              defaultView={defaultView}
              showDownloadBanner={showDownloadBanner}
              joinedMessageTemplate={props.joinedMessageTemplate && props.joinedMessageTemplate}
              viewMembersTitle={props.viewMembersTitle || 'Group Members'}
            />
          )}
          {type === 'TEACHERS_CONVERSATION_LIST' && (
            <BitChatGroupListScreen
            removeGroupsTitle={props.removeGroupsTitle}
            joinedMessageTemplate={props.joinedMessageTemplate && props.joinedMessageTemplate}
            searchKey={'-community'} />
          )}
          {type==='CONVERSATION_LIST'&&(
            <BitCometChatUI
            removeGroupsTitle={props.removeGroupsTitle}
            joinedMessageTemplate={props.joinedMessageTemplate && props.joinedMessageTemplate}
            searchKey={'-community'}
            />
          )}
        </>
      )}
    </div>
  )
}

export default BitChat
