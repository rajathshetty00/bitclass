import React from 'react'
import Loader from './book.svg'
import styles from './style.module.scss'
import clsx from 'clsx'

const BitLoader = () => {
  return (
    <div className={styles.bitLoaderContainer}>
      <div className={styles.bitLoaderContent}>
        <img src={Loader} alt="Loading..." />
        <div className={styles.progressBar}>
          <div className={styles.slider}>
            <div className={styles.line}></div>
            <div className={clsx(styles.subline, styles.inc)}></div>
            <div className={clsx(styles.subline, styles.dec)}></div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BitLoader
