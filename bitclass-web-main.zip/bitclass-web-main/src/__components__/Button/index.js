import React from 'react'
import clsx from 'clsx'
import { Button } from 'antd'
import styles from './style.module.scss'
import { exists } from '../../__utils__'

export const DefaultButton = ({
  text,
  onClick,
  disabled,
  type,
  className,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.defaultButton, className)}
      {...props}
    >
      {text}
    </button>
  )
}

export const PrimaryButton = ({
  text,
  onClick,
  disabled,
  type,
  className,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.primaryButton, className)}
      {...props}
    >
      {text}
    </button>
  )
}

export const PrimaryButtonOutline = ({
  text,
  onClick,
  disabled,
  type,
  className,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.primaryButtonOutline, className)}
      {...props}
    >
      {text}
    </button>
  )
}

export const PrimaryButtonOutlineIcon = ({
  text,
  onClick,
  disabled,
  type,
  className,
  prefixIcon,
  postfixIcon,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.primaryButtonOutline, className)}
      {...props}
    >
      {prefixIcon}
      {text}
      {postfixIcon}
    </button>
  )
}

export const PrimaryIconButtonInverted = ({
  text,
  onClick,
  disabled,
  type,
  className,
  prefixIcon,
  postfixIcon,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.primaryButtonInverted, className)}
      {...props}
    >
      {prefixIcon}
      {text}
      {postfixIcon}
    </button>
  )
}

export const IconButtonTransparent = ({
  text,
  onClick,
  disabled,
  type,
  className,
  prefixIcon,
  postfixIcon,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.iconButtonTransparent, className)}
      {...props}
    >
      {prefixIcon}
      {text}
      {postfixIcon}
    </button>
  )
}

export const PrimaryIconButton = ({
  text,
  onClick,
  disabled,
  type,
  className,
  prefixIcon,
  postfixIcon,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.primaryIconButton, className)}
      {...props}
    >
      {prefixIcon}
      {text}
      {postfixIcon}
    </button>
  )
}

export const PrimaryCompletedIconButton = ({
  text,
  onClick,
  disabled,
  type,
  className,
  prefixIcon,
  postfixIcon,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      type={type || 'button'}
      className={clsx(styles.primaryCompletedIconButton, className)}
      {...props}
    >
      {prefixIcon}
      {text}
      {postfixIcon}
    </button>
  )
}

export const AntPrimaryButton = ({
  customRef,
  text,
  customClass = '',
  prefixIcon = '',
  ...props
}) => (
  <Button
    {...props}
    ref={customRef}
    className={clsx(styles.antPrimaryButton, customClass)}
    type="primary"
  >
    {exists(prefixIcon) && prefixIcon}
    {text}
  </Button>
)

export const AntSecondaryButton = ({
  customRef,
  text,
  customClass = '',
  prefixIcon = '',
  ...props
}) => (
  <Button
    {...props}
    ref={customRef}
    className={clsx(styles.antSecondaryButton, customClass)}
  >
    {exists(prefixIcon) && prefixIcon}
    {text}
  </Button>
)
