import React from 'react'
import styles from './style.module.scss'

const CircularProgress = () => {
  return (
    <div className={styles.circularProgressBarWrapper}></div>
  )
}

export default CircularProgress
