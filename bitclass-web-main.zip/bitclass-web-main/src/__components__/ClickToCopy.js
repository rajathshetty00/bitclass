import React from 'react'
import { Copy } from 'react-feather'
import Tooltip from './Tooltip'
import IconButton from './IconButton'

export default function ClickToCopy({ text, iconColor, iconSize }) {
  return (
    <Tooltip title="Copy" placement="top">
      <IconButton
        aria-label="copy" 
        onClick={() =>  navigator.clipboard.writeText(text)}
        style={{ padding: 0 }}
      >
        <Copy color={iconColor || '#333'} size={iconSize || 20} />
      </IconButton>
    </Tooltip>
  )
}
