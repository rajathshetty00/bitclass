import React, { useState } from 'react'
import { TwitterPicker } from 'react-color'

const styles = {
  swatch: {
    padding: '5px',
    background: '#fff',
    borderRadius: '1px',
    boxShadow: '0 0 0 1px rgba(0,0,0,.1)',
    display: 'inline-block',
    cursor: 'pointer',
  },
  colorPickerContainer: {
    position: 'relative',
    zIndex: 10,
    margin: '0px auto',
  },
  color: (r, g, b) =>  ({
    width: '16px',
    height: '16px',
    borderRadius: '2px',
    background: `rgba(${r}, ${g}, ${b}, ${1})`,
  })
}

const ColorPicker = ({ selectedColor, onChange }) => {
  const [open, setOpen] = useState(false)
  const { r, g, b } = selectedColor

  return (
    <div style={styles.colorPickerContainer}>
      <div style={styles.swatch} onClick={() => setOpen(!open)}>
        <div style={styles.color(r, g, b)} />
      </div>
      { open && (
        <div>
          <div onClick={() => setOpen(false)}/>
          <TwitterPicker
            color={selectedColor}
            onChangeComplete={color => { 
              onChange(color)
              setOpen(false)
            }} />
        </div>)
      }

    </div>
  )
}

export default ColorPicker
