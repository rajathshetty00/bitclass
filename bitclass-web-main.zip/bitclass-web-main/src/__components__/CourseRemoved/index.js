import React from 'react'
import clsx from 'clsx'

import styles from './style.module.scss'
import { ReactComponent as CourseRemovedSvg } from '../../__assets__/courseRemoved.svg'

const CourseRemoved = ({
  className,
}) => {
  return (
    <div className={clsx(styles.courseRemoved, className)}>
      <div className={styles.crMidSec}>
        <CourseRemovedSvg />
        <div className={styles.descriptionAndCta}>
          <h2>Course Not Found!</h2>
          <div>Hey, seems like this course is not available anymore or course not found.</div>
        </div>
      </div>
    </div>
  )
}

export default CourseRemoved
