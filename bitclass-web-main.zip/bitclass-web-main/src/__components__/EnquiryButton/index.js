import React, { useState, useEffect } from 'react'
import clsx from 'clsx'
import BitChat from '../BitChat'
import { hasAuthToken, getCode } from '../../__utils__/auth'
import { exists } from '../../__utils__'
import { WithAuthLogin as Login } from "../../auth"
import { MessageCircle, X } from "react-feather"
import CircularProgress from "../CircularProgress"
import { connectStudentToTeacher } from "../../__utils__/api"
import styles from "./styles.module.scss"

const EnquiryButton = ({ profile, location, history }) => {
	const isLoggedIn = Boolean(hasAuthToken())
	const isSelf = profile.code === getCode()
	const [isChatOpen, setIsChatOpen] = useState(true)
	const [openLoginModal, setOpenLoginModal] = useState(false)
	const [isStudentConnected, setIsStudentConnected] = useState(false)
	useEffect(() => {
    const _queryParams = location.search
    const queryParams = _queryParams && _queryParams.split('?')[1]
    const queryObj = {
    }

    if (queryParams) {
      const _params = queryParams.split('&')

      if (_params.length > 0) {
        _params.forEach(_param => {
          const param = _param.split('=')
          queryObj[param[0]] = param[1]
        })
      }
    }

    const connectStudent = async () => {
      try {
        const _res = await connectStudentToTeacher(profile.profile_id)
        if (_res?.success) {
          setIsStudentConnected(true)
        }
      } catch (e) {
      } finally {
      }
    }

    setIsChatOpen(false)
    if (queryObj['enquiry']) {
      if (isLoggedIn && !isSelf) {
        setIsChatOpen(true)
        if (!isStudentConnected) {
          connectStudent()
        }
      }
    }
  }, [location])

	const closeLogin = () => {
    setOpenLoginModal(false)
  }
 
  const onLoginNext = () => {
    closeLogin()
    history.push({search: `enquiry=true`})
  }

  const toggleLogin = () => {
    setOpenLoginModal(!openLoginModal)
  }

	return (
		!isLoggedIn ? (
		    <React.Fragment>
		      {openLoginModal && (
		        <div className={styles.enquiryLoginBlockFloat}>
		          <p className={styles.loginTitle}>Login to talk to teacher</p>
		          <Login showSelectRole={false} role={`student`} onNextAction={() => onLoginNext()}></Login>
		        </div>
		      )}
		      <div className={styles.floatingChatIconBlock} onClick={toggleLogin}>
		        {openLoginModal ? (
		          <X size="32" />
		        ) : (
		          <MessageCircle size="32" />
		        )}
		        <p className={styles.chatText}>{openLoginModal ? `Close` : `Talk to Teacher`}</p>
		      </div>
		    </React.Fragment>
		  ) : (
		    !isSelf && exists(profile.profile_id) ? (
		      <React.Fragment>
		        <div className={styles.floatingChatIconBlock} onClick={e => {
		          if (isChatOpen) {
		            history.push({search: ``})
		          } else {
		            history.push({search: `enquiry=true`})
		          }
		        }}>
		          {isChatOpen ? (
		            <X size="24" />
		          ) : (
		            <MessageCircle size="24" />
		          )}
		          <p className={styles.chatText}>{isChatOpen ? `Close` : `Talk to Teacher`}</p>
		        </div>
		        <div className={clsx(styles.floatingChatBlock, isChatOpen ? styles.showChat : styles.hideChat)}>
		          {isStudentConnected ? (
		            <BitChat
		              type="SINGLE_CONVERSATION"
									role={`student`}
									viewDetails={false}
		              defaultView={{
		                type: 'user',
		                id: profile.chat_uid
		              }}
		            />
		          ) : (
		            <CircularProgress />
		          )}
		        </div>
		      </React.Fragment>
		    ) : null
	  )
	)
}

export default EnquiryButton
