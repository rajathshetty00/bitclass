import React, { useState, useEffect } from 'react'
import clsx from 'clsx'
import BitChat from '../BitChat'
import { hasAuthToken, getCode } from '../../__utils__/auth'
import Modal from '../Modal'
import { exists } from '../../__utils__'
import { WithAuthLogin as Login } from "../../auth"
import { MessageCircle, X } from "react-feather"
import CircularProgress from "../CircularProgress"
import { connectStudentToTeacher } from "../../__utils__/api"
import styles from "./styles.module.scss"
import trackEvent from '../../__utils__/analytics'

const EnquiryModal = ({
	profile,
	location,
	history,
	trackEnquiry = false,
	trackEnqEvtName = '',
	trackPayload = {},
	courseCode,
}) => {
	const isLoggedIn = Boolean(hasAuthToken())
	const isSelf = profile.code === getCode()
	const [isChatOpen, setIsChatOpen] = useState(true)
	const [openLoginModal, setOpenLoginModal] = useState(false)
	const [isStudentConnected, setIsStudentConnected] = useState(false)
	useEffect(() => {
    const _queryParams = location.search
    const queryParams = _queryParams && _queryParams.split('?')[1]
    const queryObj = {
    }

    if (queryParams) {
      const _params = queryParams.split('&')

      if (_params.length > 0) {
        _params.forEach(_param => {
          const param = _param.split('=')
          queryObj[param[0]] = param[1]
        })
      }
    }

    const connectStudent = async () => {
      try {
        const _res = await connectStudentToTeacher(profile.profile_id)
        if (_res?.success) {
          setIsStudentConnected(true)
        }
      } catch (e) {
      } finally {
      }
    }

    setIsChatOpen(false)
    if (queryObj['enquiry']) {
      if (isLoggedIn && !isSelf) {
      	setIsChatOpen(true)
        if (!isStudentConnected) {
          connectStudent()
        }
      }
    }
  }, [location])

	const closeLogin = () => {
    setOpenLoginModal(false)
  }
 
  const onLoginNext = () => {
    closeLogin()
    history.push({search: `enquiry=true`})
  }

  const toggleLogin = () => {
    setOpenLoginModal(!openLoginModal)
	}
	
	const trackEnquiryEvent = () => {
		if(trackEnquiry && exists(trackEnqEvtName)){
			trackEvent(trackEnqEvtName, {...trackPayload})
		}
	}

	return (
		!isLoggedIn ? (
		    <React.Fragment>
		      {openLoginModal && (
		        <Modal open={openLoginModal} onClose={() => setOpenLoginModal(false)}>
		          <p className={styles.loginTitle}>Login to talk to teacher</p>
		          <Login showSelectRole={false} role={`student`} onNextAction={() => onLoginNext()}></Login>
		        </Modal>
		      )}
		      <div className={styles.enquiryButton} onClick={() => { toggleLogin(); !openLoginModal && trackEnquiryEvent() } }>
		        <MessageCircle size="32" />
		        <p className={styles.chatText}>{`Talk to Teacher`}</p>
		      </div>
		    </React.Fragment>
		  ) : (
		    !isSelf && exists(profile.profile_id) ? (
		      <React.Fragment>
		        <div className={styles.enquiryButton} onClick={e => {
							if (isChatOpen) {
								history.push({search: ``})
		          } else {
								trackEnquiryEvent()
		            history.push({search: `enquiry=true`})
		          }
		        }}>
		          {isChatOpen ? (
		            <X size="24" />
		          ) : (
		            <MessageCircle size="24" />
		          )}
		          <p className={styles.chatText}>{`Talk to Teacher`}</p>
		        </div>

		        <Modal open={isChatOpen} onClose={() => setIsChatOpen(false)} modalInnerClass={styles.modalInner}>
		        {
		        	isStudentConnected ? (
		        		<BitChat
		              type="SINGLE_CONVERSATION"
									role={`student`}
									viewDetails={false}
		              defaultView={{
		                type: 'user',
		                id: profile.chat_uid
									}}
									showDownloadBanner={true}
		            />
		            ) : ( <CircularProgress /> )
		        }
			    	</Modal>
		      </React.Fragment>
		    ) : null
	  )
	)
}

export default EnquiryModal
