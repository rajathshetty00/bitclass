import React from 'react'
import styles from './style.module.scss'
import clsx from 'clsx'
import { Check, X } from 'react-feather'

export const ErrorMessage = ({ msg }) => {
  return (
    <div className={clsx(styles.alertBox, styles.error)}>
      <div className={styles.alertIcon}>
        <X size="20" color="tomato" />
      </div>
      <div className={styles.alertMsg}>
        <strong>{msg.toUpperCase()}</strong>
      </div>
    </div>
  )
}

export const SuccessMessage = ({ msg }) => {
  return (
    <div className={clsx(styles.alertBox, styles.success)}>
      <div className={styles.alertIcon}>
        <Check size="20" color="#75CB86" />
      </div>
      <div className={styles.alertMsg}>
        <strong>{msg.toUpperCase()}</strong>
      </div>
    </div>
  )
}
