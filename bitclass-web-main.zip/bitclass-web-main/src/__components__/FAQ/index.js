import React, { useState } from "react"
import clsx from "clsx"
import {
  ChevronDown, ChevronUp,
} from "react-feather"

import styles from "./style.module.scss"

export default function Faq({
  data,
  style={},
  className,
  trackThis = null,
}){

    const [openItem, setOpenItem] = useState(-1)

    if(!data || data.length < 0) {
      return ''
    }

    const openCloseItem = (index) => {
      if(index < 0) return false
      if(index === openItem) setOpenItem(-1)
      else {
        setOpenItem(index)
        if(typeof trackThis === "function") {
          trackThis(index)
        }
      }
    }

    return (
      <div className={clsx(styles.faqContainer, className)}>
        {data.map((faq, i) => (
          <div className={styles.faqIndvidual} key={i.toString()}>
            <div className={styles.faqTitle} onClick={() => openCloseItem(i)}>
              {faq.que}
                { openItem !== i ? <ChevronDown /> : <ChevronUp /> }
            </div>
            <div
              id={`faqAnswerEle${i}`}
              className={clsx(styles.faqAnswer)}
              style={{ maxHeight: openItem !== i ? '0' : document.getElementById(`faqAnswerEle${i}`).scrollHeight + 'px', marginTop: openItem !== i ? '0' : '8px' }}
            >
              {faq.ans}
            </div>
          </div>
        ))}
      </div>
    )
}