import React from 'react'
import ReactFilestack from 'filestack-react'
import { PrimaryButton, PrimaryIconButton } from "../Button"
import {ReactComponent as AttachmentSvgIcon} from '../../__assets__/attachment-light.svg'
import ErrorBoundary from '../../ErrorBoundary'
import styles from './style.module.scss'
import clsx from 'clsx'

const FileUploader = ({ btnClass, onUpload, disable=false }) => {
  const FILESTACK_KEY = "AZVhyTaNZRICU4mVm5l8Tz"
  const FILESTACK_OPTIONS = {
    accept: ['image/*', 'application/*'],
    displayMode: 'dropPane',
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024,
  }
  return (
    !disable && (
      <ErrorBoundary>
        <ReactFilestack
          apikey={FILESTACK_KEY}
          onSuccess={({ filesUploaded }) => onUpload(filesUploaded)}
          onError={err => window.alert("Failed to upload image", err)}
          clientOptions={FILESTACK_OPTIONS}
          customRender={ ({ onPick }) => (
            <button
              className={clsx(styles.attachmentButton, btnClass)}
              onClick={onPick}
            >
              <AttachmentSvgIcon className={styles.attachmentIcon}/>
            </button>
          )}
        />
      </ErrorBoundary>
    )
  )
}

export default FileUploader


export const ButtonFileUploader = ({ btnClass, onUpload, disable=false, btnStyles={}, btnText, icon = '', pickerOptions='', trackFn = '' }) => {
  const FILESTACK_KEY = "AZVhyTaNZRICU4mVm5l8Tz"
  const FILESTACK_OPTIONS = {
    accept: ['image/*', 'application/*'],
    displayMode: 'dropPane',
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024,
  }
  return (
    !disable && (
      <ErrorBoundary>
        <ReactFilestack
          apikey={FILESTACK_KEY}
          onSuccess={({ filesUploaded }) => onUpload(filesUploaded)}
          onError={err => window.alert("Failed to upload image", err)}
          clientOptions={FILESTACK_OPTIONS}
          actionOptions={pickerOptions}
          customRender={ ({ onPick }) => {
            return icon
            ? (<PrimaryIconButton
              onClick={e => {
                if(typeof trackFn === 'function') trackFn()
                onPick(e)
              }}
              type="submit"
              text={btnText}
              style={btnStyles}
              className={btnClass}
              prefixIcon={icon}
            />)
            : (<PrimaryButton
              onClick={e => {
                if(typeof trackFn === 'function') trackFn()
                onPick(e)
              }}
              type="submit"
              text={btnText}
              style={btnStyles}
              className={btnClass}
            />)
          }}
        />
      </ErrorBoundary>
    )
  )
}
