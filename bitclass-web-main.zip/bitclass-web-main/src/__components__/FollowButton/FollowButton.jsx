import clsx from "clsx"
import { CheckCircle, Loader, Plus } from "react-feather"
import { useState, useEffect } from "react"
import { debounce } from "lodash"
import styles from "./styles.module.scss"
import {
  followTeacher,
  unfollowTeacher,
  getMyFollowingList,
} from "../../__utils__/api"
import trackEvent from "../../__utils__/analytics"
import { BIT_EVENTS } from "../../__next__/config/events"
import { getCode } from "../../__utils__/auth"

const FollowButton = ({ teacherCode }) => {
  const [isFollowing, setIsFollowing] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  useEffect(() => {
    ;(async () => {
      try {
        const { following } = await getMyFollowingList()
        setIsFollowing(following.includes(teacherCode))
        setIsLoading(false)
      } catch (error) {
        setIsLoading(true)
      }
    })()
  }, [])

  const getFollowButtonStyle = () => {
    if (isFollowing) return clsx(styles.followBtn, styles.following)
    return styles.followBtn
  }
  const handleFollow = debounce(async () => {
   
    try {
      setIsLoading(true)
      if (isFollowing) {
        const { success } = await unfollowTeacher(teacherCode)
        trackEvent(BIT_EVENTS.FOLLOW_TEACHER_CLICKED, {
          status: false,
          student_id: getCode(),
          source: "cdp_demo",
        })
        if (success) setIsFollowing(false)
      } else {
        const { success } = await followTeacher(teacherCode)
        trackEvent(BIT_EVENTS.FOLLOW_TEACHER_CLICKED, {
          status: true,
          student_id: getCode(),
          source: "cdp_demo",
        })
        if (success) setIsFollowing(true)
      }
      setIsLoading(false)
    } catch (error) {
      setIsLoading(false)
    }
  }, 500)
  return (
    <button className={getFollowButtonStyle()} onClick={handleFollow}>
      {isLoading ? (
        <>
          <Loader className={styles.loader} />
          Loading..
        </>
      ) : isFollowing ? (
        <>
          <CheckCircle />
          Following
        </>
      ) : (
        <>
          <Plus />
          Follow
        </>
      )}
    </button>
  )
}

export default FollowButton
