import React, { useEffect } from "react"
import glide from "@glidejs/glide"
import clsx from "clsx"

import "@glidejs/glide/dist/css/glide.core.min.css"
import "react-day-picker/lib/style.css"
import styles from "./style.module.scss"

function GlideCarousal({ id, length, type = "carousel", startAt = 0, perView = 3, gap = 20, className = '', autoplay = false, ...props }) {

    useEffect(() => {
      if(length > 0 && id && length > perView) {
          new glide(`#${id}`, {
            type: type,
            startAt: startAt,
            perView: perView,
            gap: gap,
            autoplay: autoplay,
          }).mount()
      }
    }, [])

    if (!length || length <= 0 || !id) {
      return ""
    }
    const bulletArray = new Array(perView >= length ? 0 : Math.ceil(length/perView))
    // const bulletArray = new Array(length)
    bulletArray.fill(0)

    return (
      <div className={clsx("glide", className)} id={id}>
        <div className="glide__track" data-glide-el="track">
          <ul className="glide__slides">
            { props.children }
          </ul>
        </div>
        <div
          data-glide-el="controls[nav]"
          className={clsx("glide__bullets", styles.glideBullets)}
        >
          {bulletArray.map((item, index) => (
            <button
              key={index.toString()}
              className={clsx("glide__bullet", styles.glideBullet)}
              data-glide-dir={`=${index}`}
            ></button>
          ))}
        </div>
      </div>
    )

}

export default GlideCarousal
