import React from 'react'
import styles from './style.module.scss'
import clsx from 'clsx'

const GreenCheckbox = ({ checked, label, onChange, className, ...props }) => {
  return (
    <p className={clsx(styles.greenCheckboxWrapper, className)}>
      <input
        checked={checked}
        onChange={onChange}
        // id={id}
        type="checkbox"
        {...props}
      />
      <label htmlFor={props.id}>{label}</label>
    </p>
  )
}

export default GreenCheckbox
