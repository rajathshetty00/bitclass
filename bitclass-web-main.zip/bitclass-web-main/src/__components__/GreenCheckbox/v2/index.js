import React from 'react'
import styles from './style.module.scss'
import clsx from 'clsx'

const GreenCheckbox = ({ label, className, ...props }) => {
  return (
    <label className={clsx(styles.container, className)}>
      {label}
      <input type="checkbox" {...props} />
      <span className={styles.checkmark}></span>
    </label>
  )
}

export default GreenCheckbox
