import React from 'react'
import styles from './style.module.scss'
import clsx from 'clsx'

const GreenRadio = ({ id, checked, label, onChange, className, helpText, helpTextClass, labelClass, ...props }) => {
  return (
    <p className={clsx(styles.greenRadioWrapper, className)}>
      <input
        checked={checked}
        onChange={onChange}
        id={id}
        type="radio"
        {...props}
      />
      <label className={labelClass} htmlFor={id}>
        <span>{label}</span>
        <span className={helpTextClass}>{helpText}</span>
      </label>
    </p>
  )
}

export default GreenRadio
