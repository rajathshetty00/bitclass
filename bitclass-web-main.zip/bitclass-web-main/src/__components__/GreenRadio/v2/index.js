import React from "react"
import styles from "./style.module.scss"
import clsx from "clsx"

const GreenRadio = ({ label, className, ...props }) => {
  return (
    <label className={clsx(styles.container, className)}>
      {label}
      <input type="radio" {...props} />
      <span className={styles.checkmark}></span>
    </label>
  )
}

export default GreenRadio
