import React from 'react'
import styles from './style.module.scss'

export default function IconButton({children, ...props}) {
  return <button className={styles.buttonIcon} {...props}>{children}</button>
}
