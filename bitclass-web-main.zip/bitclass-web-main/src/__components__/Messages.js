import React from 'react'

export function ErrorMessage({ msg }){
  return (
  	<div
	    style={{
	      textAlign: 'center',
	      color: '#ff4444',
	      margin: 16,
	    }}  
	  >
	    <strong>{msg}</strong>
	  </div>
	)
}
