import React from 'react'
import clsx from 'clsx'
import {
  Modal
} from 'antd'
import {
  X,
} from 'react-feather'

import styles from './styles.module.scss'

const AntBitModal = ({
  visible = false,
  cancelFn = null,
  title = "",
  body = "",
  containerClass = "",
  titleClass = "",
  bodyClass = "",
  ...props
}) => {

  const Title = ({
    title="",
    className = "",
  }) => (
    <div className={clsx(styles.title, className)}>
      { title }
    </div>
  )

  const CloseIcon = () => (
    <span className={styles.closeIcon}>
      <X />
    </span>
  )

  return(
    <Modal
      visible={visible}
      title={<Title title={title} className={titleClass} />}
      className={clsx(styles.mainContainer, containerClass)}
      footer={null}
      closeIcon={<CloseIcon />}
      centered
      onCancel={() => {
        if(typeof cancelFn === 'function') {
          cancelFn()
        }
      }}
      {...props}
    >
      <div className={clsx(styles.body, bodyClass)}>
        { body }
      </div>
    </Modal>
  )
}

export default AntBitModal
