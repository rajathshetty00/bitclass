import React from 'react'
import styles from './style.module.scss'
import { X } from 'react-feather'
import clsx from 'clsx'
import CircularProgress from '../CircularProgress'

export default function Modal({
  title,
  open,
  bodyClass,
  modalInnerClass,
  containerClass,
  closeBtnClass,
  onClose,
  isLoading = false,
  ...props
}) {
  return open ? (
    <div className={clsx(styles.modalContainer, containerClass)}>
      <div className={clsx(styles.modalContent, bodyClass)}>
        <div className={clsx(styles.modalContentInner, modalInnerClass)}>
          {isLoading && (
            <div className={styles.loaderBlock}>
              <CircularProgress />
            </div>
          )}
          {title && <p className={styles.title}>{title}</p>}
          {onClose && (
            <div className={styles.closeBlock} onClick={onClose}>
              <X />
            </div>
          )}
          <div className={styles.modalBody}>{props.children}</div>
        </div>
      </div>
    </div>
  ) : null
}
