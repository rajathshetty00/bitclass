/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from "react"
import { Form, Input, Radio, Select, Switch, Tooltip } from "antd"
import { User, Mail, Monitor, UserPlus, Info } from "react-feather"
import clsx from "clsx"
import OtpInput from "react-otp-input"
import { useToasts } from "react-toast-notifications"

import styles from "./style.module.scss"
import CountryCodes from "../../__utils__/CountryCodes.json"
import { AntPrimaryButton } from "../Button"
import { checkMobileExist, generateOTP, login } from "../../__utils__/api"
import { exists } from "../../__utils__/index"
import { DEFAULT_TOAST_CONFIG } from "../../constants"
import { afterLogin } from "../../__utils__/auth"
import BitAntLoader from "../BitAntLoader"
import { isMobile, isTablet } from "react-device-detect"
import trackEvent from "../../__utils__/analytics"

const { Option } = Select

const countryToFlag = (isoCode) => {
  return typeof String.fromCodePoint !== "undefined"
    ? isoCode
        .toUpperCase()
        .replace(/./g, (char) =>
          String.fromCodePoint(char.charCodeAt(0) + 127397)
        )
    : isoCode
}

const PartnerWithBitClass = ({ className, history, source, ...props }) => {
  const [formData, setFormData] = useState({
    full_name: "",
    gender: "male",
    email: "",
    country_code: "+91",
    mobile: "",
    teach: "",
    experience: "",
    whatsappOptIn: true,
  })
  const [showOTP, setShowOTP] = useState(false)
  const [OTP, setOTP] = useState("")
  const [selectedCountryCode, setSelectedCountryCode] = useState("+91")
  const [mobileNumber, setMobileNumber] = useState("")
  const [isNewUser, setIsNewUser] = useState(true)
  const [otpCount, setOtpCount] = useState(0)
  const [showOtpLoading, setShowOtpLoading] = useState(false)

  const { addToast } = useToasts()
  const [signupFormRef] = Form.useForm()
  const [email, setEmail] = useState("")
  const _iconColor = "#969696"

  useEffect(() => {
    ;(async function () {
      if (OTP.length === 4) {
        setShowOtpLoading(true)
        let _res = await login({
          phone: formData.mobile,
          otp: OTP,
          username: formData.full_name,
          email: formData.email,
          waOptin: formData.whatsappOptIn,
          countryCode: formData.country_code,
          teachingExperience: formData.experience,
          teachingInterest: formData.teach,
          gender: formData.gender,
        })
        if (_res["data"]["success"]) {
          afterLogin(_res["data"])
          if (source === "homepage") {
            trackEvent("HomePage_Success_new_homepage_OTP", {})
          }
          history.push("/profile/apply")
        } else {
          addToast("Failed to register! Incorrect OTP.", {
            ...DEFAULT_TOAST_CONFIG,
            appearance: "error",
          })
        }
        setShowOtpLoading(false)
      }
    })()
  }, [OTP])

  useEffect(() => {
    ;(async function () {
      if (!mobileNumber) return
      let hasErrorInMobile = false
      try {
        await signupFormRef.validateFields(["mobile"])
        hasErrorInMobile = false
      } catch (e) {
        hasErrorInMobile = true
      }
      if (hasErrorInMobile) {
        setIsNewUser(true)
      }
    })()
  }, [mobileNumber])

  const checkIsNewUser = async () => {
    if (!mobileNumber || !selectedCountryCode) return
    let hasErrorInMobile = false
    try {
      await signupFormRef.validateFields(["mobile"])
      hasErrorInMobile = false
    } catch (e) {
      hasErrorInMobile = true
    }
    if (!hasErrorInMobile) {
      let _res = await checkMobileExist(mobileNumber, selectedCountryCode)
      if (exists(_res.data) && _res.data.new_user) {
        setIsNewUser(true)
      } else {
        setIsNewUser(false)
        if (source === "homepage") {
          trackEvent("HomePage_View_existing_user_message", {})
        }
      }
    } else {
      setIsNewUser(true)
    }
  }

  const mainFormSubmitHandler = async (data) => {
    if (isNewUser) {
      setFormData(data)
      let _res = await generateOTP({
        phone: data.mobile,
        countryCode: data.country_code,
        OTPCount: otpCount,
      })
      setOtpCount(1)
      if (exists(_res.data)) {
        document.body.scrollTop = 0
        document.documentElement.scrollTop = 0
        setShowOTP(true)
        if (source === "homepage") {
          trackEvent("HomePage_View_new_homepage_OTP", {})
        }
      } else {
        addToast("Failed to send otp", {
          ...DEFAULT_TOAST_CONFIG,
          appearance: "error",
        })
      }
    }
  }

  const resendOtpClickHandler = async () => {
    if (!formData.mobile || !formData.country_code) return
    let _res = await generateOTP({
      phone: formData.mobile,
      countryCode: formData.country_code,
      OTPCount: otpCount,
    })
    setOtpCount(otpCount + 1)
    if (!exists(_res.data)) {
      addToast("Failed to re-send otp", {
        ...DEFAULT_TOAST_CONFIG,
        appearance: "error",
      })
    }
    if (source === "homepage") {
      trackEvent("HomePage_Click_new_homepage_resend_OTP", {})
    }
  }

  const partnerButtonClickHandler = () => {
    signupFormRef
      .validateFields()
      .then((e) => {
        if (source === "homepage") {
          trackEvent(
            isMobile || isTablet
              ? "HomePage_Click_partner_with_us_mweb"
              : "HomePage_Click_partner_with_us",
            {
              Fields: { ...e },
              Submission_Type: "valid",
              Whatsapp_Optin: e.whatsappOptIn ? "yes" : "no",
            }
          )
        }
      })
      .catch((e) => {
        if (source === "homepage") {
          trackEvent(
            isMobile || isTablet
              ? "HomePage_Click_partner_with_us_mweb"
              : "HomePage_Click_partner_with_us",
            {
              Fields: { ...e.values },
              Submission_Type: "invalid",
              Whatsapp_Optin: e.values.whatsappOptIn ? "yes" : "no",
            }
          )
        }
      })
  }

  const onEmailChange = (e) => {
    let _v = e.currentTarget.value.trim().toLowerCase()
    if (String(_v).includes(" ")) return
    let restrictSpecialChars = /[$&+,:;=?[\]#|{}'"<>^*()%!\s/]/.test(
      String(_v).toLowerCase()
    )
    signupFormRef.setFieldsValue({
      email: !restrictSpecialChars ? _v : email,
    })

    !restrictSpecialChars && setEmail(_v)
  }

  return (
    <div className={clsx(styles.mainContainer, className)}>
      {!showOTP && (
        <Form
          initialValues={formData}
          onFinish={mainFormSubmitHandler}
          form={signupFormRef}
        >
          {/* full name */}
          <Form.Item
            name="full_name"
            rules={[
              {
                required: true,
                message: "Please add your name!",
              },
            ]}
          >
            <Input
              className={styles.input}
              prefix={<User />}
              placeholder="Full Name*"
            />
          </Form.Item>
          {/* gender */}
          <Form.Item
            name="gender"
            label="Select Gender"
            className={styles.genderItem}
            rules={[
              {
                required: true,
                message: "Please select the gender!",
              },
            ]}
          >
            <Radio.Group>
              <Radio value="male">Male</Radio>
              <Radio value="female">Female</Radio>
              <Radio value="other">Other</Radio>
            </Radio.Group>
          </Form.Item>
          {/* email */}
          <Form.Item
            name="email"
            rules={[
              {
                required: true,
                message: "Please add your email id!",
              },
              {
                pattern:
                  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                message: "Please enter a valid email id!",
              },
            ]}
          >
            <Input
              className={styles.input}
              prefix={<Mail />}
              placeholder="Email Address*"
              onChange={onEmailChange}
            />
          </Form.Item>
          <div
            className={clsx(
              styles.mobileContainer,
              !isNewUser ? styles.addBottomMarginMc : ""
            )}
          >
            {/* country code */}
            <Form.Item
              name="country_code"
              rules={[
                {
                  required: true,
                  message: "Please select country code!",
                },
              ]}
            >
              <Select
                className={clsx(styles.select, styles.countryCode)}
                dropdownMatchSelectWidth={false}
                optionLabelProp="label"
                value={selectedCountryCode}
                onSelect={setSelectedCountryCode}
              >
                {CountryCodes.map((v, i) => (
                  <Option
                    value={v.dial_code}
                    label={v.dial_code}
                    key={i.toString()}
                  >
                    {`${countryToFlag(v.code)} ${v.name} (${v.dial_code})`}
                  </Option>
                ))}
              </Select>
            </Form.Item>
            {/* phone */}
            <Form.Item
              name="mobile"
              rules={[
                {
                  required: true,
                  message: "Please add your mobile number!",
                },
                {
                  pattern: /^\d+$/,
                  message: "Please enter a valid mobile number!",
                },
              ]}
            >
              <Input
                className={clsx(styles.input, styles.mobileInput)}
                placeholder="WhatsApp Number*"
                value={mobileNumber}
                onChange={(e) => {
                  let _v = e.currentTarget.value.trim()
                  signupFormRef.setFieldsValue({
                    mobile: _v.replace(/\D/g, ""),
                  })
                  setMobileNumber(_v.replace(/\D/g, ""))
                }}
                onBlur={checkIsNewUser}
                suffix={
                  <Tooltip
                    title="This is required only for sending important updates about your class"
                    placement="topRight"
                  >
                    <Info color={_iconColor} />
                  </Tooltip>
                }
              />
            </Form.Item>
            {!isNewUser && (
              <span className={styles.userAlreadyExist}>
                Mobile number already exists.&nbsp;
                <a href="/live-classes/signin">Login</a>
              </span>
            )}
          </div>
          {/* what you teach */}
          <Form.Item
            name="teach"
            rules={[
              {
                required: true,
                message: "Please add what you teach!",
              },
            ]}
          >
            <Input
              className={styles.input}
              prefix={<Monitor />}
              placeholder="What do you teach?*"
            />
          </Form.Item>
          {/* Teaching experience in years */}
          <Form.Item
            name="experience"
            rules={[
              {
                required: true,
                message: "Please add teaching experience!",
              },
              {
                pattern: /^[+-]?\d+(\.\d+)?$/,
                message: "Please enter numbers!",
              },
            ]}
          >
            <Input
              className={styles.input}
              prefix={<UserPlus />}
              placeholder="Online teaching experience in years*"
            />
          </Form.Item>
          <div className={styles.whatsAppContainer}>
            <span className={styles.optWhatsApp}>
              Opt-in for WhatsApp notifications
            </span>
            <Form.Item name="whatsappOptIn" valuePropName="checked">
              <Switch defaultChecked />
            </Form.Item>
          </div>
          <Form.Item>
            <AntPrimaryButton
              type="primary"
              htmlType="submit"
              customClass={styles.submitButton}
              text="Partner with BitClass"
              onClick={partnerButtonClickHandler}
            />
          </Form.Item>
        </Form>
      )}
      {showOTP && (
        <div id="otpContainer" className={styles.otpScreen}>
          {showOtpLoading && <BitAntLoader />}
          <span className={styles.otpTitle}>Verify OTP</span>
          <div>
            <span className={styles.otpText}>OTP Sent to </span>
            <span className={styles.otpPhone}>{formData.mobile}</span>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault()
                setOtpCount(0)
                setShowOTP(false)
                if (source === "homepage") {
                  trackEvent(
                    "HomePage_Click_new_homepage_OTP_change_number",
                    {}
                  )
                }
              }}
            >
              change
            </a>
            <OtpInput
              onChange={(v) => {
                if (!Number(v)) {
                  return
                }
                setOTP(v)
              }}
              numInputs={4}
              inputStyle={styles.otpInputStyle}
              containerStyle={styles.otpInput}
              value={OTP}
            />
            <div className={styles.resendLeftContainer}>
              <span
                className={clsx(
                  styles.resendOtp,
                  otpCount === 3 && styles.disabled
                )}
                onClick={resendOtpClickHandler}
              >
                Resend OTP
              </span>
              <span className={styles.attemptsLeft}>
                *{3 - otpCount} attempt(s) left
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default PartnerWithBitClass
