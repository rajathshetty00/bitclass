import React from 'react'
import styles from './style.module.scss'

const Reactions = ({ text = '' }) => {
  return (
    <div className={styles.Reactions}>
      {text}
    </div>
  )
}

export default Reactions
