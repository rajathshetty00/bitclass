import React, { useState, useEffect } from 'react'
import clsx from 'clsx'

import styles from './styles.module.scss'
import { getCourseScheduleDetails } from '../../__utils__/dateFns'

const ScheduleTags = ({
  weeklySchedule,
  duration = 60,
  noTimeClass = '',
  mainContainerClass = '',
}) => {
  const [days, setDays] = useState([])

  useEffect(() => {
    let _days = getCourseScheduleDetails(weeklySchedule, duration)
    setDays(_days)
  }, [])


  return !weeklySchedule || days.length <= 0
  ? <span className={noTimeClass}>Time Not Added Yet</span>
  : (
    <div className={clsx(styles.scheduleContainer, mainContainerClass)}>
      {
        days.map((dateVal, dateIndex) => (
          <span key={dateIndex.toString()} className={styles.schedule}>
            <span className={styles.scheduleLabel}>{ dateVal.label }</span>
            <span className={styles.scheduleData}>{ dateVal.data }</span>
          </span>
        ))
      }
    </div>
  )
}

export default ScheduleTags
