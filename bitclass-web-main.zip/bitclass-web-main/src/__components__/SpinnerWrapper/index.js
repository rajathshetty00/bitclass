import * as React from 'react'
import Lock from '../../__assets__/loader.svg'
import styles from './style.module.scss'

export default function SpinnerWrapper({ children, isLoading, text='' }) {
  if (isLoading) {
    return (
      <div className={styles.spinnerWrapper}>
        <div className={styles.spinnerContainer}>
          {text && <p className={styles.Text}>{text}</p>}
          <img
            src={Lock}
            style={{ width: 96 }}
            alt="icon"
          />
        </div>
      </div>
    )
  }
  return <>{children}</>
}
