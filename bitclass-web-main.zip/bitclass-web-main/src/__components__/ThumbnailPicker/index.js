import React, { useState, useEffect, useRef } from 'react'
import { Modal } from 'antd'
import ReactPlayer from 'react-player'
import { Video, Image } from 'react-feather'
import { useToasts } from 'react-toast-notifications'
import Cropper from 'react-easy-crop'

import styles from './style.module.scss'
import { PrimaryButton, PrimaryButtonOutline, PrimaryButtonOutlineIcon } from '../Button'
import { PrimaryIconButton } from '../Button/index'
import { CLOUDINARY_CONFIG, DEFAULT_TOAST_CONFIG } from '../../constants'
import { exists, getThumbnailFromUrl } from '../../__utils__/index'
import { isMobile, isTablet } from 'react-device-detect'

const ThumbnailPicker = ({
  showPicker = false,
  video,
  afterUpload = null,
  setShowThumbnailPicker,
  ...props
}) => {

  const [step, setStep] = useState(0)
  const [img, setImg] = useState('')
  const { addToast } = useToasts()
  const [crop, setCrop] = useState({ x: 0, y: 0 })
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null)
  const [isVideoPaused, setIsVideoPaused] = useState(true)
  const [so, setSo] = useState(null) //start offset
  const [videoPlayerError, setVideoPlayerError] = useState(false)
  let videoPlayerRef = useRef()

  const _buttonTextMap = ["", "CAPTURE THIS FRAME", "SAVE THUMBNAIL"]
  const _buttonOnClick = [
    () => {},
    () => captureFrame(),
    () => saveThumbnail()
  ]
  const _backButtonClick = [
    () => {},
    () => setStep(0),
    () => so ? setStep(1) : setStep(0),
  ]

  useEffect(() => {
    setStep(0)
    setImg(getThumbnailFromUrl(video))
    setCroppedAreaPixels(null)
  }, [showPicker, video])

  const saveThumbnail = () => {
      let thumbnailURL = getCroppedUrl()
      if(typeof afterUpload === 'function') {
        afterUpload(thumbnailURL)
      }
      setShowThumbnailPicker(false)
  }

  const captureFrame = () => {
    let currentTime = videoPlayerRef.getCurrentTime()
    currentTime = currentTime.toPrecision()
    if(currentTime !== null) {
      let _img = getThumbnailFromUrl(video)
      if(!_img) return
      const urlSplit = _img.split('/upload/')
      const urlToAppend = `so_${currentTime}`
      _img = `${urlSplit[0]}/upload/${urlToAppend}/${urlSplit[1]}`
      setImg(_img)
      setSo(currentTime)
      setStep(2)
    }
  }

  const getCroppedUrl = () => {
    if(!exists(croppedAreaPixels) || !exists(img)) return ''
    const urlSplit = img.split('/upload/')
    let urlToAppend = `x_${croppedAreaPixels.x},y_${croppedAreaPixels.y},w_${croppedAreaPixels.width},h_${croppedAreaPixels.height},c_crop`
    if(so) {
      urlToAppend += `,so_${so}`
    }
    const newUrl = `${urlSplit[0]}/upload/${urlToAppend}/${urlSplit[1]}`
    return newUrl
  }

  const openCloudinaryUpload = () => {
    window.openCloudinaryWidget( {
      ...CLOUDINARY_CONFIG,
      multiple: false,
      resource_type: 'image',
    }, cloudinaryAfterUpload)
  }

  const cloudinaryAfterUpload = (err, res) => {
    if(err) {
      addToast(err.message || "Failed to upload", { ...DEFAULT_TOAST_CONFIG, appearance: 'error' })
      return
    }
    if(res[0].url) {
      setImg(res[0].url)
      setStep(2)
    } else {
      addToast("Failed to upload", { ...DEFAULT_TOAST_CONFIG, appearance: 'error' })
    }
  }

  const cropComplete = (croppedArea, croppedAreaPixels) => {
    setCroppedAreaPixels(croppedAreaPixels)
  }

  return showPicker ? (
    <Modal
      centered={ (!isMobile && !isTablet) ?  true : false}
      title="Thumbnail Picker"
      visible={true}
      className={styles.thumbnailModal}
      footer={null}
      { ...props }
    >
      <div className={styles.tContent}>
        {step === 0 && (
          <div className={styles.chooseTheType}>
            { //only if cloudinary video then show the video picker
              img && <PrimaryIconButton
                text="SELECT FROM VIDEO"
                onClick={() => setStep(1)}
                prefixIcon={<Video />}
              />
            }
            <PrimaryButtonOutlineIcon
              text="UPLOAD MANUALLY"
              onClick={openCloudinaryUpload}
              prefixIcon={<Image />}
            />
          </div>
        )}
        {step === 1 && (
          <div className={styles.videoPicker}>
            {
              !videoPlayerError && (
                <>
                  <div style={{ color: 'red' }}>Pause video to capture the frame.</div>
                  <ReactPlayer
                    ref={(re) => videoPlayerRef = re}
                    width={!isMobile && !isTablet ? 500 : '100%'}
                    height={!isMobile && !isTablet && 400}
                    controls={true}
                    loop={false}
                    url={video}
                    onError={(e) => setVideoPlayerError(true)}
                    onPause={() => setIsVideoPaused(true)}
                    onPlay={() => setIsVideoPaused(false)}
                  />
                </>
              )
            }
            {
              videoPlayerError && (
                <div className={styles.videoErrorDiv}>
                  Video will be ready for viewing in few minutes...
                </div>
              )
            }
          </div>
        )}
        {step === 2 && (
          <div className={styles.cropOpt}>
            <Cropper
              image={img}
              crop={crop}
              onCropChange={setCrop}
              zoom={1}
              aspect={5/3}
              onCropComplete={cropComplete}
            />
          </div>
        )}
      </div>
      <div className={styles.btnContainer}>
        {
          step > 0 &&
            <PrimaryButtonOutline
              text="Back"
              onClick={_backButtonClick[step]}
            />
        }
        {
          step > 0 && (
            step === 1 ?
            (
              isVideoPaused && !videoPlayerError && <PrimaryButton
              text={_buttonTextMap[step]}
              onClick={_buttonOnClick[step]}
            />
            ) : <PrimaryButton
              text={_buttonTextMap[step]}
              onClick={_buttonOnClick[step]}
            />
          )
        }
      </div>
    </Modal>
  ) : ''
}

export default ThumbnailPicker
