import React, { useState } from 'react'
import clsx from 'clsx'

import styles from './style.module.scss'

/**
 * 
 * @param { Array }      data         [{onClick, label}]   mandatory
 * @param { className }  mainClass                         optional
 * @param { className }  borderClass                       optional
 * @param { className }  itemsClass                        optional
 *  
 */
const ToggleBar = ({
  mainClass,
  borderClass,
  itemsClass,
  data,
}) => {

  const [active, setActive] = useState(0)

  if(Object.keys(data).length <= 0) return ''

  return(
    <div className={clsx(styles.toggleBar, mainClass)}>
      <div className={clsx(styles.toggleBorderBar, borderClass)}>
        {
          data.map((e, i) => (
            <div
              className={clsx(
                styles.toggleItems,
                itemsClass,
                active === i && styles.active
              )}
              key={i.toString()}
              onClick={() => {
                setActive(i)
                e.onClick()
              }}
            >
              { e.label }
            </div>
          ))
        }
      </div>
    </div>
  )
}

export default ToggleBar
