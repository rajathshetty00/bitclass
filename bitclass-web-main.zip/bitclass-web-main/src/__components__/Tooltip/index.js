import React, { Component } from 'react'
import styles from './style.module.scss'
import { isMobile } from "react-device-detect"
import clsx from 'clsx'

class Tooltip extends Component {
  constructor(props) {
    super(props)

    this.state = {
      displayTooltip: false
    }
    this.hideTooltip = this.hideTooltip.bind(this)
    this.showTooltip = this.showTooltip.bind(this)
  }
  
  hideTooltip () {
    this.setState({displayTooltip: false})
    
  }
  showTooltip () {
    this.setState({displayTooltip: true})
  }

  render() {
    const message = this.props.title
    const position = this.props.placement || 'top'

    return (
      <span className={styles.tooltip}
          onMouseLeave={this.hideTooltip}
          style={this.props.css}
        >
        {this.state.displayTooltip &&
        <div className={clsx(styles.tooltipBubble, styles[`tooltip${position}`])}>
          <div className={styles.tooltipMessage}>{message}</div>
        </div>
        }
        <span 
          className={styles.tooltipTrigger}
          onMouseOver={this.showTooltip}
          >
          {this.props.children}
        </span>
      </span>
    )
  }
}

export default Tooltip