import Lock from "public/static/__assets__/loader.svg"
import styles from "./style.module.scss"

const TransparentLoader = () => {
  return (
    <div className={styles.loaderComponent}>
      <Lock width="96" alt="icon" />
    </div>
  )
}

export default TransparentLoader
