import React, { useState } from "react"
import ReactPlayer from "react-player"
import clsx from "clsx"

import styles from "./style.module.scss"
import VideoPopup from "../VideoPopup"
import { exists, getThumbnailFromUrl } from '../../__utils__/index'
import { ReactComponent as PlayIcon } from '../../__assets__/BitPlayButton.svg'

const ErrComponent = ({ msg = 'Failed to play video' }) => (
  <div className={styles.failedVideo}>{msg}</div>
)

const VideoCard = ({
  title = "Video",
  url,
  customClass = '',
  popupClass = '',
  height = "100%",
  width = "100%",
  errComponent = "",
  errMsg = "Something went wrong",
  style = {},
  thumbnail="",
  trackEvent,
  ...props
}) => {
  const [showModal, setShowModal] = useState(false)
  const [hasErr, setHasErr] = useState(false)
  var thumbnailImage = thumbnail

  if(!exists(thumbnailImage) || thumbnailImage === false) {
    thumbnailImage = getThumbnailFromUrl(url)
  }

  return (
    <div className={clsx(styles.videoCardContainer, customClass)} style={{...style}}>
      {!hasErr ? (
        <>
          <div className={styles.overlay} onClick={() => setShowModal(true)}>
            {!exists(thumbnailImage) && exists(url) && <PlayIcon />}
          </div>
          {
            exists(thumbnailImage)
            ? <div onClick={() => {
              if(typeof trackEvent === 'function') {
                trackEvent()
              }
              setShowModal(true)
            }} className={styles.thumbnailDiv} style={{ backgroundImage: `url(${thumbnailImage})` }}>
              <PlayIcon />
            </div>
            : <ReactPlayer
              width={width}
              height={height}
              controls={false}
              loop={false}
              url={url}
              style={{ display: "flex" }}
              onError={(e) => setHasErr(true)}
            />
          }
          {
            showModal && <VideoPopup
              title={title}
              url={url}
              showModal={showModal}
              setShowModal={setShowModal}
              errComponent={<ErrComponent msg={errMsg} />}
              errMsg={errMsg}
              customClass={popupClass}
            />
          }
        </>
      )
      : (
        errComponent ? {errComponent} : <ErrComponent msg={errMsg} />
      )
    }
    </div>
  )
}

export default VideoCard
