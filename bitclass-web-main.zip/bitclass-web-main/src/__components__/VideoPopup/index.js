import React, { useState, useRef, useEffect } from "react"
import styles from "./style.module.scss"
import ReactPlayer from 'react-player'
import clsx from 'clsx'
import AntBitModal from '../Modal/AntBitModal/index'
import { AntPrimaryButton } from "../Button"
import trackEvent from "../../__utils__/analytics"
import { BIT_EVENTS } from "../../__next__/config/events"


export default function VideoPopup({
  title = "Video",
  url,
  showModal = false,
  setShowModal = () => { },
  errMsg = "Something went wrong",
  errComponent = "",
  customClass = "",
  onPause = () => { },
  onPlay = () => { },
  modalVideoData = null,
  trackingbaseData = {}
}) {
  const [playing, setPlaying] = useState(true)
  const [hasErr, setHasErr] = useState(false)
  let playerRef = useRef()
  const [isZoom, setIsZoom] = useState(false)

  useEffect(() => {
    if (url.includes('zoom.us/')) {
      window.open(url, "_blank")
      setShowModal(false)
    }
  }, [])

  const upcomingCtaClickHandler = () => {
    trackEvent(BIT_EVENTS.SUMMARY_UPCOMING_CTA_CLICKED, {
      ...trackingbaseData,
      navigation_text: modalVideoData.navigationText,
      navigation_url: modalVideoData.navigationUrl
    })
    window.location.href = modalVideoData.navigationUrl
  }

  if (!url) return ''
  return showModal ? (
    <AntBitModal
      visible={true}
      title={
        <div className={styles.modalTitleContainer}>
          {title}
          {
            modalVideoData && (
              <AntPrimaryButton
                type="primary"
                htmlType="submit"
                text={modalVideoData.navigationText}
                onClick={upcomingCtaClickHandler}
              />
            )
          }
        </div>


      }
      cancelFn={() => { setPlaying(false); setShowModal(false) }}
      footer={null}
      centered={true}
      titleClass={styles.modalTitle}
      containerClass={clsx(styles.modalContainer, customClass)}
      body={(
        !hasErr
          ? <ReactPlayer
            ref={(player) => {
              playerRef = player
            }}
            controls={true}
            loop={false}
            url={url}
            playing={playing}
            className={styles.modalPlayer}
            onError={(e) => { setHasErr(true) }}
            onPause={() => onPause(playerRef)}
            onPlay={() => onPlay(playerRef)}
          />
          : errComponent ? errComponent : errMsg
      )}
    />
  ) : ''
}
