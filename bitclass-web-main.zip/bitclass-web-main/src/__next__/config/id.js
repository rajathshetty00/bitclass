export const IOS_DOWNLOAD='iosDownloadButton'
export const ANDROID_DOWNLOAD='androidDownloadButton'
export const LOGIN_BUTTON='loginButton'
export const LOGOUT_BUTTON='logoutButton'
export const HEADER_LOGO='bitClassLogo'
export const COURSE_CARD='courseCard'

export const CDP_VIDEO_PLAY='cdp_video_play_button'
export const PAY_BOOK_NOW='payAndBookNow'
export const APPLY_COUPON_BUTTON='applyCouponButton'


export const CATEGORY_TAB='categoryTab'
export const WA_OPT_IN='waOptIn'
export const NEW_DISCOVERY='newDiscovery'