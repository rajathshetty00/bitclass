export const eventSources = {
  cdpTopBar: "cdp_top_bar",
  cdpJoinCourse: "cdp_join_course",
  home: "home",
  liveClass: "live_class",
  teacherProfile: "teacher_profile",
  sneakPeak: "sneak_peak",
  cdp:'cdp'
}
