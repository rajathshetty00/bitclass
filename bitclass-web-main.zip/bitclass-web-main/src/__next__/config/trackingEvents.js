import dayjs from "dayjs"
import {
  ANDROID_APP_DOWNLOAD_URL,
  IOS_APP_DOWNLOAD_URL,
} from "src/homepage/helper/constants"
import { exists, getUrlParametersAsArray } from "src/__utils__"
import trackEvent from "src/__utils__/analytics"
import { getCode } from "src/__utils__/auth"
import { getCourseAnalyticsData } from "src/__utils__/index"
import { BIT_EVENTS } from "./events"
import {
  ANDROID_DOWNLOAD,
  APPLY_COUPON_BUTTON,
  CATEGORY_TAB,
  CDP_VIDEO_PLAY,
  HEADER_LOGO,
  IOS_DOWNLOAD,
  LOGIN_BUTTON,
  LOGOUT_BUTTON,
  NEW_DISCOVERY,
  PAY_BOOK_NOW,
} from "./id"

import {
  androidDownloadClicked,
  iosDownloadClicked,
} from "src/helpers/appDownloadClick"

export const handleTrackEvent = (event) => {
  // console.log(event.target, "event triggered")
  const {
    id,
    dataset: { source, category, mobile, comp },
  } = event.target
  switch (id) {
    case IOS_DOWNLOAD:
      trackEvent(BIT_EVENTS.DOWNLOAD_IOS_CLICKED, { source })
      window.location.href = iosDownloadClicked({ source, mobile, comp })
      break

    case ANDROID_DOWNLOAD:
      trackEvent(BIT_EVENTS.DOWNLOAD_ANDROID_CLICKED, { source })
      window.location.href = androidDownloadClicked({ source, mobile, comp })
      break

    case LOGIN_BUTTON:
      trackEvent(BIT_EVENTS.LOGIN_VIEWED, { source })
      break

    case LOGOUT_BUTTON:
      trackEvent(BIT_EVENTS.LOGOUT_CLICKED)
      break

    case HEADER_LOGO:
      trackEvent(BIT_EVENTS.LOGO_CLICKED, {
        student_id: getCode(),
        source,
      })
      break
    case NEW_DISCOVERY:
      trackEvent(BIT_EVENTS.HOMEPAGE_LIVE_COURSES_SEARCH_BUTTON_CLICKED, {})
      break
    case CDP_VIDEO_PLAY:
      trackEvent(BIT_EVENTS.VIDEO_ACTION_CLICKED, {
        ...getCourseAnalyticsData(),
      })
      break
    case PAY_BOOK_NOW:
      trackEvent(BIT_EVENTS.PAY_AND_BOOK_CLICKED, {
        ...getCourseAnalyticsData(),
      })
      break
    case APPLY_COUPON_BUTTON:
      trackEvent(BIT_EVENTS.APPLY_COUPON__APPLY_CLICKED, {
        ...getCourseAnalyticsData(),
      })
      break
    case CATEGORY_TAB:
      trackEvent(BIT_EVENTS.TAB_CLICKED, { category: category })
      break
    default:
      break
  }
}

export const trackPageLanding = (eventName, payload) =>
  trackEvent(eventName, payload)
