import React, { createContext, useReducer } from "react"
import { appReducer, initialAppState } from "./appReducer"

export const AppContext = createContext()

const AppContextProvider = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialAppState)
  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  )
}

export default AppContextProvider
