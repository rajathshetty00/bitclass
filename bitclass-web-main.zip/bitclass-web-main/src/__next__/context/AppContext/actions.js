
export const unFollowTeacher = (state,payload) => {
  const followingList = [...state.myFollowings]
  const updatedList = followingList.filter(teacherCode=>teacherCode!==payload)
  return {...state,myFollowings:updatedList}
}
