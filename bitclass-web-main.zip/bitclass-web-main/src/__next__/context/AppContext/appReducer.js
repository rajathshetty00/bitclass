import { HEADER_LOGIN_BUTTON } from "src/__utils__/components"
import { unFollowTeacher } from "./actions"
import {
  TOGGLE_FULLSCREEN_VIDEO_MODAL,
  FULLSCREEN_MODAL_STATUS,
  TOGGLE_LOGIN_SCREEN,
  CHANGE_LOGGED_IN_STATUS,
  UPDATE_CURRENT_PAGE_STATE,
  STORE_CLICKED_FOLLOW_TEACHER_CODE,
  SAVE_FOLLOWING_LIST,
  UPDATE_FOLLOWING_LIST,
  UN_FOLLOW_FOLLOWING_LIST,
  SAVE_CATEGORIES,
  LIVE_STREAM_MODAL_ACTIVATE,
  LIVE_STREAM_MODAL_CLOSE,
  UPDATE_LIVE_USERS,
  SAVE_SELECTED_LIVE_EVENT,
  TOGGLE_EARLY_SCREEN,
  LOGIN_TRIGGERER,
  SET_SLOT,
  START_PAYMENT_WITHOUT_LOGIN,
  GET_RAZORPAY_CB,
  SET_TRANSPARENT_LOADER,
  SET_ORDER_CODE,
  SET_USER_INFO,
  RECOMMENDED_FREE_CLASSES_EXISTS,
  SAVE_LIVE_SCREEN,
} from "./types"

export const initialAppState = {
  showFullscreenVideoModal: false,
  liveUsers: 0,
  selectedLiveCourse: {},
  selectedLiveEvent: {},
  liveStreamUrl: "",
  loggedIn: false,
  openLoginScreen: false,
  loading: false,
  currentPageState: {},
  categories: [],
  teacherCode: "",
  myFollowings: [],
  showEarlyScreen: false,
  loginTriggerer: HEADER_LOGIN_BUTTON,
  slotDetails: [],
  paymentWithoutLogin: false,
  razorpaySuccessCb: null,
  showLoader: false,
  orderCode: null,
  userInfo: null,
  isRecommendedFreeClasses: false,
  liveCourseCode: null,
}
export const appReducer = (state, { payload, type }) => {
  switch (type) {
    case TOGGLE_FULLSCREEN_VIDEO_MODAL:
      return { ...state, showFullscreenVideoModal: payload }
    case FULLSCREEN_MODAL_STATUS:
      return { ...state, showFullscreenVideoModal: payload }
    case TOGGLE_LOGIN_SCREEN:
      return { ...state, openLoginScreen: payload }
    case SAVE_LIVE_SCREEN:
      return {
        ...state,
        liveCourseCode: payload,
      }
    case CHANGE_LOGGED_IN_STATUS:
      return {
        ...state,
        loggedIn: payload,
        myFollowings: payload ? state.myFollowings : [],
      }
    case LOGIN_TRIGGERER: {
      return { ...state, loginTriggerer: payload }
    }
    case UPDATE_CURRENT_PAGE_STATE:
      return { ...state, currentPageState: payload, loading: true }
    case STORE_CLICKED_FOLLOW_TEACHER_CODE:
      return { ...state, teacherCode: payload }
    case SAVE_FOLLOWING_LIST:
      return { ...state, myFollowings: payload }
    case UPDATE_FOLLOWING_LIST:
      return { ...state, myFollowings: [...state.myFollowings, payload] }
    case UN_FOLLOW_FOLLOWING_LIST:
      return unFollowTeacher(state, payload)
    case SAVE_CATEGORIES:
      return { ...state, categories: payload }
    case LIVE_STREAM_MODAL_ACTIVATE:
      return { ...state, ...payload }
    case LIVE_STREAM_MODAL_CLOSE:
      return { ...state, showFullscreenVideoModal: false }
    case UPDATE_LIVE_USERS:
      return { ...state, liveUsers: payload }
    case SAVE_SELECTED_LIVE_EVENT:
      return { ...state, selectedLiveEvent: payload }
    case TOGGLE_EARLY_SCREEN:
      return { ...state, showEarlyScreen: payload }
    case SET_SLOT:
      return { ...state, slotDetails: payload }
    case START_PAYMENT_WITHOUT_LOGIN:
      return { ...state, paymentWithoutLogin: payload }
    case GET_RAZORPAY_CB:
      return { ...state, razorpaySuccessCb: payload }
    case SET_USER_INFO:
      return { ...state, userInfo: payload }
    case SET_TRANSPARENT_LOADER:
      return { ...state, showLoader: payload }
    case SET_ORDER_CODE:
      return { ...state, orderCode: payload }
    case RECOMMENDED_FREE_CLASSES_EXISTS:
      return { ...state, isRecommendedFreeClasses: payload }
    default:
      return state
  }
}
