import { useContext } from "react"
import { AppContext } from "../AppContext"

const useAppContext = () => {
  const appContext = useContext(AppContext)
  return {...appContext}
}

export default useAppContext
