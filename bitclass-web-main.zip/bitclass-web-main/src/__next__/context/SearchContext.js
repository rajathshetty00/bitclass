import React, { createContext, useState } from "react"

export const SearchContext = createContext()
const SearchContextProvider = ({ children }) => {
  const [displayMobileSearchModal, setDisplayMobileSearchModal] = useState(
    false
  )
  return (
    <SearchContext.Provider
      value={{
        displayMobileSearchModal: displayMobileSearchModal,
        setDisplayMobileSearchModal: setDisplayMobileSearchModal,
      }}
    >
      {children}
    </SearchContext.Provider>
  )
}

export default SearchContextProvider
