import React , {useReducer} from 'react'
export const UserContext = React.createContext({
  isAuthenticated: true,
  isLoading: true,
  paymentInProgress: () => {},
  globalState: null,
  showDemoSlot: false,
  isTmprDemoCdp: false
})
