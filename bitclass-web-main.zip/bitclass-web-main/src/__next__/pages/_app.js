import React, { useState, useEffect } from "react"
import "../styles/_mixins.scss"
import "../styles/_variables.scss"
import "antd/dist/antd.less"
import "../styles/index.scss"
import "react-day-picker/lib/style.css"
import "react-image-gallery/styles/css/image-gallery.css"
import { ToastProvider } from "react-toast-notifications"
import Head from "next/head"
import * as firebase from "firebase/app"
import "firebase/analytics"
import { UserContext } from "../context/User"
import {
  FIREBASE_CONFIG,
  FB_PIXEL_ID,
  SINGULAR_API_KEY,
  SINGULAR_SECRET_KEY,
  BASE_URL,
} from "../src/constants"
import SearchContextProvider from "context/SearchContext"
import AppContextProvider from "context/AppContext/AppContext"
import { handleTrackEvent } from "config/trackingEvents"
import { deleteAuthToken, getAuthToken, initSentry } from "src/__utils__"
import { getCode } from "src/__utils__/auth"

if (firebase.apps.length === 0) {
  firebase.initializeApp(FIREBASE_CONFIG)
}

function MyApp({ Component, pageProps }) {
  const initSingular = () => {
    import("singular-sdk").then((res) => {
      const SingularConfig = res.SingularConfig
      const SingularSdk = res.singularSdk
      const config = new SingularConfig(
        SINGULAR_API_KEY,
        SINGULAR_SECRET_KEY,
        BASE_URL
      ).withCustomUserId(getCode())
      SingularSdk.init(config)
    })
  }

  useEffect(() => {
    const advancedMatching = {}
    const options = {
      autoConfig: true, // set pixel's autoConfig
      debug: false, // enable logs
    }

    if (typeof window !== "undefined") {
      if (window.location.hostname.includes("bitclass.live")) {
        import("react-facebook-pixel").then((ReactPixel) => {
          ReactPixel.default.init(FB_PIXEL_ID, advancedMatching, options)
          ReactPixel.default.pageView() // For tracking page view
        })
        // firebase.analytics()
      }
      initSingular()
    }
    initSentry()
    // check the authtoken without login is available or not if yes then clear the auth token as well as userinfo
    if (getAuthToken()) {
      deleteAuthToken()
    }
  }, [])

  const [globalState, setGlobalState] = useState({
    login: null,
    orderID: null,
  })

  const [authenticated, isAuthenticated] = useState(true)
  const [isLoading, setIsLoading] = useState(false)

  const paymentInProgress = (payload) => {
    setGlobalState({ ...globalState, ...payload })
  }

  return (
    <>
      <Head>
        <meta charset="utf-8" />
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, maximum-scale=1"
        />
        <meta name="theme-color" content="#2E3A59" />
        <meta
          name="google-site-verification"
          content="m3kR-wqiju62QzrF-jYZLtziE4r4-JSI27_qHg1uqlc"
        />
        <meta
          name="facebook-domain-verification"
          content="9d33hmy9p8ico6niubuj9cxs291vc0"
        />
        <link rel="apple-touch-icon" href="/static/logoNew.svg" />
        <link rel="manifest" href="/static/manifest.json" />
        <link rel="shortcut icon" href="/static/logoNew.svg" />
        <link rel="shortcut icon" href="/static/favicon.ico" />
      </Head>
      <UserContext.Provider
        value={{
          isAuthenticated: authenticated,
          globalState: globalState,
          isLoading: isLoading,
          setIsLoading: setIsLoading,
          paymentInProgress: paymentInProgress,
          showDemoSlot: false,
          isTmprDemoCdp: false,
        }}
      >
        <SearchContextProvider>
          <AppContextProvider>
            <ToastProvider>
              <div onClick={handleTrackEvent}>
                <Component {...pageProps} />
              </div>
            </ToastProvider>
          </AppContextProvider>
        </SearchContextProvider>
      </UserContext.Provider>
    </>
  )
}

export default MyApp
