import React, { useEffect, useState } from "react"
import styles from "./style.module.scss"
import clsx from "clsx"
import Link from "next/link"
import dynamic from "next/dynamic"
import { isMobile } from "react-device-detect"
import Head from "next/head"
import { BASE_URL } from "src/constants"

const AppFooterV3 = dynamic(() => import("src/__components__/AppFooter/v3"))
let DynamicAppHeader = null

const About = (props) => {
  const [isAppHeader, setIsAppHeader] = useState(null)

  useEffect(() => {
    DynamicAppHeader = dynamic(() =>
      import("../../src/__components__/AppHeader")
    )
    setIsAppHeader(true)
  }, [])

  return (
    <>
      <Head>
        <title>BitClass - About Us</title>
        <meta
          name="description"
          content="We
          are facilitating live interactive learning for students from
          individual teachers and empowering them to build their cohorts."
        />
        <meta property="og:title" content="BitClass - About Us" />
        <meta
          property="og:description"
          content="We
          are facilitating live interactive learning for students from
          individual teachers and empowering them to build their cohorts."
        />
        <meta property="og:url" content={BASE_URL} />
        <meta
          property="og:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1615993070/Assets/IMG_20210308_195427_1_-min_oqs2z5.jpg"
        />
        <meta name="twitter:title" content="BitClass - About Us" />
        <meta
          name="twitter:description"
          content="We
          are facilitating live interactive learning for students from
          individual teachers and empowering them to build their cohorts."
        />
        <meta
          name="twitter:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1615993070/Assets/IMG_20210308_195427_1_-min_oqs2z5.jpg"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
      </Head>

      <div className={styles.aboutWrapper}>
        {isAppHeader && (
          <div className={styles.mainHeader}>
            <DynamicAppHeader page="about" props={props} isMobile={isMobile} />
          </div>
        )}

        <div className={styles.headerContainer}>
          <h1>Our Story</h1>
        </div>
        <div className={styles.bodyContainerWrapper}>
          <div className={styles.bodyFirstContainer}>
            <p>
              <span>15</span>th century Europe : <em>"Renaissance"</em> which
              translates into <em>"rebirth"</em> in French. The point in time
              widely regarded as the start of the modern age. Led by prominent
              scholars, artists and philosophers boundless knowledge was
              rediscovered and brought to light. This was a movement that gave
              rise to cultural heroes who were regarded as the "Renaissance Men
              and Women".
            </p>
          </div>

          <div
            className={clsx(
              styles.bodyFirstContainer,
              styles.bodySecondContainer
            )}
          >
            <p>
              <span>21</span>st Century, the internet : Numerous technological
              advancements later, we are now living in a hyperconnected world
              which is looking at reinventing and disrupting learning all over
              again. For too long now learning has been confined to the walls of
              institutions and pages of books accessible only to a few.
            </p>
          </div>
          <img
            alt="founder"
            src="https://res.cloudinary.com/bitclass/image/upload/v1615993070/Assets/IMG_20210308_195427_1_-min_oqs2z5.jpg"
          />

          <div
            className={clsx(
              styles.bodyFirstContainer,
              styles.bodySecondContainer,
              styles.bodyThirdContainer
            )}
          >
            <p>
              We at BitClass are pushing the proverbial boundaries to
              revolutionise learning - completely online, distributed,
              accessible and global. The heroes this time are{" "}
              <em>"teachers"</em> - individual teachers who are expressing
              themselves to the fullest to disseminate knowledge on the
              internet. Going beyond the traditional MOOCs and video content, we
              are facilitating live interactive learning for students from
              individual teachers and empowering them to build their cohorts. We
              are not stopping at that - we are building the biggest online,
              distributed ...&lt;watch out this space for more&gt;
              <br />
            </p>
            <p>
              or click
              <Link href="/live-courses/search">
                <a target="_blank">here</a>
              </Link>
              to learn something new.
            </p>
          </div>
          <div
            className={clsx(
              styles.bodyFirstContainer,
              styles.bodySecondContainer,
              styles.bodyThirdContainer,
              styles.fourthContainer
            )}
          >
            <p>
              "Welcome to BitClass - discover the best online live learning
              courses from teachers across the world."
            </p>
          </div>
        </div>
        <AppFooterV3 />
      </div>
    </>
  )
}

export default About
