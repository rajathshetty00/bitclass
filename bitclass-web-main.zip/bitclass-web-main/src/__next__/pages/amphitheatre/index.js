import { useUserAgent, withUserAgent } from "next-useragent"
import React, { useEffect, useLayoutEffect, useState } from "react"
import LiveStreamPlayer from "src/search-result-page/LiveStreamPlayer"
import AntFullScreenModal from "src/__components__/Modal/AntFullScreenModal"
import styles from "./styles.module.scss"
import { isMobile } from "react-device-detect"
import ReactPlayer from "react-player"
import usePageState from "src/homepage/hooks/usePageState"
import useAppContext from "context/AppContext/hooks/useAppContext"
import {
  getAmphiEventById,
  getParticipantsCount,
  getProfileByCode,
  getTeacherPublicProfile,
  markEventAttendence,
  getEventParticipantsCount,
} from "src/__utils__/api"
import { useRouter } from "next/router"
import { hasAuthToken } from "src/__utils__/auth"
import { TOGGLE_LOGIN_SCREEN } from "context/AppContext/types"
import LoginModal from "src/storefront/LoginScreen"
import AntBitModal from "src/__components__/Modal/AntBitModal"
import { PlayCircle } from "react-feather"
import PlayIcon from "src/freemium/common/PlayIcon"
import NextHead from "src/__components__/NextHead"
import { AMPHI_THEATRE_PAGE } from "src/__utils__/pages"
import LiveEvent from "src/search-result-page/LiveStreamPlayer/EndScreen/LiveEvent"
const Amphitheatre = ({ ua }) => {
  // const [showFullScreen, setShowFullScreen] = useState(false)
  const [liveUsers, setLiveUsers] = useState(0)
  const [teacher, setTeacher] = useState({})
  const [event, setEvent] = useState({})
  // const { userAgent } = usePageState()
  const { state, dispatch } = useAppContext()
  const [showModal, setShowModal] = useState(true)
  const { query } = useRouter()
  // useEffect(() => {
  const fetchData = async () => {
    try {
      const { data } = await getAmphiEventById(query.eventId)
      // const teacher = await getTeacherPublicProfile(data?.performer_code)
      const attendance = await markEventAttendence(query.eventId)
      const { count } = await getEventParticipantsCount(query.eventId)
      // console.log(count,'amphi')
      setTeacher(teacher.data)
      setEvent(data)
      setLiveUsers(count)
      // dispatch({type:TOGGLE_LOGIN_SCREEN,payload:false})
    } catch (error) {
      console.log(error)
    }
  }
  //   if(hasAuthToken()) fetchData()
  //   else{
  //     dispatch({type:TOGGLE_LOGIN_SCREEN,payload:true})
  //   }
  // }, [state.loggedIn])
  useEffect(() => {
    if (hasAuthToken()) fetchData()
    else {
      setShowModal(false)
      dispatch({ type: TOGGLE_LOGIN_SCREEN, payload: true })
    }
  }, [])
  // useEffect(() => {

  // }, [event])

  // const courseDetails
  // useEffect(() => {
  //   setTimeout(() => {
  //     setLiveUsers(5)
  //   }, 200)
  // }, [])
  // console.log(event.streaming_url)

  return (
    <>
      <NextHead page={AMPHI_THEATRE_PAGE} />
      {!showModal || ua.isMobile ? (
        <div className={styles.amphi}>
          {event?.streaming_url ? (
            <LiveStreamPlayer
              liveEvent={true}
              isMobile={ua?.isMobile}
              courseDetails={{ heading: event?.heading, teacher: false }}
              showFullScreen={true}
              liveStreamUrl={event?.streaming_url}
              videoModalDetails={false}
              liveUsers={liveUsers}
              customClass={styles.livestreamModalWrapper}
            />
          ):<LiveEvent isMobile={ua?.isMobile} eventNotFound/>}

          <LoginModal onLoginNext={() => window.location.reload()} />
        </div>
      ) : (
        <div className={styles.play}>
          <div className={styles.startBtn} onClick={() => setShowModal(false)}>
            <PlayIcon />
          </div>
        </div>
      )}
    </>
  )
}

Amphitheatre.getInitialProps = async (context) => {
  let ua
  let keyword
  let queryList
  let params

  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    ua = useUserAgent(context.req.headers["user-agent"])
  } else ua = { isMobile }

  let paramObj = {
    Platform: ua.isMobile ? "mweb" : "web",
  }
  params = new URLSearchParams(context.asPath?.split("?")[1])
  for (let value of params.keys()) {
    paramObj[value] = params.get(value)
  }

  return {
    ua,
    paramObj,
  }
}

export default withUserAgent(Amphitheatre)
