import React, {useEffect, useState} from 'react'
import styles from './style.module.scss'
import dynamic from 'next/dynamic'
import {isMobile} from 'react-device-detect'
import AppFooterV2 from 'src/__components__/AppFooter/v2'
import clsx from 'clsx'
import Head from 'next/head'
import {BASE_URL} from 'src/constants'

let DynamicAppHeader = null


const careersArray = [
  {type: 'Business', tag: '#a7d6ff', role: 'Sr. Business Analyst', exp: 'Exp - 3-6 yrs', resp: 'You will work closely with product and business teams to identify, define, collect, and track key business metrics for products and business processes.'},
  {type: 'Marketing', tag: '#a7a9ff', role: 'Marketing lead', exp: 'Exp - 3-6 yrs', resp: 'Looking at full stack digital marketer who drives all the market efforts at BitClass.'},
  {type: 'Business', tag: '#a7d6ff', role: 'Strategic Partnerships', exp: 'Exp - 4-6 yrs', resp: 'Some one from Broad-based business and strategic alliances background - driving the all the business partnerships at BitClass.'}
]

const Career = (props) => {

  const [isAppHeader, setIsAppHeader] = useState(null)

  useEffect(() => {
    DynamicAppHeader = dynamic(() => import('../../src/__components__/AppHeader'))
    setIsAppHeader(true)
  }, [])

  return (

    <>
      <Head>
        <title>
          BitClass - Join the band
        </title>
        <meta
          name="description"
          content="Visit our Careers section to send across your CVs and a short write up about yourself to hear back from us. We would love to see you become a part of our team !"
        />
        <meta
          property="og:title"
          content="BitClass - Join the band"
        />
        <meta
          property="og:description"
          content="Visit our Careers section to send across your CVs and a short write up about yourself to hear back from us. We would love to see you become a part of our team !"
        />
        <meta property="og:url" content={BASE_URL} />
        <meta
          property="og:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1616159509/Assets/collage-min_xwh7u9.png"
        />
        <meta
          name="twitter:title"
          content="BitClass - Join the band"
        />
        <meta
          name="twitter:description"
          content="Visit our Careers section to send across your CVs and a short write up about yourself to hear back from us. We would love to see you become a part of our team !"
        />
        <meta
          name="twitter:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1616159509/Assets/collage-min_xwh7u9.png"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
      </Head>


      <div className={styles.careerWrapper}>
        {isAppHeader && (
          <div className={styles.mainHeader}>
            <DynamicAppHeader
              page="careers"
              props={props}
              isMobile={isMobile}
            />
          </div>
        )}


        <div className={styles.headerSection}>
          <h1>Join the band</h1>
        </div>


        <div className={styles.bodySectionWrapper}>

          <div className={styles.bodySectionContainer}>

            <img src="https://res.cloudinary.com/bitclass/image/upload/v1616159509/Assets/collage-min_xwh7u9.png"
              alt="This is BitClass collage"
            />

            <p>
              These <em>'Catchphrases'</em> summarise the team - one so audacious that none of the folks take a 'maybe' for an answer-it is always a yes.
            "Doing the right thing" and "having a bias for action" are the two simple values that govern our day-to-day lives. And this has been the fuel powering us to chase even more audacious goals. 'Nuf said - send across your CVs and a short write up about yourself at <a href="mailto:hiring@bitclass.live">hiring@bitclass.live</a>  to hear back from us. We would love to see you become a part of our team !
          </p>
          </div>


          <div className={styles.bodySection}>
            <h2>
              Featured Jobs
          </h2>
            <div className={styles.gridContainer}>
              {careersArray.map((item) => (
                <div className={styles.card}>
                  <p style={{background: item.tag}} className={clsx(styles.tag)}>
                    {item.type}
                  </p>
                  <h5>{item.role}</h5>
                  <h6>{item.exp}</h6>
                  <p>
                    {item.resp}
                  </p>
                  <a href="mailto:hiring@bitclass.live">
                    Apply Now
              </a>
                </div>
              ))}
            </div>
          </div>
        </div>
        <AppFooterV2 />
      </div>

    </>
  )
}

export default Career
