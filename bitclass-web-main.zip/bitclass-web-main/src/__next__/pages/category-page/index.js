import { useUserAgent, withUserAgent } from "next-useragent"
import dynamic from "next/dynamic"
import { useEffect, useState } from "react"
import {
  getCourseByCategory,
  getCourses,
  getFree,
  getStarTeacherCourses,
} from "src/__utils__/api"
import styles from "./styles.module.scss"
import { isMobile } from "react-device-detect"
import { objectToQueryString } from "src/__utils__"
import { getCode } from "src/__utils__/auth"
import NextHead from "src/__components__/NextHead"
import { CATEGORY_PAGE } from "src/__utils__/pages"
import CategoryPageBanner from "../../src/category-page/Banner"
import CourseCardV2 from "src/storefront/CourseCard"
import AppFooterV3 from "src/__components__/AppFooter/v3"
import useCategories from "src/homepage/hooks/useCategories"
import NoResultsFound from "src/category-page/NoResultsFound"
import trackEvent from "src/__utils__/analytics"
import { BIT_EVENTS } from "config/events"
import useIntersectionObserver from "src/hooks/useIntersectionObserver"
import BitPureCarousel from "src/__components__/BitCarousel/BitCarousel"
import {
  FREE_CLASSES_CAROUSEL,
  FULL_COURSE_CAROUSEL,
  POPULAR_COURSES_CAROUSEL,
} from "src/category-page/utils"
import SkeletonCarousel from "src/homepage/Skeletons/SkeletonCarousel"
import { Spin } from "antd"

const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const CategoryPage = ({
  ua,
  paramObj,
  searchData,
  categoryName,
  categoryData,
  startTeacherArray,
  userAgent,
}) => {
  const { isIpad, isMobile, isTablet } = ua
  //handing app header background transition on scroll
  const [stopFetching, setStopFetching] = useState(false)
  const [dataFetching, setDataFetching] = useState(false)
  const [searchResults, setSearchResults] = useState(searchData || [])
  const [page, setPage] = useState(1)
  const [finalUrl, setFinalUrl] = useState("")
  const [startTeacherCourses, setStartTeacherCourses] =
    useState(startTeacherArray)
  const [freeClasses, setFreeClasses] = useState(null)
  const [fullCourses, setFullCourses] = useState(null)
  const [freshStarTeacherCourses, setFreshStarTeacherCourses] = useState([])
  const [freshFreeClasses, setFreshFreeClasses] = useState([])
  const [freshFullCourses, setFreshFullCourses] = useState([])
  const [pageNum, setPageNum] = useState(1)
  const [freePageNum, setFreePageNum] = useState(1)
  const [coursePageNum, setCoursePageNum] = useState(1)
  const [loading, setLoading] = useState(false)

  const [containerRef, isVisible] = useIntersectionObserver()
  const MIN_DATA_LIMIT = 8

  const PAGINATION_CONSTANT_POPULAR_COURSES_CAROUSEL = 18

  const handleAfterChange = async (index, type) => {
    trackEvent(BIT_EVENTS.CATEGORY_CAROUSEL_SCROLL, {
      student_id: getCode(),
      position: index,
      carousel_type: type,
    })

    switch (type) {
      case POPULAR_COURSES_CAROUSEL:
        if ((freshStarTeacherCourses?.length + index) % 9 === 0) {
          setPageNum(pageNum + 1)
        }
        return
      case FREE_CLASSES_CAROUSEL:
        if ((freshFreeClasses?.length + index) % 9 === 0) {
          setFreePageNum(freePageNum + 1)
        }
        return
      case FULL_COURSE_CAROUSEL:
        if ((freshFullCourses?.length + index) % 9 === 0) {
          setCoursePageNum(coursePageNum + 1)
        }
        return
      default:
        return
    }
  }

  useCategories()

  useEffect(() => {
    ;(async () => {
      if (searchData?.length < MIN_DATA_LIMIT) {
        setStopFetching(true)
      }
      trackEvent(BIT_EVENTS.CATEGORY_PAGE_VIEWED, {
        student_id: getCode(),
        page_type: "categories",
        category_name: categoryName,
      })
    })()
  }, [])

  useEffect(() => {
    setFinalUrl(objectToQueryString(paramObj))
  }, [paramObj])

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const { data } = await getStarTeacherCourses(
          encodeURIComponent(categoryName),
          pageNum
        )
        setStartTeacherCourses([...startTeacherCourses, ...data])
        setFreshStarTeacherCourses(data)
      } catch (error) {
      } finally {
        // setLoading(false)
      }
    })()
  }, [pageNum])

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const { data } = await getFree(categoryName, freePageNum)
        if (freeClasses === null) {
          setFreeClasses(data)
        } else {
          setFreeClasses([...freeClasses, ...data])
        }
        setFreshFreeClasses(data)
      } catch (error) {
      } finally {
        // setLoading(false)
      }
    })()
  }, [freePageNum])

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const { data } = await getCourses(categoryName, coursePageNum)
        if (fullCourses === null) {
          setFullCourses(data)
        } else {
          setFullCourses([...fullCourses, ...data])
        }
        setFreshFullCourses(data)
      } catch (error) {
      } finally {
        setLoading(false)
      }
    })()
  }, [coursePageNum])

  return (
    <div className={styles.container}>
      {/* next head */}
      <NextHead page={CATEGORY_PAGE} />
      {/* App header */}
      <div className={styles.header}>
        <AppHeader
          className={styles.stickyHeader}
          page={CATEGORY_PAGE}
          isMobile={isMobile}
          isTablet={isTablet || isIpad}
          showHamburgerMenu={true}
        />
      </div>
      <div className={styles.body}>
        {/* banner */}
        {(searchResults?.length > 0 || startTeacherCourses?.length > 0) && (
          <CategoryPageBanner categoryData={categoryData} />
        )}

        {/* search cards */}
        {startTeacherCourses?.length > 0 && (
          <>
            <div className={styles.starTeacherSection}>
              <h3 className={styles.title}>Popular Classes</h3>
              <BitPureCarousel
                isMobile={isMobile}
                handleAfterChange={(index) =>
                  handleAfterChange(index, POPULAR_COURSES_CAROUSEL)
                }
                customClass={styles.customSlider}
              >
                {startTeacherCourses.map((course) => (
                  <CourseCardV2
                    course={course}
                    page={CATEGORY_PAGE}
                    showFollowButton={false}
                    customClass={styles.popularCard}
                    key={course.code}
                    finalUrl={finalUrl}
                    sectionHeading="category_page_search_card"
                  />
                ))}
              </BitPureCarousel>
            </div>
          </>
        )}

        {/* Free carousel */}
        {freeClasses?.length > 0 && (
          <>
            <div className={styles.starTeacherSection}>
              <h3 className={styles.title}>Free Classes</h3>
              <BitPureCarousel
                isMobile={isMobile}
                handleAfterChange={(index) =>
                  handleAfterChange(index, FREE_CLASSES_CAROUSEL)
                }
                customClass={styles.customSlider}
              >
                {freeClasses.map((course) => (
                  <CourseCardV2
                    course={course}
                    page={CATEGORY_PAGE}
                    showFollowButton={false}
                    key={course.code}
                    finalUrl={finalUrl}
                    sectionHeading="category_page_free_course"
                  />
                ))}
              </BitPureCarousel>
            </div>
          </>
        )}

        {/* Full course carousel */}
        {fullCourses?.length > 0 && (
          <>
            <div className={styles.starTeacherSection}>
              <h3 className={styles.title}>Full Courses</h3>
              <BitPureCarousel
                isMobile={isMobile}
                handleAfterChange={(index) =>
                  handleAfterChange(index, FULL_COURSE_CAROUSEL)
                }
                customClass={styles.customSlider}
              >
                {fullCourses.map((course) => (
                  <CourseCardV2
                    course={course}
                    page={CATEGORY_PAGE}
                    showFollowButton={false}
                    key={course.code}
                    finalUrl={finalUrl}
                    sectionHeading="category_page_full_course"
                  />
                ))}
              </BitPureCarousel>
            </div>
          </>
        )}

        {freeClasses?.length <= 0 && fullCourses?.length <= 0 && (
          <NoResultsFound
            loading={loading}
            setLoading={setLoading}
            categoryName={categoryName}
          />
        )}

        {(freeClasses?.length > 0 || fullCourses?.length > 0) && (
          <NoResultsFound
            categoryName={categoryName}
            endOfScreen={true}
            loading={loading}
            setLoading={setLoading}
          />
        )}
        {loading && (
          <div className={styles.loader}>
            <Spin size="large" />
          </div>
        )}
      </div>
      {/* footer */}
      <AppFooterV3 />
    </div>
  )
}

CategoryPage.getInitialProps = async (context) => {
  let userAgent,
    searchResults = [],
    params,
    categories,
    startTeacherArray = []

  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    userAgent = useUserAgent(context.req.headers["user-agent"])
  } else userAgent = { isMobile }

  let paramObj = {
    platform: userAgent.isMobile ? "mweb" : "web",
  }

  if (context.asPath.includes("?")) {
    params = new URLSearchParams(context.asPath?.split("?")[1])
    for (let value of params.keys()) {
      paramObj[value] = params.get(value)
    }
  }

  try {
    searchResults = await getCourseByCategory(
      encodeURIComponent(context.query.categoryName),
      1
    )
  } catch (error) {}

  return {
    categoryName: decodeURI(context.query.categoryName),
    userAgent,
    searchData: searchResults?.data,
    categoryData: searchResults?.category_meta,
    asPath: context.asPath,
    paramObj,
    categories,
    startTeacherArray,
  }
}
export default withUserAgent(CategoryPage)
