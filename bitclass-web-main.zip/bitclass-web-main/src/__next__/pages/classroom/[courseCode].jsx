import { BASE_URL } from "src/constants"
import { nextRedirection } from "src/__utils__/nextRedirection"

const Classroom = () => {
  return <div />
}

export default Classroom

export const getServerSideProps = async (context) => {
  const { code } = context.query
  nextRedirection({
    context,
    location: `${BASE_URL}/live-classes/classroom/${code}`,
  })
}
