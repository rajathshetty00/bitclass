import React, { useState, useEffect } from 'react'
import styles from './style.module.scss'
import { Phone, AtSign } from 'react-feather'
import { isMobile } from 'react-device-detect'
import dynamic from 'next/dynamic'
import AppFooterV2 from 'src/__components__/AppFooter/v2'
import Head from 'next/head'
import {BASE_URL} from 'src/constants'
import AppFooterV3 from 'src/__components__/AppFooter/v3'

let DynamicAppHeader = null


const ContactUs = (props) => {

  const [isAppHeader, setIsAppHeader] = useState(null)

  useEffect(() => {
    DynamicAppHeader = dynamic(() => import('../../src/__components__/AppHeader'))
    setIsAppHeader(true)
  }, [])


  return (
    <>
  <Head>
  <title>BitClass - Contact Us</title>
        <meta
          name="description"
          content="Want to get in touch? We'd love to hear from you. Here's how you can reach us..."
        />
        <meta property="og:title" content="BitClass - Contact Us" />
        <meta
          property="og:description"
          content="Want to get in touch? We'd love to hear from you. Here's how you can reach us..."
        />
        <meta property="og:url" content={BASE_URL} />
        <meta
          property="og:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1616255763/Assets/miles-burke-idhx-MOCDSk-unsplash_l0rdkr.jpg"
        />
        <meta name="twitter:title" content="BitClass - Contact Us" />
        <meta
          name="twitter:description"
          content="Want to get in touch? We'd love to hear from you. Here's how you can reach us..."
        />
        <meta
          name="twitter:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1616255763/Assets/miles-burke-idhx-MOCDSk-unsplash_l0rdkr.jpg"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
  </Head>




    <div className={styles.contactUsWrapper}>

      {isAppHeader && (
        <div className={styles.mainHeader}>
          <DynamicAppHeader
            page="contact us"
            props={props}
            isMobile={isMobile}
          />
        </div>
      )}


      <div className={styles.headerSection}>
        <div className={styles.heading}>
          <h1>
            Get in touch
          </h1>
          <p>Want to get in touch? We'd love to hear from you. Here's how you can reach us...</p>
        </div>
      </div>

      <div className={styles.bodyWrapper}>
        <div className={styles.bodyContainer}>
          {/* <div className={styles.body}>
            <div className={styles.iconContainer}>
              <Phone />
            </div>
            <h6>Talk to us</h6>
            <p>Interested in teaching ? Just pick up the phone to chat with a member of our team.</p>
            <a href="tel:+91-8047186300"> +91-8047186300</a>
          </div> */}

          <div className={styles.body}>
            <div className={styles.iconContainer}>
              <AtSign />
            </div>
            <h6>Contact via e-mail</h6>
            <p>Sometimes you need a little help from your friends. Or our support representative. Don’t worry… we’re always here for you.</p>
            <a href="mailto:hello@bitclass.live"> hello@bitclass.live</a>
          </div>
        </div>
      </div>
      <AppFooterV3 />
    </div>
    </>
  )
}

export default ContactUs
