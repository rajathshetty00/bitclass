import dynamic from "next/dynamic"
import Head from "next/head"
import { useRouter } from "next/router"
import React from "react"
import { BASE_URL } from "src/constants"
import AppFooterV2 from "src/__components__/AppFooter/v2"
import AppFooterV3 from "src/__components__/AppFooter/v3"
import { PrimaryIconButton } from "src/__components__/Button"
import styles from "./styles.module.scss"

const AppHeader = dynamic(()=>import('src/__components__/AppHeader'),{ssr:false})

const CourseRemoved = () => {
  const router = useRouter()
  const TITLE='BitClass - Build A Successful Live Teaching Business | All-in-one Platform'
  const META_DESC='Live Online Course, Online Class, Live courses, BitClass Classes'
  return (
    <div>
      <Head>
        <title>BitClass - Build A Successful Live Teaching Business | All-in-one
          Platform</title>
        {/* <link rel="shortcut icon" href = "/static/favicon.ico"/> */}
        {/* Meta information */}
        <meta name="description" content={META_DESC} />
        <meta
          name="keywords"
          content={META_DESC}
        />
        <meta property="og:title" content={TITLE} />
        <meta property="og:description" content={META_DESC} />
       
        <meta name="twitter:title" content={TITLE} />
        <meta name="twitter:description" content={META_DESC} />

        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta property="og:site_name" content="BitClass" />

      </Head>
      <AppHeader/>
    <div className={styles.courseRemoved} style={{paddingBottom:'5rem'}}>
      <div className={styles.crMidSec}>
        <img src="/static/__assets__/courseRemoved.svg" alt=""/>
        <div className={styles.descriptionAndCta}>
          <h2>Course Removed!</h2>
          <div>Hey, seems like this course has been removed by the teacher</div>
          <div className={styles.checkoutText}>
          Want to explore more courses?
          </div>
          <PrimaryIconButton
            text="Discover Courses"
            onClick={() => {
              router.push(`/`)
            }}
          />
        </div>
      </div>
    </div>
    <AppFooterV3 />
    </div>
  )
}

export default CourseRemoved
