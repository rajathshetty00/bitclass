import { useUserAgent, withUserAgent } from "next-useragent"
import React, { useEffect, useState } from "react"
import AboutCourse from "src/expert-cdp/AboutCourse"
import Banner from "src/expert-cdp/Banner"
import Details from "src/expert-cdp/Details"
import FAQS from "src/expert-cdp/FAQ"
import Highlights from "src/expert-cdp/Highlights"
import Intro from "src/expert-cdp/Intro"
import Testimonials from "src/expert-cdp/Testimonials"
import Topics from "src/expert-cdp/Topics"
import VideoIntro from "src/expert-cdp/VideoIntro"
import styles from "./styles.module.scss"
import { isMobile } from "react-device-detect"
import AppFooterV2 from "src/__components__/AppFooter/v2"
import { Affix } from "antd"
import { getCourseData } from "src/expert-cdp/helper/getCourseData"
import ApplyNow from "src/expert-cdp/ApplyButton"
import Head from "next/head"
import { createUrlSlug, exists, sanitizeHtml } from "src/__utils__"
import { BASE_URL } from "src/constants"

const ExclusiveCdp = ({ nextUserAgent, course, introVideo, pageUrl }) => {
  const { isMobile } = nextUserAgent
  const [container, setContainer] = useState(null)
  useEffect(() => setContainer(window.innerHeight), [])
  const title = course?.heading
  const metaDesc = sanitizeHtml(course?.goal.slice(0, 350)||'')
  return (
    <div className={styles.masterClass}>
      <Head>
        <title>{title} | Live Online Course</title>
        {/* <link rel="shortcut icon" href = "/static/favicon.ico"/> */}
        {/* Meta information */}
        <meta name="description" content={metaDesc} />
        <meta
          name="keywords"
          content={`${title} | Live Online Course, Online Class, Live courses, BitClass Classes`}
        />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={metaDesc} />
        <meta
          property="og:image"
          content={course?.intro_meta_thumbnail || course?.teacher.image}
        />
        <meta property="og:url" content={pageUrl} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={metaDesc} />
        <meta
          name="twitter:image"
          content={course?.intro_meta_thumbnail || course?.teacher.image}
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta name="twitter:creator" content={course?.teacher.teacher_name} />
        <meta property="og:site_name" content="BitClass" />

        {/* Adding course schema  */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org/",
              "@type": "Course",
              name: title,
              description: metaDesc,
              provider: {
                "@type": "Organization",
                name: "BitClass",
                url: { BASE_URL },
              },
            }),
          }}
        />
        {/* --completed course schema-- */}

        {/* Adding FAQ schema  */}
        {exists(course?.faq) && (
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "FAQPage",
                name: "CDP FAQ",
                mainEntity: course?.faq.map((item) => {
                  return {
                    "@type": "Question",
                    name: item.que,
                    acceptedAnswer: {
                      "@type": "Answer",
                      text: item.ans,
                    },
                  }
                }),
              }),
            }}
          />
        )}
        {/* --completed FAQ schema-- */}

      </Head>

      <Banner
        teacher={course?.teacher}
        heading={course?.heading}
        courseCode={course?.code}
        isMobile={isMobile}
        introVideo={introVideo}
        bannerImage={course?.additional_info?.banner_image}
        course={course}
      />
      <Details
        course={course}
        courseCode={course?.code}
        isMobile={isMobile}
        startDate={course?.start_ts}
        endDate={course?.end_ts}
        amount={course?.amount}
        currency={course?.currency}
        totalLiveHours={course?.additional_info?.live_class_hours}
      />
      {isMobile && (
        <Affix offsetTop={container - 10}>
          <div className={styles.stickyBtnContainer}>
            <ApplyNow className={styles.stickyButton} courseCode={course.code} course={course}/>
          </div>
        </Affix>
      )}
      <VideoIntro
        teacher={course?.teacher}
        heading={course?.heading}
        video={introVideo}
        thumbnail={course?.intro_video_thumbnail}
        course={course}
      />
      {course?.goal && <AboutCourse courseDescription={course?.goal} course={course}/>}
      {course?.additional_info?.syllabus && (
        <Topics
          teacher={course?.teacher}
          topics={course?.additional_info?.syllabus}
        />
      )}
      {course?.highlights && <Highlights highlights={course?.highlights} />}
      <Intro
        isMobile={isMobile} 
        teacher={course?.teacher} 
        course={course}
        overlayColor = "rgb(249,250,252,1)"
      />
      {course?.testimonials && (
        <Testimonials testimonials={course?.testimonials} />
      )}
      <FAQS faqs={course?.faqs} />
      <AppFooterV2 />
    </div>
  )
}

ExclusiveCdp.getInitialProps = async (context) => {
  let nextUserAgent, pageUrl
  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    nextUserAgent = useUserAgent(context.req.headers["user-agent"])
  } else nextUserAgent = { isMobile }
  const { course, introVideo } = await getCourseData({ context })
  const { teacherName, slug, courseCode } = context.req.params
  if (course)
    pageUrl = `${BASE_URL}/live-classes/${createUrlSlug(
      course?.teacher?.username || teacherName
    )}/${createUrlSlug(course?.heading || slug)}/${course.code || courseCode}`
  return {
    nextUserAgent,
    course,
    introVideo,
    pageUrl,
  }
}

export default withUserAgent(ExclusiveCdp)
