import dynamic from "next/dynamic"
import React from "react"
import AppFooterV3 from "src/__components__/AppFooter/v3"
import styles from "./styles.module.scss"
const AppHeader = dynamic(() => import("src/__components__/AppHeader"),{ssr:false})

const FallbackPage = ({ page, pageName = "", pageTitle = '' }) => {
  return (
    <div className={styles.fallBack}>
      <AppHeader page={page}/>
      <div className={styles.body}>
        <div className={styles.left}>
          <h3>
          {`Sorry! At the moment there are no 
classes going on under Mandala`}
          </h3>
          <p>
            You may have mistyped the profile name or the page may have moved
          </p>
          <button>Discover Live Courses</button>
        </div>
        <div className={styles.right}></div>
      </div>
      <AppFooterV3 />
    </div>
  )
}

export default FallbackPage
