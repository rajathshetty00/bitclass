import React, { useEffect, useState } from "react"
import dynamic from "next/dynamic"
import FeedBanner from "src/feeds/Banner"
import NextHead from "src/__components__/NextHead"
import styles from "./styles.module.scss"
import { FEED_PAGE } from "src/__utils__/pages"
import { useUserAgent, withUserAgent } from "next-useragent"
import { convertUtmParams } from "src/__utils__"
import { getFeedById } from "src/__utils__/api"
import Discover from "src/feeds/Discover"
import Teachers from "src/feeds/Teachers"
import { useRouter } from "next/router"
import FeedCard from "src/feeds/FeedCard"
import FeedCardSkeleton from "src/feeds/FeedCards/FeedCardsSkeleton/FeedCardSkeleton"
import { ArrowLeft } from "react-feather"
import Fallback from "src/feeds/Fallback"

const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const FeedDownloadScreen = ({ initialPageState }) => {
  const [feed, setFeed] = useState({})
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const [noResultsPage, setNoResultsPage] = useState(false)

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const { data } = await getFeedById(router.query.feedId)
        if (Object.entries(data).length === 0 && data.constructor === Object)
          setNoResultsPage(true)
        setFeed(data)
        setLoading(false)
      } catch (error) {}
    })()
  }, [])

  return (
    <div className={styles.feed}>
      <div className={styles.header}>
        <NextHead page={FEED_PAGE} />
        <AppHeader
          className={styles.stickyHeader}
          page={FEED_PAGE}
          showHamburgerMenu={true}
          isMobile={initialPageState?.userAgent?.isMobile}
          isTablet={
            initialPageState?.userAgent?.isTablet ||
            initialPageState?.userAgent?.isIpad
          }
        />
      </div>
      <div className={styles.banner}>
        <FeedBanner />
      </div>
      <div className={styles.body}>
        <div className={styles.discover}>
          <div
            className={styles.returnBtnWeb}
            onClick={() => window.open("/content/feed", "_self")}
          >
            <ArrowLeft />
            <span>Go back to Campus Feed</span>
          </div>
          <div className={styles.discoverCard}>
          <Discover />
          </div>
        </div>
        <div className={styles.feedList}>
          {loading ? (
            <FeedCardSkeleton />
          ) : noResultsPage ? (
            <Fallback />
          ) : (
            <FeedCard feedData={feed} />
          )}
          <div
            className={styles.returnBtnMWeb}
            onClick={() => window.open("/content/feed", "_self")}
          >
            <ArrowLeft />
            <span>Go back to Campus Feed</span>
          </div>
        </div>
        <div className={styles.teachers}>
          <Teachers />
        </div>
      </div>
    </div>
  )
}

FeedDownloadScreen.getInitialProps = async (context) => {
  const { req } = context
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const userAgent = useUserAgent(
    req ? req.headers["user-agent"] : navigator.userAgent
  )

  const paramObj = convertUtmParams(context)
  const initialPageState = { userAgent, paramObj }
  return { initialPageState }
}
export default withUserAgent(FeedDownloadScreen)
