import React, { useEffect, useState } from "react"
import dynamic from "next/dynamic"
import FeedBanner from "src/feeds/Banner"
import NextHead from "src/__components__/NextHead"
import styles from "./styles.module.scss"
import { FEED_PAGE } from "src/__utils__/pages"
import { useUserAgent, withUserAgent } from "next-useragent"
import { convertUtmParams } from "src/__utils__"
import useSavePageState from "src/homepage/hooks/useSavePageState"
import { getFeedList } from "src/__utils__/api"
import FeedCards from "src/feeds/FeedCards"
import useIntersectionObserver from "src/hooks/useIntersectionObserver"
import useInfiniteScroll from "src/feeds/hooks/useInfiniteScroll"
import { LoadingOutlined } from "@ant-design/icons"
import FeedCardsSkeleton from "src/feeds/FeedCards/FeedCardsSkeleton"
import BitSvg from "src/__components__/BitSvg"
import Discover from "src/feeds/Discover"
import Teachers from "src/feeds/Teachers"
import useAppContext from "context/AppContext/hooks/useAppContext"
import {
  GET_MY_FOLLOWING_LIST,
  handleApiCall,
} from "src/homepage/helper/homepageAdapter"
import { SAVE_FOLLOWING_LIST } from "context/AppContext/types"
import useScrollPosition from "src/hooks/useScrollPosition"
import StickyBanner from "src/feeds/StickyBanner"
import clsx from "clsx"

const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const SCROLL_LIMIT_FOR_STICKY_CARDS = 156
const SCROLL_LIMIT_FOR_STICKY_HEADER = 140
const SCROLL_LIMIT_FOR_STICKY_HEADER_MWEB = 125

const Feeds = ({ initialPageState }) => {
  useSavePageState(initialPageState)
  const [containerRef, isVisible] = useIntersectionObserver()
  const { state: feeds, loading } = useInfiniteScroll(isVisible, getFeedList)
  const scrollPosition = useScrollPosition()
  const { dispatch } = useAppContext()

  useEffect(() => {
    ;(async () => {
      try {
        const { following } = await handleApiCall(GET_MY_FOLLOWING_LIST)
        if (following)
          dispatch({ type: SAVE_FOLLOWING_LIST, payload: following })
      } catch (error) {}
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const enableSticky = scrollPosition > SCROLL_LIMIT_FOR_STICKY_CARDS
  const enableStickyHeader = initialPageState?.userAgent?.isMobile
    ? scrollPosition >= SCROLL_LIMIT_FOR_STICKY_HEADER_MWEB
    : scrollPosition >= SCROLL_LIMIT_FOR_STICKY_HEADER

  return (
    <div className={styles.feeds}>
      <div className={styles.header}>
        <NextHead page={FEED_PAGE} />
        <AppHeader
          className={styles.stickyHeader}
          page={FEED_PAGE}
          showHamburgerMenu={true}
          isMobile={initialPageState?.userAgent?.isMobile}
          isTablet={
            initialPageState?.userAgent?.isTablet ||
            initialPageState?.userAgent?.isIpad
          }
        />
      </div>

      <div className={styles.banner}>
        <FeedBanner 
          isMobile = {initialPageState?.userAgent?.isMobile} 
          page={FEED_PAGE} 
        />
      </div>
      <div className={styles.banner}>
        {enableStickyHeader && 
          <StickyBanner
            isMobile = {initialPageState?.userAgent?.isMobile} 
            page={FEED_PAGE} 
         />}
      </div>
      <div
        className={clsx(enableStickyHeader && styles.stickyBanner, styles.body)}
      >
        <div className={styles.discover}>
          <div className={enableSticky && styles.stickyDiscoverCard}>
            <Discover />
          </div>
        </div>
        <div className={styles.feedList}>
          {loading ? <FeedCardsSkeleton /> : <FeedCards feeds={feeds} />}
        </div>
        <div className={styles.teachers}>
          <div className={enableSticky && styles.stickyTeachersCard}>
            <Teachers />
          </div>
        </div>
      </div>

      {loading && (
        <div className={styles.loading}>
          <LoadingOutlined style={{ fontSize: 24 }} spin />
        </div>
      )}

      {!loading && (
        <div className={styles.bottom}>
          <BitSvg src="tickCircularOutlined.svg" />
          <span>You’re All Caught Up</span>
        </div>
      )}
      {/* End */}
      {feeds.length > 0 && (
        <div ref={containerRef} style={{ height: "1rem" }} />
      )}
    </div>
  )
}

Feeds.getInitialProps = async (context) => {
  const { req } = context
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const userAgent = useUserAgent(
    req ? req.headers["user-agent"] : navigator.userAgent
  )

  const paramObj = convertUtmParams(context)
  const initialPageState = { userAgent, paramObj }
  return { initialPageState }
}
export default withUserAgent(Feeds)
