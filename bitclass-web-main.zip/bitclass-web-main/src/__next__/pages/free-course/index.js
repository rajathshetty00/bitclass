import React, { useEffect, useState } from "react"
import SeeMore from "src/__components__/SeeMore"
import trackEvent from "src/__utils__/analytics"
import { useUserAgent, withUserAgent } from "next-useragent"
import styles from "./styles.module.scss"
import { API_URL, BASE_URL } from "src/constants"
import dynamic from "next/dynamic"
import { getCode, getUID, hasAuthToken } from "src/__utils__/auth"
import FreeCourseModal from "src/cdp/FreeCourse/FreeCourseModal"
import dayjs from "dayjs"
import { useRouter } from "next/router"
import Head from "next/head"
import {
  exists,
  getUrlParametersAsArray,
  sanitizeHtml,
  saveAnalyticsData,
} from "src/__utils__"
import { getLiveUserCount } from "src/__utils__/api"
// import SuccessModal from "src/profile/__components__/SuccessModal"
import { UserContext } from "context/User"
import { BIT_EVENTS } from "config/events"

const DynamicAppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})
const RegisterButton = dynamic(() => import("src/payment/RegisterButton"), {
  ssr: false,
})

const SuccessModal = dynamic(
  () => import("src/profile/__components__/SuccessModal"),
  {
    ssr: false,
  }
)

const FreeClassCdp = (props) => {
  const { course, profile, ua } = props

  const { isMobile } = ua
  const router = useRouter()

  const [SuccessModalFlag, setSuccessModalFlag] = useState(false)
  const [windowAvailable, setWindowAvailable] = useState(false)
  const [showNotifyModal, setShowNotifyModal] = useState(false)
  const [share, setShare] = useState(false)
  const [trackingBaseData, setTrackingBaseData] = useState({})

  const startDate = dayjs.unix(course?.start_ts).format("D MMM")
  const startTime =
    course && course.weekly_schedule && course.weekly_schedule.length > 0
      ? dayjs.unix(course.weekly_schedule[0]).format("h:mm A")
      : ""
  const endTime =
    course && course.weekly_schedule && course.weekly_schedule.length > 0
      ? dayjs
          .unix(course.weekly_schedule[0])
          .add(course?.course_schedule?.lesson_duration, "minute")
          .format("h:mm A")
      : ""

  const isRegistered =
    windowAvailable && course?.students?.includes(parseInt(getUID(), 10))

  //  const UserState = useContext(UserContext)

  useEffect(() => {
    if (window) setWindowAvailable(true)
    let urlParams = getUrlParametersAsArray(window.location.href)
    let baseTracking = {
      source: exists(urlParams["source"]) ? urlParams["source"] : "direct",
      student_id: getCode(),
      course_title: course?.heading,
      course_price: course?.amount,
      course_code: course?.code,
      course_time_schedule: course?.weekly_schedule
        ? course?.weekly_schedule.map((ws) => dayjs.unix(ws).format("hh:mm a"))
        : [],
      course_start_date: course?.start_ts
        ? dayjs.unix(course?.start_ts).format("YYYY-MM-DD")
        : "",
      course_end_date: course?.end_ts
        ? dayjs.unix(course?.end_ts).format("YYYY-MM-DD")
        : "",
      teacher_name: course?.teacher?.username,
      course_type: "workshops",
      course_category: [],
      cdp_type: "free_classes",
      tmpr_code: "",
    }
    setTrackingBaseData(baseTracking)
    trackEvent(BIT_EVENTS.CDP_VIEWED, baseTracking)
    saveAnalyticsData(baseTracking)
  }, [])

  const handleShare = () => {
    setShowNotifyModal(true)
    setShare(true)
  }

  const RenderNotifyButton = () => {
    if (course?.is_class_live)
      return (
        <button
          className={styles.notify}
          onClick={() => {
            trackEvent("join_my_class_button_clicked", {
              course_code: course.code,
              course_title: course.heading,
              is_live: true,
            })((window.location.href = BASE_URL + `/classroom/${course.code}`))
          }}
        >
          Join Live Class
        </button>
      )
    else
      return (
        <button
          className={styles.notify}
          onClick={() => {
            trackEvent("join_my_class_button_clicked", {
              course_code: course.code,
              course_title: course.heading,
              is_live: true,
            })
            window.location.href =
              BASE_URL + `/course/summary/${course.code}#chats`
          }}
        >
          Join Live Class
        </button>
      )
  }

  const details = sanitizeHtml((course?.goal || "").substring(0, 100)) || ""
  const metaDesc = `Enrol into this FREE live instructor-led course online on BitClass. ${details}`
  const title = course.heading || ""
  const intro_meta_thumbnail = course?.intro_video_thumbnail

  const DEFAULT_BACKGROUND_IMAGE = "/static/__assets__/default.svg"
  const DEFAULT_TEACHER_PROFILE_IMAGE =
    "https://res.cloudinary.com/bitclass/image/upload/v1617482858/Assets/defaultAvatar_yakmah.png"

  const [liveUsers, setLiveUsers] = useState(0)
  useEffect(() => {
    const fetchLiveUserCount = async () => {
      try {
        const { count } = await getLiveUserCount(course.code)
        if (count > 0) setLiveUsers(count)
      } catch (error) {
        console.error(`error`, error)
      }
    }
    fetchLiveUserCount()
  }, [])

  return (
    <div className={styles.freeCourseContainer}>
      <Head>
        <title>{title} | Free CDP Course</title>
        {/* <link rel="shortcut icon" href = "/static/favicon.ico"/> */}
        {/* Meta information */}
        <meta name="description" content={metaDesc} />
        <meta
          name="keywords"
          content={`${title} | Live Online Course, Online Class, Live courses, BitClass Classes`}
        />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={metaDesc} />
        <meta
          property="og:image"
          content={intro_meta_thumbnail || profile?.teacher?.image}
        />
        <meta property="og:url" content={props.pageUrl} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={metaDesc} />
        <meta
          name="twitter:image"
          content={intro_meta_thumbnail || profile?.teacher?.image}
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta name="twitter:creator" content={profile?.teacher?.teacher_name} />
        <meta property="og:site_name" content="BitClass" />

      </Head>
      <DynamicAppHeader
        className={styles.header}
        page="free-course"
        isMobile={isMobile}
        props={props}
        darkMode={true}
      />
      <UserContext.Consumer>
        {(User) => {
          if (User.globalState.status === "done") {
            setSuccessModalFlag(true)
            User.paymentInProgress({ status: false, courseCode: "" })
          }
          return (
            <>
              <div className={styles.container}>
                <div className={styles.desktopRightSection}>
                  <img
                    src={`${
                      course.intro_video_thumbnail || DEFAULT_BACKGROUND_IMAGE
                    }`}
                    style={{
                      objectFit: "cover",
                      width: "100%",
                      height: isMobile ? "216px" : "270px",
                    }}
                    alt="this is free course thumbnail"
                  />

                  {isMobile ? (
                    <div className={styles.titleContainer}>
                      <h3 className={styles.freeTag}>FREE</h3>
                      <h3>{course.heading}</h3>
                      <div className={styles.dateContainer}>
                        <div className={styles.date}>
                          <img
                            src="/static/__assets__/calendarIcon.svg"
                            alt="date"
                            width="10"
                          />
                          <span>Date and Time</span>
                        </div>
                        <div className={styles.dateTime}>
                          {`Daily, ${startTime} - ${endTime}`}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className={styles.desktopTeacherContainer}>
                      <div className={styles.iconText}>
                        <img
                          src={
                            course.teacher?.image ||
                            DEFAULT_TEACHER_PROFILE_IMAGE
                          }
                          alt="teacher"
                        />
                        <span className={styles.teacherName}>
                          {profile?.username}
                        </span>
                      </div>
                      <div className={styles.teacherDetails}>
                        <SeeMore
                          text={profile?.story}
                          size={7}
                          trackEvent={() => {
                            trackEvent(
                              BIT_EVENTS.CDP_TEACHER_DESCRIPTION_SHOW_MORE_CLICKED,
                              trackingBaseData
                            )
                          }}
                        >
                          <span
                            dangerouslySetInnerHTML={{
                              __html: profile?.story,
                            }}
                          ></span>
                        </SeeMore>
                      </div>
                    </div>
                  )}
                </div>
                <div className={styles.desktopLeftSection}>
                  {!isMobile && (
                    <div className={styles.titleContainer}>
                      <h3 className={styles.freeTag}>FREE</h3>
                      <h3>{course.heading}</h3>
                      <div className={styles.dateContainer}>
                        <div className={styles.date}>
                          <img
                            src="/static/__assets__/calendarIcon.svg"
                            alt="date"
                            width="10"
                          />
                          {/* <span>Date and Time</span> */}
                          <span>Daily</span>
                        </div>
                        {/* <div
                  className={styles.dateTime}
                >{`${startDate}, ${startTime} - ${endTime}`}</div>{" "} */}
                      </div>
                    </div>
                  )}
                  <div className={styles.description}>
                    <div>
                      {exists(course.goal) ? (
                        <SeeMore
                          text={course.goal}
                          size={20}
                          trackEvent={() => {
                            trackEvent(
                              BIT_EVENTS.CDP_SHOW_MORE_CLICKED,
                              trackingBaseData
                            )
                          }}
                        >
                          <span
                            dangerouslySetInnerHTML={{
                              __html: course.goal,
                            }}
                          ></span>
                        </SeeMore>
                      ) : (
                        // sanitizeHtml(course.goal.slice(0, 600))
                        ""
                      )}
                    </div>
                  </div>

                  {isMobile && (
                    <div className={styles.teacherContainer}>
                      <div className={styles.iconText}>
                        <img
                          src={
                            course.teacher?.image ||
                            DEFAULT_TEACHER_PROFILE_IMAGE
                          }
                          alt="teacher"
                        />
                        <span>{profile?.username}</span>
                      </div>
                      <div className={styles.teacherDetails}>
                        <SeeMore text={profile?.story} size={4}>
                          <span
                            dangerouslySetInnerHTML={{
                              __html: profile?.story || "",
                            }}
                          ></span>
                        </SeeMore>
                      </div>
                    </div>
                  )}

                  <div className={styles.buttonContainer}>
                    {windowAvailable && hasAuthToken() && isRegistered ? (
                      <RenderNotifyButton />
                    ) : (
                      <RegisterButton
                        btnClass={styles.notify}
                        course={course}
                        profile={profile}
                        containerClass={styles.freeCourseRegBtn}
                        text={
                          isMobile
                            ? "Join this class"
                            : "Join this class for Free"
                        }
                        trackPreRegister={true}
                        trackEvtName={BIT_EVENTS.CDP_JOIN_CLICKED}
                        trackPayload={trackingBaseData}
                      />
                    )}
                    <button className={styles.share} onClick={handleShare}>
                      <div className={styles.btnContent}>
                        <img
                          src="/static/__assets__/shareIconGreen.svg"
                          alt="share"
                        />
                        <span>Share</span>
                      </div>
                    </button>
                  </div>
                  {
                    <FreeCourseModal
                      isMobile={isMobile}
                      share={share}
                      course={course}
                      windowAvailable={windowAvailable}
                      courseCode={course.code}
                      isModalVisible={showNotifyModal}
                      handleCancel={() => setShowNotifyModal(false)}
                    />
                  }
                </div>
              </div>
              <SuccessModal
                SuccessModalFlag={SuccessModalFlag}
                setSuccessModalFlag={setSuccessModalFlag}
                status={"success"}
                course={course}
                courseCode={course?.code}
              />
            </>
          )
        }}
      </UserContext.Consumer>
    </div>
  )
}

FreeClassCdp.getInitialProps = async (context) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const ua = useUserAgent(context.req.headers["user-agent"])
  const { courseCode } = context.query
  let _course
  let resCourse
  try {
    if (courseCode !== undefined) {
      resCourse = await fetch(`${API_URL}/v2/courses/${courseCode}`)
      _course = await resCourse.json()
      if (_course?.data?.amount > 0) {
        context.res.writeHead(302, {
          Location: `/${_course.data?.teacher?.teacher_handle}/${_course.data?.code}`,
          "Content-Type": "text/html; charset=utf-8",
        })
        context.res.end()
      }
    }
    if (!_course.success || courseCode === undefined || !_course) {
      context.res.writeHead(302, {
        Location: "/course-not-found",
        "Content-Type": "text/html; charset=utf-8",
      })
      context.res.end()
    }
  } catch (e) {
    console.error(e)
  }

  return {
    profile: _course?.data?.teacher,
    course: _course?.data,
    ua,
  } // will be passed to Id react component as props
}
export default withUserAgent(FreeClassCdp)
