import { useUserAgent, withUserAgent } from "next-useragent"
import { isMobile } from "react-device-detect"
import { getCourseData } from "src/freemium/apiController/getCourseData"
import React, { useEffect, useState } from "react"
import AboutSection from "src/freemium/AboutSection"
import Heading from "src/freemium/common/Heading"
import HowItWorks from "src/freemium/HowItWorks"
// import PrimaryCTAsection from "src/freemium/PrimaryCTAsection"
import StartEndDetails from "src/freemium/StartEndDetails"
// import TopSection from "src/freemium/TopSection"
import VideoSection from "src/freemium/VideoSection"
import Timeline from "src/freemium/Timeline"
import styles from "./style.module.scss"
import IncludesSection from "src/freemium/IncludesSection"
import LiveSection from "src/freemium/LiveSection"
import FreemiumAccordion from "src/freemium/FreemiumAccordion"
import Highlights from "src/expert-cdp/Highlights"
import Intro from "src/expert-cdp/Intro"
import Testimonials from "src/expert-cdp/Testimonials"
import FAQS from "src/expert-cdp/FAQ"
import {
  appendWidthToUrl,
  exists,
  getCookie,
  getThumbnailFromUrl,
  getUrlParametersAsArray,
  sanitizeHtml,
  setCookie,
} from "src/__utils__"
import { FREEMIUM_PAGE } from "src/__utils__/pages"
import clsx from "clsx"
import dynamic from "next/dynamic"
import WeeklyScheduleContainer from "src/freemium/common/WeeklySchedule"
import { getCourse, getFreemiumData, getCookieData } from "src/__utils__/api"
import Head from "next/head"
import { get } from "lodash"
import { API_URL, BASE_URL } from "src/constants"
import { BIT_EVENTS } from "config/events"
import trackEvent from "src/__utils__/analytics"
import { getCode } from "src/__utils__/auth"
import dayjs from "dayjs"
import NotifyCourseModal  from "src/__components__/NotifyCourseModal"

const DynamicAppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})


const DynamicTopSection = dynamic(() => import("src/freemium/TopSection"), {
  ssr: false,
})

const PrimaryCTAsection = dynamic(
  () => import("src/freemium/PrimaryCTAsection"),
  {
    ssr: false,
  }
)

const Freemium = ({
  courseProp,
  introVideo,
  thumbnail,
  nextUserAgent,
  url,
  featureInclusion,
  liveSessions,
  courseLearning,
  trackPreRegister,
  weeklySchedule,
  freemiumData,
  ...props
}) => {
  const { isMobile } = nextUserAgent

  const [freemium, setFreemium] = useState(null)
  const [course, setCourse] = useState(courseProp)
  const [trackingBaseData, setTrackingBaseData] = useState({})
  const [priceCookie , setPriceCookie] = useState(null)

  // state

  // handlers

  // hooks
  useEffect(() => {
    let urlParams = getUrlParametersAsArray(window.location.href)     
    async function fetchData() {
      // You can await here
      const { data, success } = await getFreemiumData(course?.code)
      if (success) {
        setFreemium(data)
      }
      setTrackingBaseData({
        source: exists(urlParams["source"]) ? urlParams["source"] : "direct",
        student_id: getCode(),
        course_title: course?.heading,
        course_price: course?.amount,
        course_code: course?.code,
        course_time_schedule: course?.weekly_schedule
          ? course?.weekly_schedule.map((ws) => dayjs.unix(ws).format("hh:mm a"))
          : [],
        course_start_date: course?.start_ts
          ? dayjs.unix(course?.start_ts).format("YYYY-MM-DD")
          : "",
        course_end_date: course?.end_ts
          ? dayjs.unix(course?.end_ts).format("YYYY-MM-DD")
          : "",
        teacher_name: course?.teacher?.username,
        course_type: "courses",
        course_category: [],
        cdp_type: "freemium",
        tmpr_code: "",
        exp_id: getCookie('bitclass_ab')  
      })     
    }
    fetchData()

    trackEvent(BIT_EVENTS.CDP_VIEWED, {
      source: exists(urlParams["source"]) ? urlParams["source"] : "direct",
      student_id: getCode(),
      course_title: course?.heading,
      course_price: course?.amount,
      course_code: course?.code,
      course_time_schedule: course?.weekly_schedule
        ? course?.weekly_schedule.map((ws) => dayjs.unix(ws).format("hh:mm a"))
        : [],
      course_start_date: course?.start_ts
        ? dayjs.unix(course?.start_ts).format("YYYY-MM-DD")
        : "",
      course_end_date: course?.end_ts
        ? dayjs.unix(course?.end_ts).format("YYYY-MM-DD")
        : "",
      teacher_name: course?.teacher?.username,
      course_type: "courses",
      course_category: [],
      cdp_type: "freemium",
      tmpr_code: "",
      exp_id: getCookie('bitclass_ab')
    })

    // this is cookie used for a/b expt
    const getFreemiumPriceBasedCookie = getCookie('bitclass_ab')
  }, [])


  useEffect(()=>{
    if(exists(freemium)){
      async function fetchData(){
        // a/b testing
        let cookieApi =  await fetch(`${API_URL}/v2/experiments/trial/${course?.code}`, {
         credentials: "include"
       })
       let getCourseCookie
       cookieApi = await cookieApi.json()
       if(cookieApi.cookie){
        setCookie('bitclass_ab' ,cookieApi.cookie,  365)
        getCourseCookie = cookieFinder(cookieApi.cookie)
       }
       if(getCourseCookie){
        setPriceCookie(getCourseCookie)
       }
     }
     fetchData()
    }
  }, [freemium])

// a/b tests
const cookieFinder = (giantCookie) => {
  let cookieArrayList = giantCookie.split('+')
   if(freemium && freemium.experiment_id){
    return cookieArrayList.find((item, index)=>item.includes(freemium.experiment_id))
     }
 }



// accordion header click handler


  // constants
  let title = get(course, "heading", "")
  let teacher = get(course, "profile", {})
  
  let intro_meta_thumbnail = exists(get(course, "intro_video_thumbnail", null))
  ? appendWidthToUrl(get(course, "intro_video_thumbnail", ""))
  : getThumbnailFromUrl(get(course, "intro_video", ""), true)
  let aboutCourse = get(course, "goal", "")
  let metaDesc = sanitizeHtml(aboutCourse.substring(0, 80))
  
  const _teacherName = course?.teacher_name
  const _teacherHandle = course?.teacher?.teacher_handle

  return (
    <div className={styles.freemiumWrapper}>
      <Head>
        <title>{title} | Live Online Course</title>
        <meta name="description" content={metaDesc} />
        <meta
          name="keywords"
          content={`${title} | Live Online Course, Online Class, Live courses, BitClass Classes`}
        />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={metaDesc} />
        <meta
          property="og:image"
          content={intro_meta_thumbnail || teacher.image}
        />
        <meta property="og:url" content={props.pageUrl} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={metaDesc} />
        <meta
          name="twitter:image"
          content={intro_meta_thumbnail || teacher.image}
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta name="twitter:creator" content={teacher.teacher_name} />
        <meta property="og:site_name" content="BitClass" />
      </Head>

      <header>
        <DynamicAppHeader
          className={styles.header}
          page={FREEMIUM_PAGE}
          isMobile={isMobile}
          props={props}
          darkMode={false}
        />
      </header>

      <div className={styles.gridContainer1}>
        <div className={styles.overlay}></div>
        <VideoSection
          isMobile={isMobile}
          course={course}
          introVideo={introVideo}
          thumbnail={thumbnail}
          url={url}
          customClass={styles.videoSectionRoot}
          trackingBaseData={trackingBaseData}
        />
        <div className={styles.secondTopColumn}>
          <DynamicTopSection
            courseLearning={courseLearning}
            course={course}
            customClass={styles.topSectionRoot}
            weeklySchedule={weeklySchedule}
            isMobile={isMobile}
            url={url}
            priceCookie = {priceCookie}
            trackingBaseData={trackingBaseData}
          />
          {/* CTAs in desktop */}
          {!isMobile && freemium && (
            <div className={styles.flexCTA}>
              <PrimaryCTAsection
                course={freemium}
                customClass={styles.primaryCTAsectionRoot}
                trackingBaseData={trackingBaseData}
              />
              {freemium?.has_ended ? (
                <NotifyCourseModal teacherName={_teacherName} teacherHandle={_teacherHandle} courseCode={course?.code}/>
              ) : (
                <HowItWorks
                  wrapperClass={styles.HowItWorksRoot}
                  trackingBaseData={trackingBaseData}
                />
              )}
            </div>
          )}

          {/* CTAs in mweb */}
          {isMobile && freemium && (
            <>
              <PrimaryCTAsection
                customClass={styles.primaryCTAsectionRoot}
                course={freemium}
                trackPreRegister={trackPreRegister}
                trackingBaseData={trackingBaseData}
              />
              {freemium?.has_ended&&<NotifyCourseModal teacherName={_teacherName} teacherHandle={_teacherHandle} className={styles.notification} courseCode={course?.code}/>}
              <HowItWorks
                trackingBaseData={trackingBaseData}
                wrapperClass={styles.HowItWorksRoot}
              />
            </>
          )}
        </div>
      </div>
      {/* {weeklySchedule && (
        <StartEndDetails customClass={styles.startEndDetailsWrapper}>
          <WeeklyScheduleContainer
            weeklySchedule={weeklySchedule}
            customClass={styles.weeklyScheduleRoot}
          />
        </StartEndDetails>
      )} */}

      <div className={styles.container}>
        <Heading
          text={
            <p>
              About the <span>Course</span>
            </p>
          }
        />
        <div className={clsx(styles.gridContainer1, styles.gridContainer2)}>
          <AboutSection
            course={course}
            isMobile={isMobile}
            customClass={styles.marginAdder}
            trackingBaseData={trackingBaseData}
          />
          <div>
            <Timeline
              course={course}
              format1="MMM DD"
              format2="MMM DD, YYYY"
              customClass={styles.timelineRoot}
            />
            <IncludesSection featureInclusion={featureInclusion} />
          </div>
        </div>

        <Heading
          text={
            <p>
              Course <span>schedule </span>and <span> structure</span>{" "}
            </p>
          }
        />
        {exists(liveSessions) && liveSessions.length > 0 && (
          <LiveSection
            liveSessions={liveSessions}
            customClass={styles.liveSectionRoot}
          />
        )}
        {course?.meta?.course_index && (
          <FreemiumAccordion
            arrayList={course?.meta?.course_index}
            customClass={styles.freemiumAccordionRoot}
            trackingBaseData={trackingBaseData}
            // headerClick = {(e)=>accordionHeaderClick(e)}
          />
        )}

        {course?.highlights && (
          <Highlights
            customClass={styles.highlightsWrapper}
            highlights={course?.highlights}
          />
        )}
      </div>
      <Intro
        isMobile={isMobile}
        teacher={course?.teacher}
        course={course}
        page={FREEMIUM_PAGE}
        customClass={styles.freemiumIntro}
        overlayColor="rgb(255,255,255,1)"
      />
      {/* <div className={styles.container}> */}
      {course?.testimonials && (
        <Testimonials testimonials={course?.testimonials} />
      )}
      {course?.faqs && <FAQS faqs={course?.faqs} />}
      {/* </div> */}
    </div>
  )
}

Freemium.getInitialProps = async (context) => {
  let nextUserAgent, pageUrl
  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    nextUserAgent = useUserAgent(context.req.headers["user-agent"])
  } else nextUserAgent = { isMobile }
  const {
    courseProp,
    slug,
    introVideo,
    thumbnail,
    url,
    featureInclusion,
    liveSessions,
    courseLearning,
    weeklySchedule,
    freemiumData,
  } = await getCourseData(context)
  return {
    nextUserAgent,
    courseProp,
    slug,
    introVideo,
    thumbnail,
    url,
    featureInclusion,
    liveSessions,
    courseLearning,
    weeklySchedule,
    trackPreRegister: true,
    freemiumData,
  }
}

export default withUserAgent(Freemium)
