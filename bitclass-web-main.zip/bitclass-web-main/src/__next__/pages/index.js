import { useUserAgent, withUserAgent } from "next-useragent"
import dynamic from "next/dynamic"
import { useContext, useEffect, useRef, useState } from "react"
import BitSearch from "src/homepage/BitSearch"
import Categories from "src/homepage/categories"
import useSavePageState from "src/homepage/hooks/useSavePageState"
import NextHead from "src/__components__/NextHead"
import { getAllCategories } from "src/__utils__/api"
import { HOMEPAGE } from "src/__utils__/pages"
import styles from "./style.module.scss"
import { convertUtmParams, getParamObj } from "src/__utils__/index"
// import CoursesCarousel from "src/homepage/Courses"
import FeedContainer from "src/homepage/FeedCard"
import HomepageAppDownloadSection from "src/homepage/HomepageAppDownload"
// import FeedHeader from "src/homepage/FeedHeader"
// import CampusFeed from "src/homepage/CampusFeed"
// import TeachOnBitClass from "src/homepage/TeachOnBitClass"
// import AppFooterV3 from "src/__components__/AppFooter/v3"
import useFollow from "src/storefront/utils/useFollow"
import { AppContext } from "context/AppContext/AppContext"
import {
  GET_MY_FOLLOWING_LIST,
  handleApiCall,
} from "src/homepage/helper/homepageAdapter"
import { SAVE_FOLLOWING_LIST } from "context/AppContext/types"
// import Testimonials from "src/homepage/Testimonials"
import trackEvent from "src/__utils__/analytics"
import { BIT_EVENTS } from "config/events"
import { getCode } from "src/__utils__/auth"
import { BASE_URL } from "src/constants"
import { isMobile } from "react-device-detect"

const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})
const CoursesCarousel = dynamic(() => import("src/homepage/Courses"))
const TeacherCarousel = dynamic(() => import("src/homepage/TeacherCarousel"))
const LoginModal = dynamic(() => import("src/storefront/LoginScreen"))
const FeedHeader = dynamic(() => import("src/homepage/FeedHeader"))
const CampusFeed = dynamic(() => import("src/homepage/CampusFeed"))
const TeachOnBitClass = dynamic(() => import("src/homepage/TeachOnBitClass"))
const AppFooterV3 = dynamic(() => import("src/__components__/AppFooter/v3"))
const Testimonials = dynamic(() => import("src/homepage/Testimonials"))

const BitHome = ({ initialPageState }) => {
  useSavePageState(initialPageState)

  const { state, dispatch } = useContext(AppContext)
  const { afterLogin } = useFollow(state.teacherCode)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [categories, setCategories] = useState([])

  useEffect(() => {
    ;(async () => {
      try {
        const { following } = await handleApiCall(GET_MY_FOLLOWING_LIST)
        if (following)
          dispatch({ type: SAVE_FOLLOWING_LIST, payload: following })
      } catch (error) {}
      try {
        const { data } = await getAllCategories()
        setCategories(data)
      } catch (error) {}
      try {
        trackEvent(BIT_EVENTS.HOMEPAGE_VIEWED, {
          student_id: getCode(),
        })
      } catch (error) {}
    })()

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const storeUrl = initialPageState?.userAgent?.isIphone
    ? `https://apps.apple.com/in/app/bitclass/id1537353964`
    : `https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=mweb&utm_medium=mweb-classroom-student&utm_campaign=gplayicon`

  const handleLoginNext = () => {
    if (state?.selectedLiveEvent?.id) {
      window.location.href =
        BASE_URL + "/amphitheatre/events/" + state?.selectedLiveEvent?.id
      return
    }
    if (state?.liveCourseCode) {
      window.location.href = `${BASE_URL}/classroom/${state?.liveCourseCode}`
      return
    }
    afterLogin()
  }

  const teacherCarouselRef = useRef()

  return (
    <div className={styles.home}>
      <div className={styles.header}>
        <NextHead page={HOMEPAGE} />
        <AppHeader
          // className={styles.header}
          className={styles.stickyHeader}
          page={HOMEPAGE}
          showHamburgerMenu={true}
          isMobile={initialPageState?.userAgent?.isMobile}
          isTablet={
            initialPageState?.userAgent?.isTablet ||
            initialPageState?.userAgent?.isIpad
          }
        />
      </div>
      <div className={styles.categoriesSlider}>
        <Categories
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          categories={categories}
        />
      </div>
      {selectedCategory === "All" && (
        <div className={styles.searchContainer}>
          <BitSearch />
        </div>
      )}
      <div
        className={styles.downloadApp}
        onClick={() => {
          window.open(storeUrl, "_blank")
          trackEvent(
            initialPageState?.userAgent?.isIphone
              ? BIT_EVENTS.DOWNLOAD_IOS_CLICKED
              : BIT_EVENTS.DOWNLOAD_ANDROID_CLICKED,
            { source: "home", student_id: getCode() }
          )
        }}
      ></div>
      <div className={styles.courses}>
        <CoursesCarousel
          selectedCategory={selectedCategory}
          teacherCarouselRef={teacherCarouselRef}
          page={HOMEPAGE}
        />
      </div>
      <div ref={teacherCarouselRef}>
        <TeacherCarousel />
      </div>
      {
        <div className={styles.testimonials}>
          <Testimonials />
        </div>
      }
      <div className={styles.teachOnBitClass}>{/* <TeachOnBitClass /> */}</div>
      <div className={styles.campusFeed} id="campus-feed-view">
        <CampusFeed />
      </div>
      <div className={styles.feedHeader}>
        <FeedHeader page={HOMEPAGE} isMobile={isMobile} />
        <FeedContainer />
      </div>
      <div className={styles.appDownloadSection}>
        <HomepageAppDownloadSection
          isMobile={initialPageState?.userAgent?.isMobile}
        />
      </div>
      <div>
        <AppFooterV3 />
      </div>
      <LoginModal onLoginNext={handleLoginNext} />
    </div>
  )
}

BitHome.getInitialProps = async (context) => {
  const { req } = context
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const userAgent = useUserAgent(
    req ? req.headers["user-agent"] : navigator.userAgent
  )
  let categories = []

  const paramObj = convertUtmParams(context, getParamObj("home", userAgent))
  // console.log(paramObj,'params')
  const initialPageState = { userAgent, paramObj, source: "home" }
  return { initialPageState }
}

export default withUserAgent(BitHome)
