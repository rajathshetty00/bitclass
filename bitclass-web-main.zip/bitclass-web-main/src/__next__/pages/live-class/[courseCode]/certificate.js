import dynamic from 'next/dynamic'
import MwebDownloadApp from 'src/__components__/MwebDownloadApp'
import AppFooterV3 from 'src/__components__/AppFooter/v3'
import { isMobile } from "react-device-detect"
const DynamicAppHeader = dynamic(() => import('src/__components__/AppHeader'), { ssr: false })

const Certificate = () => {
    const certificateMsg = "To download and share your Certificate, download the BitClass App by clicking on the link below"
    return (
        <div>
            <DynamicAppHeader page="search" isMobile={isMobile} />
            <MwebDownloadApp appMsg={certificateMsg} />
            <AppFooterV3 />

        </div>
    )
}


export default Certificate
