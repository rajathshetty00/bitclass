import React, {useEffect, useState, useRef} from 'react'
import {API_URL, BASE_URL} from 'src/constants'
import {ChevronDown, ChevronUp} from 'react-feather'
import Title from '../../../src/cdp/__components__/Title'
import {useToasts} from 'react-toast-notifications'
import {
  get,
  has,
} from 'lodash'
import ShowMoreText from 'react-show-more-text'
import styles from './styles.module.scss'
import Head from 'next/head'
import dynamic from 'next/dynamic'
import {useRouter} from 'next/router'
import {useUserAgent, withUserAgent} from 'next-useragent'
import {createUrlSlug, exists, getThumbnailFromUrl, getUrlParametersAsArray, sanitizeHtml} from '../../../src/__utils__'
import Banner from '../../../src/cdp/__components__/Banner'
import CourseRemoved from '../../../src/__components__/CourseRemoved'
// import SuccessModal from '../../../src/profile/__components__/SuccessModal'
import About from "../../../src/cdp/__components__/common/About"
import AboutTeacher from '../../../src/cdp/__components__/AboutTeacher'
import CdpCarousel from "../../../src/cdp/__components__/common/CdpCarousel"
import FAQs from "../../../src/cdp/__components__/FAQs"
import PaymentButtons from '../../../src/cdp/__components__/PaymentButtons'
import CourseTab from 'src/cdp/__components__/CourseTab'
import {UserContext} from "../../../context/User"
import trackEvent from '../../../src/__utils__/analytics'
import { registerStudentForCourse, validateShopseSignature } from 'src/__utils__/api'
import { getCode } from 'src/__utils__/auth'
import dayjs from 'dayjs'
import { BIT_EVENTS } from 'config/events'
import { registerFromSezzleCallback } from 'src/__utils__/api'

let DynamicAppHeader = null

const SuccessModal =  dynamic(() => import("src/profile/__components__/SuccessModal"), {
  ssr: false,
})


const Id = (props) => {

  //It is important to render react component here. This populates html with data from getIniitialProps

  const [isAppHeader, setIsAppHeader] = useState(null)
  const [data, setData] = useState(exists(props._data['data']) ? props._data['data'] : null)
  const [courseRemoved, setCourseRemoved] = useState(exists(props._data['data']) ? false : true)
  const [SuccessModalFlag, setSuccessModalFlag] = useState(false)
  const [paidCourseCode, setPaidCourseCode] = useState('')
  const [SuccessModalStatus, setSuccessModalStatus] = useState('success')
  const [emiCourseCode, setEmiCourseCode] = useState(null)
  const [modalVisible, setModalVisible] = useState(false)
  const [paymentStatusMessage, setPaymentStatusMessage] = useState('')
  const [trackingBaseData, setTrackingBaseData] = useState({})

  const {addToast} = useToasts()
  const courseHighlightRef = useRef(null)
  const aboutTeacherRef = useRef(null)
  const faqRef = useRef(null)
  const router = useRouter()
  const {isMobile, isTablet} = props.ua
  const tmprCode = router.query.id

  const images = [
    {original: 'https://cdn.wallpapersafari.com/76/89/bzHTM1.jpg'},
    {original: 'https://images.pexels.com/photos/799443/pexels-photo-799443.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'},
    {original: 'https://i.imgur.com/Ywcvr7u.png'},
    {original: 'https://images.pexels.com/photos/1535162/pexels-photo-1535162.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'}
  ]


  const _gradients = [
    "linear-gradient(225.92deg, #33D2FF 5.73%, #3D68DE 54.65%, #9845E8 96.75%)",
    "linear-gradient(135deg, #B65FC4 2.88%, #DB6E4E 100%)",
    "linear-gradient(224.86deg, #73CCD8 4.87%, #2B6B9F 96.04%)",
    "linear-gradient(135deg, #6964DE 2.88%, #FCA6E9 100%)",
    "linear-gradient(315deg, #21BDB8 0%, #280684 100%)"
  ]



  // dynamically rendering <AppHeader>
  useEffect(() => {
    DynamicAppHeader = dynamic(() => import('../../../src/__components__/AppHeader'))
    setIsAppHeader(true)

    if (exists(data) && exists(data['title'])) {
      let slug = createUrlSlug(data['title'])
      let _url = `/live-courses/${slug}/${tmprCode}`
      router.push(_url, _url, {shallow: true})
    }

    if (typeof window !== undefined) {
      let course = has(data, 'upsell') ? get(data, 'upsell[0]', null) : get(data, 'demos[0]', null)
      course = !exists(course) ? get(data, 'demos[0]', null) : course
      let teacher = get(data, 'teacher', {})
      let urlParams = getUrlParametersAsArray(window.location.href)
      let baseTracking = {
        source: exists(urlParams['source']) ? urlParams['source'] : "direct",
        student_id: getCode(),
        course_title: course?.heading,
        course_price: course?.amount,
        course_code: course?.code,
        course_time_schedule: course?.weekly_schedule
          ? course?.weekly_schedule.map(ws => dayjs.unix(ws).format('hh:mm a'))
          : [],
        course_start_date: course?.start_ts
          ? dayjs.unix(course?.start_ts).format('YYYY-MM-DD')
          : '',
        course_end_date: course?.end_ts
        ? dayjs.unix(course?.end_ts).format('YYYY-MM-DD')
        : '',
        teacher_name: teacher?.teacher_name,
        course_type: "courses",
        course_category: [],
        cdp_type: "emi",
        tmpr_code: "",
      }
      setTrackingBaseData(baseTracking)
      trackEvent(BIT_EVENTS.CDP_VIEWED, baseTracking)
    }
  }, [])

  useEffect(() => {
    if (exists(paidCourseCode) && !SuccessModalFlag) {
      window.location.reload()
    }
  }, [paidCourseCode, SuccessModalFlag])


  const refHandler = (index) => {
    switch (index) {
      case 0:
        return courseHighlightRef.current.scrollIntoView(
          {
            behavior: "smooth"
          })
      case 1:
        return aboutTeacherRef.current.scrollIntoView(
          {
            behavior: "smooth"
          })
      case 2:
        return faqRef.current.scrollIntoView(
          {
            behavior: "smooth"
          })
      default:
        return
    }
  }





  // variables for components
  let _course = has(data, 'upsell') ? get(data, 'upsell[0]', null) : get(data, 'demos[0]', null)
  _course = !exists(_course) ? get(data, 'demos[0]', null) : _course
  let intro_video = get(_course, 'intro_video', null)
  let intro_thumbnail = get(_course, 'intro_video_thumbnail', getThumbnailFromUrl(get(_course, 'intro_video', '')))
  let title = get(data, 'title', '')
  let learning_level = get(_course, 'additional_info.course_learning_level', null)
  let weekly_schedule = get(_course, 'weekly_schedule', [])
  let start_date = get(_course, 'start_ts', null)
  let end_date = get(_course, 'end_ts', null)
  let highlights = get(_course, 'highlights', [])
  let faq = get(_course, 'faqs', [])
  let testimonials = get(_course, 'testimonials', [])
  let teacher = get(data, 'teacher', {})
  let aboutCourse = get(_course, 'goal', '')
  let metaDesc = sanitizeHtml(aboutCourse.substring(0, 80))
  metaDesc = `Enrol into this live instructor-led course online on BitClass. ${metaDesc}`
  let courseSchedule = get(_course, 'course_schedule', null)
  let demoClassDays = 0
  let upsellCourseCode = get(data, 'upsell[0].code', null)
  let demoCourseCode = get(data, 'demos[0].code', null)
  let courseCode = get(_course, 'code', '')

  if (exists(get(data, 'upsell[0]', null))) {
    demoClassDays = get(data, 'demos[0].number_of_classes', 0)
  }
  // end variables

// Shopse
const [paymentProcessing, setPaymentProcessing] = useState(false)
useEffect(() => {
  async function fetchData() {
    try {
      const courseURL = BASE_URL+router.asPath
      const _urlSearch =  new URL(courseURL)
      const _urlParams = new URLSearchParams(_urlSearch.search)
      const _orderId = _urlParams.get('order_id')
      const _isSezzle = _urlParams.get('is_sezzle')

      // sezzle payment check
      if(_isSezzle === "true"){
        setPaymentProcessing(true)
        const sezzleStatus = await registerFromSezzleCallback(
         _orderId
        )
        if(
          sezzleStatus.success === true){
          setPaymentProcessing(false)
          setSuccessModalStatus("success")
          setEmiCourseCode(courseCode)
          setSuccessModalFlag(true)
        } else {
          setPaymentProcessing(false)
          setSuccessModalStatus("failure")
          setSuccessModalFlag(true)
        }
      }
      const _orderCode = router.asPath.split("?")[1].split("&")[0].split('=')[1]
      const _paymentMode = 'emi'
      const _paymentStatus = _urlParams.get("status")
      const _statusMessage = _urlParams.get("statusMessage")
      const _shopSeTxnId = _urlParams.get('shopSeTxnId')
      const _statusCode = _urlParams.get('statusCode')
      const _currentTime = _urlParams.get('currentTime')
      const _signature = router.asPath.split("signature")[1].split('=')[1]
      const signatureResponse = await validateShopseSignature(
       encodeURI(_orderCode),
       encodeURI(_paymentStatus),
       encodeURI(_shopSeTxnId),
       encodeURI(_statusCode),
       encodeURI(_statusMessage),
       encodeURI(_currentTime),
       _signature
      )
      if(signatureResponse.is_valid){
      if (_paymentStatus === "success") {
        setPaymentProcessing(true)
        const _regStatus = await registerStudentForCourse(
          courseCode,
          _orderCode,
          null,
          _paymentMode
        )

        if (!_regStatus["success"]) {
          setPaymentProcessing(false)
          setSuccessModalStatus("failure")
          setSuccessModalFlag(true)
        }
        setPaymentProcessing(false)
        setSuccessModalStatus("success")
        setEmiCourseCode(courseCode)
        setSuccessModalFlag(true)
        
      } else if (
        _orderCode &&
        _paymentMode &&
        _paymentStatus!=='success'
      ) {
        // setPaymentProcessing(false)
        setSuccessModalStatus("failure")
        setPaymentStatusMessage(_statusMessage)
        setSuccessModalFlag(true)
        // history.push(props.location.pathname)
      }
    }else{
      setSuccessModalStatus("failure")
      setPaymentStatusMessage("Unauthorized Access!")
      setSuccessModalFlag(true)
    }

    } catch (err) {
      return // handle error once we build error component
    } finally {
    }
  }
  fetchData()
}, [])

  //shopse end

  return (
    <div className={styles.container}>
      <Head>
        <title>{title} | Live Online Course</title>
        <meta name="description" content={metaDesc} />
        <meta name="keywords" content={`${title} | Live Online Course, Online Class, Live courses, BitClass Classes`} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={metaDesc} />
        <meta property="og:image" content={intro_thumbnail || teacher.image} />
        <meta property="og:url" content={props.pageUrl} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={metaDesc} />
        <meta name="twitter:image" content={intro_thumbnail || teacher.image} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta name="twitter:creator" content={teacher.teacher_name} />
        <meta property="og:site_name" content="BitClass" />

        {/* Adding course schema  */}
        <script type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org/",
              "@type": "Course",
              "name": title,
              "description": metaDesc,
              "provider": {
                "@type": "Organization",
                "name": "BitClass",
                "url": {BASE_URL}
              }
            })
          }}
        />
        {/* --completed course schema-- */}


        {/* Adding FAQ schema  */}
        {exists(faq) && (
          <script type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "name": "CDP FAQ",
                "mainEntity": faq.map((item) => {
                  return {
                    "@type": "Question",
                    "name": item.que,
                    "acceptedAnswer": {
                      "@type": "Answer",
                      "text": item.ans
                    }
                  }
                })
              })
            }}
          />
        )}
        {/* --completed FAQ schema-- */}

        
      </Head>
      <>
        <UserContext.Consumer>
          {
            (details) => {
              if (details.globalState.status === 'done') {
                setSuccessModalFlag(true)
                setPaidCourseCode(details.globalState.courseCode)
                details.paymentInProgress({status: false, courseCode: ''})
              }
              return (
                <>
                  <header>
                    {isAppHeader && (
                      <DynamicAppHeader
                        className={courseRemoved ? '' : styles.header}
                        page="cdp"
                        props={props}
                        darkMode={courseRemoved ? false : true}
                        isMobile={isMobile}
                        isTablet={isTablet}
                      />
                    )}
                  </header>
                  <main>
                    {
                      courseRemoved && <CourseRemoved className={styles.noCourse} />
                    }
                    {
                      !courseRemoved && (
                        <>
                          <Banner
                            introVideo={intro_video}
                            introVideoThumbnail={intro_thumbnail}
                            heading={title}
                            level={learning_level}
                            tmprCode={tmprCode}
                            courseCode={courseCode}
                          />
                          <div className={styles.bodyContainer}>
                            <div className={styles.areaLeft}>
                              {/* Title Component*/}
                              <Title
                                title={title}
                                weeklySchedule={weekly_schedule}
                                startDate={start_date}
                                endDate={end_date}
                                courseSchedule={courseSchedule}
                              />
                              {/* Title Component Ends */}

                              {/* Payment / Sticky Component */}
                              {(isMobile || isTablet) && <PaymentButtons
                                course={_course}
                                profile={teacher}
                                history={props.history}
                                demoCourse={
                                  exists(get(data, 'upsell[0]', null))
                                    ? get(data, 'demos[0]', null)
                                    : null
                                }
                                isMobile={isMobile}
                                isTablet={isTablet}
                                demoClassDays={demoClassDays}
                              />}
                              {/* Payment / Sticky Component Ends */}

                              {/* About Teacher */}
                              {
                                exists(aboutCourse) && (
                                  <>
                                    <CourseTab isMobile={isMobile}
                                      isTablet={isTablet} refHandler={refHandler} />
                                    <div ref={courseHighlightRef} ></div>
                                    <About
                                      trackShowMore={() => {
                                        trackEvent(
                                          BIT_EVENTS.CDP_SHOW_MORE_CLICKED,
                                          trackingBaseData
                                        )
                                      }}
                                    >
                                      {aboutCourse}
                                    </About>
                                  </>
                                )
                              }
                              {/* About Teacher Ends */}

                              {/* Highlights Carousal */}
                              {
                                exists(highlights) && highlights.length > 0 && (
                                  <>
                                    <CdpCarousel
                                      heading="COURSE HIGHLIGHTS"
                                      className={styles.carousal}
                                      isMobile={isMobile}
                                      isTablet={isTablet}
                                    >
                                      {
                                        highlights.map((item, index) => (
                                          <div key={index.toString()}>
                                            <div
                                              className={styles.course}
                                              style={{background: _gradients[index % 5]}}
                                            >
                                              <p className={styles.courseNumber}>
                                                0{index + 1}
                                              </p>
                                              <p>{item}</p>
                                            </div>
                                          </div>
                                        ))
                                      }
                                    </CdpCarousel>
                                  </>
                                )
                              }
                              {/* Highlights Carousal Ends */}

                              {/* About Teacher */}
                              <div ref={aboutTeacherRef}></div>
                              {
                                exists(get(data, 'teacher.story', null)) && (
                                  <>
                                    <AboutTeacher data={teacher} />
                                    <About>
                                      {get(data, 'teacher.story')}
                                    </About>
                                  </>
                                )
                              }
                              {/* About Teacher Ends */}

                              {/* Testimonials Carousal */}
                              {
                                exists(testimonials) && testimonials.length > 0 && (
                                  <CdpCarousel
                                    isMobile={isMobile}
                                    isTablet={isTablet}
                                    darkDots={(isMobile || isTablet)}
                                    heading="TESTIMONIALS"
                                  >
                                    {
                                      testimonials.map((t, index) => (
                                        <div key={index.toString()}>
                                          <div className={styles.testimonial}>
                                            <div className={styles.profile}>
                                              <div><img src='/static/__assets__/teacher-empty.svg' alt="Course Testimonial" /></div>
                                              <h5>{t.student_name}</h5>
                                            </div>
                                            <ShowMoreText
                                              lines={2}
                                              more={<div> <span>Show more</span><ChevronDown /></div>}
                                              less={<div> <span>Show less</span> <ChevronUp /></div>}
                                              expanded={false}
                                              anchorClass={styles.readMoreText}
                                              width={600}
                                            >
                                              {t.testimonial}
                                            </ShowMoreText>
                                          </div>
                                        </div>
                                      ))
                                    }
                                  </CdpCarousel>
                                )
                              }
                              {/* Testimonials Carousal Ends */}

                              {/* FAQs */}
                              <div ref={faqRef} ></div>
                              {exists(faq) && <FAQs
                                courseCode={courseCode}
                                data={faq}
                                heading={title}
                                _trackEvent={() => {
                                  trackEvent(BIT_EVENTS.CDP_FAQ_CLICKED, trackingBaseData)
                                }}
                              />}
                              {/* FAQs Ends */}
                            </div>



                            {/* Sticky Side Bar */}
                            <div className={styles.areaRight}>
                              {/* Payment / Sticky Component */}
                              {!isMobile && !isTablet && <PaymentButtons
                                course={_course}
                                profile={teacher}
                                history={props.history}
                                demoCourse={
                                  exists(get(data, 'upsell[0]', null))
                                    ? get(data, 'demos[0]', null)
                                    : null
                                }
                                isMobile={isMobile}
                                isTablet={isTablet}
                                demoClassDays={demoClassDays}
                              />}
                              {/* Payment / Sticky Component Ends */}
                            </div>
                            {/* Sticky Side Bar Ends */}
                          </div>
                        </>
                      )
                    }
                  </main>
                  {
                    SuccessModalFlag && (
                    <SuccessModal
                      SuccessModalFlag={SuccessModalFlag}
                      setSuccessModalFlag={setSuccessModalFlag}
                      status={SuccessModalStatus}
                      courseCode={emiCourseCode?emiCourseCode: paidCourseCode}
                      statusMessage={paymentStatusMessage}
                      profile={teacher}
                      courseData={_course}
                    />
                  )
                }
                </>
              )
            }
          }
        </UserContext.Consumer>
      </>
    </div >
  )
}



Id.getInitialProps = async (context) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const ua = useUserAgent(context.req.headers['user-agent'])
  let _data
  let res
  try {
    if(context.query.id !== undefined ){
      res = await fetch(`${API_URL}/v2/courses/${context.query.id}/details?include_upsell=true`)
      _data = await res.json()
    }
  } catch (e) {
    _data = null
  }
  return {
    _data,
    pageUrl: `${BASE_URL}${context.asPath}`,
    ua,
  }
}



export default withUserAgent(Id)

