import clsx from "clsx"
import React, { useEffect, useRef, useState } from "react"
import styles from "./style.module.scss"
import Head from "next/head"
import Link from "next/link"
import { isMobile } from "react-device-detect"
import { Badge } from "antd"
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsDown,
  ChevronUp,
  Play,
} from "react-feather"
import dynamic from "next/dynamic"
import { API_URL, BASE_URL } from "src/constants"
import { exists } from "src/__utils__"
import { UserContext } from "context/User"
import BootCampDrawer from "src/bootcamp/Drawer"
import BootcampSuccessModal from "src/bootcamp/BootcampSuccessModal"
import CoursesCard from "src/bootcamp/CourseCard"
import FAQs from "src/cdp/__components__/FAQs"
import { getCourse, getScheduleTime } from "src/__utils__/api"
import { getUID } from "src/__utils__/auth"
import VideoPopup from "src/__components__/VideoPopup"
import trackEvent from "src/__utils__/analytics"
import { get } from "lodash"
import VideoCard from "src/__components__/VideoCard"
import { useUserAgent, withUserAgent } from "next-useragent"
import { useRouter } from "next/router"

const _summer_course_schedule = [
  {
    name: "Excel in MUN",
    dateRange: "March 15-25",
    time: "15th Mar : 4-5 PM | 20th Mar : 4-5 PM | 25th Mar : 4-5 PM",
  },
  {
    name: "How to become a TedX Speaker",
    dateRange: "March 15-25",
    time: "15th Mar : 5-6 PM | 20th Mar : 3-4 PM | 25th Mar : 5-6 PM",
  },
  {
    name: "Carnatic music",
    dateRange: "March 17-27",
    time: "17th Mar: 4-5 PM | 22nd Mar: 4-5 PM | 27th Mar: 4-5 PM",
  },
  {
    name: "Become a star Magician",
    dateRange: "March 17-27",
    time: "17th Mar: 5-6 PM | 22nd Mar: 5-6 PM | 27th Mar: 5-6 PM",
  },
  {
    name: "Bharatnatyam",
    dateRange: "March 17-27",
    time: "17th Mar: 6-7 PM | 22nd Mar: 6-7 PM | 27th Mar: 6-7 PM",
  },
  {
    name: "Draw better than a photograph : Realism",
    dateRange: "March 19-29",
    time: "19th Mar: 4-5 PM | 24th Mar: 4-5 PM | 29th Mar: 4-5 PM",
  },
  {
    name: "Learn how to make sculptures",
    dateRange: "March 19-29",
    time: "19th Mar: 5-6 PM | 24th Mar: 5-6 PM | 29th Mar: 5-6 PM",
  },
  {
    name: "Master the art of Zendoodling",
    dateRange: "March 19-29",
    time: "19th Mar: 6-7 PM | 24th Mar: 6-7 PM | 29th Mar: 6-7 PM",
  },
  {
    name: "Piano",
    dateRange: "March 16-26",
    time: "16th Mar: 4-5 PM | 21st Mar: 4-5 PM | 26th Mar: 7-8 PM",
  },
  {
    name: "Drums",
    dateRange: "March 16-26",
    time: "16th Mar: 3-4 PM | 21st Mar: 3-4 PM | 26th Mar: 3-4 PM",
  },
  {
    name: "French",
    dateRange: "March 18-28",
    time: "18th Mar: 4-5 PM | 23rd Mar: 4-5 PM | 28th Mar: 4-5 PM",
  },
  {
    name: "Spanish",
    dateRange: "March 20-28",
    time: "20th Mar: 5-6 PM | 21st Mar: 5-6 PM | 28th Mar: 5-6 PM",
  },
  {
    name: "Japanese",
    dateRange: "March 18-28",
    time: "18th Mar: 6-7 PM | 23rd Mar: 6-7 PM | 28th Mar: 6-7 PM",
  },
  {
    name: "Learn Coding from Scratch",
    dateRange: "March 15-25",
    time: "15th Mar: 6-7 PM | 20th Mar: 6-7 PM | 25th Mar: 6-7 PM",
  },
  {
    name: "Robotics",
    dateRange: "March 16-26",
    time: "16th Mar: 6-7 PM | 21st Mar: 6-7 PM | 26th Mar: 6-7 PM",
  },
  {
    name: "Basics of Python",
    dateRange: "March 19-29",
    time: "19th Mar: 6-7 PM | 24th Mar: 6-7 PM | 29th Mar: 6-7 PM",
  },
]

const faq = [
  {
    que: "What is this Summer Camp about?",
    ans:
      "Nothing of this sort has happened ever. This summer camp, what we really want to do is, help kids just explore their potential and possibly surpass them to create a tangible skill out of them.",
  },
  {
    que: "What are the dates of the Summer Camp ?",
    ans: (
      <span>
        The Summer Camp is happening from 15th - 30th March completely online on{" "}
        <a href="https://www.bitclass.live/">
          <b>www.bitclass.live</b>
        </a>{" "}
        with multiple sessions on 16 courses so that you can attend any of them
        at your convenience.
      </span>
    ),
  },
  {
    que: "What is the Summer Pass?",
    ans:
      "Summer Pass is your ticket to participate in the World’s Largest Online Summer Camp! This Summer Pass will give you complete access to register and attend more than 16 courses over a period of 2 weeks.",
  },
  {
    que: "Will my kid become an expert in this field?",
    ans:
      "Yes. Once he or she has attended these sessions, we will be offering advanced level courses to allow your child pursue his or her passion and become an expert.",
  },
  {
    que: "When will the advanced classes happen?",
    ans: (
      <span>
        After you have attended all the classes, you can register for the
        advanced courses, starting in April, to hone your kids’ skills in the
        field of their preference.
        <br />
        <br />
        It’s like trying out all types of clothes and buying the ones you really
        like.
      </span>
    ),
  },
]
const courseCategories = [
  "Entrepreneurship",
  "Performing Arts",
  "Visual Arts",
  "Instruments",
  "Language",
  "Technical",
]

//static data
const _payBtnText = "Buy 16 Courses for ₹199"
const _pageTitle = "World’s Biggest Online Summer Camp (15th - 30th March)"
const _postponed = true

let RegisterButton = ""
const BootCamp = (props) => {
  const { isMobile, isTablet } = props.ua

  const [selectedButton, setSelectedButton] = useState(0)
  const [showLeftNavigation, setShowLeftNavigation] = useState(true)
  const [showRightNavigation, setShowRightNavigation] = useState(true)
  const [showPaymentButton, setShowPaymentButton] = useState(false)
  const [showDrawer, setShowDrawer] = useState(false)
  const [showSticky, setShowSticky] = useState(false)
  const [course, setCourse] = useState(props._courses)
  const [paymentCourse, setPaymentCourse] = useState(null)
  const [SuccessModalFlag, setSuccessModalFlag] = useState(false)
  const [SuccessModalStatus, setSuccessModalStatus] = useState("success")
  const [selectedCourses, setSelectedCourses] = useState([])
  const [added, setAdded] = useState([])
  const [showTrailer, setShowTrailer] = useState(false)
  const [addedToCart, setAddedToCart] = useState([])
  const [scheduledCourse, setScheduledCourse] = useState(null)

  let _url = `${BASE_URL}/live-courses/summer-camp-2021}`
  let _title = `Summer Camp 2021 | Live Online Course`
  let meta_image = `https://res.cloudinary.com/bitclass/image/upload/v1615193441/Assets/summer-bootcamp/summercamp_zwdxaa.png`

  const removeCourse = (code) => {
    if (added.includes(code)) {
      const updatedCourse = added.filter((course) => course !== code)
      const updatedCart = addedToCart.filter(
        (cart) => cart.courseHeading !== code
      )
      setAdded(updatedCourse)
      setAddedToCart(updatedCart)
    }
    const courseIndex = selectedCourses.findIndex(
      (course) => course.code === code
    )
    if (courseIndex >= 0) {
      const updatedCourseList = selectedCourses.filter(
        (course) => course.code !== code
      )
      setSelectedCourses(updatedCourseList)
    }
  }
  const slidingMenuRef = useRef()
  useEffect(() => {
    RegisterButton = dynamic(() =>
      import("../../../src/payment/RegisterButton")
    )
    setShowPaymentButton(true)
    if (slidingMenuRef?.current?.scrollWidth > slidingMenuRef?.current?.clientWidth)
      setShowRightNavigation(true)

    var code = `
    (function(d, src, c) { var t=d.scripts[d.scripts.length - 1],s=d.createElement('script');s.id='la_x2s6df8d';s.async=true;s.src=src;s.onload=s.onreadystatechange=function(){var rs=this.readyState;if(rs&&(rs!='complete')&&(rs!='loaded')){return;}c(this);};t.parentElement.insertBefore(s,t.nextSibling);})(document, 'https://bitclass.ladesk.com/scripts/track.js',   function(e){ LiveAgent.createButton('cn7kslcy', e); });
    `
    var script = document.createElement("script")
    script.setAttribute("type", "text/javascript")
    script.appendChild(document.createTextNode(code))
    document.body.appendChild(script)

    return () => document.body.removeChild(script)
  }, [])

  useEffect(() => {
    ;(async function () {
      let _payment_course = await getCourse("C69215a")
      let _course_schedule = ""
      if (exists(localStorage.getItem("Authorization"))) {
        _course_schedule = await getScheduleTime()
        setScheduledCourse(get(_course_schedule, "data", null))
      }

      if (exists(_payment_course["data"]))
        setPaymentCourse(_payment_course["data"])
    })()
  }, [])

  useEffect(() => {
    if (
      exists(paymentCourse) &&
      paymentCourse?.students?.includes(parseInt(getUID(), 10))
    ) {
      window.scrollTo(0, 0)
      setSuccessModalFlag(true)
    }
  }, [paymentCourse])

  const scrollX = (direction) => {
    if (direction === "left") {
      slidingMenuRef.current.scrollLeft -= 250
      if (slidingMenuRef.current.scrollLeft === 0) setShowLeftNavigation(true)
      setShowRightNavigation(true)
    } else {
      slidingMenuRef.current.scrollLeft += 250
      setShowLeftNavigation(true)
      if (
        slidingMenuRef.current.scrollLeft ===
        slidingMenuRef.current.scrollWidth - slidingMenuRef.current.offsetWidth
      )
        setShowRightNavigation(true)
    }
  }

  const checkoutContainerRef = useRef()
  useEffect(() => {
    if (selectedCourses.length < 0) {
      const scrollHandler = () => {
        let bottom = checkoutContainerRef?.current?.getBoundingClientRect()
          ?.bottom
        if (bottom < 1230 && !showSticky) {
          setShowSticky(true)
        } else if (bottom > 1230 && showSticky) {
          setShowSticky(false)
        }
      }
      window.addEventListener("scroll", scrollHandler)
      return () => window.removeEventListener("scroll", scrollHandler)
    } else setShowSticky(true)
  }, [showSticky])

  // const [windowResized, setWindowResized] = useState()

  useEffect(() => {
    let vh = window.innerHeight * 0.01
    // Then we set the value in the --vh custom property to the root of the document
    document.documentElement.style.setProperty("--vh", `${vh}px`)
    // We listen to the resize event
    // window.addEventListener("resize", () => {
    //   // We execute the same script as before
    //   let vh = window.innerHeight * 0.01
    //   document.documentElement.style.setProperty("--vh", `${vh}px`)
    // })
    // setWindowResized(!windowResized)
  }, [])

  const router = useRouter()
  return (
    <>
      <Head>
        <title>{_title}</title>
        <meta name="description" content="" />
        <meta
          name="keywords"
          content={`${_title}, Discover 16 courses spread across 6 different categories on single summer pass`}
        />
        <meta property="og:title" content={_title} />
        <meta
          property="og:description"
          content={`${_title}, Discover 16 courses spread across 6 different categories on single summer pass`}
        />
        <meta property="og:image" content={meta_image} />
        <meta property="og:url" content={_url} />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="bitclass.live" />
        <meta name="twitter:title" content={_title} />
        <meta
          name="twitter:description"
          content={`${_title}, Discover 16 courses spread across 6 different categories on single summer pass`}
        />
        <meta name="twitter:image" content={meta_image} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta name="twitter:creator" content="@bitclass.live" />
      </Head>
      <UserContext.Consumer>
        {(User) => {
          if (User.globalState.status === "done") {
            window.location.reload()
            User.paymentInProgress({ status: false, courseCode: "" })
          }
          return (
            <>
              {_postponed ? (
                <div className={styles.postPoned}>
                  <img
                    alt="BitClass Logo"
                    src="/static/__assets__/BitClassLogos/LogoForDarkBG.svg"
                    width="162"
                    height="49"
                    className={styles.logo}
                  />
                  <div className={styles.text}>POSTPONED!</div>
                  <div style={{fontSize:'1.4rem'}}>
                    We regret to inform you that the summer camp has been
                    postponed due to unavoidable circumstances. For any queries,
                    please drop in an email to{" "}
                    <a href="mailto:support@bitclass.live">
                      <span style={{fontWeight:700,color:'white'}}>support@bitclass.live</span>
                    </a>
                  </div>
                  <div className={styles.discoverBtn}>
                    <Link href="/live-courses/search">Discover Courses</Link>
                  </div>
                </div>
              ) : (
                <div className={styles.container}>
                  <div style={{ backgroundColor: "#1f1f47" }}>
                    <div
                      className={styles.header}
                      // style={{ height: isIOS &&'89vh' }}
                    >
                      <img
                        alt="BitClass Logo"
                        src="/static/__assets__/BitClassLogos/LogoForDarkBG.svg"
                        width="162"
                        height="49"
                        className={styles.logo}
                      />
                      <div className={styles.content}>
                        <div className={styles.subHeader1}>
                          {!isMobile &&
                            "This summer, let kids explore their real talent"}
                        </div>
                        <div className={styles.title}>{_pageTitle}</div>
                        <div className={styles.subHeader2}>
                          Get access to <b>16 courses</b>, across <b>SIX </b>
                          different categories on a single Summer Pass
                        </div>
                        {/* <div className={styles.summerPass}>SummerPass</div> */}
                        <div className={styles.priceContainer}>
                          <div className={styles.price}>₹ 199/-</div>
                          <div className={styles.priceDescription}>
                            all inclusive
                          </div>
                        </div>
                        <div className={styles.buttonContainer}>
                          {/* <button
                            className={styles.summerPassBtn}
                            onClick={() => {
                              trackEvent("click_get_summer_pas")
                            }}
                          >
                            get summer pass
                          </button> */}
                          <>
                            {exists(paymentCourse) &&
                              paymentCourse.teacher?.code &&
                              !paymentCourse.students?.includes(
                                parseInt(getUID(), 10)
                              ) && (
                                <RegisterButton
                                  btnClass={styles.summerPassBtn}
                                  course={paymentCourse}
                                  profile={paymentCourse.teacher}
                                  text={_payBtnText}
                                  trackPreRegister
                                  trackEvtName="click_book_now"
                                  containerClass={styles.paymentBtnContainer}
                                  // multiCourse={selectedCourses}
                                />
                              )}
                          </>
                          <div className={styles.container}>
                            <div className={styles.center}>
                              <button
                                className={clsx(styles.exploreBtn, styles.btn)}
                                onClick={() => {
                                  trackEvent("watch_summer_intro_video_click")
                                  setShowTrailer(true)
                                }}
                              >
                                <svg
                                  width="100%"
                                  height="100%"
                                  preserveAspectRatio="none"
                                  viewBox="0 0 180 60"
                                  class="border"
                                >
                                  <polyline
                                    points="179,1 179,59 1,59 1,1 179,1"
                                    class="bg-line"
                                  />
                                  <polyline
                                    points="179,1 179,59 1,59 1,1 179,1"
                                    class="hl-line"
                                  />
                                </svg>
                                <span className={styles.playsvg}>
                                  <Play />
                                </span>{" "}
                                <span
                                  style={{
                                    fontWeight: 600,
                                    textTransform: "uppercase",
                                  }}
                                >
                                  Watch Trailer
                                </span>
                              </button>
                            </div>
                          </div>
                        </div>
                        <div className={styles.scrollDown}>
                          <Link href="#howItWorks">
                            <ChevronsDown className={styles.downArrow} />
                          </Link>
                        </div>
                      </div>
                    </div>
                    <div className={styles.howItWorks} id="howItWorks">
                      <div className={styles.title}>What is Summer Pass?</div>
                      <div className={styles.contentHowItWorks}>
                        <div className={styles.textSection}>
                          BitClass is hosting World’s Biggest Online Live Summer
                          Camp, where kids can attend 16 online live courses,
                          spread across 6 different categories -{" "}
                          <b>
                            Entrepreneurship, Performing and Visual Arts,
                            Technical, Language and Instruments
                          </b>
                          .
                          <br />
                          <br />
                          For <b>Rs. 199/- (all inclusive)</b> you’ll get 16
                          courses spread across 6 different categories. This
                          will give your child an opportunity to attend live
                          classes from experts so that you are able to identify
                          their talent.
                          <div>
                            {exists(paymentCourse) &&
                              paymentCourse.teacher?.code &&
                              !paymentCourse.students?.includes(
                                parseInt(getUID(), 10)
                              ) && (
                                <RegisterButton
                                  btnClass={styles.summerPassBtn}
                                  course={paymentCourse}
                                  profile={paymentCourse.teacher}
                                  text={_payBtnText}
                                  trackPreRegister
                                  trackEvtName="click_book_now"
                                  containerClass={styles.verticalMargin}
                                  // multiCourse={selectedCourses}
                                />
                              )}
                          </div>
                        </div>
                        <div>
                          <VideoCard
                            url={
                              "https://res.cloudinary.com/bitclass/video/upload/v1615034927/Assets/summer-bootcamp/Summer_Camp_Video_01_amssdq.mp4"
                            }
                            title={""}
                            customClass={styles.howItWorksVideo}
                            thumbnail={
                              "http://res.cloudinary.com/bitclass/image/upload/x_28,y_0,w_1200,h_720,c_crop/v1615210471/BitClass/icuexjhc4cx5pm56bw6d.jpg"
                            }
                          />
                        </div>
                      </div>
                    </div>
                    <div
                      className={styles.courseDetailsContainer}
                      id="courseDetails"
                    >
                      <div className={styles.title}>
                        Courses Under Summer Pass
                      </div>
                      <div className={styles.categoryContainer}>
                        {!isTablet && isMobile && showLeftNavigation && (
                          <ChevronLeft
                            onClick={() => scrollX("left")}
                            size={isMobile && "4rem"}
                            color="white"
                          />
                        )}
                        <div
                          className={styles.menuContainer}
                          ref={slidingMenuRef}
                        >
                          {courseCategories.map((category, index) => (
                            <div className={styles.buttonContainer}>
                              <button
                                className={clsx(
                                  styles.categoryBtn,
                                  index === selectedButton && styles.active
                                )}
                                onClick={(e) => {
                                  setSelectedButton(index)
                                  trackEvent("click_category", {
                                    category,
                                  })
                                }}
                              >
                                {category}
                              </button>
                            </div>
                          ))}
                        </div>
                        {!isTablet && isMobile && showRightNavigation && (
                          <ChevronRight
                            onClick={() => scrollX("right")}
                            size={isMobile && "4rem"}
                            color="white"
                          />
                        )}
                      </div>
                      <div
                        className={styles.courseContainer}
                        ref={checkoutContainerRef}
                      >
                        <CoursesCard
                          courseDetails={course}
                          category={courseCategories[selectedButton]}
                          selectedCourses={selectedCourses}
                          setSelectedCourses={setSelectedCourses}
                          added={added}
                          setAdded={setAdded}
                          removeCourse={removeCourse}
                          addedToCart={addedToCart}
                          setAddedToCart={setAddedToCart}
                        />
                      </div>
                      <div
                        style={{ display: "flex", justifyContent: "center" }}
                      >
                        {exists(paymentCourse) &&
                          paymentCourse.teacher?.code &&
                          !paymentCourse.students?.includes(
                            parseInt(getUID(), 10)
                          ) && (
                            <RegisterButton
                              btnClass={styles.summerPassBtn}
                              course={paymentCourse}
                              profile={paymentCourse?.teacher}
                              text={_payBtnText}
                              trackPreRegister
                              trackEvtName="click_book_now"
                              // multiCourse={selectedCourses}
                              containerClass={styles.marginBottom}
                            />
                          )}
                      </div>
                    </div>
                  </div>
                  {/* {showSticky && selectedCourses.length > 0 && (
                  <div className={styles.checkoutContainer}>
                    <div className={styles.floatingButton}>
                      <div className={styles.container}>
                        <div className={styles.seeMoreBtnContainer}>
                          <button
                            onClick={() => {
                              if (!showDrawer) {
                                trackEvent("click_see_cart")
                              }
                              setShowDrawer(showDrawer ? false : true)
                            }}
                            className={styles.seeMoreBtn}
                          >
                            {showDrawer ? <ChevronDown /> : <ChevronUp />}
                            {!isMobile ?  showDrawer ? "see less": "see more" : ""}

                          </button>

                          <b>
                            {" "}
                            {selectedCourses.length < 7
                              ? `select ${7 - selectedCourses.length} more`
                              : ""}
                          </b>
                        </div>
                        <BootCampDrawer
                          showDrawer={showDrawer}
                          setShowDrawer={setShowDrawer}
                          selectedCourses={selectedCourses}
                          courses={props._courses.courses}
                          removeCourse={removeCourse}
                        />
                        <div style={{display: "flex", alignItems: "center"}}>
                          <div className={styles.priceText}>
                            {isMobile ? "₹ 199/-" : "Total Amount: ₹ 199/-"}
                          </div>
                          <Badge count={selectedCourses.length}>
                            {exists(paymentCourse) &&
                              !paymentCourse.students?.includes(
                                parseInt(getUID(), 10)
                              ) && (
                                <RegisterButton
                                  btnClass={styles.checkoutBtn}
                                  course={paymentCourse}
                                  profile={paymentCourse?.teacher}
                                  text={"Get "}
                                  trackPreRegister
                                  trackEvtName="click_book_now"
                                  multiCourse={selectedCourses}
                                />
                              )}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                )} */}
                  <>
                    <BootcampSuccessModal
                      SuccessModalFlag={SuccessModalFlag}
                      setSuccessModalFlag={setSuccessModalFlag}
                      status={SuccessModalStatus}
                      course={course}
                      courseCode={"C821654"}
                      scheduledCourse={scheduledCourse}
                    />
                    {showTrailer && (
                      <VideoPopup
                        title={"WORLD’S BIGGEST ONLINE SUMMER CAMP"}
                        url={
                          "https://res.cloudinary.com/bitclass/video/upload/v1615034927/Assets/summer-bootcamp/Summer_Camp_Video_01_amssdq.mp4"
                        }
                        showModal={showTrailer}
                        setShowModal={setShowTrailer}
                        customClass={styles.videoModal}
                        onPause={(ref) => {
                          let time = 0
                          try {
                            time = ref.getCurrentTime()
                          } catch (e) {}
                          trackEvent("watch_summer_intro_video_watch", {
                            duration: time,
                          })
                        }}
                        onClose={(ref) => {
                          let time = 0
                          try {
                            time = ref.getCurrentTime()
                          } catch (e) {}
                          trackEvent("watch_summer_intro_video_watch", {
                            duration: time,
                          })
                        }}
                      />
                    )}
                  </>
                  <div className={styles.faqContainer}>
                    <div className={styles.faqHeader}>
                      Frequently asked questions
                    </div>
                    <div style={{ display: "flex", justifyContent: "center" }}>
                      <FAQs
                        courseCode={"C821654"}
                        data={faq}
                        heading={"title"}
                        className={styles.faqs}
                        disable={false}
                        onOpen={() => trackEvent("click_open_faq")}
                        onClose={() => trackEvent("click_close_faq")}
                      />
                    </div>
                  </div>
                  <div className={styles.courseSchedule}>
                    <div className={styles.title}>Course Schedule</div>
                    {_summer_course_schedule.map((course, index) => (
                      <div className={styles.schedule} key={index}>
                        <div className={styles.item}>
                          <div
                            className={styles.number}
                            style={{
                              padding: index >= 9 && ".29rem .71rem",
                              marginRight: index >= 9 && "1rem",
                            }}
                          >
                            {index + 1}
                          </div>
                          <div className={styles.courseName}>{course.name}</div>
                          <div className={styles.dateTime}>
                            <div className={styles.date}>
                              {course.dateRange}
                            </div>
                            <div className={styles.time}>{course.time}</div>
                          </div>
                        </div>
                        {/* <div style={{border}}/> */}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )
        }}
      </UserContext.Consumer>
    </>
  )
}

BootCamp.getInitialProps = async (context) => {
  let _data

  let ua
  if(context.req) ua=useUserAgent(context.req.headers["user-agent"])
  else ua= {isMobile}
  try {
    let res = await fetch(`${API_URL}/v2/festival-event/summer_bootcamp`)
    _data = await res.json()
  } catch (e) {
    _data = null
  }
  return {
    _courses: _data,
    ua,
  }
}
export default withUserAgent(BootCamp)
