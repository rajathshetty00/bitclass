import React, { useEffect, useState, useRef } from "react"
import styles from "./styles.module.scss"
import { Input, Tabs } from "antd"
import { AntPrimaryButton } from "src/__components__/Button"
import dynamic from "next/dynamic"
import { exists, sanitizeSpecialCharacter } from "src/__utils__"
import { BASE_URL } from "src/constants"
import { useUserAgent, withUserAgent } from "next-useragent"
import { Search } from "react-feather"
import { useRouter } from "next/router"
import {
  filteredSearchData,
  getLiveUserCount,
  updateLiveCount,
  getLiveCourses,
  getDefaultFollowingList,
} from "src/__utils__/api"
import trackEvent from "src/__utils__/analytics"
import BitAntLoader from "src/__components__/BitAntLoader"
import Head from "next/head"
import { useToasts } from "react-toast-notifications"
import { isMobile } from "react-device-detect"
import AppFooterV2 from "src/__components__/AppFooter/v2"
import AntFullScreenModal from "src/__components__/Modal/AntFullScreenModal"
import { getCode } from "src/__utils__/auth"
import Feed, { feed } from "src/homepage/FeedCard"
import FeedContainer from "src/__components__/home/__components__/FeedCard"
import { objectToQueryString } from "src/__utils__"
import LiveStreamPlayer from "src/search-result-page/LiveStreamPlayer"
import CoursesCarousel from "src/__components__/CoursesCarousel"
import { get } from "lodash"
import { BIT_EVENTS } from "config/events"
import dayjs from "dayjs"
// import Feed, { feed } from "src/__components__/FeedCard"
import { hasAuthToken } from "src/__utils__/auth"
import AppFooterV3 from "src/__components__/AppFooter/v3"

const DynamicAppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const DynamicRootInstance = dynamic(() => import("src/root/rootInstance"), {
  ssr: false,
})

const DEFAULT_TAB_KEY = "3"

const { TabPane } = Tabs

const SearchPage = ({ paramObj, ...props }) => {
  const { isMobile, isIpad, isTablet } = props.ua
  const [queryList, setQueryList] = useState(
    props.queryList["data"] ? props.queryList["data"] : []
  )
  const [search, setSearch] = useState("")
  const [dataFetching, setDataFetching] = useState(false)

  const [showFullScreen, setShowFullScreen] = useState(false)

  const router = useRouter()
  const liveList = useRef(null)

  const [page, setPage] = useState(1)
  const [stopFetching, setStopFetching] = useState(false)
  const [key, setKey] = useState(DEFAULT_TAB_KEY)
  const [currentCourse, setCurrentCourse] = useState(null)
  const [liveStreamUrl, setLiveStreamUrl] = useState("")
  const [courseDetails, setCourseDetails] = useState(null)
  const [follow, setFollow] = useState(false)
  const [videoModalDetails, setVideoModalDetails] = useState(null)
  const [liveUsers, setLiveUsers] = useState(0)
  const [liveCoursesList, setLiveCoursesList] = useState([])
  const [finalUrl, setFinalUrl] = useState("")
  const [followingList, setFollowingList] = useState([])
  const [load, setLoad] = useState(false)
  const [autoPlay, setAutoPlay] = useState(true)

  useEffect(() => {
    const fetchLiveUserCount = async () => {
      if (exists(courseDetails)) {
        if (showFullScreen === true) {
          try {
            await updateLiveCount("add", courseDetails.code, getCode())
            const { count } = await getLiveUserCount(courseDetails.code)
            if (count > 0) setLiveUsers(count)
          } catch (e) {}
        } else {
          try {
            await updateLiveCount("remove", courseDetails.code, getCode())
            const { data } = await getLiveCourses()
            setLiveCoursesList(data)
          } catch (e) {}
        }
      }
    }
    fetchLiveUserCount()
  }, [showFullScreen, courseDetails])

  useEffect(() => {
    if (courseDetails) {
      const { tmpr_code, teacher } = courseDetails
      setVideoModalDetails({
        tmprCode: tmpr_code,
        teacherCode: teacher.code,
        image: get(teacher, "image", "/static/__assets__/teacher-empty.svg"),
        name: teacher.name,
        storefront: teacher.storefront_url,
      })
    }
  }, [courseDetails])

  const loadMoreCourses = async () => {
    try {
      trackEvent(BIT_EVENTS.SEARCH_SHOW_MORE_CLICKED, {
        student_id: getCode(),
      })

      setDataFetching(true)
      // if (!stopFetching) {
      const { data } = await filteredSearchData(search, key, page + 1)
      setPage(page + 1)
      setQueryList([...queryList, ...data])
      setDataFetching(false)
      if (data.length < 6) setStopFetching(true)
    } catch (error) {
      console.error(error)
    }
  }

  const searchClickHandler = (val, item) => {
    // setShowFullScreen(true)
    setCurrentCourse(item)
  }

  useEffect(() => {
    trackEvent(BIT_EVENTS.HOMEPAGE_VIEWED, {
      student_id: getCode(),
    })
    setFinalUrl(objectToQueryString(paramObj))
  }, [])

  useEffect(() => {
    ;(async () => {
      if (hasAuthToken()) {
        let { following } = await getDefaultFollowingList()
        setFollowingList(following)
      }
    })()
  }, [])

  const searchHandler = async () => {
    trackEvent(BIT_EVENTS.SEARCH_CLICKED, {
      keyword: search,
      student_id: getCode(),
    })

    router.push(
      `/search-result-page/${finalUrl}&q=${sanitizeSpecialCharacter(search)}`
    )
  }

  const onTabChangeHandler = async (key) => {
    trackEvent(BIT_EVENTS.SEARCH_TAB_CLICKED, {
      student_id: getCode(),
    })
    setKey(key)
    setDataFetching(true)
    const { data } = await filteredSearchData(search, key, 1)
    setPage(1)
    setQueryList(data)
    if (data.length < 6) setStopFetching(true)
    else setStopFetching(false)
    setDataFetching(false)
  }

  //handing app header background transition on scroll
  const [stickyHeader, setStickyHeader] = useState(false)

  const handleScroll = (e) => {
    const { scrollTop } = e.target
    if (scrollTop >= 20 && !stickyHeader) setStickyHeader(true)
    else if (scrollTop === 0 && stickyHeader) setStickyHeader(false)
  }

  // change top section background after one second
  const [documentLoading, setDocumentLoading] = useState(true)
  useEffect(() => {
    const timer = setTimeout(() => {
      setDocumentLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (router.asPath.includes("?")) {
      const query = new URLSearchParams(router.asPath?.split("?")[1]).get("q")
      if (query) setSearch(query)
    }
    // if (router.asPath.includes("#")) router.push("/live-courses/search")

    if (exists(queryList) && queryList.length < 6) {
      setStopFetching(true)
    }
  }, [])

  // Fetch live courses list
  useEffect(() => {
    const fetchLiveCourses = async () => {
      try {
        const { data } = await getLiveCourses()
        setLiveCoursesList(data)
      } catch (error) {
        console.log(error)
      }
    }
    fetchLiveCourses()
  }, [])

  // ---do not delete---
  // mock livestream
  // useEffect(()=> {
  //   const {data} = getLiveCourses()
  //   setLiveCoursesList(data)
  // },[])

  return (
    <div>
      <Head>
        <title>
          BitClass: World’s Biggest Platform To Learn Anything. Live. Together.
        </title>
        <meta
          name="description"
          content="BitClass is your campus on the internet. Learn new-age skills, network with learners across the globe, attend events and fests online, enjoy a library full of curated content and much more."
        />
        <meta
          name="keywords"
          content={`Live Online Course, Online Class, Live courses, BitClass Classes`}
        />
        <meta
          property="og:title"
          content="BitClass: World’s Biggest Platform To Learn Anything. Live. Together."
        />
        <meta
          property="og:description"
          content="BitClass is your campus on the internet. Learn new-age skills, network with learners across the globe, attend events and fests online, enjoy a library full of curated content and much more."
        />
        <meta
          property="og:image"
          content="https://res.cloudinary.com/bitclass/image/upload/v1617623261/Assets/Frame_892_ikhor0.png"
        />
        <meta
          property="og:url"
          content="https://www.bitclass.live/live-courses/search"
        />
        <meta
          name="twitter:title"
          content="BitClass: World’s Biggest Platform To Learn Anything. Live. Together."
        />
        <meta
          name="twitter:description"
          content="BitClass is your campus on the internet. Learn new-age skills, network with learners across the globe, attend events and fests online, enjoy a library full of curated content and much more."
        />
        <meta
          name="twitter:image"
          content="https://res.cloudinary.com/bitclass/image/upload/v1617623261/Assets/Frame_892_ikhor0.png"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta property="og:site_name" content="BitClass" />
      </Head>

      {/* <BackTop visibilityHeight={100} /> */}
      <div
        className={styles.wrapper}
        //  onScroll={handleScroll}
      >
        <header>
          <DynamicAppHeader
            className={styles.stickyHeader}
            page="search"
            isMobile={isMobile}
            isTablet={isIpad}
            props={props}
            darkMode={false}
            transparentMode={false}
            showHamburgerMenu={true}
          />
        </header>

        <div className={styles.headerContainer} id="top">
          <div
            style={{
              height: isMobile ? "30rem" : isTablet || isIpad ? "40vh" : "85vh",
            }}
          >
            {documentLoading ? (
              <div
                style={{
                  width: "100%",
                  height: isMobile
                    ? "30rem"
                    : isTablet || isIpad
                    ? "40vh"
                    : "85vh",
                  background:
                    "linear-gradient(90deg, #314755 0%, #26A0DA 100%)",
                }}
              />
            ) : (
              <video
                width="100%"
                height="100%"
                muted
                autoPlay
                loop
                playsInline
                style={{
                  objectFit: "cover",
                  background:
                    "linear-gradient(90deg, #314755 0%, #26A0DA 100%)",
                }}
              >
                <source
                  src={
                    isMobile
                      ? "https://res.cloudinary.com/bitclass/video/upload/f_auto/q_50/Assets/MWEB-banner-video_jdcgki.mp4"
                      : "https://res.cloudinary.com/bitclass/video/upload/f_auto/q_50/w_1000/Assets/Web-video-banner_iawbzw.mp4"
                  }
                  type="video/mp4"
                />
              </video>
            )}
          </div>
          <div className={styles.colorBlur} />
          <div className={styles.leftHeading}>
            <h1>Learn Live. Learn Together.</h1>
            <p>
              <strong>
                Where the most passionate, ambitious and creative people learn
                and grow
              </strong>
            </p>
            <div>
              <div className={styles.searchInput}>
                <Input
                  onChange={(e) => setSearch(e.target.value)}
                  className={styles.input}
                  value={search}
                  prefix={<Search />}
                  placeholder={`Search for courses`}
                  onKeyPress={(e) => {
                    setStopFetching(false)
                    if (e?.code === "Enter") {
                      searchHandler()
                    }
                  }}
                />
                <AntPrimaryButton
                  text="Search"
                  customClass={styles.button}
                  onClick={searchHandler}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Tab section starts */}

        <div className={styles.bodyWrapper}>
          <div className={styles.bodyContainer}>
            <div className={styles.titleText}>
              <h2 ref={liveList} className={styles.bodyHeader}>
                The world's largest platform for live courses by the best
                teachers.
              </h2>
              <p>
                Choose from 3,000 online live courses with new additions
                published every day
              </p>
            </div>
            {/* live course carousel   */}

            {liveCoursesList && liveCoursesList.length > 3 ? (
              <div className={styles.coursesCarouselWrapper}>
                <CoursesCarousel
                  autoplay={autoPlay}
                  infinite={true}
                  page="homepage"
                  onClick={() => trackEvent("homepage_carousel_scroll", {})}
                  heading={"Live Classes - Happening right now!"}
                  isMobile={isMobile}
                  isTablet={isTablet || isIpad}
                  disableSeeAll={true}
                >
                  {liveCoursesList.map((item, index) => {
                    return (
                      <DynamicRootInstance
                        key={index}
                        page="homepage"
                        trackEventName={BIT_EVENTS.COURSE_CARD_CLICKED}
                        trackPayload={{
                          course_type: "live_classes",
                          source: "direct",
                          course_title: item?.heading,
                          course_price: get(
                            item,
                            "demo[0].amount",
                            get(item, "amount", null)
                          ),
                          course_code: get(
                            item,
                            "demo[0].code",
                            get(item, "code", null)
                          ),
                          course_time_schedule: item?.weekly_schedule
                            ? item?.weekly_schedule.map((ws) =>
                                dayjs.unix(ws).format("hh:mm a")
                              )
                            : [],
                          course_start_date: item?.start_ts
                            ? dayjs.unix(item?.start_ts).format("YYYY-MM-DD")
                            : "",
                          course_end_date: item?.end_ts
                            ? dayjs.unix(item?.end_ts).format("YYYY-MM-DD")
                            : "",
                          teacher_name: get(item, "teacher.name", null),
                          course_category: get(item, "categories", []),
                        }}
                        isMobile={isMobile}
                        item={item}
                        index={index}
                        setCourseDetails={setCourseDetails}
                        setLiveStreamUrl={setLiveStreamUrl}
                        setShowFullScreen={setShowFullScreen}
                        searchClicked={(value) =>
                          searchClickHandler(value, item)
                        }
                        setAutoPlay={setAutoPlay}
                        finalUrl={finalUrl}
                        customClass={styles.liveCourseCard}
                        followingList={followingList}
                        follow={follow}
                        setFollow={setFollow}
                      />
                    )
                  })}
                </CoursesCarousel>
              </div>
            ) : liveCoursesList.length > 0 && liveCoursesList.length < 4 ? (
              <>
                <h3 className={styles.liveCourseTitle}>
                  Live Classes - Happening right now!
                </h3>
                <div className={styles.liveCoursesCards}>
                  {liveCoursesList.map((item, index) => {
                    return (
                      <DynamicRootInstance
                        key={index}
                        page="homepage"
                        trackEventName={BIT_EVENTS.COURSE_CARD_CLICKED}
                        trackPayload={{
                          course_type: "live_classes",
                          source: "direct",
                          course_title: item?.heading,
                          course_price: get(
                            item,
                            "demo[0].amount",
                            get(item, "amount", null)
                          ),
                          course_code: get(
                            item,
                            "demo[0].code",
                            get(item, "code", null)
                          ),
                          course_time_schedule: item?.weekly_schedule
                            ? item?.weekly_schedule.map((ws) =>
                                dayjs.unix(ws).format("hh:mm a")
                              )
                            : [],
                          course_start_date: item?.start_ts
                            ? dayjs.unix(item?.start_ts).format("YYYY-MM-DD")
                            : "",
                          course_end_date: item?.end_ts
                            ? dayjs.unix(item?.end_ts).format("YYYY-MM-DD")
                            : "",
                          teacher_name: get(item, "teacher.name", null),
                          course_category: get(item, "categories", []),
                        }}
                        isMobile={isMobile}
                        item={item}
                        index={index}
                        setCourseDetails={setCourseDetails}
                        setLiveStreamUrl={setLiveStreamUrl}
                        setShowFullScreen={setShowFullScreen}
                        searchClicked={(value) =>
                          searchClickHandler(value, item)
                        }
                        finalUrl={finalUrl}
                        customClass={styles.cardWrapper}
                        followingList={followingList}
                        setFollow={setFollow}
                        follow={follow}
                      />
                    )
                  })}
                </div>
              </>
            ) : (
              ""
            )}
            {/* Tabs  */}

            <Tabs defaultActiveKey="3" onChange={onTabChangeHandler}>
              {/* <TabPane tab="Free Classes" key="2"></TabPane> */}
              <TabPane tab="Workshops" key="3"></TabPane>
              <TabPane tab="Courses" key="4"></TabPane>
            </Tabs>

            {queryList && queryList.length > 0 ? (
              <>
                <div className={styles.cardSection}>
                  {queryList.map((item, index) => {
                    return (
                      <DynamicRootInstance
                        key={index}
                        page="searchCard"
                        trackEventName={BIT_EVENTS.COURSE_CARD_CLICKED}
                        trackPayload={{
                          course_type: key === "3" ? "workshops" : "courses",
                          source: "direct",
                          course_title: item?.heading,
                          course_price: get(
                            item,
                            "demo[0].amount",
                            get(item, "amount", null)
                          ),
                          course_code: get(
                            item,
                            "demo[0].code",
                            get(item, "code", null)
                          ),
                          course_time_schedule: item?.weekly_schedule
                            ? item?.weekly_schedule.map((ws) =>
                                dayjs.unix(ws).format("hh:mm a")
                              )
                            : [],
                          course_start_date: item?.start_ts
                            ? dayjs.unix(item?.start_ts).format("YYYY-MM-DD")
                            : "",
                          course_end_date: item?.end_ts
                            ? dayjs.unix(item?.end_ts).format("YYYY-MM-DD")
                            : "",
                          teacher_name: get(item, "teacher.name", null),
                          course_category: get(item, "categories", []),
                        }}
                        isMobile={isMobile}
                        item={item}
                        index={index}
                        setCourseDetails={setCourseDetails}
                        setLiveStreamUrl={setLiveStreamUrl}
                        setShowFullScreen={setShowFullScreen}
                        searchClicked={(value) =>
                          searchClickHandler(value, item)
                        }
                        finalUrl={finalUrl}
                        customClass={styles.card}
                        followingList={followingList}
                        follow={follow}
                        setFollow={setFollow}
                      />
                    )
                  })}
                </div>
                {/* <!-- Add Ref to Load More div --> */}
                {!stopFetching && (
                  <div className={styles.loading}>
                    <button onClick={loadMoreCourses}>
                      {dataFetching ? "Loading..." : "Show More Results"}{" "}
                    </button>
                  </div>
                )}
                <div id="campus-feed-entry" />
              </>
            ) : (
              <div className={styles.noResults}>
                Clearly your taste is better than ours. Try again with different
                keyword...!
              </div>
            )}
          </div>
        </div>
        <div id="campus-feed-entry" />
        <div className={styles.feedHeader}>
          <div className={styles.feedTitle}>
            <img
              src="/static/__assets__/BitClassLogos/LogoSmallForDarkBG.svg"
              alt="feed title logo"
            />
            <div className={styles.title}>Campus on cloud</div>
          </div>
          {/* <div className={styles.subTitle}>University on cloud</div> */}
          <div className={styles.appstorecontainer}>
            <a
              onClick={() =>
                trackEvent(BIT_EVENTS.DOWNLOAD_IOS_CLICKED, {
                  source: "home",
                  student_id: getCode(),
                })
              }
              href={`https://apps.apple.com/in/app/bitclass/id1537353964`}
            >
              <img
                src="/static/__assets__/appstore-1.svg"
                alt="apple store"
                style={{ marginRight: ".5rem" }}
              />
            </a>
            <a
              onClick={() =>
                trackEvent(BIT_EVENTS.DOWNLOAD_ANDROID_CLICKED, {
                  source: "home",
                  student_id: getCode(),
                })
              }
              href={`https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=mweb&utm_medium=mweb-classroom-student&utm_campaign=gplayicon`}
            >
              <img
                src="/static/__assets__/googleplay-1.svg"
                alt="google play"
              />
            </a>
          </div>
        </div>
        <FeedContainer />
        <div className={styles.footer} id="download-the-app">
          <div className={styles.footerLeft}>
            <h1>Learn from Anywhere</h1>
            <p>
              Take Live classes on the go with the BitClass app. Download to
              watch on the bus, the metro, or wherever you learn best.
            </p>
            <div className={styles.appstorecontainer}>
              <a
                onClick={() =>
                  trackEvent(BIT_EVENTS.DOWNLOAD_IOS_CLICKED, {
                    source: "home",
                    student_id: getCode(),
                  })
                }
                href={`https://apps.apple.com/in/app/bitclass/id1537353964`}
              >
                <img
                  src="/static/__assets__/appstore-1.svg"
                  alt="apple store"
                  style={{ marginRight: ".5rem" }}
                />
              </a>
              <a
                onClick={() =>
                  trackEvent(BIT_EVENTS.DOWNLOAD_ANDROID_CLICKED, {
                    source: "home",
                    student_id: getCode(),
                  })
                }
                href={`https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=mweb&utm_medium=mweb-classroom-student&utm_campaign=gplayicon`}
              >
                <img
                  src="/static/__assets__/googleplay-1.svg"
                  alt="google play"
                />
              </a>
            </div>
          </div>
          {!isMobile && (
            <div className={styles.footerImg}>
              <img
                src={
                  "https://res.cloudinary.com/bitclass/image/upload/f_auto/q_30/Assets/Frame_igizbz.png"
                }
                alt="iphone"
              />
            </div>
          )}
        </div>
        <AppFooterV3 />
        <AntFullScreenModal
          visible={showFullScreen}
          cancelFn={() => {
            setShowFullScreen(false)
            trackEvent(BIT_EVENTS.LIVE_VIDEO_CLOSED, {
              course_type: "live_classes",
              student_id: getCode(),
              course_code: courseDetails?.courseCode,
              course_category: courseDetails.categories,
            })
          }}
          titleClass={styles.title}
          title={courseDetails && courseDetails.heading}
          footer={null}
          centered={true}
          destroyOnClose={true}
          containerClass={styles.livestreamModalWrapper}
          bodyClass={styles.livestreamModalContainer}
          videoPlayer={true}
          zIndex="10000000000"
          body={
            <LiveStreamPlayer
              isMobile={isMobile}
              courseDetails={courseDetails}
              showFullScreen={showFullScreen}
              liveStreamUrl={liveStreamUrl}
              videoModalDetails={videoModalDetails}
              liveUsers={liveUsers}
              customClass={styles.liveStreamWrapper}
              // follow = {follow}
              // setFollow = {setFollow}
              // load = {load}
              // setLoad = {setLoad}
            />
          }
        />
      </div>
    </div>
  )
}

SearchPage.getInitialProps = async (context) => {
  let ua
  let keyword
  let queryList
  let params

  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    ua = useUserAgent(context.req.headers["user-agent"])
  } else ua = { isMobile }

  let paramObj = {
    platform: ua.isMobile ? "mweb" : "web",
  }
  if (context.asPath.includes("?")) {
    params = new URLSearchParams(context.asPath?.split("?")[1])
    for (let value of params.keys()) {
      paramObj[value] = params.get(value)
    }
    keyword = new URLSearchParams(context.asPath?.split("?")[1]).get("q")
  } else {
    keyword = ""
  }

  if (typeof keyword === "undefined" || !exists(keyword)) {
    keyword = ""
  }

  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    ua = useUserAgent(context.req.headers["user-agent"])
  } else ua = { isMobile }
  try {
    queryList = await filteredSearchData(keyword, DEFAULT_TAB_KEY, 1)
    if (exists(queryList["data"])) {
      queryList["data"].sort((a, b) => a.amount - b.amount)
    }
  } catch (e) {
    queryList = null
  }
  return {
    ua,
    queryList,
    paramObj,
  }
}

export default withUserAgent(SearchPage)
