import { API_URL, BASE_URL } from "src/constants"
import { get } from "lodash"
import { useUserAgent, withUserAgent } from "next-useragent"
import Heading from "src/freemium/common/Heading"
import AboutSection from "src/freemium/AboutSection"
import { isMobile, isTablet } from "react-device-detect"
import styles from "./style.module.scss"
import { getCourseData } from "src/combined-cdp/apiController"
import CdpCarousel from "src/cdp/__components__/common/CdpCarousel"
import {
  exists,
  getUrlParametersAsArray,
  isObjectHasTrueValues,
  saveAnalyticsData,
  scrollFunctionWithOffset,
} from "src/__utils__"
import ShowMoreText from "react-show-more-text"
import { ChevronDown, ChevronsUp, ChevronUp } from "react-feather"
import FAQs from "src/cdp/__components__/FAQs"
import TeacherSection from "src/cdp/__components__/TeacherSection"
import SlotComponent from "src/cdp/__components__/SlotComponent"
import VideoComponent from "src/cdp/__components__/VideoComponent"
import dynamic from "next/dynamic"
import AdditionalInfo from "src/cdp/__components__/AdditionalInfo"
import Seperator from "src/freemium/common/Seperator"
import InviteSection from "src/cdp/__components__/InviteSection"
import clsx from "clsx"
import ChangingBackground from "src/cdp/__components__/VideoComponent/ChangingBackground"
import NextHead from "src/__components__/NextHead"
import { CDP_PAGE, DEMO_CDP, FULL_COURSE_CDP } from "src/__utils__/pages"
// import SuccessModal from "src/profile/__components__/SuccessModal"
import { UserContext } from "context/User"
import { useContext, useEffect, useRef, useState } from "react"
import { getCode } from "src/__utils__/auth"
import dayjs from "dayjs"
import trackEvent from "src/__utils__/analytics"
import { BIT_EVENTS } from "config/events"
import BitSkeletonLoader from "src/__components__/BitSkeletonLoader"
import NotifyCourseModal from "src/__components__/NotifyCourseModal"
import { AppContext } from "context/AppContext/AppContext"
import { SET_SLOT, SET_TRANSPARENT_LOADER } from "context/AppContext/types"
import { useRouter } from "next/router"
import { registerStudentForCourse } from "src/__utils__/api"
import TransparentLoader from "src/__components__/TransparentLoader"
import AppFooterV3 from "src/__components__/AppFooter/v3"
import OptimizedImage from "src/__components__/OptimizedImage"
import AntFullScreenModal from "src/__components__/Modal/AntFullScreenModal"
import ImageGallery from "react-image-gallery"
import ImageGallerySvg from "public/static/__assets__/image-gallery.svg"
import BitPureCarousel from "../../../../src/__components__/BitPureCarousel/BitPureCarousel"
import CoursesCarousel from "src/homepage/Courses"
import CdpNewCarousel from "src/cdp/__components__/cdpCarousel"
import useSavePageState from "src/homepage/hooks/useSavePageState"

const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const SuccessModal = dynamic(
  () => import("src/profile/__components__/SuccessModal"),
  {
    ssr: false,
  }
)

const CheckoutModal = dynamic(() => import("src/demo-cdp/CheckoutModal"), {
  ssr: false,
  loading: () => <BitSkeletonLoader loading={true} />,
})

const EnquiryModal = dynamic(() => import("src/__components__/EnquiryModal"), {
  ssr: false,
  loading: () => <BitSkeletonLoader loading={true} />,
})

const _gradients = [
  "linear-gradient(225.92deg, #33D2FF 5.73%, #3D68DE 54.65%, #9845E8 96.75%)",
  "linear-gradient(135deg, #B65FC4 2.88%, #DB6E4E 100%)",
  "linear-gradient(224.86deg, #73CCD8 4.87%, #2B6B9F 96.04%)",
  "linear-gradient(135deg, #6964DE 2.88%, #FCA6E9 100%)",
  "linear-gradient(315deg, #21BDB8 0%, #280684 100%)",
]

const CDP = ({
  course,
  nextUserAgent,
  profile,
  introVideo,
  thumbnail,
  featureInclusion,
  courseLearning,
  initialPageState,
  pageUrl,
  metaInfo,
  demolist,
  tmprCode,
  cdpType,
  setSlot,
  categoryText,
}) => {
  useSavePageState(initialPageState)

  const { state, dispatch } = useContext(AppContext)
  const { isMobile, isTablet } = nextUserAgent
  const router = useRouter()
  const UserState = useContext(UserContext)
  const [SuccessModalFlag, setSuccessModalFlag] = useState(false)
  const [SuccessModalStatus, setSuccessModalStatus] = useState("success")
  const [trackingBaseData, setTrackingBaseData] = useState({})
  const [dynamicCompLoading, setDynamicCompLoading] = useState(false)
  const [galleryModalVisible, setGalleryModalVisible] = useState(false)
  const [galleryStartIndex, setGalleryStartIndex] = useState(0)
  const [isRegistered, setIsRegistered] = useState(false)

  // const freeClassesRef = useRef()

  let limitImage =
    exists(course) &&
    exists(course?.featured_images) &&
    course?.featured_images.length > 3
      ? 2
      : 3

  useEffect(() => {
    ;(async () => {
      if (cdpType !== DEMO_CDP) {
        localStorage.setItem("selectedCourse", JSON.stringify(null))
      }
      let urlParams = getUrlParametersAsArray(window.location.href)
      let baseTracking = {
        source: exists(urlParams["source"]) ? urlParams["source"] : "direct",
        student_id: getCode(),
        course_title: course?.heading,
        course_price: course?.amount,
        course_code: course?.code,
        course_time_schedule: course?.weekly_schedule
          ? course?.weekly_schedule.map((ws) =>
              dayjs.unix(ws).format("hh:mm a")
            )
          : [],
        course_start_date: course?.start_ts
          ? dayjs.unix(course?.start_ts).format("YYYY-MM-DD")
          : "",
        course_end_date: course?.end_ts
          ? dayjs.unix(course?.end_ts).format("YYYY-MM-DD")
          : "",
        teacher_name: profile ? profile?.teacher_name : "",
        course_type: course?.type,
        course_category: [],
        tmpr_code: tmprCode,
      }
      setTrackingBaseData(baseTracking)
      trackEvent(BIT_EVENTS.CDP_VIEWED, baseTracking)
      setDynamicCompLoading(false)
      dispatch({ type: SET_SLOT, payload: setSlot[0] })
      saveAnalyticsData(baseTracking)
      // trackevent ends

      let queryParams = getUrlParametersAsArray(router.asPath)
      // stripe payment
      try {
        let { _orderCode, _paymentMode, _paymentStatus } = queryParams
        if (_paymentStatus === "successful") {
          dispatch({ type: SET_TRANSPARENT_LOADER, payload: true })
          let _regStatus = await registerStudentForCourse(
            course?.code,
            _orderCode,
            null,
            _paymentMode
          )
          if (!_regStatus["success"]) {
            UserState.paymentInProgress({ status: false, courseCode: "" })
            setSuccessModalStatus("failure")
            setSuccessModalFlag(true)
            trackEvent(BIT_EVENTS.PAYMENT_FAILED, trackingBaseData)
          } else {
            UserState.paymentInProgress({
              status: "done",
              courseCode: course?.code,
            })
            setSuccessModalStatus("success")
            setSuccessModalFlag(true)
            if (window.location.hostname.includes("bitclass.live")) {
              try {
                const { default: ReactPixel } = await import(
                  "react-facebook-pixel"
                )
                if (course.amount === 0) {
                  ReactPixel.trackCustom("FreeCourseRegistered", {
                    title: `Course Title: ${course.heading}`,
                    courseCode: course?.code,
                    _orderCode,
                  })
                } else if (course.amount > 0 && course.amount <= 99) {
                  ReactPixel.trackCustom("CoursePurchaseSuccess", {
                    title: `Course Title: ${course.heading}`,
                    courseCode: course?.code,
                    _orderCode,
                  })
                } else if (course.amount > 99) {
                  ReactPixel.trackCustom("FullCourseRegistered", {
                    title: `Course Title: ${course.heading}`,
                    courseCode: course?.code,
                    _orderCode,
                    amount: course.amount,
                  })
                }
              } catch (e) {
                console.log(e)
              }
            }
          }
        } else if (
          _orderCode &&
          _paymentMode &&
          _paymentStatus !== "successful"
        ) {
          UserState.paymentInProgress({ status: false, courseCode: "" })
          setSuccessModalStatus("failure")
          setSuccessModalFlag(true)
          trackEvent(BIT_EVENTS.PAYMENT_FAILED, trackingBaseData)
        }
      } catch (err) {
        return // handle error once we build error component
      } finally {
        dispatch({ type: SET_TRANSPARENT_LOADER, payload: false })
      }
    })()
  }, [])

  return (
    <div className={styles.wrapper}>
      <NextHead page={CDP_PAGE} payload={metaInfo} />

      <AppHeader
        // className={styles.header}
        className={styles.stickyHeader}
        page={CDP_PAGE}
        showHamburgerMenu={false}
        isMobile={nextUserAgent?.isMobile}
        isTablet={nextUserAgent?.isTablet || nextUserAgent?.isIpad}
      />
      <ChangingBackground />
      {/* Slot component in desktop */}

      <div className={styles.cdpSubWrapper}>
        <div className={styles.firstContainer}>
          <VideoComponent
            course={course}
            profile={profile}
            thumbnail={thumbnail}
            introVideo={introVideo}
            customClass={styles.videoComponentWrapper}
            trackingBaseData={trackingBaseData}
            isMobile={isMobile}
            pageUrl={pageUrl}
          />
          <div className={styles.margin}></div>

          {/* Slot start */}
          {isMobile && (
            <SlotComponent
              cdpType={cdpType}
              demolist={demolist}
              course={course}
            />
          )}
          {/* Slot end */}

          <div className={styles.margin}></div>

          {course?.featured_images && course?.featured_images.length > 0 && (
            <div className={styles.imageGalleryWrapper}>
              <Heading
                text={
                  <p>
                    Gallery <span>Images</span>
                  </p>
                }
                customClass={styles.headingWrapper}
              />
              <div className={styles.imageThumbnailContainer}>
                {course?.featured_images
                  .slice(0, limitImage)
                  .map((item, index) => (
                    <div className={styles.seeMoreMain}>
                      <OptimizedImage
                        keepOriginal={false}
                        imgQuality="1"
                        // width='120'
                        onClick={() => {
                          trackEvent(BIT_EVENTS.CDP_SNEAK_PEAK_IMAGE_CLICKED, {
                            ...trackingBaseData,
                            card_no: index,
                          })
                          setGalleryStartIndex(index)
                          setGalleryModalVisible(true)
                          // setShowThumbnail(false)
                        }}
                        className={styles.thumbnailImg}
                        src={item}
                        alt="gallery"
                      />
                    </div>
                  ))}
                {course?.featured_images.length > 3 && (
                  <div className={styles.seeMoreMain}>
                    <img
                      onClick={() => {
                        setGalleryStartIndex(2)
                        setGalleryModalVisible(true)
                      }}
                      className={styles.thumbnailImg}
                      src={course?.featured_images[2]}
                      alt="gallery"
                    />
                    <span
                      onClick={() => {
                        trackEvent(
                          BIT_EVENTS.CDP_SNEAK_PEAK_SEE_MORE_CLICKED,
                          trackingBaseData
                        )
                        setGalleryStartIndex(2)
                        setGalleryModalVisible(true)
                      }}
                    >
                      See More
                    </span>
                  </div>
                )}
              </div>
              <div className={styles.margin}></div>
            </div>
          )}
          {/* image gallery ends */}

          {exists(course && course?.goal) && (
            <>
              <Heading
                text={
                  <p>
                    About this <span>Course</span>
                  </p>
                }
                customClass={styles.headingWrapper}
              />
              <AboutSection
                course={course}
                isMobile={isMobile}
                customClass={styles.marginAdder}
                trackingBaseData={trackingBaseData}
              />
            </>
          )}

          <div className={styles.margin}></div>

          <InviteSection
            url={pageUrl}
            customclass={styles.inviteSectionWrapper}
            course={course}
            trackingBaseData={trackingBaseData}
            pageType="cdp-demo"
            isMobile={isMobile}
          />

          <div className={styles.margin}></div>

          {/* Higlights started */}

          {exists(course && course?.highlights) && (
            <>
              <Heading
                text={
                  <p>
                    Course <span>Highlights</span>
                  </p>
                }
                customClass={styles.headingWrapper}
              />
              <CdpCarousel
                customClass={styles.carousalWrapper}
                bodyClass={styles.carousalBody}
                isMobile={isMobile}
                isTablet={isTablet}
                autoplay={true}
              >
                {course?.highlights.map((item, index) => (
                  <div key={index.toString()}>
                    <div
                      className={styles.course}
                      style={{ background: _gradients[index % 5] }}
                    >
                      <p className={styles.courseNumber}>0{index + 1}</p>
                      <p className={styles.details}>{item}</p>
                    </div>
                  </div>
                ))}
              </CdpCarousel>
            </>
          )}

          {/* Higlights ended */}

          <div className={styles.margin}></div>
          {(isObjectHasTrueValues(featureInclusion) ||
            courseLearning.length > 0) && (
            <AdditionalInfo
              courseLearning={courseLearning}
              featureInclusion={featureInclusion}
            />
          )}

          {/* About teacher section */}

          {exists(profile?.story) && (
            <>
              <Seperator customClass={styles.seperatorClass} />
              <TeacherSection
                trackingBaseData={trackingBaseData}
                profile={profile}
                isMobile={isMobile}
              />
            </>
          )}

          <div className={styles.margin}></div>

          {/* Testimonials */}
          {exists(course?.testimonials) && course?.testimonials.length > 0 && (
            <>
              <Heading
                text={<p>Testimonials</p>}
                customClass={styles.headingWrapper}
              />
              <CdpCarousel
                isMobile={isMobile}
                isTablet={isTablet}
                darkDots={isMobile || isTablet}
                heading=""
                customClass={styles.carousalTestimonialWrapper}
                bodyClass={styles.carousalBody}
                autoplay={true}
              >
                {course?.testimonials.map((t, index) => (
                  <div key={index.toString()}>
                    <div className={styles.testimonial}>
                      <div className={styles.profile}>
                        <div>
                          <img
                            src="/static/__assets__/teacher-empty.svg"
                            alt="Course Testimonial"
                          />
                        </div>
                        <h5>{t.student_name}</h5>
                      </div>
                      <ShowMoreText
                        lines={1}
                        more={
                          <div>
                            {" "}
                            <span>See more</span>
                            <ChevronDown />
                          </div>
                        }
                        less={
                          <div>
                            {" "}
                            <span>Show less</span> <ChevronUp />
                          </div>
                        }
                        expanded={false}
                        anchorClass={styles.readMoreText}
                        width={600}
                      >
                        {t.testimonial}
                      </ShowMoreText>
                    </div>
                  </div>
                ))}
              </CdpCarousel>
            </>
          )}

          <div className={styles.margin}></div>
          {/* FAQs */}
          {exists(course?.faqs) && (
            <>
              <Heading
                text={
                  <p>
                    Frequently Asked <span>Questions</span>
                  </p>
                }
                customClass={styles.headingWrapper}
              />
              <FAQs
                className={styles.faqWrapper}
                courseCode={course?.code}
                data={course?.faqs}
                heading={""}
                disable={false}
                trackingBaseData={trackingBaseData}
              />
            </>
          )}
        </div>

        {!isMobile && (
          <div className={styles.stickyRightBar}>
            <SlotComponent
              cdpType={cdpType}
              course={course}
              customClass={styles.slotRightSection}
              demolist={demolist}
            />
            <div
              className={clsx(
                styles.registrationBlock,
                styles.desktopRegButton
              )}
            >
              <CheckoutModal
                tmprCode={course?.code}
                course={course}
                demos={demolist}
                btnClass={styles.regButton}
                trackingBaseData={trackingBaseData}
                cdpType={cdpType}
              />

              {course?.has_ended ? (
                <NotifyCourseModal
                  teacherName={profile?.teacher_name}
                  teacherHandle={profile?.profile_id}
                  className={styles.notification}
                  courseCode={course?.code}
                />
              ) : (
                ""
              )}
            </div>
          </div>
        )}
      </div>
      {isMobile && (
        <div className={styles.registrationBlock}>
          <BitSkeletonLoader loading={dynamicCompLoading} />
          <CheckoutModal
            tmprCode={course?.code}
            course={course}
            demos={demolist}
            btnClass={styles.regButton}
            trackingBaseData={trackingBaseData}
            cdpType={cdpType}
          />

          {course?.has_ended ? (
            <NotifyCourseModal
              teacherName={profile?.teacher_name}
              teacherHandle={profile?.profile_id}
              className={styles.notification}
              courseCode={course?.code}
            />
          ) : (
            ""
          )}
        </div>
      )}

      {/*Recommended section */}
      <div id="free-classes">
        <CoursesCarousel
          selectedCategory={categoryText}
          autoplay={true}
          infinite={true}
          page={CDP_PAGE}
          isMobile={isMobile}
          isTablet={isTablet}
          disableSeeAll={true}
          customClass={styles.coursesCarouselWrapper}
          courseType={course?.type}
          courseCode={course?.code}
          tmprCode={tmprCode}
          teacherId={profile?.profile_id}
        />
      </div>

      <UserContext.Consumer>
        {(User) => {
          if (
            User.globalState.status === "done" ||
            User.globalState.status === "failed"
          )
            setSuccessModalFlag(true)
          if (User.globalState.status === "done") {
            setSuccessModalStatus("success")
          } else {
            setSuccessModalStatus("failed")
          }
          return (
            <SuccessModal
              SuccessModalFlag={SuccessModalFlag}
              setSuccessModalFlag={setSuccessModalFlag}
              status={SuccessModalStatus}
              course={course}
              courseCode={course?.code}
              demos={demolist}
              trackingBaseData={trackingBaseData}
              newDemo={true}
            />
          )
        }}
      </UserContext.Consumer>
      {state?.showLoader && <TransparentLoader />}

      <AntFullScreenModal
        visible={galleryModalVisible}
        cancelFn={() => {
          setGalleryModalVisible(false)
        }}
        body={
          <ImageGallery
            additionalClass={styles.imageGalleryContainer}
            showThumbnails={false}
            showPlayButton={false}
            showFullscreenButton={false}
            startIndex={galleryStartIndex}
            items={
              exists(course) && exists(course?.featured_images)
                ? course?.featured_images.map((i, key) => {
                    if (
                      key !== course?.featured_images.length - 1 ||
                      isRegistered
                    ) {
                      return {
                        original: i,
                      }
                    } else {
                      return {
                        renderItem: () => (
                          <div
                            className={styles.buttonContainer}
                            style={{
                              width: "100%",
                              display: "flex",
                              alignItems: "center",
                            }}
                          >
                            <div
                              style={{
                                width: "300px",
                                margin: "0 auto",
                              }}
                            >
                              <h3
                                style={{ marginBottom: "20px", color: "white" }}
                              >
                                Love these Images? Join Now!
                              </h3>
                              <ImageGallerySvg width="200px" height="100px" />
                              {course ? (
                                <CheckoutModal
                                  tmprCode={course?.code}
                                  course={course}
                                  demos={demolist}
                                  btnClass={styles.regButton}
                                  trackingBaseData={trackingBaseData}
                                  cdpType={cdpType}
                                />
                              ) : (
                                <NotifyCourseModal
                                  notifyButtonStyle={styles.notifyButtonStyle}
                                  teacherName={profile?.teacher_name}
                                  teacherHandle={profile?.profile_id}
                                  className={styles.notification}
                                  courseCode={
                                    course?.code || router.query.course
                                  }
                                />
                              )}
                            </div>
                          </div>
                        ),
                      }
                    }
                  })
                : []
            }
            onSlide={(currentIndex) => {
              trackEvent(
                BIT_EVENTS.CDP_SNEAK_PEAK_ARROW_CLICKED,
                trackingBaseData
              )
            }}
          />
        }
        titleClass={styles.title}
        title={null}
        footer={null}
        centered={true}
        destroyOnClose={true}
        bodyClass={styles.imageModal}
        zIndex={999}
      />

      <div className={styles.appFooterWrapper}>
        <AppFooterV3 />
      </div>
    </div>
  )
}

CDP.getInitialProps = async (context) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  let nextUserAgent
  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    nextUserAgent = useUserAgent(context.req.headers["user-agent"])
  } else nextUserAgent = navigator.userAgent
  const {
    tmprCode,
    profile,
    course,
    pageUrl,
    categories,
    paramObj,
    introVideo,
    thumbnail,
    featureInclusion,
    courseLearning,
    metaInfo,
    demolist,
    cdpType,
    setSlot,
    categoryText,
  } = await getCourseData(context)

  const initialPageState = { userAgent: nextUserAgent, categories, paramObj }
  return {
    // teacherCode: course ? course["data"]?.teacher.teacher_handle : "",
    tmprCode,
    profile,
    course,
    pageUrl,
    nextUserAgent,
    introVideo,
    thumbnail,
    initialPageState,
    featureInclusion,
    courseLearning,
    metaInfo,
    demolist,
    cdpType,
    setSlot,
    categoryText,
  } // will be passed to Id react component as props
}

export default withUserAgent(CDP)
