import React, { useEffect, useState, useRef, useContext } from "react"
import { ArrowRight } from "react-feather"
import ReactPlayer from "react-player"
import clsx from "clsx"
import { Input } from "antd"
import { X } from "react-feather"
import { useUserAgent, withUserAgent } from "next-useragent"
import dynamic from "next/dynamic"
import ImageGallery from "react-image-gallery"
import "react-day-picker/lib/style.css"
import styles from "./styles.module.scss"
import Layout from "src/__components__/Layout"
import { hasAuthToken } from "src/__utils__/auth"
import SpinnerWrapper from "src/__components__/SpinnerWrapper"
import {
  SocialShareLink,
  determineCoursePrice,
} from "src/profile/__utils__"
import { getCode, getUID } from "src/__utils__/auth"
import {
  exists,
  getThumbnailFromUrl,
  appendWidthToUrl,
  getUrlParametersAsArray,
  existsV2,
  getCookieString,
  setCookie,
} from "src/__utils__"
import { BASE_URL, API_URL } from "src/constants"
import { RenderHTML } from "src/profile/__components__/RenderHTML"
import FaqComponent from "src/__components__/FAQ"
import trackEvent from "src/__utils__/analytics"
import Wallet from "public/static/__assets__/wallet.svg"
import AntCarousal from "src/__components__/AntCarousal"
import PlayIcon from "public/static/__assets__/BitPlayButton.svg"
import ImageGallerySvg from "public/static/__assets__/image-gallery.svg"
import VideoCard from "src/__components__/VideoCard"
import { validateCoupon, registerStudentForCourse, getTmprStatus } from "src/__utils__/api"
import CircularProgress from "src/__components__/CircularProgress"
import { useRouter } from "next/router"
import { UserContext } from "context/User"
// import SuccessModal from "src/profile/__components__/SuccessModal"
import Head from "next/head"
import { get, has, filter } from "lodash"
import { sanitizeHtml } from "src/__utils__"
import AntFullScreenModal from "src/__components__/Modal/AntFullScreenModal"
import OptimizedImage from "src/__components__/OptimizedImage"
import SeeMore from "src/__components__/SeeMore"
import Schedule from "src/cdp/__components__/NewSchedule"
import { BIT_EVENTS } from "config/events"
import dayjs from "dayjs"
import LoginModal from "src/storefront/LoginScreen"
import { AppContext } from "context/AppContext/AppContext"
import { TOGGLE_LOGIN_SCREEN, SET_SLOT } from "context/AppContext/types"

const { Search } = Input

/* Dynamically rendering components */
let RegisterButton = null
let DynamicAppHeader = null
let EnquiryModal = null

const SuccessModal =  dynamic(() => import("src/profile/__components__/SuccessModal"), {
  ssr: false,
})

function Course(props) {
  const { isMobile, isTablet } = props.ua
  const { teacherCode, courseCode, subject } = props
  const [profile, setProfile] = useState(
    exists(props._profile["data"]) ? props._profile["data"] : props._profile
  )
  const [course, setCourse] = useState(
    !exists(props._course["data"]["error"]) ?  
    has(props._course["data"], 'demos') ?
    get(props._course["data"], 'demos[0]', null) : 
    props._course["data"] : null)

  const [demolist, setDemoList] = useState(props._course["data"]["demos"] 
  ? props._course["data"]["demos"].filter(s => !s.has_ended) : null)



  const [fullData, setFullData] = useState(!exists(props._course["data"]["error"]) ? props._course["data"] : null )
  const [showGraphicDetails, setShowGraphicDetails] = useState(false)
  const [showEnquiryModal, setShowEnquiryModal] = useState(false)
  const [thumbnailUrl, setThumbnailUrl] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showAppHeader, setShowAppHeader] = useState(false)
  const [showRegisterBtn, setShowRegisterBtn] = useState(false)
  const [SuccessModalFlag, setSuccessModalFlag] = useState(false)
  const [SuccessModalStatus, setSuccessModalStatus] = useState("success")
  const [courseURL, setCourseURL] = useState("")
  const [galleryModalVisible, setGalleryModalVisible] = useState(false)
  const [galleryStartIndex, setGalleryStartIndex] = useState(0)
  const [isRegistered, setIsRegistered] = useState(false)
  const [ tmprRegStatus, setTmprRegStatus ] = useState(null)
  const [trackingBaseData, setTrackingBaseData] = useState({})
  const [showSlotSelection, setShowSlotSelection] = useState(false)

  const DEFAULT_TEACHER_PROFILE_IMAGE='https://res.cloudinary.com/bitclass/image/upload/v1617482858/Assets/defaultAvatar_yakmah.png'

  const {state,dispatch}=useContext(AppContext)


  // start adding variables

  const MODAL_ITEM_COUNT = isMobile ? 1 : 3
  const router = useRouter()
  const UserState = useContext(UserContext)
  let title = get(course, "heading", "")
  let faq = get(course, "faqs", [])
  let teacher = get(profile, "data", {})
  let intro_meta_thumbnail = exists(get(course, "intro_video_thumbnail", null))
    ? appendWidthToUrl(get(course, "intro_video_thumbnail", ""))
    : getThumbnailFromUrl(get(course, "intro_video", ""), true)
  let aboutCourse = get(course, "goal", "")
  let metaDesc = sanitizeHtml(aboutCourse.substring(0, 80))
  const hashCode = (s) =>
    s.split("").reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) | 0, 0)
  let mod = hashCode(courseCode) % 3
    let _url
  const _gradients = [
    "linear-gradient(90deg, #4848E9 0%, #7429CB 100%)",
    "linear-gradient(90deg, #1BAEBE 0%, #1DC69B 100%)",
    "linear-gradient(90deg, #DD5094 0%, #C82844 100%)",
    "linear-gradient(90deg, #4B6CB7 0%, #182848 100%)",
    "linear-gradient(90deg, #42275A 0%, #734B6D 100%)",
  ]

  // end variables

  // block level statements
  metaDesc = `Enrol into this live instructor-led course online on BitClass. ${metaDesc}`

  if (mod <= 0) mod *= -1
  let colorGradient = ""
  if (mod === 0) {
    colorGradient = "linear-gradient(180deg, #F1AC47, #EF7784)"
  } else if (mod === 1) {
    colorGradient = "linear-gradient(180deg, #2AA39E, #F1E447)"
  } else {
    colorGradient =
      "linear-gradient(180deg, rgba(135, 118, 199, 1), rgba(93, 170, 219, 1))"
  }
  // block level statements ended


  useEffect(()=>{
    RegisterButton = dynamic(() => import("src/payment/RegisterButton"))
    DynamicAppHeader = dynamic(() => import("src/__components__/AppHeader"))
    EnquiryModal = dynamic(() => import("src/__components__/EnquiryModal"))
    if (exists(demolist) && demolist.length > 0) {
      let filteredDemoCourses = filter(demolist, function (demo) {
        return !demo.has_ended
      })
      setDemoList(filteredDemoCourses)
      if (exists(filteredDemoCourses) && filteredDemoCourses.length > 0) {
        setCourse(filteredDemoCourses[0])
      }
    }
    setShowAppHeader(true)
    setShowRegisterBtn(true)
    setShowEnquiryModal(true)
    setShowGraphicDetails(true)
    setThumbnailUrl(
      course
        ? course.intro_video_thumbnail ||
            getThumbnailFromUrl(course.intro_video)
        : ""
    )



    if (exists(course && courseCode ) && exists(course['heading'])) {

      //set cookie re-targeting
      setCookie('multiTargeting__' + subject, courseCode, 2)

      let urlParams = getUrlParametersAsArray(window.location.href)

      let baseTracking = {
        source: exists(urlParams['source']) ? urlParams['source'] : "direct",
        student_id: getCode(),
        course_title: course?.heading,
        course_price: course?.amount,
        course_code: course?.code,
        course_time_schedule: course?.weekly_schedule
          ? course?.weekly_schedule.map(ws => dayjs.unix(ws).format('hh:mm a'))
          : [],
        course_start_date: course?.start_ts
          ? dayjs.unix(course?.start_ts).format('YYYY-MM-DD')
          : '',
        course_end_date: course?.end_ts
        ? dayjs.unix(course?.end_ts).format('YYYY-MM-DD')
        : '',
        teacher_name: profile ? profile?.teacher_name : '',
        course_type: "workshops",
        course_category: [],
        cdp_type: "multi-target",
        tmpr_code: props.courseCode,
      }
      setTrackingBaseData(baseTracking)
      trackEvent(BIT_EVENTS.CDP_VIEWED, baseTracking)
    }


    if(hasAuthToken() && courseCode ){
      (async function (){
        const checkTmprStatus = await getTmprStatus(courseCode)
        setTmprRegStatus(checkTmprStatus)
        if(checkTmprStatus['data']['is_slot_selected'] === false && 
          checkTmprStatus['data']['is_registered'] === true ){
          UserState.showDemoSlot = true
          setSuccessModalFlag(true)
        }
      })()
    }  
    if(fullData?.demo_slots?.length>0 && fullData?.demo_slots?.length<=1){
      dispatch({ type: SET_SLOT , payload: fullData?.demo_slots[0]})
    }

  
    setCourseURL(`${BASE_URL}${router.asPath}`)
  }, [])



  useEffect(() => {
    let queryParams = getUrlParametersAsArray(router.asPath)
    async function fetchData() {
      try {
        let _orderCode = queryParams.order_id
        let _paymentMode = queryParams.payment_mode
        let _paymentStatus = queryParams.payment_status
        if (_paymentStatus === "successful") {
          UserState.paymentInProgress({ status: true, courseCode: "" })
          let _regStatus = await registerStudentForCourse(
            courseCode,
            _orderCode,
            null,
            _paymentMode
          )
          if (!_regStatus["success"]) {
            UserState.paymentInProgress({ status: false, courseCode: "" })
            setSuccessModalStatus("failure")
            setSuccessModalFlag(true)
          }
          UserState.paymentInProgress({ status: false, courseCode: "" })
          setSuccessModalStatus("success")
          setSuccessModalFlag(true)
          if (window.location.hostname.includes("bitclass.live")) {
            try{
              const { default: ReactPixel } = await import("react-facebook-pixel")
              if (course.amount === 0) {
                ReactPixel.trackCustom("FreeCourseRegistered", {
                  title: `Course Title: ${course.heading}`,
                  courseCode,
                  _orderCode,
                })
              } else if (course.amount > 0 && course.amount <= 99) {
                ReactPixel.trackCustom("CoursePurchaseSuccess", {
                  title: `Course Title: ${course.heading}`,
                  courseCode,
                  _orderCode,
                })
              } else if (course.amount > 99) {
                ReactPixel.trackCustom("FullCourseRegistered", {
                  title: `Course Title: ${course.heading}`,
                  courseCode,
                  _orderCode,
                  amount: course.amount,
                })
              }
            } catch(e) {
              console.log(e)
            }
          }
        } else if (
          _orderCode &&
          _paymentMode &&
          _paymentStatus !== "successful"
        ) {
          UserState.paymentInProgress({ status: false, courseCode: "" })
          setSuccessModalStatus("failure")
          setSuccessModalFlag(true)
        }
      } catch (err) {
        return // handle error once we build error component
      }
    }

    fetchData()
  }, [courseCode, router.query])

  // schedule component start
  function GraphicDetails({
    icon,
    data,
    subData = "",
    customClass,
    customComponent = "",
  }) {
    return (
      <div className={clsx(styles.graphicDetailsContainer, customClass)}>
        <div className={styles.graphicDetailsIcon}>{icon}</div>
        <div className={styles.graphicDetailsData}>
          {data}
          {exists(subData) && (
            <div className={styles.graphicDetailsSubData}>({subData})</div>
          )}
        </div>
        {customComponent}
      </div>
    )
  }
  // schedule ends

  // Title component starts
  const HeadingWithLine = ({ title }) => (
    <div className={styles.headingWithLineContainer}>
      <span className={styles.heading}>{title}</span>
      <span className={styles.line}></span>
    </div>
  )
  // Title ends

  // Highlight component starts
  const ColorCard = ({ number, text, index }) => {
    if (!index || !text || !number) return ""
    const color = _gradients[index % 5]
    return (
      <div className={styles.colorCardContainer} style={{ background: color }}>
        <div className={styles.number}> {number} </div>
        <div className={styles.text}>
          <RenderHTML content={text} maxCharLength={64} maxHeight={null} />
        </div>
      </div>
    )
  }
  // End of highlight component

  // Top info card starts
  const AdditionalInfoCard = ({ data }) => {
    const { human_readable } = data
    if (!exists(human_readable)) {
      return null
    }
    if (isMobile) {
      return (
        <div className={styles.additionalInfoCardContainer}>
          {human_readable.map((aData, i) => (
            <div key={i.toString()} className={styles.subCard}>
              <div className={styles.iconSec}>
                <img src={aData.icon.svg} style={{ width: 36 }} alt="info" />
              </div>
              <div className={styles.dataSec}>
                <div className={styles.text}>{aData.text}</div>
              </div>
            </div>
          ))}
        </div>
      )
    } else {
      return (
        <div className={styles.additionalInfoCardContainer}>
          {human_readable.map((aData, i) => (
            <div key={i.toString()} className={styles.subCard}>
              <div className={styles.iconSec}>
                <img src={aData.icon.svg} style={{ width: 36 }} alt="info" />
              </div>
              <div className={styles.dataSec}>
                <div className={styles.text}>{aData.text}</div>
              </div>
            </div>
          ))}
        </div>
      )
    }
  }
  // Top info card ends

  // Course info card starts
  const CourseInfoCard = () => {
    const [couponCode, setCouponCode] = useState("")
    const [validCoupon, setValidCoupon] = useState(false)
    const [couponError, setCouponError] = useState("")
    const [showApplyCoupon, setShowApplyCoupon] = useState(false)

    useEffect(() => {
      (async () => {
        if (exists(couponCode)) {
          try {
            let _validateRes = await validateCoupon(couponCode, courseCode)
            if (_validateRes.data.success) {
              setValidCoupon(true)
              setCourse({
                ...course,
                old_amount: course.old_amount || course.amount,
                amount: _validateRes.data.amount,
                couponCode,
              })
            } else {
              setValidCoupon(false)
              setCouponError(
                _validateRes.data.success
                  ? _validateRes.data.msgTimestampStyle
                  : "Invalid coupon!"
              )
            }
            trackEvent(BIT_EVENTS.APPLY_COUPON_STATUS, {
              status: _validateRes.data.success ? "successful" : "failed",
              course_code: course.code
            })
          } catch (e) {
            setCouponError("Failed to apply coupon")
            trackEvent(BIT_EVENTS.APPLY_COUPON_STATUS, {
              status: "failed",
              course_code: course.code
            })
          }
        }
      })()
    }, [couponCode])

    const ApplyCouponComponent = () => (
      <div className={styles.applyCoupon}>
        {!exists(course.couponCode) && !showApplyCoupon && (
          <div
            className={styles.textLink}
            onClick={() => {
              if(hasAuthToken()){
              setShowApplyCoupon(true)
              setValidCoupon(false)
              setCouponError("")
              } else {
               dispatch({type: TOGGLE_LOGIN_SCREEN, payload: true})
              }
            }}
            enterButton="Search"
          >
            Apply coupon
          </div>
        )}
        {showApplyCoupon && !validCoupon && (
          <div className={styles.inputSection}>
            <Search
              placeholder="Enter coupon"
              enterButton="Apply"
              size="medium"
              style={{ width: 250 }}
              onSearch={(coupon) => {
                setCouponCode(coupon)
                trackEvent(BIT_EVENTS.APPLY_COUPON__APPLY_CLICKED, trackingBaseData)
              }}
            />
            {exists(couponError) && (
              <span className={styles.couponError}>{couponError}</span>
            )}
          </div>
        )}
        {exists(course.couponCode) && (
          <div className={styles.selectedCoupon}>
            <span className={styles.coupon}>{course.couponCode}</span>
            is applied
            <span
              className={styles.closeIcon}
              onClick={() => {
                setCouponCode("")
                setValidCoupon(false)
                setShowApplyCoupon(false)
                setCourse({
                  ...course,
                  couponCode: "",
                  amount: course.old_amount || course.amount,
                })
              }}
            >
              <X />
            </span>
          </div>
        )}
    <LoginModal onLoginNext = {()=>{
          if(hasAuthToken()){
            (async function (){
              dispatch({type: TOGGLE_LOGIN_SCREEN, payload: false})
              const checkTmprStatus = await getTmprStatus(courseCode)
              if ((checkTmprStatus && checkTmprStatus.data["is_slot_selected"]) || 
              course.students?.includes(parseInt(getUID(), 10))
              ) {
               window.location.reload()
              } else {
                setShowApplyCoupon(true)
                setValidCoupon(false)
                setCouponError("")
              }
            })()
          }    
    }}/>
    </div>
    )

    const CutDownPrice = ({ currency, oldPrice, newPrice }) => (
      <span className={styles.offerAppliedPrice}>
        <span className={styles.newPrice}>{`${currency} ${newPrice} /-`}</span>
        <span className={styles.oldPrice}>{`${currency} ${oldPrice} /-`}</span>
      </span>
    )



    return (
      <div className={styles.courseInfoBlock}>
        <div className={clsx(styles.courseInfoSubBlock, styles.firstBlock)}>
          {/* {!isTablet && !isMobile && <HeadingWithLine title="DETAILS" />} */}
          {showGraphicDetails && (
            <>
              <GraphicDetails
                icon={<Wallet />}
                data={
                  !exists(course.couponCode) ? (
                    determineCoursePrice(course)
                  ) : (
                    <CutDownPrice
                      currency={course.currency}
                      oldPrice={course.old_amount}
                      newPrice={course.amount}
                    />
                  )
                }
                customClass={styles.priceGrid}
                customComponent={
                  !course.students.includes(parseInt(getUID(), 10)) &&
                  profile.code !== getCode() &&
                  !course.has_ended &&
                  course.amount >= 99 && <ApplyCouponComponent />
                }
              />
              {/* <GraphicDetails
                icon={<Calendar />}
                data={determineCourseDate(course) || "Date Not Added Yet"}
              />
              <GraphicDetails
                icon={<Clock />}
                data={
                  <ScheduleTags
                    weeklySchedule={course?.weekly_schedule}
                    duration={course?.course_schedule?.lesson_duration}
                  />
                }
                customClass={styles.timeSchedules}
              /> */}
              <Schedule customClass = {styles.availabilityContainer} determineCoursePrice={determineCoursePrice(course)} course={fullData.demo_slots} fullData = {fullData} applyCouponComponent={<ApplyCouponComponent/>}/>
            </>
          )}
        </div>
      </div>
    )
  }
  // Course info card ends

  // Share component starts
  const ShareCourseCard = () => (
    <div className={styles.shareBlock}>
      <p>Share :</p>

      {/* <SocialShareLink linkUrl={_url} linkText={`Check out ${heading} course on BitClass`} page="NewCDP" contentID={tmprCode} contentType={"tmpr"} /> */}

      <SocialShareLink
        linkUrl={courseURL}
        linkText={`Check out this course on BitClass - ${course.heading}`}
        page="multi-target"
        contentID={course.code}
        contentType={"course"}
      />
    </div>
  )
  // share component ends

  // Testimonials starts
  const TestimonialComponent = ({ data }) => {
    const TestimonialCard = ({ item, className }) => (
      <div className={clsx(styles.testimonialCard, className)}>
        <div className={item.video ? "" : styles.videoProfileContainer}>
          {item.video ? (
            <VideoCard
              url={item.video}
              title={`Testimonial - ${item.student_name}`}
            />
          ) : (
            <>
              <div
                className={styles.profilePic}
                style={exists(item.profilePic)
                  ? {
                      backgroundImage: `url(${item.profilePic})`,
                    }
                  : {}
                }
              >
                {!item.profilePic && (
                  <span>
                    {exists(item.student_name) ? item.student_name[0] : ""}
                  </span>
                )}
              </div>
              <div className={styles.name} title={item.student_name}>
                {item.student_name}
              </div>
            </>
          )}
        </div>
        <div className={styles.dataPart}>
          {item.video && <div className={styles.name}>{item.student_name}</div>}
          <span>
            <RenderHTML
              content={item.testimonial}
              maxCharLength={40}
              maxHeight={48}
            />
          </span>
        </div>
      </div>
    )

    return data.length > 0 ? (
      <AntCarousal
        infinite={data.length <= MODAL_ITEM_COUNT ? false : true}
        slidesToShow={
          data.length <= MODAL_ITEM_COUNT ? data.length : MODAL_ITEM_COUNT
        }
        slidesToScroll={
          data.length <= MODAL_ITEM_COUNT ? data.length : MODAL_ITEM_COUNT
        }
        swipeToSlide={true}
        dots={data.length <= MODAL_ITEM_COUNT ? false : true}
        autoplay={data.length <= MODAL_ITEM_COUNT ? false : false}
        pauseOnHover={true}
        swipe={true}
        autoplaySpeed={3000}
        draggable={true}
        variableWidth={false}
        customClass={clsx(
          styles.carousalDiv,
          data.length <= MODAL_ITEM_COUNT && styles.testimonialCarousalLess
        )}
      >
        {data.map((item, i) => (
          <TestimonialCard
            item={item}
            key={i.toString()}
            className={data.length <= MODAL_ITEM_COUNT && styles.lessItems}
          />
        ))}
      </AntCarousal>
    ) : (
      <TestimonialCard item={data[0]} />
    )
  }
  // Testimonials end

  // Video card carousel starts
  const AdditionalVideoComponent = ({ data }) => {
    data = data.filter((vData) => vData.type === "video")
    return (
      <AntCarousal
        infinite={data.length <= MODAL_ITEM_COUNT ? false : true}
        slidesToShow={
          data.length <= MODAL_ITEM_COUNT ? data.length : MODAL_ITEM_COUNT
        }
        slidesToScroll={
          data.length <= MODAL_ITEM_COUNT ? data.length : MODAL_ITEM_COUNT
        }
        swipeToSlide={true}
        dots={data.length <= MODAL_ITEM_COUNT ? false : true}
        autoplay={data.length <= MODAL_ITEM_COUNT ? false : true}
        pauseOnHover={true}
        swipe={true}
        autoplaySpeed={3000}
        draggable={true}
        variableWidth={false}
        customClass={clsx(
          styles.carousalDiv,
          data.length <= MODAL_ITEM_COUNT && styles.lessNumbered
        )}
      >
        {data
          .filter((vData) => vData.type === "video")
          .map((vData, index) => (
            <>
              <li
                className={clsx(
                  data.length <= MODAL_ITEM_COUNT
                    ? styles.additionalVideoLi
                    : styles.additionalVideoMoreThanCount
                )}
                style={
                  isMobile || isTablet
                    ? { height: "196px" }
                    : { height: "126px" }
                }
                key={index.toString()}
              >
                <VideoCard
                  url={vData.url}
                  title="Additional videos"
                  thumbnail={exists(vData.thumbnail) ? vData.thumbnail : ""}
                  errMsg={"Video will be ready for viewing in few minutes"}
                  customClass={styles.additionalVideoCard}
                />
              </li>
            </>
          ))}
      </AntCarousal>
    )
  }
  // Video card carousel ends

  // Highlights carousel starts
  const CourseHighlightComponent = ({ data }) => (
    <AntCarousal
      infinite={data.length <= MODAL_ITEM_COUNT ? false : true}
      slidesToShow={
        isMobile ? 1 : 2
        // data.length <= MODAL_ITEM_COUNT ? data.length : MODAL_ITEM_COUNT
      }
      slidesToScroll={
        1
        // data.length <= MODAL_ITEM_COUNT ? data.length : MODAL_ITEM_COUNT
      }
      swipeToSlide={true}
      dots={true}
      // autoplay={data.length <= MODAL_ITEM_COUNT ? false : true}
      pauseOnHover={true}
      swipe={true}
      autoplaySpeed={3000}
      autoplay={true}
      infinite={true}
      draggable={true}
      variableWidth={false}
      customClass={clsx(
        styles.carousalDiv,
        data.length <= MODAL_ITEM_COUNT && styles.lessNumbered,
        styles.highlightCarousal
      )}
    >
      {data.map((hData, index) => (
        <>
          <li
            key={index.toString()}
            style={
              !isMobile && !isTablet && data.length <= MODAL_ITEM_COUNT
                ? { width: "300px", marginRight: "12px" }
                : !isMobile && !isTablet
                ? { width: "95%" }
                : {}
            }
          >
            <ColorCard
              index={index + 1}
              text={hData}
              number={(index + 1).toString().padStart(2, "0")}
            />
          </li>
        </>
      ))}
    </AntCarousal>
  )
  // Highlights carousel ends

  // Title bar component start
  const SectionWithTitleComponent = ({ title, dataComponent }) => (
    <React.Fragment>
      <HeadingWithLine title={title} />
      {dataComponent}
    </React.Fragment>
  )
  // Title bar component ends

  let limitImage = exists(course) &&  exists(course.featured_images) && course.featured_images.length > 3 ? 2 : 3

  const [showThumbnail, setShowThumbnail] = useState(true)
  let IntroVideoRef = useRef()

  return (
    <>
      <Head>
        <title>{title} | Live Online Course</title>
        {/* <link rel="shortcut icon" href = "/static/favicon.ico"/> */}
        {/* Meta information */}
        <meta name="description" content={metaDesc} />
        <meta
          name="keywords"
          content={`${title} | Live Online Course, Online Class, Live courses, BitClass Classes`}
        />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={metaDesc} />
        <meta
          property="og:image"
          content={intro_meta_thumbnail || teacher.image}
        />
        <meta property="og:url" content={props.pageUrl} />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={metaDesc} />
        <meta
          name="twitter:image"
          content={intro_meta_thumbnail || teacher.image}
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        <meta name="twitter:creator" content={teacher.teacher_name} />
        <meta property="og:site_name" content="BitClass" />

        {/* Adding course schema  */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org/",
              "@type": "Course",
              name: title,
              description: metaDesc,
              provider: {
                "@type": "Organization",
                name: "BitClass",
                url: { BASE_URL },
              },
            }),
          }}
        />
        {/* --completed course schema-- */}

        {/* Adding FAQ schema  */}
        {exists(faq) && (
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{
              __html: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "FAQPage",
                name: "CDP FAQ",
                mainEntity: faq.map((item) => {
                  return {
                    "@type": "Question",
                    name: item.que,
                    acceptedAnswer: {
                      "@type": "Answer",
                      text: item.ans,
                    },
                  }
                }),
              }),
            }}
          />
        )}
        {/* --completed FAQ schema-- */}

       
      </Head>

      {/* Appheader rendering */}
      <header>
        {showAppHeader && (
          <div className={styles.mainHeader}>
            <DynamicAppHeader
              // className={courseRemoved ? '' : styles.header}
              page="cdp"
              props={props}
              // darkMode={courseRemoved ? false : true}
              isMobile={isMobile}
              isTablet={isTablet}
            />
          </div>
        )}
      </header>

      <UserContext.Consumer>
        {(User) => {
          if (User.globalState.status === "done") {
            setSuccessModalFlag(true)
            User.paymentInProgress({ status: false, courseCode: "" })
          }
          return (
            <Layout>
              <SpinnerWrapper
                text="Confirming your registration, please don't close the browser"
                isLoading={User.isLoading}
              >
                <div>
                  <div
                    className={styles.teacherProfileWrapper}
                    style={{ background: colorGradient }}
                  >
                    <div className={styles.individualCoursesWrapper}>
                      {isLoading ? (
                        <CircularProgress />
                      ) : course && (
                        <SpinnerWrapper isLoading={isLoading}>
                          <div
                            className={styles.courseIndividualDetailsWrapper}
                          >
                            <></>
                            <div className={styles.courseDetailHeaderWrapper}>
                              <div className={styles.headingText}>
                                {course.heading}
                              </div>
                            </div>
                            <div className={styles.detailContentWrapper}>
                              <div className={styles.detailContentLeftWrapper}>
                                {course.intro_video || profile.intro_video ? (
                                  <ReactPlayer
                                  ref={IntroVideoRef}
                                    className={styles.courseVideo}
                                    width="640"
                                    height="228"
                                    controls={true}
                                    loop={false}
                                    playing={
                                      !exists(thumbnailUrl) ? false : true
                                    }
                                    url={
                                      course.intro_video || profile.intro_video
                                    }
                                    light={thumbnailUrl}
                                    playIcon={
                                      <PlayIcon width="58" height="58" />
                                    }
                                    onPause={() => {
                                      let time = 0
                                      try {
                                        time = IntroVideoRef.current.getCurrentTime()
                                        trackEvent(BIT_EVENTS.VIDEO_ACTION_CLICKED, {...trackingBaseData, video_page_source: "cdp", action: "pause", duration: time})
                                      } catch (e) {}
                                    }}
                                    onPlay={() => {
                                      trackEvent(BIT_EVENTS.VIDEO_ACTION_CLICKED, {...trackingBaseData, video_page_source: "cdp", action: "play",
                                       duration:
                                        IntroVideoRef.current.getCurrentTime()
                                      })
                                    }}
                                  />
                                ) : (
                                  <div className={styles.noVideo}>
                                    <img
                                      alt="No Course Video"
                                      src="https://bitclass-assets.s3.ap-south-1.amazonaws.com/no-video.svg"
                                      className={styles.noVideoImg}
                                    />
                                    <div>No video uploaded for this course</div>
                                  </div>
                                )}
                                

                                {(isMobile || isTablet) && (
                                  <React.Fragment>
                                    <ShareCourseCard />
                                    <CourseInfoCard />
                                  </React.Fragment>
                                )}

                                <div className={styles.courseDetailsWrapper}>
                                  <HeadingWithLine title="ABOUT" />
                                  <SeeMore
                                    text={course.goal}
                                    size={25}
                                    trackEvent={() =>
                                      trackEvent(
                                        BIT_EVENTS.CDP_SHOW_MORE_CLICKED,
                                        trackingBaseData
                                      )
                                    }
                                  >
                                    <div
                                      className={styles.courseDescription}
                                      dangerouslySetInnerHTML={{
                                        __html:
                                          course.goal ||
                                          `No details added to this course`,
                                      }}
                                    ></div>
                                  </SeeMore>
                                  {course.featured_images &&
                                    course.featured_images.length > 0 && (
                                      <div
                                        className={styles.imageGalleryWrapper}
                                      >
                                        <HeadingWithLine title="SNEAK PEEK" />
                                        <div
                                          className={
                                            styles.imageThumbnailContainer
                                          }
                                        >
                                          {course.featured_images
                                            .slice(0, limitImage)
                                            .map((item, index) => (
                                              <div
                                                className={styles.seeMoreMain}
                                              >
                                                <OptimizedImage
                                                  keepOriginal={false}
                                                  imgQuality="1"
                                                  // width='120'
                                                  onClick={() => {
                                                    trackEvent(
                                                      BIT_EVENTS.CDP_SNEAK_PEAK_IMAGE_CLICKED,
                                                      {...trackingBaseData, card_no: index}
                                                    )
                                                    setGalleryStartIndex(index)
                                                    setGalleryModalVisible(true)
                                                    // setShowThumbnail(false)
                                                  }}
                                                  className={
                                                    styles.thumbnailImg
                                                  }
                                                  src={item}
                                                  alt="gallery"
                                                />
                                              </div>
                                            ))}
                                          {course.featured_images.length >
                                            3 && (
                                            <div className={styles.seeMoreMain}>
                                              <img
                                                onClick={() => {
                                                  setGalleryStartIndex(2)
                                                  setGalleryModalVisible(true)
                                                }}
                                                className={styles.thumbnailImg}
                                                src={course.featured_images[2]}
                                                alt="gallery"
                                              />
                                              <span
                                                onClick={() => {
                                                  trackEvent(
                                                    BIT_EVENTS.CDP_SNEAK_PEAK_SEE_MORE_CLICKED,
                                                    trackingBaseData
                                                  )
                                                  setGalleryStartIndex(2)
                                                  setGalleryModalVisible(true)
                                                }}
                                              >
                                                See More
                                              </span>
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  {/* image gallery ends */}

                                  <div style={{ height: "32px" }}></div>
                                  {course.highlights &&
                                    course.highlights.length > 0 && (
                                      <SectionWithTitleComponent
                                        title="COURSE HIGHLIGHTS"
                                        dataComponent={
                                          <CourseHighlightComponent
                                            data={course.highlights}
                                          />
                                        }
                                      />
                                    )}
                                  {exists(course.additional_info) &&
                                    exists(
                                      course.additional_info.human_readable
                                    ) &&
                                    course.additional_info.human_readable
                                      .length > 0 && (
                                      <SectionWithTitleComponent
                                        title="ADDITIONAL INFO"
                                        dataComponent={
                                          <AdditionalInfoCard
                                            data={course.additional_info}
                                          />
                                        }
                                      />
                                    )}
                                  {course.media && course.media.length > 0 && (
                                    <SectionWithTitleComponent
                                      title="PAST COURSE VIDEOS"
                                      dataComponent={
                                        <AdditionalVideoComponent
                                          data={course.media}
                                        />
                                      }
                                    />
                                  )}
                                  {course.faqs && course.faqs.length > 0 && (
                                    <SectionWithTitleComponent
                                      title="FAQs"
                                      dataComponent={
                                        <FaqComponent
                                          data={course.faqs}
                                          trackThis={(i) => {
                                            trackEvent(BIT_EVENTS.CDP_FAQ_CLICKED, trackingBaseData)
                                          }}
                                        />
                                      }
                                    />
                                  )}
                                  {course.testimonials &&
                                    course.testimonials.length > 0 && (
                                      <SectionWithTitleComponent
                                        title="TESTIMONIALS"
                                        dataComponent={
                                          <TestimonialComponent
                                            data={course.testimonials}
                                          />
                                        }
                                      />
                                    )}
                                </div>
                              </div>
                              <div
                                className={clsx(
                                  styles.detailContentRightWrapper,
                                  !isMobile && !isTablet
                                    ? styles.stickySideBar
                                    : ""
                                )}
                              >
                                {!isMobile && !isTablet && <div className={styles.newSchedule}><CourseInfoCard/></div>}
                                <div className={styles.registrationBlock}>
                                  {showRegisterBtn && (
                                    <RegisterButton
                                      btnClass={styles.regButton}
                                      course={course}
                                      profile={profile}
                                      // history={history}
                                      text={`Join this course for ${determineCoursePrice(course)}`}
                                      trackPreRegister={true}
                                      RegisterButton
                                      couponCode={course.couponCode}
                                      tmprCode = {courseCode}
                                      tmprRegStatus = {tmprRegStatus}
                                      fullData = {fullData}
                                      type = "demo"
                                      demolist = {fullData?.demo_slots}
                                      setShowSlotSelection = {setShowSlotSelection}
                                      showSlotSelection = {showSlotSelection}
                                    />
                                  )}

                                  {profile.profile_id && showEnquiryModal && (
                                    <EnquiryModal
                                      profile={profile}
                                      courseCode={courseCode}
                                      teacherCode={teacherCode}
                                      trackEnquiry={true}
                                      trackEnqEvtName={BIT_EVENTS.CDP_TALK_TO_TEACHER_CLICKED}
                                      trackPayload={trackingBaseData}
                                      fullData={fullData}
                                    />
                                  )}
                                </div>
                                <div className={styles.detailContentInner}>
                                  {!isMobile && !isTablet && (
                                    <HeadingWithLine title="KNOW THE TEACHER" />
                                  )}
                                  <div className={styles.teacherProfileBlock}>
                                    <div className={styles.teacherInfoBlock}>
                                      <p className={styles.teacherName}>
                                        <span>{profile.teacher_name}</span>
                                        {profile.qualifications && (
                                          <span
                                            className={styles.qualifications}
                                          >
                                            ({profile.qualifications})
                                          </span>
                                        )}
                                      </p>
                                      <p className={styles.teacherBio}>
                                        {profile.story ? (
                                          <SeeMore
                                            text={profile.story}
                                            size={8}
                                            trackEvent={() => {
                                              trackEvent(BIT_EVENTS.CDP_TEACHER_DESCRIPTION_SHOW_MORE_CLICKED, trackingBaseData)
                                            }}
                                          >
                                            <span
                                              dangerouslySetInnerHTML={{
                                                __html: profile.story,
                                              }}
                                            ></span>
                                          </SeeMore>
                                        ) : (
                                          ""
                                        )}
                                      </p>
                                    </div>
                                    <div
                                      className={styles.profilePic}
                                      style={{
                                        backgroundImage: `url(${profile.image||DEFAULT_TEACHER_PROFILE_IMAGE})`,
                                      }}
                                    >
                                      {/* {!profile.image && (
                                        <span>{ profile.teacher_name}</span>
                                      )} */}
                                    </div>
                                  </div>
                                </div>
                                {!isMobile && !isTablet && <ShareCourseCard />}
                                <div className={styles.otherCourses}>
                                  <span className={styles.interested}>
                                    Interested in learning more?
                                  </span>
                                  <span
                                    onClick={() => {
                                      trackEvent(BIT_EVENTS.CDP_OTHER_COURSES_CLICKED, trackingBaseData)
                                      window.location.href = `${BASE_URL}/${profile.profile_id}`
                                    }}
                                    className={styles.checkoutLink}
                                  >
                                    <div>
                                      <div className={styles.checkoutText}>
                                        Checkout other courses by
                                      </div>
                                      <div
                                        className={styles.checkoutTeacherName}
                                      >
                                        {profile.username || profile.teacher_name}
                                      </div>
                                    </div>
                                    <ArrowRight />
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </SpinnerWrapper>
                        // ) : (
                        //   <div className={styles.courseRemoved}>
                        //     <div className={styles.crMidSec}>
                        //       <CourseRemovedSvg />
                        //       <div className={styles.descriptionAndCta}>
                        //         <h2>Course Removed!</h2>
                        //         <div>
                        //           Hey, seems like this course has been removed by
                        //           the teacher
                        //         </div>

                        //         <div className={styles.checkoutText}>
                        //           Checkout other courses by{" "}
                        //           <strong>{profile.username || profile.teacher_name}</strong>
                        //         </div>
                        //         <PrimaryIconButton
                        //           text="View Courses"
                        //           onClick={() => {
                        //             window.location.href = `${BASE_URL}/${profile.profile_id}`
                        //           }}
                        //         />
                        //       </div>
                        //     </div>
                        //   </div>
                      )}
                    </div>
                  </div>
                </div>
                <SuccessModal
                  SuccessModalFlag={SuccessModalFlag}
                  setSuccessModalFlag={setSuccessModalFlag}
                  status={SuccessModalStatus}
                  course={course}
                  courseCode={courseCode}
                  demos = {demolist}
                  fullData = {fullData}
                />

                <AntFullScreenModal
                  visible={galleryModalVisible}
                  cancelFn={() => {
                    setGalleryModalVisible(false)
                  }}
                  body={
                    <ImageGallery
                      additionalClass={styles.imageGalleryContainer}
                      showThumbnails={false}
                      showPlayButton={false}
                      showFullscreenButton={false}
                      startIndex={galleryStartIndex}
                      items={
                        exists(course) &&
                        exists(course.featured_images)
                          ? course.featured_images.map((i, key) => {
                              if (
                                key !== course.featured_images.length - 1 ||
                                isRegistered
                              ) {
                                return {
                                  original: i,
                                }
                              } else {
                                return {
                                  renderItem: () => (
                                    <div className={styles.buttonContainer}>
                                      <div
                                        style={{
                                          width: "300px",
                                          margin: "0 auto",
                                        }}
                                      >
                                        <h3>
                                          Love these Images? Register Now!
                                        </h3>
                                        <ImageGallerySvg
                                          width="200px"
                                          height="100px"
                                        />
                                        <RegisterButton
                                          btnClass={styles.regButton}
                                          course={course}
                                          profile={profile}
                                          text="Register"
                                          trackPreRegister={true}
                                          trackEvtName={BIT_EVENTS.CDP_JOIN_CLICKED}
                                          trackPayload={trackingBaseData}
                                          couponCode={course.couponCode}
                                          setShowSlotSelection = {setShowSlotSelection}
                                          demolist = {fullData?.demo_slots}
                                          showSlotSelection = {showSlotSelection}
                                        />
                                      </div>
                                    </div>
                                  ),
                                }
                              }
                            })
                          : []
                      }
                      onSlide={(currentIndex) => {
                        trackEvent(BIT_EVENTS.CDP_SNEAK_PEAK_ARROW_CLICKED, trackingBaseData)
                      }}
                    />
                  }
                  titleClass={styles.title}
                  title={null}
                  footer={null}
                  centered={true}
                  destroyOnClose={true}
                  bodyClass={styles.imageModal}
                />
      </SpinnerWrapper>
        </Layout>
          )
      }}
      </UserContext.Consumer>
    </>
  )
}

Course.getInitialProps = async (context) => {
  const ua = useUserAgent(context.req.headers["user-agent"])
  const cookie = context.req ? context.req.headers.cookie : null
  let { subject } = context.query
  const tmpr = getCookieString('multiTargeting__' + subject, cookie)
  let _profile
  let _course=false
  let res
  let course = ''

    try {
      if(typeof subject !== undefined  && subject !== 'undefined'){
        res = await fetch(`${API_URL}/v2/courses/multi-course/${subject}/${existsV2(tmpr) ?  tmpr : ''}`)
        _course = await res.json()
        _profile = await get(_course.data, 'teacher', {})
        course = get(_course.data, 'selected_tmpr', "")
      }
      if(!_course.data.title||!_course.data||!_course||_course?.data?.demos.length<1||!_course?.data?.hasOwnProperty('demos')) {
        context.res.writeHead(302, {
          Location: '/course-not-found',
          'Content-Type': 'text/html; charset=utf-8',
        })
        context.res.end()
      }
    } catch (e) {
      if(e) {
        context.res.writeHead(302, {
          Location: '/course-not-found',
          'Content-Type': 'text/html; charset=utf-8',
        })
        context.res.end()
      }
      _profile = {
        rating: {
          score: "",
        },
        tags: [],
        lessons: {
          past: [],
          present: [],
          future: [],
        },
        username: "",
        courses: [],
        qualifications: "",
        story: "",
      }
      _course = null
    }  


  return {
    teacherCode: _course ? _course["data"]?.teacher.teacher_handle : "",
    courseCode: course,
    _profile,
    _course,
    pageUrl: `${BASE_URL}${context.asPath}`,
    ua,
    subject,
  } // will be passed to Id react component as props
}

export default withUserAgent(Course)
