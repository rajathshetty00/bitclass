import React, { useEffect, useState } from "react"
import dynamic from "next/dynamic"
import Head from "next/head"
import { partner } from "src/partner/partnerStaticData"
import styles from "./styles.module.scss"
import TopSection from "src/partner/__components__/TopSection"
import HowToApply from "src/partner/__components__/HowToApply"
import Benefits from "src/partner/__components__/Benefits"
// import Step from "src/partner/__components__/Step"
import Payout from "src/partner/__components__/Payout"
import AppFooterV2 from "src/__components__/AppFooter/v2"
import AntBitModal from "src/__components__/Modal/AntBitModal"
import ConfirmationModal from "src/partner/__components__/ModalBody"
import { checkPartnerWithBitclassStatus } from "src/__utils__/api"
import { hasAuthToken } from "src/__utils__/auth"
import { BASE_URL } from "src/constants"
import trackEvent from "src/__utils__/analytics"
import { BIT_EVENTS } from "config/events"
const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const Partner = (props) => {
  // Destructuring static data
  const {
    title,
    topMedia,
    subTitle,
    offerText,
    howToApply,
    benefits,
    earning,
    payout,
  } = partner

  const {
    img,
    title: earningsTitle,
    subTitle: { startString, endString },
  } = earning


  //State
const [showModal, setShowModal] = useState(false)
useEffect(() => {
  const checkPartnershipStatus = async() => {
    try {
      const {data} = await checkPartnerWithBitclassStatus()
      if(data) setShowModal(true)
    } catch (error) {
      console.error(error)
    }
  }
  if(hasAuthToken())
  checkPartnershipStatus()
  trackEvent(BIT_EVENTS.PARTNER_PAGE_VIEWED, {})
}, [])
  return (
    <div className={styles.partner}>
      <div>
        <Head>
        <title>
        Partner With BitClass
        </title>
        <meta
          name="description"
          content="Become our partner and grow together with us. BitClass helps in making independent teachers successful on the internet. Help us in growing our reach and earn money while doing so from the comfort of your home."
        />
        <meta
          property="og:title"
          content="Partner With BitClass"
        />
        <meta
          property="og:description"
          content="Become our partner and grow together with us. BitClass helps in making independent teachers successful on the internet. Help us in growing our reach and earn money while doing so from the comfort of your home."
        />
        <meta property="og:url" content={BASE_URL+'/partner-with-bitclass'} />
        <meta
          name="twitter:title"
          content={
            "Partner With BitClass"
          }
        />
        <meta
          name="twitter:description"
          content="Become our partner and grow together with us. BitClass helps in making independent teachers successful on the internet. Help us in growing our reach and earn money while doing so from the comfort of your home."
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL+'/partner-with-bitclass'} />
        </Head>
        <AppHeader page="partner" props={props} />
      </div>
      <div className={styles.partnerBody}>
        <TopSection
          title={title}
          topMedia={topMedia}
          subTitle={subTitle}
          offerText={offerText}
          setShowModal={setShowModal}
        />
        <HowToApply howToApply={howToApply} />
        <Benefits benefits={benefits} />
        <div className={styles.earnings}>
          <img src={img} alt={"earning media"} />
          <div className={styles.detailsContainer}>
            <div className={styles.title}>{earningsTitle}</div>
            <div className={styles.subTitle}>
              {startString}
              <strong>{endString}</strong>
            </div>{" "}
          </div>
        </div>
      </div>
      <Payout payout={payout} />
      <AntBitModal
        visible={showModal}
        body={<ConfirmationModal />}
        cancelFn={() => {}}
        closable={false}
      />
      <AppFooterV2 />
    </div>
  )
}

export default Partner
