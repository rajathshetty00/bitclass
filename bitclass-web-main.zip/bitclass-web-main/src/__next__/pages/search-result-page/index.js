import { useEffect, useState } from "react"
import { useUserAgent, withUserAgent } from "next-useragent"
import dynamic from "next/dynamic"
import { isMobile } from "react-device-detect"
import styles from "./styles.module.scss"
import CategoryTab from "src/search-result-page/CategoryTab"
import trackEvent from "src/__utils__/analytics"
import { filteredSearchData } from "src/__utils__/api"
import { objectToQueryString } from "src/__utils__"
import Head from "next/head"
import { BASE_URL } from "src/constants"
// import { get } from "lodash"
// import { exists } from "src/__utils__"
import { getCode } from "src/__utils__/auth"
// import { getLiveUserCount, updateLiveCount } from "src/__utils__/api"
import { BIT_EVENTS } from "config/events"
// import { hasAuthToken } from "src/__utils__/auth"
import NoResultsFound from "src/search-result-page/NoResultsFound"
import AppFooterV3 from "src/__components__/AppFooter/v3"
import CourseCardV2 from "src/storefront/CourseCard"
import { SEARCH_RESULT_PAGE } from "src/__utils__/getNextHead"
import NextHead from "src/__components__/NextHead"

const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const DEFAULT_TAB_KEY = "1"
const SearchResultPage = ({ q: query, searchData, userAgent, paramObj }) => {
  // States
  const [key, setKey] = useState(DEFAULT_TAB_KEY)
  const [dataFetching, setDataFetching] = useState(false)
  const [page, setPage] = useState(1)
  // const [courseDetails, setCourseDetails] = useState(null)
  // const [videoModalDetails, setVideoModalDetails] = useState(null)
  const [searchResults, setSearchResults] = useState(searchData || [])
  // const [showFullScreen, setShowFullScreen] = useState(false)
  // const [liveUsers, setLiveUsers] = useState(0)
  const [finalQueryUrl, setFinalQueryUrl] = useState("")
  const [finalUrl, setFinalUrl] = useState("")
  const [showMoreBtn, setShowMoreBtn] = useState(
    searchData.length < 6 ? false : true
  )
  // const [followingList, setFollowingList] = useState([])
  const [totalResults, setTotalResults] = useState(null)

  // constants
  const { isMobile, isTablet, isIpad } = userAgent
  const q = query

  // handler functions
  let keyMap = {
    1: "all",
    3: "workshops",
    4: "courses",
  }
  const onTabChangeHandler = async (key) => {
    trackEvent(BIT_EVENTS.SEARCH_TAB_CLICKED, {
      primary_nav: "search",
      secondary_nav: keyMap[key],
      student_id: getCode(),
    })
    setKey(key)
    setDataFetching(true)
    const { data } = await filteredSearchData(q, key, 1)
    setPage(1)
    setSearchResults(data)
    if (data.length < 6) {
      setShowMoreBtn(false)
    } else {
      setShowMoreBtn(true)
    }
    setDataFetching(false)
  }

  const loadMoreCourses = async () => {
    try {
      trackEvent(BIT_EVENTS.SEARCH_SHOW_MORE_CLICKED, {
        primary_nav: "search",
        secondary_nav: keyMap[key],
        student_id: getCode(),
      })
      setDataFetching(true)
      // if (!stopFetching) {
      const { data } = await filteredSearchData(q, key, page + 1)
      setPage(page + 1)
      setSearchResults([...searchResults, ...data])
      setDataFetching(false)
      if (data.length < 6) {
        setShowMoreBtn(false)
      } else {
        setShowMoreBtn(true)
      }
    } catch (error) {
      console.error(error)
    }
  }

  //handing app header background transition on scroll
  const [stickyHeader, setStickyHeader] = useState(false)

  const handleScroll = (e) => {
    const { scrollTop } = e.target
    if (scrollTop >= 20 && !stickyHeader) setStickyHeader(true)
    else if (scrollTop === 0 && stickyHeader) setStickyHeader(false)
  }

  useEffect(() => {
    setFinalUrl(objectToQueryString(paramObj).replace("?", ""))
    setFinalQueryUrl(objectToQueryString(paramObj, true).replace("?", ""))
  }, [paramObj])

  useEffect(() => {
    const fetchData = async () => {
      setDataFetching(true)
      const { data, total_results } = await filteredSearchData(q, key, 1)
      setTotalResults(total_results)
      setSearchResults(data)
      if (data.length < 6) {
        setShowMoreBtn(false)
      } else {
        setShowMoreBtn(true)
      }
      setDataFetching(false)
    }
    fetchData()
  }, [q])

  return (
    <div className={styles.container} onScroll={handleScroll}>

      <NextHead page={SEARCH_RESULT_PAGE} />
      <AppHeader
        className={styles.stickyHeader}
        page={SEARCH_RESULT_PAGE}
        showHamburgerMenu={true}
        isMobile={isMobile}
        isTablet={isTablet || isIpad}
      />

      <div className={styles.body}>
        {
          <div className={styles.top}>
            {(q || query) && (
              <div className={styles.searchCount}>
                {totalResults} Results found for <span>"{q || query}"</span>
              </div>
            )}
            <div className={styles.tabContainer}>
              <CategoryTab onTabChangeHandler={onTabChangeHandler} />
            </div>
          </div>
        }

        {searchResults && searchResults.length > 0 ? (
          <div className={styles.searchResultContainer}>
            <div className={styles.cardSection}>
              {searchResults.map((item, index) => (
                <CourseCardV2
                  showFollowButton={true}
                  page={"searchCard"}
                  hideTeacher={false}
                  course={item}
                  isLiveTagShow={item?.is_live}
                  key={item.code}
                  finalUrl={finalUrl}
                  sectionHeading="search"
                />
              ))}
            </div>
          </div>
        ) : (
          <NoResultsFound query={q} isMobile={isMobile} />
        )}
        {/* </div> */}

        {showMoreBtn && (
          <div className={styles.loading}>
            <button onClick={loadMoreCourses}>
              {dataFetching ? "Loading..." : "Show More Results"}{" "}
            </button>
          </div>
        )}
      </div>
      <AppFooterV3 />
    </div>
  )
}

SearchResultPage.getInitialProps = async (context) => {
  let userAgent, searchResults
  let params
  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    userAgent = useUserAgent(context.req.headers["user-agent"])
  } else userAgent = { isMobile }

  let paramObj = {
    platform: userAgent.isMobile ? "mweb" : "web",
  }
  if (context.asPath.includes("?")) {
    params = new URLSearchParams(context.asPath?.split("?")[1])
    for (let value of params.keys()) {
      paramObj[value] = params.get(value)
    }
  }
  try {
    searchResults = await filteredSearchData(
      paramObj.q ? paramObj.q : "",
      DEFAULT_TAB_KEY,
      1
    )
  } catch (error) { }
  return {
    q: paramObj.q ? paramObj.q : "",
    userAgent,
    searchData: searchResults?.data,
    paramObj,
  }
}
export default withUserAgent(SearchResultPage)
