import { getServerSideSitemap } from "next-sitemap"
import { BASE_URL, API_URL } from "src/constants"
import { exists } from "src/__utils__"
import { get } from "lodash"

export const getServerSideProps = async (ctx) => {
  // Method to source urls

  let allCourses
  let fields

  try {
    let res = await fetch(
      `${API_URL}/v2/discovery/search?categories=&limit=100&pageNum=1&q=`
    )
    allCourses = await res.json()
    if (exists(allCourses)) {
      fields = allCourses["data"].map((item) => {
        return {
          loc: item.course_url,
          lastmod: new Date().toISOString(),
        }
      })
    }
  } catch (e) {
    allCourses = null
    fields = [
      {
        loc: BASE_URL,
        lastmod: new Date().toISOString(),
      },
    ]
  }

  return getServerSideSitemap(ctx, fields)
}

// Default export to prevent next.js errors
export default () => {}
