import React, { useEffect, useState } from 'react'
import dynamic from "next/dynamic"
import { useUserAgent, withUserAgent } from "next-useragent"
import Head from 'next/head'
import { get } from 'lodash'

import { exists } from 'src/__utils__'
import styles from "./styles.module.scss"
import { getTmprDataWithToken } from 'src/__utils__/api'
// import SlotSelection from '../../src/profile/__components__/SuccessModal/SlotSelection'
import BitAntLoader from 'src/__components__/BitAntLoader'
import { BASE_URL } from 'src/constants'

const SelectSlot = (props) => {

  const [token, setToken]                   = useState(props.token)
  const [data, setData]                     = useState(null)
  const [slotSelected, setSlotSelected]     = useState(false)
  const [selectedCourse, setSelectedCourse] = useState(null)
  const [showLoader, setShowLoader]         = useState(true)
  const [status, setStatus]                 = useState(-1)

  let DynamicHeader = dynamic(() => import("src/__components__/AppHeader"))
  const { isMobile, isTablet } = props.ua

  const  SlotSelection = dynamic(() => import("../../src/profile/__components__/SuccessModal/SlotSelection"), {
    ssr: false
  })

  // ===== effect
  useEffect(() => {
    console.log(status)
  }, [status])
  // ===== effect ends

  // ===== token effect
  useEffect(() => {

    async function fetchData(){
      if(exists(token)) {
        let _data = await getTmprDataWithToken(token)
        if(exists(_data['data'])) {
          setData(_data['data'])
          if(exists(_data['data']['demos']) && _data['data']['demos'].length > 0) {
            let filteredDemo = _data['data']['demos'].filter(dd => !dd.has_ended)
            setSelectedCourse(filteredDemo[0])
          }
          setShowLoader(false)
        }
      }
    }

    fetchData()
  }, [token])
  // ===== token effect ends

  // const 

  return (
    <>
      <Head>
        <title>
          BitClass: World’s Biggest Platform To Learn Anything. Live. Together.
        </title>
        <meta
          name="description"
          content="BitClass is your campus on the internet. Learn new-age skills, network with learners across the globe, attend events and fests online, enjoy a library full of curated content and much more"
        />
        <meta
          property="og:title"
          content="BitClass: World’s Biggest Platform To Learn Anything. Live. Together."
        />
        <meta
          property="og:description"
          content="BitClass is your campus on the internet. Learn new-age skills, network with learners across the globe, attend events and fests online, enjoy a library full of curated content and much more"
        />
        <meta name="twitter:title" content={"BitClass: World’s Biggest Platform To Learn Anything. Live. Together."} />
        <meta name="twitter:description"
          content="BitClass is your campus on the internet. Learn new-age skills, network with learners across the globe, attend events and fests online, enjoy a library full of curated content and much more"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
      </Head>
      <DynamicHeader
        page="slot-slection"
        props={props}
        isMobile={isMobile}
        isTablet={isTablet}
      />
      <div className={styles.slotContainer}>
        {
          showLoader && <BitAntLoader customClass={styles.loaderContainer} />
        }
        {
          data && status === -1 && <SlotSelection
            demos={exists(data['demos']) ? data['demos'].filter(s => !s.has_ended) : []}
            tmprCode={data['tmpr_code']}
            setSlotSelected={setSlotSelected}
            selectedCourse = {selectedCourse}
            setSelectedCourse = {setSelectedCourse}
            showTitle={true}
            token={token}
            afterSelection={setStatus}
            setShowLoader={setShowLoader}
          />
        }
        {
          status && status !== -1 && (
            <div className={styles.messageContainer}>
              <img src="/static/__assets__/congratulations.svg" alt="success" width={150}/>
              <div className={styles.congratulationMsg}>
                <div className={styles.heading}>
                  Congratulations, you are registered
                </div>
              </div>
            </div>
          )
        }
        {
          status === false && status !== -1 && (
            <div className={styles.messageContainer}>
              <img src={"/static/__assets__/error.svg"} width={150} alt="failed"/>

              <div className={styles.failureMessage}>
                <div className={styles.heading}>
                  Failed to register
                </div>
              </div>
            </div>
          )
        }
      </div>
    </>
  )
}

SelectSlot.getInitialProps = async (context) => {
  const { token } = context.query
  const ua = useUserAgent(context.req.headers["user-agent"])

  return {
    token,
    ua,
  }
}

export default withUserAgent(SelectSlot)