import React, { useState, useEffect, useRef } from "react"
import { isMobile, isTablet } from "react-device-detect"

import PartnerWithBitClass from "src/__components__/PartnerWithBitClass"
import HowBitHelps from "src/__components__/home/__components__/howBitHelps"
import AppFooterV2 from "src/__components__/AppFooter/v2"
import SuccessStories from "src/__components__/home/__components__/successStories"
import { AntPrimaryButton } from "src/__components__/Button"
import HowToGetStarted from "src/__components__/home/__components__/howToGetStarted"
import AntBitModal from "src/__components__/Modal/AntBitModal/index"
import trackEvent from "src/__utils__/analytics"
import Intro from "src/__components__/home/__components__/intro"
import { useRouter } from "next/router"
import styles from "./style.module.scss"
import dynamic from "next/dynamic"
import { BASE_URL, API_URL } from "src/constants"
import Head from "next/head"
import CoursesCarousel from "src/__components__/CoursesCarousel"
import SearchCard from "src/__components__/SearchCard"
import { useUserAgent, withUserAgent } from "next-useragent"
import BitStats from "src/__components__/home/__components__/BitStats"
import { objectToQueryString } from "src/__utils__"
import { BIT_EVENTS } from "config/events"
import {hasAuthToken} from 'src/__utils__/auth'
import {getDefaultFollowingList} from 'src/__utils__/api'

const DynamicRootInstance = dynamic(() => import("src/root/rootInstance"), {
  ssr: false,
})


let AppHeader = null
const Home = ({ history, paramObj, ...props }) => {
  const [showForm, setShowForm] = useState(false)
  const [showSticky, setShowSticky] = useState(false)
  const [showFullScreen, setShowFullScreen] = useState(false)
  const [followingList, setFollowingList] = useState([])
  let partnerWithRef = useRef()
  const router = useRouter()

  const [isAppHeader, setIsAppHeader] = useState(false)
  const [queryList, setQueryList] = useState(
    props.queryList["data"] ? props.queryList["data"] : null
  )
  const [finalUrl, setFinalUrl] = useState("")

  useEffect(() => {
    AppHeader = dynamic(() => import("src/__components__/AppHeader"))
    setIsAppHeader(true)
    trackEvent(BIT_EVENTS.TEACH_ON_BITCLASS_VIEWED, {})
    setFinalUrl(objectToQueryString(paramObj))
  }, [])

  useEffect(() => {
    ;(async () => {
      if (hasAuthToken()) {
        let { following } = await getDefaultFollowingList()
        setFollowingList(following)
      }
    })()
  }, [])
  // useEffect(() => {
  //   (async function () {
  //     if (hasAuthToken()) {
  //       let route = await getDefaultRouteForLoggedIn()
  //       if (router.asPath !== route) window.location.href = BASE_URL + route
  //     }
  //     // tracking
  //     trackEvent("HomePage_View_homepage", {})
  //     // tracking ends
  //   })()
  // }, [])

  useEffect(() => {
    if (showForm) {
      trackEvent("HomePage_View_partner_with_us_mweb", {})
    }
  }, [showForm])

  useEffect(() => {
    if (isMobile || isTablet) {
      const scrollHandler = () => {
        let bottom = partnerWithRef?.current?.getBoundingClientRect()?.bottom
        if (bottom < 60 && !showSticky) {
          setShowSticky(true)
        } else if (bottom > 60 && showSticky) {
          setShowSticky(false)
        }
      }
      window.addEventListener("scroll", scrollHandler)
      return () => window.removeEventListener("scroll", scrollHandler)
    }
  }, [showSticky])

  const partnerWithButtonHandler = () => {
    if (isMobile || isTablet) {
      setShowForm(true)
    } else {
      document.body.scrollTop = 0
      document.documentElement.scrollTop = 0
      trackEvent("HomePage_Click_partner_with_us_scroll", {})
    }
  }

  return (
    <>
      <Head>
        <title>
          BitClass - Build A Successful Live Teaching Business | All-in-one
          Platform
        </title>
        <meta
          name="description"
          content="Establish your own teaching brand with BitClass. Create a webpage, host live courses, collect registrations & payments, teach live in our 2-way virtual classroom, acquire learners with free marketing help from experts"
        />
        <meta
          property="og:title"
          content="BitClass - Build A Successful Live Teaching Business | All-in-one Platform"
        />
        <meta
          property="og:description"
          content="Establish your own teaching brand with BitClass. Create a webpage, host live courses, collect registrations & payments, teach live in our 2-way virtual classroom, acquire learners with free marketing help from experts"
        />
        <meta property="og:url" content={BASE_URL} />
        <meta
          property="og:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600/v1611743039/Testimonials/Thumbnail_Gunjan_video_slczru.png"
        />
        <meta
          name="twitter:title"
          content={
            "BitClass - Build A Successful Live Teaching Business | All-in-one Platform"
          }
        />
        <meta
          name="twitter:description"
          content="Establish your own teaching brand with BitClass. Create a webpage, host live courses, collect registrations & payments, teach live in our 2-way virtual classroom, acquire learners with free marketing help from experts"
        />
        <meta
          name="twitter:image"
          content="https://res.cloudinary.com/bitclass/image/upload/w_600//v1611743039/Testimonials/Thumbnail_Gunjan_video_slczru.png"
        />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content={BASE_URL} />
        {/* <meta name="twitter:creator" content={teacher.teacher_name} /> */}
      </Head>
      <div>
        {isAppHeader && (
          <AppHeader
            className={styles.header}
            page="home"
            props={props}
            darkMode={false}
            isMobile={isMobile}
            isTablet={isTablet}
          />
        )}
      </div>
      <div className={styles.homeMainContainer}>
        <div className={styles.section1}>
          <Intro className={styles.introWithSeparator} />
          {isMobile || isTablet ? (
            <AntPrimaryButton
              customRef={partnerWithRef}
              type="primary"
              htmlType="submit"
              text="Partner with BitClass"
              onClick={() => setShowForm(true)}
            />
          ) : (
            <PartnerWithBitClass
              history={history}
              className={styles.partnerForm}
              source="homepage"
            />
          )}
        </div>
        <div className={styles.statistics}>
          <BitStats />
        </div>
        <div className={styles.section2}>
          <HowBitHelps partnerWithButtonHandler={partnerWithButtonHandler} />
        </div>
        <div className={styles.section3}>
          <SuccessStories partnerWithButtonHandler={partnerWithButtonHandler} />
        </div>

        {queryList && queryList.length > 0 ? (
          <div className={styles.coursesCarouselWrapper}>
            <CoursesCarousel
              autoplay={false}
              infinite={true}
              onClick={() => {}}
              heading={isMobile ? "Discover Courses" : "Discover Live Courses"}
              isMobile={isMobile}
              isTablet={isTablet}
            >
              {queryList.map((item, index) => {
                return (
                  <DynamicRootInstance
                    key={item.code}
                    page="teach-on-bitclass"
                    trackEventName="homepage_carousel_card_click"
                    trackPayload={{
                      courseCode: item.code,
                      position: index + 1,
                    }}
                    isMobile={isMobile}
                    item={item}
                    index={index}
                    finalUrl={finalUrl}
                    customClass={styles.cardWrapper}
                    setShowFullScreen={setShowFullScreen}
                    followingList = {followingList}
                  />
                )
              })}
            </CoursesCarousel>
          </div>
        ) : (
          ""
        )}

        <div className={styles.section4}>
          <HowToGetStarted
            partnerWithButtonHandler={partnerWithButtonHandler}
          />
        </div>
        {(isMobile || isTablet) && showForm && (
          <AntBitModal
            title="Partner with BitClass"
            visible={showForm}
            footer={null}
            cancelFn={() => setShowForm(false)}
            centered
            containerClass={styles.partnerPopUp}
            body={
              <PartnerWithBitClass
                history={history}
                className={styles.partnerForm}
                source="homepage"
              />
            }
          />
        )}
        {(isMobile || isTablet) && showSticky && (
          <div className={styles.stickyFooter}>
            <AntPrimaryButton
              type="primary"
              htmlType="submit"
              text="Partner with BitClass"
              onClick={() => setShowForm(true)}
            />
          </div>
        )}
      </div>
      <AppFooterV2 history={history} />
    </>
  )
}

Home.getInitialProps = async (context) => {
  let ua
  let queryList
  let params
  let paramObj = {
    utm_source: "teach_at_bitclass",
  }

  if (context.asPath.includes("?")) {
    params = new URLSearchParams(context.asPath?.split("?")[1])
    for (let value of params.keys()) {
      paramObj[value] = params.get(value)
    }
  }

  if (context.req) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    ua = useUserAgent(context.req.headers["user-agent"])
  } else {
    ua = { isMobile, isTablet } // if you are on the client you can access the devie details from react-device-detect
  }
  try {
    const res = await fetch(
      `${API_URL}/v2/discovery/search?limit=10&pageNum=1&q=`
    )
    queryList = await res.json()
  } catch (e) {
    queryList = null
  }
  return {
    queryList,
    ua,
    paramObj,
  }
}

export default withUserAgent(Home)
