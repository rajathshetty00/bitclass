import { useUserAgent, withUserAgent } from "next-useragent"
import React, { useContext, useEffect } from "react"
import { STORE_FRONT_PAGE } from "src/__utils__/getNextHead"
import styles from "./styles.module.scss"
import { isMobile } from "react-device-detect"
import Banner from "src/storefront/Banner"
import AppFooterV2 from "src/__components__/AppFooter/v2"
import SearchBarModal from "src/search-result-page/SearchModal"
import NextHead from "src/__components__/NextHead"
import { getTeacherPublicProfileData } from "src/storefront/utils/storefrontAdapter"
import CourseCardV2 from "src/storefront/CourseCard"
import { getUpdatedCourse } from "src/storefront/utils/storefrontAdapter"
import LoginModal from "src/storefront/LoginScreen"
import useFollow from "src/storefront/utils/useFollow"
import useFinalUrl from "src/storefront/utils/useFinalUrl.js"
import BitCarousel from "src/storefront/BitCarousel"
import clsx from "clsx"
import { convertUtmParams, getParamObj } from "src/__utils__/index"
import { AppContext } from "context/AppContext/AppContext"
import {
  GET_MY_FOLLOWING_LIST,
  handleApiCall,
} from "src/homepage/helper/homepageAdapter"
import { SAVE_FOLLOWING_LIST } from "context/AppContext/types"
import TeacherNotFound from "src/storefront/TeacherNotFound"
import dynamic from "next/dynamic"
import AppFooterV3 from "src/__components__/AppFooter/v3"
import StaticBanner from "src/storefront/StaticBanner"
import { FULL_COURSE, WORKSHOP, FREE } from "src/__utils__/constants"
const AppHeader = dynamic(() => import("src/__components__/AppHeader"), {
  ssr: false,
})

const StoreFront = ({
  nextUserAgent,
  courses,
  teacherProfile,
  errorFetching,
  courseCategories,
  paramObj,
  infinityBanner,
}) => {
  const { afterLogin } = useFollow(teacherProfile?.code)
  const { finalUrl } = useFinalUrl(paramObj)
  const { isMobile, isTablet, isIpad } = nextUserAgent
  const fullCourses =
    courses
      ?.filter((course) => {
        if (infinityBanner) {
          return course.type === FULL_COURSE && !course?.has_ended
        }
        return course.type === FULL_COURSE
      })
      .sort((x) => (!x ? -1 : 1)) || []
  const workshops =
    courses
      ?.filter((course) => {
        if (infinityBanner) {
          return (
            (course.type === WORKSHOP || course.type === FREE) &&
            !course?.has_ended
          )
        }
        return course.type === WORKSHOP || course.type === FREE
      })
      .sort((x) => (!x ? -1 : 1)) || []

  const { state, dispatch } = useContext(AppContext)

  useEffect(() => {
    ;(async () => {
      try {
        const { following } = await handleApiCall(GET_MY_FOLLOWING_LIST)
        if (following)
          dispatch({ type: SAVE_FOLLOWING_LIST, payload: following })
      } catch (error) {}
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className={styles.storefront}>
      <div className={styles.nextHead}>
        <NextHead page={STORE_FRONT_PAGE} payload={{ ...teacherProfile }} />
        <div className={styles.header}>
          <AppHeader
            className={styles.appHeader}
            page={STORE_FRONT_PAGE}
            // darkMode={true}
            isMobile={isMobile}
            isTablet={isTablet || isIpad}
            transparentMode={false}
          />
        </div>
      </div>

      {infinityBanner && <StaticBanner infinityBanner={infinityBanner} />}

      <div>
        {teacherProfile ? (
          <div className={styles.body}>
            {teacherProfile && (
              <Banner
                teacherProfile={teacherProfile}
                nextUserAgent={nextUserAgent}
                infinityBanner={infinityBanner}
              />
            )}
            <div id="courses" />
            {/* <CoursesList /> */}
            <div className={styles.courses}>
              <h3>Classes by teacher</h3>
              <div className={styles.courseList}>
                {workshops?.length > 0 && (
                  <div
                    className={clsx(
                      styles.courseCarousel,
                      styles.workshopsCarousel
                    )}
                    style={fullCourses.length < 1 ? { paddingBottom: 0 } : {}}
                  >
                    <h4 className={styles.workshopsTitle}>Workshops</h4>

                    <BitCarousel
                      arrows
                      centerMode={isMobile ? true : false}
                      slidesToScroll={1}
                      page={STORE_FRONT_PAGE}
                      dots={false}
                      autoplay={true}
                      infinite={workshops?.length > 3 ? true : false}
                      heading={false}
                      onClick={() => {}}
                      isMobile={isMobile}
                      isTablet={isTablet || isIpad}
                    >
                      {workshops?.map((course) => (
                        <CourseCardV2
                          customClass={styles.courseCard}
                          page={STORE_FRONT_PAGE}
                          hideTeacher={true}
                          course={getUpdatedCourse(course, teacherProfile)}
                          categories={courseCategories}
                          key={course.code}
                          finalUrl={finalUrl}
                          sectionHeading="teacher_profile_free"
                        />
                      ))}
                    </BitCarousel>
                  </div>
                )}
                {fullCourses?.length > 0 && (
                  <div
                    className={clsx(
                      styles.courseCarousel,
                      styles.coursesCarousel
                    )}
                  >
                    <h4>Courses</h4>
                    <BitCarousel
                      arrows
                      centerMode={isMobile ? true : false}
                      slidesToScroll={1}
                      page={STORE_FRONT_PAGE}
                      dots={false}
                      autoplay={true}
                      infinite={fullCourses?.length > 3 ? true : false}
                      heading={false}
                      onClick={() => {}}
                      isMobile={isMobile}
                      isTablet={isTablet || isIpad}
                    >
                      {fullCourses.map((course) => (
                        <CourseCardV2
                          customClass={styles.courseCard}
                          page={STORE_FRONT_PAGE}
                          hideTeacher={true}
                          course={getUpdatedCourse(course, teacherProfile)}
                          categories={courseCategories}
                          key={course.code}
                          finalUrl={finalUrl}
                          sectionHeading="teacher_profile_paid"
                        />
                      ))}
                    </BitCarousel>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <TeacherNotFound />
        )}
        <div className={styles.footer}>
          <AppFooterV3 />
        </div>
        <div>
          <SearchBarModal />
        </div>
      </div>

      <LoginModal onLoginNext={afterLogin} />
    </div>
  )
}

StoreFront.getInitialProps = async (context) => {
  let nextUserAgent
  if (context.req)
    // eslint-disable-next-line react-hooks/rules-of-hooks
    nextUserAgent = useUserAgent(context.req.headers["user-agent"])
  else nextUserAgent = { isMobile }
  const paramObj = convertUtmParams(
    context,
    getParamObj("storefront", nextUserAgent)
  )

  const {
    teacherProfile,
    courses,
    errorFetching,
    courseCategories,
    infinityBanner,
  } = await getTeacherPublicProfileData({
    teacherName: context.query.teacherCode,
  })

  return {
    nextUserAgent,
    courses,
    teacherProfile,
    errorFetching,
    courseCategories,
    paramObj,
    infinityBanner,
  }
}
export default withUserAgent(StoreFront)
