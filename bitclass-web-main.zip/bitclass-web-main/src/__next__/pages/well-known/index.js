const AssetFiles = () => {
  return (
    <div>
      <pre>
        {JSON.stringify(
          [
            {
              "relation": [
                "delegate_permission/common.handle_all_urls"
              ],
              "target": {
                "namespace": "android_app",
                "package_name": "com.bitclass.android",
                "sha256_cert_fingerprints": [
                  "6E:2B:A4:E0:57:E6:1C:0B:D0:7B:8E:01:24:69:8A:BA:29:03:EA:D0:8B:34:09:29:27:74:EE:4A:95:23:7D:EE",
                  "E7:A1:B1:2E:C2:29:AE:55:82:D0:56:16:EC:A4:A8:BD:EF:48:61:FD:06:94:65:74:12:BF:ED:88:A9:DC:C2:88"
                ]
              }
            }
          ],
          null,
          2
        )}
      </pre>
    </div>
  )
}

export default AssetFiles
