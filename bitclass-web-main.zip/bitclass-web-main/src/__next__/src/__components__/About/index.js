import React from 'react'

const About = () => {
  return (
    <div>
      this is nextjs about section
    </div>
  )
}

export default About