import React, { useState, useEffect } from 'react'
import { X } from 'react-feather'

import styles from './style.module.scss'
import { exists } from '../../__utils__/index'
import { isAndroid, isIOS } from 'react-device-detect'
import { getRole } from '../../__utils__/auth'
// import IosBanner from 'public/static/__assets__/iosDownloadBanner.svg'
import clsx from 'clsx'


const IosBanner = '/static/__assets__/iosDownloadBanner.svg'

const CONTINUE_CHAT_PROMPT = 'To continue this chat on your mobile, download the app now'

const AppDownload = ({
  promptText = CONTINUE_CHAT_PROMPT,
  hideClose = false,
  customClass = ''
}) => {

  const [show, setShow] = useState(true)
  const role = getRole()

  useEffect(() => {
    setTimeout(() => {
      const mainHeader = document.getElementsByClassName("main-header")[0]
      if (!exists(mainHeader)) return
      if (show) {
        mainHeader.classList.add("main-header-push")
      } else {
        mainHeader.classList.remove("main-header-push")
      }
    }, 500)
  }, [show])

  if(show && (isAndroid || isIOS)){
    return (
      <div className={clsx(styles.appDownloadPrompt, customClass)}>
        <div className={styles.close}>
          { !hideClose && <X onClick={() => setShow(false)} /> }
        </div>
        <div className={styles.text}>
          <div className={styles.description}>{promptText}</div>
        </div>
        <div className={styles.download}>
          {/* <PrimaryIconButtonInverted
            text={"Download"}
          /> */}
          {
            isAndroid && (
              <a className={styles.banner} href={`https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=mweb&utm_medium=mweb-classroom-${role}&utm_campaign=gplayicon`}>
                <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/>
              </a>
            )
          }
          {
            isIOS && (
              <a className={styles.banner} href={`https://apps.apple.com/in/app/bitclass/id1537353964`}>
                <img src='static/__assets__/iosDownloadBanner.svg' alt='Get it on App Store' />
              </a>
            )
          }
        </div>
      </div>
    )
  } else if(show && !isAndroid && !isIOS) {
    return (
      <div className={styles.appDownloadPrompt}>
        <div className={styles.close}>
          <X onClick={() => setShow(false)} />
        </div>
        <div className={styles.downloadTitleContainer}>
          <div className={styles.text}>
            <div className={styles.description}>{promptText}</div>
          </div>
          <div className={styles.download}>
            <a target="_blank" rel="noopener noreferrer" className={styles.banner} href={`https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=mweb&utm_medium=mweb-classroom-${role}&utm_campaign=gplayicon`}>
              <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/>
            </a>
            <a target="_blank" rel="noopener noreferrer" className={styles.banner} href={`https://apps.apple.com/in/app/bitclass/id1537353964`}>
              <img src = {IosBanner} alt='Get it on App Store' />
            </a>
          </div>
        </div>
      </div>
    )
  } else {
    return ''
  }
}

export default AppDownload
