import React from 'react'
import Logo from '../../../public/static/__assets__/BitClassLogos/LogoForWhiteBg.svg'
import styles from './style.module.scss'
import IosBannerSvg from '../../../public/static/__assets__/iosDownloadBanner.svg'
import clsx from 'clsx'

export const AndroidBanner = ({
  role = 'student',
  logo = true,
  message = `For an amazing classroom experience on mobile, please download our app`,
  className = '',
  ...props
}) => {


  return (
    <div className={clsx(styles.bannerWrapper, className)}>
      {logo && (<img className={styles.logo} src={Logo} alt="BitClass" />)}
      <div className={styles.bannerContent}>
      {/* For an amazing classroom experience on mobile, please download our app */}
        <p className={styles.info} dangerouslySetInnerHTML={{__html: message}}></p>
        <a className={styles.banner} href={`https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=mweb&utm_medium=mweb-classroom-${role}&utm_campaign=gplayicon`}>
          <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/>
        </a>
      </div>
    </div>
  )
}

export const IosBanner = ({
  role = 'student',
  logo = true,
  message = `For an amazing classroom experience on mobile, please download our app`,
  className = '',
  ...props
}) => {

  return (
    <div className={clsx(styles.bannerWrapper, className)}>
      {logo && (<img className={styles.logo} src={Logo} alt="BitClass" />)}

      <div className={styles.bannerContent}>
      {/* For an amazing classroom experience, please use our web app at <a href={BASE_URL}>{BASE_URL}</a> */}
        <p className={styles.info} dangerouslySetInnerHTML={{__html: message}}></p>
        <a className={styles.banner} href={`https://apps.apple.com/in/app/bitclass/id1537353964`}>
          <img src={IosBannerSvg} alt='Get it on App Store' />
        </a>
      </div>
    </div>
  )
}
