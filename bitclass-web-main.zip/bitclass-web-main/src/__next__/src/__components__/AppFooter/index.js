import React from 'react'
import { Link as RouterLink  } from 'next/link'
import styles from './style.module.scss'

export function Copyright() {
  const date = new Date()
  return (
    <div className={styles.bitclassFooterCopyright}>
      <p>Livestream Infra Technologies Pvt Ltd © {date.getFullYear()}</p>
    </div>
    // <div className={styles.bitclassFooterCopyright}>
    //   {'Copyright © '}
    //   <RouterLink color="inherit" to="/">
    //     BitClass
    //   </RouterLink>{' '}
    //   {new Date().getFullYear()}
    //   {'.'}
    // </div>
  )
}

const AppFooter = () => {
  return (
    <footer className={styles.bitclassFooter}>
      <div className={styles.bitclassFooterLinks}>
        <RouterLink
          className={styles.bitclassLinks}
          to={{ pathname: '/extrainfo', search: '?about' }}
        >
          About
        </RouterLink>
        <RouterLink
          className={styles.bitclassLinks}
          to={{ pathname: '/extrainfo', search: '?contact' }}
        >
          Contact
        </RouterLink>
        <RouterLink
          className={styles.bitclassLinks}
          to={{ pathname: '/extrainfo', search: '?careers' }}
        >
          Careers
        </RouterLink>
        <RouterLink
          className={styles.bitclassLinks}
          to={{ pathname: '/extrainfo', search: '?t&c' }}
        >
          Terms &amp; Conditions
        </RouterLink>
      </div>

      <Copyright />
    </footer>
  )
}

export default AppFooter
