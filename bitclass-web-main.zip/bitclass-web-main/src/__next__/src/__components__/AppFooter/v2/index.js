/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react'
import styles from './style.module.scss'
import {MapPin, Mail, Phone} from 'react-feather'
import {isMobile, isTablet} from 'react-device-detect'

import Facebook from 'public/static/__assets__/facebook.svg'
import Twitter from 'public/static/__assets__/twitter.svg'
import Link from 'next/link'
import trackEvent from 'src/__utils__/analytics'
import { BIT_EVENTS } from 'config/events'
import { getCode } from 'src/__utils__/auth'


// icon data
const linkedinIcon = {
  icon: "/static/__assets__/linkedin.svg",
  url: "https://www.linkedin.com/company/bitclass-live/",
}
const instagramIcon = {
  icon: "/static/__assets__/instagram.svg",
  url: "https://www.instagram.com/bitclass/",
}
const bitclassLogoPath = "/static/__assets__/BitClassLogos/LogoForDarkBG.svg"
const blogURL = "https://blog.bitclass.live/"
//default icons width
const iconWidth = '35px'

const AppFooterV2 = () => {

  const [trackingBaseParam, setTrackingBaseParam] = useState({})

  useEffect(() => {
    setTrackingBaseParam({
      student: getCode()
    })
  }, [])

  const date = new Date()
  return (
    <footer className={styles.footerDistributed}>
      <div className={styles.footerLeft}>
        <img
          src={bitclassLogoPath}
          alt="Bitclass Logo"
          width="120px"
        />

        <p className={styles.footerLinks}>
          <Link href="/">
            <a onClick={() => trackEvent(BIT_EVENTS.FOOTER_HOME_CLICKED, trackingBaseParam)} className={styles.link1}>Home</a>
          </Link>

          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_BLOG_CLICKED, trackingBaseParam)
              window.open(blogURL)
            }}
          >
            Blog
          </a>

          <Link href="/about" >
            <a onClick={() => trackEvent(BIT_EVENTS.FOOTER_ABOUT_CLICKED, trackingBaseParam)}>
              About
            </a>
          </Link>

          <Link href="/contact" >
            <a onClick={() => trackEvent(BIT_EVENTS.FOOTER_CONTACT_US_CLICKED, trackingBaseParam)}>
              Contact
            </a>
          </Link>

          <Link href="/careers">
            <a onClick={() => trackEvent(BIT_EVENTS.FOOTER_CAREERS_CLICKED, trackingBaseParam)}>
              Careers
            </a>
          </Link>
          <Link href="/app/policy" shallow={true}>
            <a onClick={() => trackEvent(BIT_EVENTS.FOOTER_POLICY_CLICKED, trackingBaseParam)}>
              Policy
            </a>
          </Link>

        </p>

        {!isMobile && !isTablet && (
          <p className={styles.footerCompanyName}>
            Livestream Infra Technologies Pvt Ltd © {date.getFullYear()}
          </p>
        )}
      </div>

      <div className={styles.footerCenter}>
        <div className={styles.footerContactDiv}>
          <MapPin />
          <p>
            <span>#316, 14th B Cross, 7th Main, Sector 6,</span>{" "}
            <span>HSR Layout, Bengaluru, Karnataka 560102</span>
          </p>
        </div>

        {/* <div className={styles.footerContactDiv}>
          <Phone />
          <p>
            <a
              href="tel:08047186300"
              onClick={() => trackEvent(BIT_EVENTS.FOOTER_PHONE_CLICKED, {...trackingBaseParam, number: 1})}
            >
              08047186300
            </a>
          </p>
        </div>
        <div className={styles.footerContactDiv}>
          <Phone />
          <p>
            <a
              href="tel:08047193322"
              onClick={() => trackEvent(BIT_EVENTS.FOOTER_PHONE_CLICKED, {...trackingBaseParam, number: 2})}
            >
              08047193322
            </a>
          </p>
        </div> */}
        <div className={styles.footerContactDiv}>
          <Mail />
          <p>
            <a
              href="mailto:hello@bitclass.live"
              onClick={() => trackEvent(BIT_EVENTS.FOOTER_EMAIL_CLICKED, trackingBaseParam)}
            >
              hello@bitclass.live
            </a>
          </p>
        </div>
      </div>

      <div className={styles.footerRight}>
        <p className={styles.footerCompanyAbout}>
          <span>About the company</span>
          BitClass helps individual teachers, trainers and coaches setup and
          grow their online live teaching business successfully.
        </p>

        <div className={styles.footerIcons}>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_FB_CLICKED, trackingBaseParam)
              window.open("https://www.facebook.com/Bitclasscommunity")
            }}
          >
            <Facebook />
          </a>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_TWITTER_CLICKED, trackingBaseParam)
              window.open("https://twitter.com/bitclass_live")
            }}
          >
            <Twitter />
          </a>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_LINKEDIN_CLICKED, trackingBaseParam)
              window.open(linkedinIcon.url)
            }}
          >
            <img src={linkedinIcon.icon} alt="" width={iconWidth} />
          </a>
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_INSTAGRAM_CLICKED, trackingBaseParam)
              window.open(instagramIcon.url)
            }}
          >
            {/* <Instagram/> */}
            <img src={instagramIcon.icon} alt="" width={iconWidth} />
          </a>
        </div>
      </div>
      {(isMobile || isTablet) && (
        <p className={styles.footerCompanyName}>
          Livestream Infra Technologies Pvt Ltd © {date.getFullYear()}
        </p>
      )}
    </footer>
  )
}

export default AppFooterV2
