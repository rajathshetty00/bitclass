import React, { useEffect, useState } from "react"
import BitSvg from "src/__components__/BitSvg"
import styles from "./styles.module.scss"
import LinkedIn from "public/static/__assets__/social/linkedIn.svg"
import Facebook from "public/static/__assets__/social/facebook.svg"
import Instagram from "public/static/__assets__/social/instagram.svg"
import Twitter from "public/static/__assets__/social/twitter.svg"
import BitLink from "src/__components__/BitLink"
import { LOGO } from "src/__utils__/logo/logo"
import trackEvent from "src/__utils__/analytics"
import { BIT_EVENTS } from "config/events"
import { getCode } from "src/__utils__/auth"

const FooterAbout = () => {
  const [trackingBaseParam, setTrackingBaseParam] = useState({})

  useEffect(() => {
    setTrackingBaseParam({
      student: getCode(),
    })
  }, [])

  return (
    <div className={styles.footerAbout}>
      <div className={styles.details}>
        <img alt="logo" src={LOGO.dark} className={styles.logo} />
        <p>
          BitClass is the largest LIVE learning platform. Get started for FREE
          and explore 100s of classes across several categories.
        </p>
        <div className={styles.social}>
          <BitLink
            href="https://www.linkedin.com/company/bitclass-live/"
            target="_blank"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_LINKEDIN_CLICKED, trackingBaseParam)
              window.open("https://www.linkedin.com/company/bitclass-live/")
            }}
          >
            <LinkedIn />
          </BitLink>
          <BitLink
            href="https://www.facebook.com/Bitclasscommunity"
            target="_blank"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_FB_CLICKED, trackingBaseParam)
              window.open("https://www.facebook.com/Bitclasscommunity")
            }}
          >
            <Facebook />
          </BitLink>
          <BitLink
            href="https://www.instagram.com/bitclass/"
            target="_blank"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_INSTAGRAM_CLICKED, trackingBaseParam)
              window.open("https://www.instagram.com/bitclass/")
            }}
          >
            <Instagram />
          </BitLink>
          <BitLink
            href="https://twitter.com/bitclass_live"
            target="_blank"
            onClick={(e) => {
              e.preventDefault()
              trackEvent(BIT_EVENTS.FOOTER_TWITTER_CLICKED, trackingBaseParam)
              window.open("https://twitter.com/bitclass_live")
            }}
          >
            <Twitter />
          </BitLink>
        </div>
      </div>
      <div className={styles.copyright}>
        Livestream Infra Technologies Pvt Ltd © {new Date().getFullYear()}
      </div>
    </div>
  )
}

export default FooterAbout
