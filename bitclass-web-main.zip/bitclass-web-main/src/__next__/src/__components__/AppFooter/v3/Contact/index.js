import { BIT_EVENTS } from "config/events"
import React from "react"
import { Mail, MapPin, Phone } from "react-feather"
import trackEvent from "src/__utils__/analytics"
import { getCode } from "src/__utils__/auth"
import styles from "./styles.module.scss"

const FooterContact = () => {
  return (
    <div className={styles.contact}>
      <h3>Contact Us</h3>
      <div className={styles.footerContacts}>
        <p>For Students</p>
        <div className={styles.footerContactDiv}>
          <Mail />
          <p>
            <a
              href="mailto:hello@bitclass.live"
              onClick={() =>
                trackEvent(BIT_EVENTS.FOOTER_EMAIL_CLICKED, {
                  student_id: getCode(),
                })
              }
            >
              hello@bitclass.live
            </a>
          </p>
        </div>
        <p>For Teachers</p>
        <div className={styles.footerContactDiv}>
          <Mail />
          <p>
            <a
              href="mailto:teachers@bitclass.live"
              onClick={() =>
                trackEvent(BIT_EVENTS.FOOTER_EMAIL_CLICKED, {
                  student_id: getCode(),
                })
              }
            >
              teachers@bitclass.live
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}

export default FooterContact
