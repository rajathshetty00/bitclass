import { BIT_EVENTS } from "config/events"
import Link from "next/link"
import React, { useEffect, useState } from "react"
import BitLink from "src/__components__/BitLink"
import trackEvent from "src/__utils__/analytics"
import { getCode } from "src/__utils__/auth"
import styles from "./styles.module.scss"
import { BASE_URL } from "src/constants"

const PAGE = [{ pageName: "Home" }]

const FooterPages = () => {
  const [trackingBaseParam, setTrackingBaseParam] = useState({})
  const blogURL = "https://blog.bitclass.live/"

  useEffect(() => {
    setTrackingBaseParam({
      student: getCode(),
    })
  }, [])

  return (
    <div className={styles.footerPage}>
      <h3>Useful Links</h3>
      <div className={styles.links}>
        <BitLink
          href={`${BASE_URL}`}
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_HOME_CLICKED, trackingBaseParam)
          }
        >
          Home
        </BitLink>
        <BitLink
          href="/about"
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_ABOUT_CLICKED, trackingBaseParam)
          }
        >
          About
        </BitLink>
        <BitLink
          href="/contact"
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_CONTACT_US_CLICKED, trackingBaseParam)
          }
        >
          Contact
        </BitLink>
        <BitLink
          href="/careers"
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_CAREERS_CLICKED, trackingBaseParam)
          }
        >
          Careers
        </BitLink>
        <BitLink href={`${BASE_URL}/live-classes/faq`}>FAQs</BitLink>

        <BitLink
          href={`${BASE_URL}/n/launchpad`}
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_POLICY_CLICKED, trackingBaseParam)
          }
        >
          Teach On BitClass
        </BitLink>
        <BitLink
          href={blogURL}
          target="_blank"
          onClick={(e) => {
            trackEvent(BIT_EVENTS.FOOTER_BLOG_CLICKED, trackingBaseParam)
          }}
        >
          Blog
        </BitLink>
        <BitLink
          href={`${BASE_URL}/live-classes/policy`}
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_POLICY_CLICKED, trackingBaseParam)
          }
        >
          Policy
        </BitLink>
        <BitLink
          href={`${BASE_URL}/live-classes/terms`}
          onClick={() =>
            trackEvent(BIT_EVENTS.FOOTER_TERM_CLICKED, trackingBaseParam)
          }
        >
          terms & conditions
        </BitLink>
      </div>
    </div>
  )
}

export default FooterPages
