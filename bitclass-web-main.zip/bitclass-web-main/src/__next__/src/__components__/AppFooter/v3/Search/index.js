import React from "react"
import { MapPin } from "react-feather"
import { BASE_URL, SEARCH_LINK } from "src/constants"
import BitLink from "src/__components__/BitLink"

import styles from "./styles.module.scss"

const FooterSearch = () => {
  return (
    <div className={styles.address}>
      <h3>Popular Searches</h3>
      <div className={styles.links}>
        {SEARCH_LINK.map((item)=>
        <BitLink 
          href = {item?.link}>
            {item?.name}
        </BitLink>
        )}
      </div>
    </div>
  )
}

export default FooterSearch
