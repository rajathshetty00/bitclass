import React from "react"
import FooterAbout from "./About"
import FooterContact from "./Contact"
import FooterPages from "./Pages"
import FooterSearch from "./Search"
import styles from "./style.module.scss"
import clsx from "clsx"

const AppFooterV3 = ({ customClass }) => {
  return (
    <div className={clsx(styles.footer, customClass)}>
      <FooterAbout />
      <div className={styles.mobileGroup}>
        <FooterPages />
        <FooterSearch />
      </div>
      <FooterContact />
    </div>
  )
}

export default AppFooterV3
