import clsx from "clsx"
import { ANDROID_DOWNLOAD, IOS_DOWNLOAD } from "config/id"
import BitSvg from "src/__components__/BitSvg"
import styles from "./styles.module.scss"

const AppDownloadButtons = ({
  dark = true, 
  source = "direct", 
  isMobile, 
  componentName,
  showDivider = true,
  customClass = ''
}) => {
  const _iosIcon = dark ? "appstore-1.svg" : "appStoreOutlineIcon.svg",
    _androidIcon = dark ? "googleplay-1.svg": "playStoreOutlineIcon.svg"
    
  return (
    <div className={ clsx(styles.stores, customClass)}>
      <div>
        <BitSvg 
          src={_iosIcon} 
          id={IOS_DOWNLOAD} 
          data-source={source.toLowerCase()} 
          data-mobile={isMobile}           
          data-comp={componentName} />
      </div>
      <div>
        <BitSvg 
          src={_androidIcon} 
          id={ANDROID_DOWNLOAD} 
          data-source={source.toLowerCase()} 
          data-mobile={isMobile} 
          data-comp={componentName}
        />
      </div>
      {showDivider && <div className={styles.divider} />}
    </div>
  )
}

export default AppDownloadButtons
