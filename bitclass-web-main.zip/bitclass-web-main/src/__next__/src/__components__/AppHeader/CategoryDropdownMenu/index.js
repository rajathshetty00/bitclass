import { Menu } from "antd"
import { BIT_EVENTS } from "config/events"
import BitLink from "src/__components__/BitLink"
import trackEvent from "src/__utils__/analytics"
import { getCode } from "src/__utils__/auth"
import styles from "./styles.module.scss"

export const dropDownMenu = (categories, hideIcon = true, categoryName) => (
  <Menu className={styles.menu}>
    {categories.map(({ display_text, icon }) => (
      <Menu.Item
        key={display_text}
        className={styles.menuItem}
        style={
          categoryName === display_text ? { backgroundColor: "#E6F7FF" } : {}
        }
      >
        {!hideIcon && <img src={icon} alt="" />}
        <BitLink
          href={`/c/${encodeURI(display_text)}`}
          target="_blank"
          onClick={() =>
            trackEvent(BIT_EVENTS.DROPDOWN_OPTION_CLICKED, {
              drop_down_name: "categories",
              drop_down_option: display_text,
              student_id: getCode(),
            })
          }
        >
          {display_text}
        </BitLink>
      </Menu.Item>
    ))}
  </Menu>
)
