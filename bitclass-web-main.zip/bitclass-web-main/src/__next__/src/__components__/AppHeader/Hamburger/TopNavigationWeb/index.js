import React from "react"
import SearchBar from "src/search-result-page/SearchBar"

import styles from "./styles.module.scss"

const TopNavigationWeb = ({ page, finalUrl, searchQuery }) => {
  return (
    <>
      <div className={styles.menu}>
        <SearchBar finalUrl={finalUrl} searchQuery={searchQuery} />
      </div>
    </>
  )
}

export default TopNavigationWeb
