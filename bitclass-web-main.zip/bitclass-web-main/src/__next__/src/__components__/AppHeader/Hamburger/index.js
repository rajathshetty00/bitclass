import { Drawer } from "antd"
// import clsx from "clsx"
import Link from "next/link"
import { useRouter } from "next/router"
import React from "react"
import { ChevronLeft } from "react-feather"
import styles from "./styles.module.scss"
import { hasAuthToken } from "src/__utils__/auth"
import { getMenuByPage } from "../utils/getMenu"
import { getHamburgerBgColor, getNavigationRoute } from "../utils/utils"
import AppDownloadButtons from "../AppDownloadButtons"

import { COMPONENT_NAMES } from "src/constants"

const DrawerMenuItem = ({ data, router, closeDrawer, page }) => {
  const { href, icon, name } = data
  const getClassName = () => {
    if (router.asPath === href || router.asPath.includes(href))
      return styles.active
    else return styles.hamburgerBtn
  }

  return (
    <>
      {href !== "/teach-on-bitclass" ? (
        <Link href={getNavigationRoute({ path: router.asPath, href, page })}>
          <a href={href} className={getClassName()} onClick={closeDrawer}>
            {icon}
            <span>{name}</span>
          </a>
        </Link>
      ) : (
        !hasAuthToken() && (
          <Link href={getNavigationRoute({ path: router.asPath, href, page })}>
            <a href={href} className={getClassName()} onClick={closeDrawer}>
              {icon}
              <span>{name}</span>
            </a>
          </Link>
        )
      )}
    </>
  )
}

const Hamburger = ({ setVisible, visible, page, isMobile }) => {
  const router = useRouter()
  const closeDrawer = () => {
    setVisible(false)
  }
  return (
    <Drawer
      style={{ zIndex: 10200 }}
      bodyStyle={{
        width: "100%",
        backgroundColor: getHamburgerBgColor(page),
        color: "white",
        padding: "0",
      }}
      title={
        <div
          className={styles.header}
          style={{ backgroundColor: getHamburgerBgColor(page) }}
        >
          <ChevronLeft
            color="white"
            size="30"
            onClick={() => setVisible(false)}
          />
          <img
            src="/static/__assets__/BitClassLogos/LogoForDarkBG.svg"
            alt="whiteLogo"
            width="120"
            height="30"
          />{" "}
        </div>
      }
      placement={"left"}
      closable={false}
      onClose={() => setVisible(false)}
      visible={visible}
      key={"left"}
      className={styles.drawerContainer}
    >
      <div className={styles.topSection}>
        {getMenuByPage(page).map((menuItem) => (
          <DrawerMenuItem
            data={menuItem}
            closeDrawer={closeDrawer}
            router={router}
            page={page}
            key={menuItem}
          />
        ))}
      </div>
      <AppDownloadButtons
        componentName={COMPONENT_NAMES.hamburger}
        isMobile={isMobile}
        source={page}
        showDivider={false}
        dark={true}
        customClass={styles.appDownloadWrapper}
      />
    </Drawer>
  )
}

export default Hamburger
