import React, { useContext, useState } from "react"
import { Popover } from "antd"

import {
  hasAuthToken,
  getRole,
  getDefaultRouteForLoggedIn,
  getUserInfo,
} from "../../__utils__/auth"
import styles from "./style.module.scss"
import { setRole } from "../../__utils__/auth"
import trackEvent, { analyticsLogout } from "../../__utils__/analytics"
import clsx from "clsx"
import { ChevronDown, Menu, Search } from "react-feather"
import LoggedInAvatar from "../../profile/__components__/LoggedInAvatar"
import { useRouter } from "next/router"
import {
  BASE_URL,
  // CHRISTMAS_LOGOS,
  // COMPONENT_NAMES,
  // SOURCE,
} from "src/constants"
import Hamburger from "./Hamburger"
import { isTablet as reactIsTablet } from "react-device-detect"
import { getAppHeaderComponent, getqueryStr } from "./utils/utils"
import { SearchContext } from "context/SearchContext"
import { CATEGORY_PAGE, CDP_PAGE } from "src/__utils__/pages"
import { HOMEPAGE } from "src/__utils__/pages"
import { AppContext } from "context/AppContext/AppContext"
import {
  CHANGE_LOGGED_IN_STATUS,
  LOGIN_TRIGGERER,
  SET_USER_INFO,
  TOGGLE_LOGIN_SCREEN,
} from "context/AppContext/types"
import LoginModal from "src/storefront/LoginScreen"
import { STORE_FRONT_PAGE } from "src/__utils__/getNextHead"
import SearchBarModal from "src/search-result-page/SearchModal"
import { HEADER_LOGIN_BUTTON } from "src/__utils__/components"
import { LOGIN_BUTTON, LOGOUT_BUTTON, HEADER_LOGO } from "config/id"
import { deleteAuthToken, deleteCookie } from "src/__utils__"
import { LOGO, LOGO_ICON } from "src/__utils__/logo/logo"
import { BIT_EVENTS } from "config/events"
const _BaseHeader = ({
  props,
  page = "",
  className = "",
  darkMode = false,
  isMobile = false,
  isTablet = false,
  transparentMode = false,
  showHamburgerMenu = false,
  finalQueryUrl = false,
  searchQuery = "",
  source = "direct",
}) => {
  const [isMenuOpened, setIsMenuOpened] = useState(false)
  const [visible, setVisible] = useState(false)
  const router = useRouter()
const queryStr = getqueryStr(router)

  const userInfo = getUserInfo()
  
  const handleLogoClick = () => {
    window.location.href = `${BASE_URL}/?channel=home&platform=${
      isMobile ? "mweb" : "web"
    }${queryStr?`&${queryStr}`:''}`
  }

  const getLogo = () => {
    return isMobile || isTablet
      ? darkMode
        ? LOGO_ICON.light
        : LOGO_ICON.dark
      : darkMode
      ? LOGO.light
      : LOGO.dark
  }

  const { setDisplayMobileSearchModal } = useContext(SearchContext)
  const { state, dispatch } = useContext(AppContext)

  const handleLogout = (e) => {
    let url = ""
    setIsMenuOpened(false)
    localStorage.clear()
    analyticsLogout()
    deleteCookie("auth-key")
    deleteAuthToken()
    dispatch({
      type: CHANGE_LOGGED_IN_STATUS,
      payload: false,
    })
    dispatch({
      type: SET_USER_INFO,
      payload: null,
    })
    url = window.location.href.split("#")[0]
    window.location.href = url
  }

  const handleLogin = (e) => {
    dispatch({ type: TOGGLE_LOGIN_SCREEN, payload: true })
    dispatch({
      type: LOGIN_TRIGGERER,
      payload: HEADER_LOGIN_BUTTON,
    })
  }

  return (
    <>
      <div
        className={clsx(
          styles.menuWrapper,
          className,
          darkMode && styles.dark,
          transparentMode && styles.transparent
        )}
        style={{ zIndex: 999 }}
      >
        <div className={styles.menuLeft}>
          <div className={styles.bitclassLogo}>
            {showHamburgerMenu && (isMobile || isTablet || reactIsTablet) && (
              <>
                <button
                  onClick={() => setVisible(true)}
                  className={styles.hamburger}
                >
                  <Menu
                    color={transparentMode || darkMode ? "white" : "#2E3A59"}
                  />
                </button>
                <Hamburger
                  visible={visible}
                  setVisible={setVisible}
                  page={page}
                  transparentMode={transparentMode}
                  isMobile={isMobile}
                />
              </>
            )}
            <img
              id={HEADER_LOGO}
              data-source={page}
              onClick={handleLogoClick}
              src={getLogo()}
              alt="Bitclass Logo"
              style={isMobile || isTablet ? { width: 40 } : { maxWidth: 112 }}
            />

            <div className={styles.searchIcon}>
              {getAppHeaderComponent(
                page,
                isMobile,
                isTablet,
                finalQueryUrl && finalQueryUrl,
                searchQuery
              )}
            </div>
          </div>

          {props?.showRole && (
            <div className={styles.roleContainer}>
              <div className={styles.roleBlock}>
                <div
                  className={clsx(
                    styles.role,
                    getRole() === "teacher" && styles.active
                  )}
                  onClick={async () => {
                    setRole("teacher")
                    let _r = await getDefaultRouteForLoggedIn()
                    if (props.history.location.pathname !== _r)
                      props.history.push(_r)
                  }}
                >
                  Courses I am teaching
                </div>
                <div
                  className={clsx(
                    styles.role,
                    getRole() === "student" && styles.active
                  )}
                  onClick={() => {
                    setRole("student")
                    props.history.push(`/profile?channel=search&platform=${
                      isMobile ? "mweb" : "web"
                    }${queryStr?`&${queryStr}`:''}`)
                  }}
                >
                  Courses I am attending
                </div>
              </div>
            </div>
          )}
        </div>
        {
          <div className={styles.menuRight}>
            {isMobile &&
              (page === "search-result-page" ||
                page === CATEGORY_PAGE ||
                page === HOMEPAGE) && (
                <div className={styles.searchIcon}>
                  <Search
                    size="18px"
                    onClick={() => {
                      trackEvent(BIT_EVENTS.SEARCH_CLICKED)
                      setDisplayMobileSearchModal(true)
                    }}
                  />
                </div>
              )}

            {/* {(page === CATEGORY_PAGE ||
              page === HOMEPAGE ||
              page === "search") &&
              !isMobile &&
              !isTablet && (
                <AppDownloadButtons
                  dark={false}
                  componentName={COMPONENT_NAMES.appHeader}
                  isMobile={isMobile}
                  source={page}
                  customClass={styles.appDownloadWrapper}
                />
              )} */}
            {page === HOMEPAGE && !isMobile && (
              <button
                className={styles.teachOnBitClassBtn}
                onClick={() => {
                  trackEvent(BIT_EVENTS.TEACH_ON_BITCLASS_CLICKED, {
                    source: "app-header",
                    platform: "web",
                  })
                  window.open(`${BASE_URL}/n/launchpad?channel=home&platform=${
                    isMobile ? "mweb" : "web"
                  }${queryStr?`&${queryStr}`:''}`)
                }}
              >
                Teach on BitClass
              </button>
            )}

            {state?.userInfo || hasAuthToken() ? (
              <>
                <Popover
                  content={() => {
                    return (
                      <div className={styles.siteMenuDropdownContent}>
                        <p
                          onClick={(e) => {
                            setIsMenuOpened(false)
                            window.location.href = `${BASE_URL}/live-classes/profile?channel=home&platform=${
                              isMobile ? "mweb" : "web"
                            }${queryStr?`?${queryStr}`:''}`
                          }}
                        >
                          My Classes
                        </p>

                        <p id={LOGOUT_BUTTON} onClick={handleLogout}>
                          Logout
                        </p>
                      </div>
                    )
                  }}
                  trigger="click"
                  visible={isMenuOpened}
                  onVisibleChange={(e) => setIsMenuOpened(e)}
                  placement="bottomRight"
                >
                  <p
                    onClick={(e) => setIsMenuOpened(true)}
                    style={{ cursor: "pointer" }}
                  >
                    <LoggedInAvatar userInfo={userInfo} />
                    <ChevronDown color="#3C3C3C" size="16" />
                  </p>
                </Popover>
              </>
            ) : (
              <div style={{ display: "flex", alignItems: "center" }}>
                <div
                  id={LOGIN_BUTTON}
                  data-source={page === CDP_PAGE ? "cdp_top_bar" : page}
                  onClick={handleLogin}
                  className={
                    darkMode && !transparentMode
                      ? styles.darkHeaderLoginButton
                      : styles.headerLoginButton
                  }
                >
                  Login
                </div>
              </div>
            )}
          </div>
        }
        {(page !== HOMEPAGE || page !== STORE_FRONT_PAGE) && (
          <LoginModal
            onLoginNext={() => {
              dispatch({ type: TOGGLE_LOGIN_SCREEN, payload: false })
              window.location.reload()
            }}
          />
        )}
      </div>
      <SearchBarModal
        customClass={styles.searchPageWrapper}
        searchQuery={searchQuery}
        isMobile={isMobile}
      />
    </>
  )
}

export default _BaseHeader
