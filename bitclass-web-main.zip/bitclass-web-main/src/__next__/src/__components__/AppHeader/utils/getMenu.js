import { EXPERT_CDP_PAGE, HOMEPAGE } from "src/__utils__/pages"
import { defaultMenuItems, expertCdpMenuItems } from "./menuData"

export const getMenuByPage = (page) => {
  switch (page) {
    case EXPERT_CDP_PAGE:
      return expertCdpMenuItems
    case HOMEPAGE:
      return defaultMenuItems
    default:
      return defaultMenuItems
  }
}
