import {
  Book,
  HelpCircle,
  Layers,
  MessageSquare,
  Star,
  UserCheck,
} from "react-feather"


export const expertCdpMenuItems = [
  {
    name: "About course",
    href: "#about-course",
    icon: <Layers style={{ marginLeft: "15px" }} size="25px" />,
  },
  {
    name: "Topics Taught",
    href: "#topics-taught",
    icon: <Book style={{ marginLeft: "15px" }} size="25px" />,
  },
  {
    name: "Course Highlights",
    href: "#course-highlights",
    icon: <Star style={{ marginLeft: "15px" }} size="25px" />,
  },
  {
    name: "About Teacher",
    href: "#about-teacher",
    icon: <UserCheck style={{ marginLeft: "15px" }} size="25px" />,
  },
  {
    name: "Testimonials",
    href: "#testimonials",
    icon: <MessageSquare style={{ marginLeft: "15px" }} size="25px" />,
  },
  {
    name: "FAQS",
    href: "#faqs",
    icon: <HelpCircle style={{ marginLeft: "15px" }} size="25px" />,
  },
]
export const defaultMenuItems = [
  {
    name: "Teach on BitClass",
    href: "/n/launchpad",
    icon: <Book style={{ marginLeft: "15px" }} size="25px" />,
    tabName:'download_app',
  }
]