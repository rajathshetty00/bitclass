import SearchBar from "src/search-result-page/SearchBar"
import { CATEGORY_PAGE, EXPERT_CDP_PAGE, FEED_PAGE } from "src/__utils__/pages"
import {  HOMEPAGE } from "src/__utils__/pages"
import TopNavigationWeb from "../Hamburger/TopNavigationWeb"



export const getAppHeaderComponent = (page, isMobile,isTablet, finalUrl, searchQuery) => {
  switch (page) {
    case CATEGORY_PAGE:
    case "search-result-page":
      if (isMobile) return
      return <SearchBar finalUrl={finalUrl} searchQuery = {searchQuery} page={page}/>
    case HOMEPAGE:
    case FEED_PAGE:
        if(isTablet || isMobile) return
        return <TopNavigationWeb page={HOMEPAGE} finalUrl={finalUrl} searchQuery = {searchQuery}/>
    default:
      return false
  }
}

export const getHamburgerBgColor = (page) => {
  switch (page) {
    case EXPERT_CDP_PAGE:
      return "#191c21"
    default:
      return "#2e3a59"
  }
}

export const getNavigationRoute = ({page,path,href}) => {
  switch (page) {
    case EXPERT_CDP_PAGE:
      return `${path.split("#")[0]}${href}`
    default:
      return href
  }
}

export const getqueryStr =(router)=>{
  const paramsObj = router.query
  delete paramsObj?.q
  delete paramsObj?.channel
  delete paramsObj?.platform
    if (Object.keys(paramsObj).length) {
      return  Object.keys(paramsObj)
          .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(paramsObj[key])}`)
          .join('&')
    }
    return null
}