import React from 'react'
import { Spin } from 'antd'
import { LoadingOutlined } from '@ant-design/icons'
import clsx from 'clsx'

import styles from './style.module.scss'

const BitAntLoader = ({
  customClass = ''
}) => {

  const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />

  return (
    <div className={clsx(styles.bitAntLoader, customClass)}>
      <Spin indicator={antIcon} />
    </div>
  )
}

export default BitAntLoader
