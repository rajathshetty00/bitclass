/* eslint-disable no-return-assign */
import Slider from "react-slick"
import styles from "./styles.module.scss"
import { ChevronLeft, ChevronRight } from "react-feather"
// import { useState } from "react"
import clsx from 'clsx'

const NextArrow = ({ onClick }) => (
  <button onClick={onClick} type="button" className={clsx(styles.navArrow, styles.navRight)}>
    <ChevronRight />
  </button>
)
const PreviousArrow = ({ onClick }) => (
  <button onClick={onClick} type="button" className={clsx(styles.navArrow, styles.navLeft)}>
    <ChevronLeft />
  </button>
)

const BitPureCarousel = ({ children, isMobile, handleAfterChange, customClass = "", customSettings = {} }) => {
  const isInfiniteScroll = isMobile ? children.length > 1 : children.length > 4
  const settings = {
    dots:  false,
    infinite: isInfiniteScroll,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    swipeToSlide: true,
    afterChange: handleAfterChange,
    responsive: [
      {
        breakpoint: 3072,
        settings: {
          slidesToShow: 6,
          slidesToScroll: 1,
          infinite: children.length > 6,
          dots: false,
        },
      },
      {
        breakpoint: 2000,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
          infinite: children.length > 5,
          dots: false,
        },
      },
      {
        breakpoint: 1440,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
          infinite: children.length > 4,
          dots: false,
        },
      },
      {
        breakpoint: 1280,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1,
          infinite: children.length > 4,
          dots: false,
        },
      },
      {
        breakpoint: 1000,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: children.length > 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
    ...customSettings
  }    
  return (
    <div className={clsx(styles.slider, customClass)}>
      <Slider
        {...settings}
        nextArrow={ <NextArrow />}
        prevArrow={ <PreviousArrow />}
      >
        {children}
      </Slider>
    </div>
  )
}

export default BitPureCarousel
