import "styles/globals.css"
import "styles/index.css"
import { Provider } from "react-redux"
import { useStore } from "redux/store"
import { useGtm } from "src/hooks/useGtm"
import { initDefaultsRequestHeader } from "utils"
import BitFooter from "@/components/Footer/BitFooter"

function MyApp({ Component, pageProps }) {
  const store = useStore(pageProps.initialReduxState)
  useGtm(store)
  initDefaultsRequestHeader()
  return (
    <>
      <Provider store={store}>
        <Component {...pageProps} />
      </Provider>
      <BitFooter />
    </>
  )
}

export default MyApp
