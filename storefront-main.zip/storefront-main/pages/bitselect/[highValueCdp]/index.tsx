import Banner from "src/layouts/HighValueCdp/Banner/Banner"
import axios from "axios"
import { useState } from "react"
import { initializeStore } from "redux/store"
import VideoModal from "src/layouts/HighValueCdp/Banner/VideoModal"
import HVCStickyNavigation from "src/layouts/HighValueCdp/HVCStickyNavigation/HVCStickyNavigation"
import HVCSummary from "src/layouts/HighValueCdp/Summary/HVCSummary"
import HVCOutcome from "src/layouts/HighValueCdp/HVCOutcome/HVCOutcome"
import HVCTopics from "src/layouts/HighValueCdp/HVCTopics/HVCTopics"
import HVCTeacherSection from "src/layouts/HighValueCdp/HVCAboutTeacherSection/HVCTeacherSection"
import HVCCurriculum from "src/layouts/HighValueCdp/HVCCurriculum/HVCCurriculum"
import HVCReview from "src/layouts/HighValueCdp/HVCReview/HVCReview"
import HVCPriceSection from "src/layouts/HighValueCdp/HVCPriceSection/HVCPriceSection"
import HVCFaq from "src/layouts/HighValueCdp/HVCFaq/HVCFaq"
import BitModal from "@/components/Modal/Modal"
import HVCStickyEnrollSection from "src/layouts/HighValueCdp/HVCStickyEnroll/HVCStickyEnrollSection"
import WhyBitclass from "src/layouts/HighValueCdp/WhyBitclass/WhyBitclass"
import HowToEnroll from "src/layouts/HighValueCdp/HowToEnroll/HowToEnroll"
import { API_URL } from "utils/constants"

const HighValueCDP = (props) => {
  const [showModal, setShowModal] = useState(false)
  const handleEventBubbling = (e) => {
    if (e.target.id === "modal") setShowModal(false)
    if (e.target.id === "enroll-now") {
      const position = e.target.dataset?.position || ""
      // @ts-ignore
      window.dataLayer.push({ position })
      window.open(props.registrationFormURL)
    }
  }

  return (
    <div onClick={handleEventBubbling}>
      <HVCStickyNavigation />
      <div className="md:pt-24 md:bg-darkBlue">
        <Banner setShowModal={setShowModal} />
      </div>
      <div id="outcomes">
        <HVCSummary />
      </div>
      <HVCOutcome />
      <div id="topics">
        <HVCTopics />
      </div>
      <WhyBitclass />
      <div id="teacher">
        <HVCTeacherSection />
      </div>
      <div id="curriculum">
        <HVCCurriculum />
      </div>
      <HowToEnroll />
      <div id="reviews">
        <HVCReview />
      </div>
      <HVCPriceSection />
      <HVCFaq />
      <BitModal showModal={showModal} setShowModal={setShowModal}>
        <VideoModal />
      </BitModal>
      <HVCStickyEnrollSection />
    </div>
  )
}

export default HighValueCDP

export const getServerSideProps = async (ctx) => {
  const reduxStore = initializeStore({})
  const { dispatch } = reduxStore
  let registrationFormURL = ""
  try {
    const { data } = await axios.get(
      `${API_URL}/v3/hvc/${ctx.params.highValueCdp}/details`
    )
    registrationFormURL = data?.data?.registration_form_url ?? null
    dispatch({
      type: "COURSE_DATA",
      payload: data.data,
    })
  } catch (error) {
    return {
      redirect: {
        destination: "/course-not-found",
        permanent: false,
      },
    }
  }

  return {
    props: {
      initialReduxState: reduxStore.getState(),
      registrationFormURL,
    },
  }
}
