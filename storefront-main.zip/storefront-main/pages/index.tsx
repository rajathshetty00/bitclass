import { FC } from "react"

const HomePage: FC = () => {
  return (
    <>
      <div className="section_top_margin">
        <div className="flex items-center justify-center h-screen p-16 shadow"></div>
      </div>
    </>
  )
}

export default HomePage
