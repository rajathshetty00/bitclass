import React from "react"
import LaunchPadApplyNav from 'src/layouts/LaunchPadApply/LaunchPadApplyNav/LaunchPadApplyNav';
import AboutYourSelf from 'src/layouts/LaunchPadApply/AboutYourSelfForm/AboutYourSelfForm';

const Apply = () => {
  return (
    <div>
      <head>
        <title>
        Launchpad | Teach Online on BitClass
        </title>
      </head>
      <div className="sticky top-0 z-50">
        <LaunchPadApplyNav />
      </div>
      <div className="mt-12 z-10">
        <AboutYourSelf/>
      </div>
    </div>
  )
}

export default Apply