import HowLaunchPadWorks from "src/layouts/LaunchPad/HowLaunchPadWorks/HowLaunchPadWorks"
import JoinLaunchPad from "src/layouts/LaunchPad/JoinLaunchPad/JoinLaunchPad"
import LaunchPadNav from "src/layouts/LaunchPad/LaunchPadNav/LaunchPadNav"
import WhoIsItFor from "src/layouts/LaunchPad/WhoIsItFor/WhoIsItFor"
import LaunchPadTopBanner from "src/layouts/LaunchPad/AboutLaunchPad/AboutLaunchPad"
import Head from "next/head"
import { saveDataLayerData } from "utils/gtm"
import { BIT_EVENTS } from "utils/events"

export const handleJoinClicked = (source: string = "") => {
  saveDataLayerData({ event: BIT_EVENTS.joinLaunchPadClicked, source })
}
const LaunchPads = () => {
  return (
    <div>
      <Head>
        <title>Launchpad | Teach Online on BitClass</title>
      </Head>
      <div className="sticky top-0 z-50">
        <LaunchPadNav />
      </div>
      <div className="bg-lp-bg-pattern">
        <LaunchPadTopBanner />
        <div className="mb-32">
          <HowLaunchPadWorks />
        </div>
        <div className="mb-20">
          <WhoIsItFor />
        </div>
        <div className="mb-20">
          <JoinLaunchPad />
        </div>
      </div>
    </div>
  )
}

export default LaunchPads
