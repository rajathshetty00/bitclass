const initialState = { courseData: {} }
export const appReducer = (state = initialState, action) => {
  switch (action.type) {
    case "COURSE_DATA":
      return { ...state, courseData: action.payload }
    default:
      return state
  }
}
