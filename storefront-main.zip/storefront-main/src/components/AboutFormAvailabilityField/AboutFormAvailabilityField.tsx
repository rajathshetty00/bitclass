import { TypographyNew } from ".."


const AboutFormAvailabilityField = ({register,errors}) => {
  return (
    <div className="rounded md:w-60 lg:w-80 xl:flex xl:w-full">
    <TypographyNew className="mb-4 text-sm font-normal text-darkBlue lg:text-base">
      Availability for <br className="hidden xl:flex" /> Screening
      Call*
    </TypographyNew>
    <div>
      <div className="p-2 mb-1 border rounded-lg border-lavender_grey xl:w-384 xl:ml-32 xl:h-44">
        <input
          name="date"
          type="text"
          placeholder="DD-MM-YYYY"
          {...register("date", { required: true })}
          className="w-full bg-transparent outline-none focus:type-date"
        />
      </div>
      <div className="xl:ml-32">
        {errors?.date?.type === "required" && (
          <TypographyNew className="text-brick_red">
            This field is required
          </TypographyNew>
        )}
        {errors?.date?.type === "pattern" && (
          <TypographyNew className="text-brick_red">
            Enter in YYYY-MM-DD (EG:2021-09-06)
          </TypographyNew>
        )}
      </div>
    </div>
  </div>
  )
}

export default AboutFormAvailabilityField