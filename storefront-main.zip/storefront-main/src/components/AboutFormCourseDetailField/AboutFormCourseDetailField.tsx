import { AboutFormLabel, TypographyNew } from ".."


const AboutFieldCourseDetailField = ({register,errors}) => {
  return (
    <div className="mb-6 xl:flex">
    <div>
      <AboutFormLabel htmlFor="name">Course Details*</AboutFormLabel>
      <TypographyNew className="mt-1 text-xs font-normal text-darkBlue">
        Share about
        <br className="hidden xl:flex" /> your course curriculum
      </TypographyNew>
    </div>
    <div className="xl:flex xl:flex-col xl:ml-28">
      <div>
        <textarea
          name="pointer1"
          placeholder="Eg : Learn Technique of Warli Art"
          className="flex items-start w-full h-24 p-2 mt-3 text-sm font-normal border rounded-lg outline-none xl:w-384 border-lavender_grey"
          {...register("course_details.point1", {
            required: true,
            minLength: 20,
            maxLength: 200,
          })}
        />
        {errors?.course_details?.point1?.type === "required" && (
          <TypographyNew className="text-brick_red">
            This field is required
          </TypographyNew>
        )}
        {errors?.course_details?.point1?.type === "minLength" && (
          <TypographyNew className="text-brick_red">
            Please provide more details &#128522;
          </TypographyNew>
        )}
        {errors?.course_details?.point1?.type === "maxLength" && (
          <TypographyNew className="text-brick_red">
            Exceeding character limit
          </TypographyNew>
        )}
      </div>
    </div>
  </div>
  )
}

export default AboutFieldCourseDetailField