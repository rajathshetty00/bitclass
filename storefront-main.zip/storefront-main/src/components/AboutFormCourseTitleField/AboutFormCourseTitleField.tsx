import React from 'react'
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from '..'

const AboutFormCourseTitleField = ({register,errors}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel htmlFor="name"> Title of your Course*</AboutFormLabel>
    <div>
      <textarea
        name="course_name"
        placeholder="Eg : Learn Warli Painting | Indian Tribal Folk Art"
        className="flex items-start w-full h-24 p-2 mt-3 text-sm font-normal border rounded-lg outline-none xl:w-384 border-lavender_grey xl:mt-0 xl:ml-5.5"
        {...register("course_name", {
          required: true,
          minLength: 4,
          maxLength: 64,
        })}
      />
      <div className="xl:ml-5.5">
        {errors?.course_name?.type === "required" && (
          <TypographyNew className="text-brick_red">
            This field is required
          </TypographyNew>
        )}
        {errors?.course_name?.type === "minLength" && (
          <TypographyNew className="text-brick_red">
            Please provide more details &#128522;
          </TypographyNew>
        )}
        {errors?.course_name?.type === "maxLength" && (
          <TypographyNew className="text-brick_red">
            Exceeding character limit
          </TypographyNew>
        )}
      </div>
    </div>
  </AboutFormMainLayout>
  )
}

export default AboutFormCourseTitleField