import React from 'react'
import { BLACK_MAIL_ICON } from 'src/constants/constants'
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from '..'
import NextImage from '../Image/Image'

const AboutFormEmailField = ({register,errors}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel htmlFor="name">Email Address*</AboutFormLabel>
      <div>
        <div className="flex items-center w-full p-2 mt-3 border rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-32">
          <div className="flex mr-4">
            <NextImage
              src={BLACK_MAIL_ICON}
              width="20"
              height="20"
              objectFit="contain"
            />
          </div>
          <input
            type="text"
            name="email"
            {...register("email", {
              required: true,
              pattern:
                /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i,
            })}
            className="w-full text-sm font-normal outline-none"
            placeholder="Email Address"
          />
        </div>
        <div className="xl:ml-32">
          {errors?.email?.type === "required" && (
            <TypographyNew className="text-brick_red">
              This field is required
            </TypographyNew>
          )}
          {errors?.email?.type === "pattern" && (
            <TypographyNew className="text-brick_red">
              Enter a valid email
            </TypographyNew>
          )}
        </div>
      </div>
  </AboutFormMainLayout>
  )
}

export default AboutFormEmailField