import { FC, ReactNode } from "react"

interface IAboutFormLabel {
    htmlFor?:string,
    children?:ReactNode,
    className?:string
}

const AboutFormLabel:FC<IAboutFormLabel> = ({htmlFor,children,className}) => {
  return (
    <label
    htmlFor={htmlFor}
    className={className||"text-sm font-normal text-darkBlue lg:text-base"}
  >
    {children}
  </label>
  )
}

export default AboutFormLabel