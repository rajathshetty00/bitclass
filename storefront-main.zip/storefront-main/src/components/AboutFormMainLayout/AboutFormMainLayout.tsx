import { FC, ReactChild, ReactChildren, ReactNode } from "react";

interface IAboutFormLayout{
  children: ReactChild | ReactChild[] | ReactChildren | ReactChildren[],
  className?: string;
}

const AboutFormMainLayout:FC<IAboutFormLayout>= ({children,className}) => {
  return (
    <div className={`mt-4 mb-6`}>
      <div className="flex flex-col xl:flex-row">
        {children}
      </div>
    </div>
  );
}

export default AboutFormMainLayout
