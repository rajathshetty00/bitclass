import { AboutFormLabel, AboutFormMainLayout } from ".."


const AboutFormMaterialField = ({register}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel htmlFor="name" >Materials Required/
      <br />
      Pre-requisites</AboutFormLabel>
    <div>
      <div className="flex items-start w-full p-2 mt-3 mb-1 border rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-24 xl:flex-row">
        <input
          {...register("material_required")}
          className="w-full text-sm font-normal outline-none"
          placeholder="Enter course Material or Pre-requisites if required"
        />
      </div>
    </div>
</AboutFormMainLayout>
  )
}

export default AboutFormMaterialField