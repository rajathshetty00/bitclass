import React from 'react'
import { DEFAULT_FLAG } from 'src/constants/constants'
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from '..'
import NextImage from '../Image/Image'


const COUNTRY_CODE = [
    {
      name: "IND",
      code: "+91",
      flag: "",
    },
  ];

const AboutFormMobileField = ({register,errors}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel htmlFor="name">Whatsapp Number*</AboutFormLabel>
    <div className="flex xl:pl-2">
      <div className="flex items-center justify-around w-24 h-10 border rounded-lg border-lavender_grey xl:ml-20 xl:w-input_num">
        <NextImage
          src={DEFAULT_FLAG}
          width="20"
          height="20"
          objectFit="contain"
        />
        <select
          id="country"
          name="country_code"
          {...register("country_code", { required: true })}
          className="text-sm font-normal outline-none"
        >
          {COUNTRY_CODE.map((items) => (
            <option value={items.code} key={items.code}>
              {items.code}
            </option>
          ))}
        </select>
      </div>
      <div>
        <div className="flex items-start w-full p-2 ml-2 border rounded-lg border-lavender_grey w-60 lg:w-72">
          <input
            name="phone"
            {...register("phone", {
              required: true,
              maxLength: 10,
              minLength: 5,
              pattern: /^[0-9]+$/,
            })}
            className="w-full text-sm font-normal outline-none"
            placeholder="Whatsapp Number"
          />
        </div>
        <div className="xl:text-left xl:ml-2">
          {errors?.phone?.type === "required" && (
            <TypographyNew className="text-brick_red">
              This field is required
            </TypographyNew>
          )}
          {errors?.phone?.type === "maxLength" && (
            <TypographyNew className="text-brick_red">
              Number cannot exceed 10 characters
            </TypographyNew>
          )}
          {errors?.phone?.type === "minLength" && (
            <TypographyNew className="text-brick_red">
              Please provide more details &#128522;
            </TypographyNew>
          )}
          {errors?.phone?.type === "pattern" && (
            <TypographyNew className="text-brick_red">
              Please enter a valid number
            </TypographyNew>
          )}
        </div>
      </div>
    </div>
</AboutFormMainLayout>
  )
}

export default AboutFormMobileField