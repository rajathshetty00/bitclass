import { USER_ICON } from "src/constants/constants"
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from ".."
import NextImage from "../Image/Image"

const AboutFormNameField = ({register,errors}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel htmlFor="name">Full Name*</AboutFormLabel>
    <div>
      <div className="flex items-start w-full p-2 mt-3 mb-1 border rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-40 xl:flex-row">
        <div className="flex mr-4">
          <NextImage
            src={USER_ICON}
            width="18"
            height="18"
            objectFit="contain"
          />
        </div>
        <input
          {...register("name", {
            required: true,
            maxLength: 25,
            pattern: /^[a-zA-Z ]+$/,
          })}
          className="w-full text-sm font-normal outline-none"
          placeholder="Full Name"
        />
      </div>
      <div className="xl:ml-40">
        {errors?.name?.type === "required" && (
          <TypographyNew className="text-brick_red">
            This field is required
          </TypographyNew>
        )}
        {errors?.name?.type === "maxLength" && (
          <TypographyNew className="text-brick_red">
            First name cannot exceed 25 characters
          </TypographyNew>
        )}
        {errors?.name?.type === "pattern" && (
          <TypographyNew className="text-brick_red">
            Alphabetical characters only
          </TypographyNew>
        )}
      </div>
    </div>
</AboutFormMainLayout>
  )
}

export default AboutFormNameField