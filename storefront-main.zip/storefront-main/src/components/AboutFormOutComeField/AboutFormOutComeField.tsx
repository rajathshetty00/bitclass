import { USER_ICON } from "src/constants/constants"
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from ".."
import NextImage from "../Image/Image"

const AboutFormOutComeField = ({register,errors}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel htmlFor="name">Outcome/Takeaway*</AboutFormLabel>
    <div>
      <div className="flex items-start w-full p-2 mt-3 mb-1 border rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-20 xl:flex-row">
        <input
          {...register("outcome",{ required: true})
          }
          className="w-full text-sm font-normal outline-none"
          placeholder="Enter outcome or takeaway"
        />
      </div>
      <div className="xl:ml-20">
          {errors?.outcome?.type === "required" && (
            <TypographyNew className="text-brick_red">
              This field is required
            </TypographyNew>
          )}
          
        </div>
    </div>
</AboutFormMainLayout>
  )
}

export default AboutFormOutComeField