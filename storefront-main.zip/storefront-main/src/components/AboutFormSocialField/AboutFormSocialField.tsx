import { AboutFormLabel, AboutFormMainLayout } from ".."

const AboutFormSocialField = ({register}) => {
  return (
    <AboutFormMainLayout>
                <AboutFormLabel htmlFor="name"  >Social Media Link&nbsp; </AboutFormLabel>
                <div>
                  <div className="flex items-start w-full p-2 mt-3 mb-1 border rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-28 xl:flex-row">
                    <input
                      {...register("social_link")}
                      className="w-full text-sm font-normal outline-none"
                      placeholder="Enter your social media link"
                    />
                  </div>
                </div>
            </AboutFormMainLayout>
  )
}

export default AboutFormSocialField