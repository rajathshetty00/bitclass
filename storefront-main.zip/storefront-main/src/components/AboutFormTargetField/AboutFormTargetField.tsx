import { checkboxConfig } from "src/constants/constants"
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from ".."
import BitCheckbox from "../BitCheckbox/BitCheckbox"


const AboutFormTargetField = ({register,errors}) => {
  return (
    <AboutFormMainLayout>
    <AboutFormLabel >Target Audience*</AboutFormLabel>
    <div className="flex  flex-wrap items-start w-full p-2 mt-3 mb-1 rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-24 xl:flex-col ">
      {checkboxConfig.map((checkbox) => (
        <BitCheckbox
          key={checkbox.value}
          label={checkbox.label}
          value={checkbox.value}
          register={register}
        />
      ))}
    <div>
          {errors?.target_audience?.type === "validate" && (
            <TypographyNew className="text-brick_red">
              You much select at least one target audience
            </TypographyNew>
          )}
        </div>
    </div>
</AboutFormMainLayout>
  )
}

export default AboutFormTargetField