import { radioInputConfig } from "src/constants/constants"
import { AboutFormLabel, AboutFormMainLayout, TypographyNew } from ".."
import BitRadioInput from "../BitRadioInput/BitRadioInput"


const AboutFormTeachingField = ({register,errors}) => {
  return (
    <div>
    <AboutFormMainLayout>
    <AboutFormLabel >Teaching Experience*</AboutFormLabel>
    <div className="flex flex-wrap items-start w-full p-1 mt-3 mb-1 rounded-lg border-lavender_grey lg:w-96 xl:mt-0 xl:w-384 xl:ml-20 xl:flex-col ">
      {radioInputConfig.map((radio) => (
        <BitRadioInput
          key={radio.label}
          {...radio}
          register={register}
        />
      ))}
    <div className="xd:w-full">
          {errors?.teaching_experience?.type === "required" && (
            <TypographyNew className="text-brick_red">
              Please select your teaching experience
            </TypographyNew>
          )}
        </div>
    </div>
    
</AboutFormMainLayout>

</div>
  )
}

export default AboutFormTeachingField