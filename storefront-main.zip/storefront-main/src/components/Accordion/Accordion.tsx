import Image from "next/image"
import { useState } from "react"
import { ICONS } from "utils/icons"
import Button from "../Button/Button"
import Typography from "../Typography/Typography"

interface IProps {
  title: string
  description: string
}
const Accordion = ({ title, description }: IProps) => {
  const [showDetails, setShowDetails] = useState(false)
  const toggleAccordion = () => {
    // @ts-ignore
    dataLayer.push({
      event: "faq-clicked",
      accordionData: {
        title,
        description,
        status: showDetails,
      },
    })
    setShowDetails(!showDetails)
  }
  return (
    <>
      <Button
        className="flex items-start w-full p-6 mb-3 bg-white rounded-lg md:p-8 accordionShadow md:w-6/12"
        onClick={toggleAccordion}
        id="accordion"
      >
        <div className="min-w-max" id="accordion">
          <Image
            src={showDetails ? ICONS.minusRed : ICONS.plus}
            width="23"
            height="23"
          />
        </div>
        <div className="ml-4 text-left" id="accordion">
          <span
            className="text-base text-left md:text-xl text-darkBlue md:max-w-xl"
            id="accordion"
          >
            {title}
          </span>
          {showDetails && (
            <Typography
              text={description}
              className="pt-4 text-lg font-light text-darkBlue"
            />
          )}
        </div>
      </Button>
    </>
  )
}

export default Accordion
