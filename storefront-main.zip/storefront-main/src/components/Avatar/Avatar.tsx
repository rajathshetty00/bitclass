import NextImage from "../Image/Image"

interface Props {
  src: string
}
export default function Avatar({ src }: Props) {
  return (
    <NextImage
      src={src}
      alt="avatar"
      width="63px"
      height="63px"
      quality="100"
      className="bg-cover rounded-full"
    />
  )
}
