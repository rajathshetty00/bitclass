import { BACK_ICON } from "src/constants/constants"
import { BIT_EVENTS } from "utils/events"
import { saveDataLayerData } from "utils/gtm"
import NextImage from "../Image/Image"
import Link from "next/link";


const BackButton = () => {
  return (
    <div className="m-auto md:w-6/12 lg:m-0">
          <Link href="/launchpad">
            <NextImage
              src={BACK_ICON}
              alt="bitlogo"
              width="24"
              height="24"
              className="cursor-pointer"
              objectFit="contain"
              onClick={() =>
                saveDataLayerData({ event: BIT_EVENTS.backBtnClicked })
              }
            />
          </Link>
    </div>
  )
}

export default BackButton