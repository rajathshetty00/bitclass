const validateAudience =(selectedAudience)=>{
  if (!selectedAudience||selectedAudience.length ===0) return false;
}
const BitCheckbox = ({label,value,register}) => {
  return (
    <label className="custom-label text-sm font-normal text-darkBlue lg:text-base  flex p-2 cursor-pointer">
                    <div className="bg-white shadow w-4 h-4 flex  border-gray-400 focus:border-raisin  focus:ring-2 checked:bg-red-600 focus:ring-black text-green-600 justify-center items-center mr-2 border " >
                      <input type="checkbox" className="hidden" value={value}  {...register("target_audience",{
    validate: validateAudience })} />
                      <svg className="hidden w-4 h-4 text-red pointer-events-none rounded border-gray-400 " viewBox="0 0 172 172"><g fill="none" stroke-width="none" stroke-miterlimit="10" font-family="none" font-weight="none" font-size="none" text-anchor="none" style={{ mixBlendMode: 'normal' }} ><path d="M0 172V0h172v172z" /><path d="M145.433 37.933L64.5 118.8658 33.7337 88.0996l-10.134 10.1341L64.5 139.1341l91.067-91.067z" fill="currentColor" stroke-width="1" /></g></svg>
                    </div>
                    <span className="select-none">{label}</span>
    </label>
  )
}

export default BitCheckbox