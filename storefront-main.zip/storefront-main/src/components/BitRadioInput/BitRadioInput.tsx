import React from 'react'

const BitRadioInput = ({id,name,value,label,register}) => {
  return (
    <div className="flex items-center mr-4 mb-4">
    <input id={id} type="radio" name={name} className="hidden" value={value} {...register("teaching_experience",{required: true})}   />
    <label htmlFor={id} className="font-normal gap-1 text-sm font-normal text-darkBlue lg:text-base  flex items-center cursor-pointer">
      <span className="w-4 h-4 inline-block mr-1 rounded-full border border-grey"></span>
     {label}</label>
  </div>
  )
}

export default BitRadioInput