import { IButton } from "src/interfaces/buttonInterface"

const Button = ({
  children,
  rightIcon,
  className = "",
  onClick,
  ...props
}: IButton) => {
  return (
    <button
      onClick={onClick}
      className={`text-white text-xs md:text-lg focus:outline-none ${className}`}
      {...props}
    >
      {rightIcon}
      {children}
    </button>
  )
}

export default Button
