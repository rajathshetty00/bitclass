import { ReactChild, ReactChildren } from "react"

interface Props {
  children: ReactChild | ReactChild[] | ReactChildren | ReactChildren[]
  className?: string
}
const Container = ({children,className}:Props) => {
  return <div className={`py-10 md:py-20 px-11 md:px-24 2xl:px-auto ${className}`}>{children}</div>
}

export default Container
