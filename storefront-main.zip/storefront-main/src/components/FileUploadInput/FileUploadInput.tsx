import { useState } from "react"
import TypographyNew from "src/components/TypographyNew"
import NextImage from "@/components/Image/Image"
import { useRef } from "react"
import {
  UPLOAD_ICON,
  EDIT_ICON,
  VIDEO_ICON,
  CHANGE_ICON,
  POSTER_URL,
  CLOUDINARY_CONFIG,
} from "src/constants/constants"

interface IProps {
  file?: string
  setUrl?: React.Dispatch<React.SetStateAction<string>>
}

const FileUploadInput = ({ setUrl }: IProps) => {
  const video = useRef(null)
  const [preview_video, setPreviewVideo] = useState(false)
  const [video_link, setVideoLink] = useState(null)
  const [remove_video, setRemoveVideo] = useState(false)
  const [show_play, setShowPlay] = useState(false)
  const [control, setControl] = useState(false)

  const cloudinaryAfterUpload = (err, res) => {
    // set error handling here for file sizes
    setShowPlay(true)
    setPreviewVideo(true)
    setRemoveVideo(true)
    setVideoLink(res[0].url)
    setUrl(res[0].url)
  }

  const onUploadVideo = () => {
    try {
      // @ts-ignore
      window.openCloudinaryWidget(
        {
          ...CLOUDINARY_CONFIG,
          multiple: false,
          resource_type: "video",
        },
        cloudinaryAfterUpload
      )
    } catch (error) {}
  }

  const onRemoveVideo = () => {
    setRemoveVideo(true)
    setPreviewVideo(false)
    setVideoLink("")
  }

  const onShowPlay = () => {
    setShowPlay(false)
    setControl(true)
    video.current.play()
  }

  const onChangeVideo = () => {
    onUploadVideo()
  }

  return (
    <div className="xl:flex">
      <div className="xl:w-40">
        <TypographyNew className="mb-2 text-sm font-normal">
          Video Introduction <br className="hidden xl:flex"/>( Recommended &#128578; )
        </TypographyNew>
        <TypographyNew className="mb-4 text-xs font-normal">
          Please record a 30 second video introducing yourself
        </TypographyNew>
      </div>
      <div className="xl:ml-90"> 
      {!preview_video ? (
        <label
          onClick={onUploadVideo}
          className="flex flex-col items-center w-full px-4 py-6 tracking-wide text-purple-600 
          uppercase transition-all duration-150 ease-linear border border-dashed rounded-md 
          cursor-pointer bg-magnolia border-lavender_grey 
          hover:bg-purple-600 hover:text-white xl:w-384"
        >
          <i className="fas fa-cloud-upload-alt fa-3x"></i>
          <NextImage src={UPLOAD_ICON} width="32" height="24" />
          <span className="mt-2 text-xs font-normal text-echo_blue">
            Choose File
          </span>
          <div></div>
        </label>
      ) : (
        <>
          <div className="relative">
            <video
              ref={video}
              width="400"
              height="300"
              className="rounded-lg"
              poster={POSTER_URL}
              controls={control}
            >
              <source src={video_link} />
            </video>
            {show_play && (
              <div
                className="absolute cursor-pointer top-2/4 left-2/4 -translate-y-2/4 -translate-x-2/4"
                onClick={onShowPlay}
              >
                <div className="block xl:hidden">
                  <NextImage src={VIDEO_ICON} width="50" height="50" />
                </div>
                <div className="hidden xl:block">
                  <NextImage src={VIDEO_ICON} width="80" height="80" />
                </div>
              </div>
            )}
          </div>
          {remove_video ? (
            <div className="flex">
              <div className="flex mt-3 cursor-pointer" onClick={onRemoveVideo}>
                <NextImage
                  src={EDIT_ICON}
                  width="20"
                  height="10"
                  alt="edit icon"
                  objectFit="contain"
                />
                <TypographyNew className="ml-2 text-base font-medium">
                  Remove Video
                </TypographyNew>
              </div>
              <div
                className="flex mt-3 ml-3 cursor-pointer"
                onClick={onChangeVideo}
              >
                <NextImage
                  src={CHANGE_ICON}
                  width="20"
                  height="10"
                  alt="edit icon"
                  objectFit="contain"
                />
                <TypographyNew className="ml-2 text-base font-medium">
                  Change Video
                </TypographyNew>
              </div>
            </div>
          ) : null}
        </>
      )}
      </div>
      
    </div>
  )
}

export default FileUploadInput
