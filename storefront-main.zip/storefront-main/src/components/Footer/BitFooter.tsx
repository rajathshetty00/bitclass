/* eslint-disable react/jsx-one-expression-per-line */
import NextImage from 'src/components/NextImage/NextImage';
import Socials from 'src/components/Socials/Socials';
import Link from 'next/link';
import { BASE_URL, ROOT_URL } from 'utils/constants';
import { Mail } from 'react-feather';


import { LOGO } from 'utils/logo/logo';
import styles from './footer.module.css';

const SEARCH_LINKS = [
  { name: 'Arts', link: `${ROOT_URL}/search-result-page?q=art` },
  { name: 'Music', link: `${ROOT_URL}/search-result-page?q=music` },
  { name: 'Dance', link: `${ROOT_URL}/search-result-page?q=dance` },
  { name: 'Crypto', link: `${ROOT_URL}/search-result-page?q=crypto` },
  { name: 'Baking', link: `${ROOT_URL}/search-result-page?q=baking` },
  { name: 'Health', link: `${ROOT_URL}/search-result-page?q=Health` },
];
const BLOG_URL = 'https://blog.bitclass.live/';
const BitLogo='https://res.cloudinary.com/bitclass/image/upload/v1643685201/Logos/LogoForWhiteBg_jsuxze.svg';
const EmailIcon ='https://res.cloudinary.com/bitclass/image/upload/v1630151618/Assets/Launchpad/mail_giwjua.svg';

const CURRENT_YEAR = new Date().getFullYear();

const BitFooter = () => (
  <div className={styles.footer}>
    <div className={styles.footerAbout}>
      <div className={styles.details}>
        <NextImage
          src={BitLogo}
          width={160}
          height={64}
          objectFit="contain"
        />
        <p>
          BitClass helps individual teachers, trainers and coaches setup and
          grow their online live teaching business successfully.
        </p>
        <Socials />
      </div>
      <div className={styles.copyright}>
        Livestream Infra Technologies Pvt Ltd © {CURRENT_YEAR}
      </div>
    </div>
    {/* pages */}
    <div className={styles.pagesSearchesContainer}>
      <div className={styles.footerPage}>
        <h3>Useful Links</h3>
        <div className={styles.links}>
          <a href={BASE_URL}>Home</a>
          <a href={`${BASE_URL}/about`}>About</a>
          <a href={`${BASE_URL}/contact`}>Contact</a>
          <a href={`${BASE_URL}/careers`}>Careers</a>
          <a href={`${BASE_URL}/n/launchpad`}>Teach On BitClass</a>
          <a href={BLOG_URL}>Blog</a>
          <a href={`${BASE_URL}/live-classes/policy`}>Policy</a>
          <a href={`${BASE_URL}/live-classes/n/faq`}>FAQs</a>
          <a href={`${BASE_URL}/live-classes/terms`}>Terms & Conditions</a>
        </div>
      </div>
      <div className={styles.popularSearches}>
        <h3>Popular Searches</h3>
        <div className={styles.links}>
          {SEARCH_LINKS.map((item) => (
            <Link href={item?.link} key={item?.link}>
              {item?.name}
            </Link>
          ))}
        </div>
      </div>
    </div>
    <div className={styles.contact}>
      <h3>Contact Us</h3>
      <div className={styles.footerContacts}>
        <p className={styles.footerContactsHeading}>For Students</p>
        <div className={styles.footerContactDiv}>
          <Mail style={{width:'20px',marginRight:'5px'}} />
          <p>
            <a href="mailto:hello@bitclass.live">hello@bitclass.live</a>
          </p>
        </div>
        <p className={styles.footerContactsHeading}>For Teachers</p>
        <div className={styles.footerContactDiv}>
        <Mail style={{width:'20px',marginRight:'5px'}} />
          <p>
            <a href="mailto:teachers@bitclass.live">teachers@bitclass.live</a>
          </p>
        </div>
      </div>
    </div>
  </div>
);

export default BitFooter;
