import { ROOT_URL } from 'utils/constants';

const SEARCH_LINKS = [
  { name: 'Arts', link: `${ROOT_URL}/search-result-page?q=art` },
  { name: 'Music', link: `${ROOT_URL}/search-result-page?q=music` },
  { name: 'Dance', link: `${ROOT_URL}/search-result-page?q=dance` },
  { name: 'Crypto', link: `${ROOT_URL}/search-result-page?q=crypto` },
  { name: 'Baking', link: `${ROOT_URL}/search-result-page?q=baking` },
  { name: 'Health', link: `${ROOT_URL}/search-result-page?q=Health` },
];

const SOCIAL_LINKS = [
  // {
  //   Icon: LinkedInIcon,
  //   link: 'https://www.linkedin.com/company/bitclass-live/',
  // },
  // {
  //   Icon: FacebookIcon,
  //   link: 'https://www.facebook.com/Bitclasscommunity',
  // },
  // {
  //   Icon: InstagramIcon,
  //   link: 'https://www.instagram.com/bitclass/',
  // },
  // {
  //   Icon: TwitterIcon,
  //   link: 'https://twitter.com/bitclass_live',
  // },
];

const footerData = { SOCIAL_LINKS, SEARCH_LINKS };
export default footerData;
