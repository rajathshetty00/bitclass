import Image, { ImageLoaderProps, ImageProps } from "next/image"
import { optimizeImage } from "utils"
const NextImage = (props: ImageProps) => {
  return <Image loader={optimizeImage} className={props.className} {...props} />
}

export default NextImage
