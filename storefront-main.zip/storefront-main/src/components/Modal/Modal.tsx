import React from "react"

export default function BitModal({
  children,
  showModal,
  setShowModal,
  bodyStyle = "",
}) {
  return (
    <>
      {showModal ? (
        <>
          <div
            className="fixed inset-0 z-50 flex items-center justify-center overflow-x-hidden overflow-y-auto outline-none focus:outline-none bg-modalOverlay"
            id="modal"
          >
            <div className="relative my-6 rounded md:mx-auto md:w-4/6">
              {/*content*/}
              <div
                className={`relative flex flex-col w-full bg-white border-0 rounded-lg shadow-lg outline-none focus:outline-none ${bodyStyle}`}
              >
                {children}
              </div>
            </div>
          </div>
        </>
      ) : null}
    </>
  )
}
