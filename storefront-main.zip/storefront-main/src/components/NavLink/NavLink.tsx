import { FC } from "react"

interface IProps {
  navData: {
    name: string
    link: string
  }
}
const NavLink: FC<IProps> = ({ navData }) => {
  const { name, link } = navData
  const handleNavLinkClicked = () => {
    // @ts-ignore
    dataLayer.push({ section: name })
  }

  return (
    <div className="px-2 cursor-pointer" id="nav-item">
      <a href={link} id="nav-item" onClick={handleNavLinkClicked}>
        {" "}
        <span
          className="text-xs font-semibold md:font-medium md:text-base text-primaryGreen md:text-darkBlue"
          id="nav-item"
        >
          {name}
        </span>
      </a>
    </div>
  )
}

export default NavLink
