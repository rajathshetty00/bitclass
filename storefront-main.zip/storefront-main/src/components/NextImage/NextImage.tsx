import { FC } from 'react';
import Image from 'next/image';
import { optimizeCloudinaryImage } from 'utils';


const NextImage = ({ src, ...props }) => (
  <Image
    src={src}
    loader={optimizeCloudinaryImage}
    // unoptimized
    {...props}
  />
);

export default NextImage;
