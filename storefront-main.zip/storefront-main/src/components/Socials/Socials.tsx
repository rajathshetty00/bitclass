import Link from 'next/link';
import SOCIAL_DATA from 'src/components/Socials/socialData';
import NextImage from '../NextImage/NextImage';
import styles from './styles.module.css';

const Socials = () => (
  <div className={styles.social}>
    {SOCIAL_DATA.map(({ name, link, Icon }) => (
      <Link href={link} key={name}>
        <Icon />
      </Link>
    ))}
  </div>
);

export default Socials;
