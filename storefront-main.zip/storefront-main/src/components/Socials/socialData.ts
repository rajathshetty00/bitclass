import { Linkedin,Twitter,Facebook,Instagram } from 'react-feather';

const SOCIAL_DATA = [
  {
    name: 'linkedIn',
    link: 'https://www.linkedin.com/company/bitclass-live/',
    Icon: Linkedin,
  },
  {
    name: 'facebook',
    link: 'https://www.facebook.com/Bitclasscommunity',
    Icon: Facebook,
  },
  {
    name: 'instagram',
    link: 'https://www.instagram.com/bitclass/',
    Icon: Instagram,
  },
  {
    name: 'twitter',
    link: 'https://twitter.com/bitclass_live',
    Icon: Twitter,
  },
];

export default SOCIAL_DATA;
