import NextImage from "@/components/Image/Image"
import TypographyNew from "src/components/TypographyNew"

interface IProps {
  card_details: {
    id: any
    image_url: string
    title: string
    description: string
  }
}

const StepDetailedCard = ({ card_details }: IProps) => {
  return (
    <>
      <div className="w-36 md:w-56 xl:w-64">
        <div className="relative">
          <NextImage
            src={card_details.image_url}
            width="110"
            height="100"
            alt="learner"
          objectFit="contain"

          />
          <TypographyNew className="absolute left-0 inline text-4xl font-light text-white top-20">
            {card_details.id}
          </TypographyNew>
        </div>
        <TypographyNew className="mt-8 text-lg font-medium text-white xl:text-2xl">
          {card_details.title}
        </TypographyNew>
        <TypographyNew className="mt-2 text-sm font-normal text-acadia xl:text-xl">
          {card_details.description}
        </TypographyNew>
      </div>
    </>
  )
}

export default StepDetailedCard
