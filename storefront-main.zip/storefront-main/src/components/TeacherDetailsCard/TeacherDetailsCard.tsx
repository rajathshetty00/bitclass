import TypographyNew from "@/components/TypographyNew";
import NextImage from "@/components/Image/Image"
import {COURSE_ICON , STAR_ICON} from 'src/constants/constants';

interface IProps {
  details: {
    name: string;
    profession:string;
    rating:number;
    courses:number;
    image_url:string;
  }
}

const TeacherDetailsCard = ({details}:IProps)=> {

  
  return (
    <div className="bg-white w-96 h-120 rounded flex">
      <div className="w-4/12">
        <NextImage 
        src={details.image_url}
        width="200"
        height="190"
        objectFit="fill"
        className="rounnded"
        />
      </div>
      <div className="w-8/12 p-4">
      <TypographyNew className="text-darkBlue font-semibold text-base mb-2">{details.name}</TypographyNew>
      <TypographyNew className="text-slate_grey font-light text-sm">{details.profession}</TypographyNew>
      <div className="flex mt-5">
      <div className="flex items-center">
        <NextImage
          src={STAR_ICON}
          width="18"
          height="18"
        />
        <TypographyNew className="ml-2">
          {details.rating}
        </TypographyNew>
      </div>
      <div className="flex items-center ml-8">
        <NextImage
          src={COURSE_ICON}
          width="12"
          height="16"
        />
        <TypographyNew className="ml-2">
          {details.courses}
        </TypographyNew>
      </div>
      </div>
      </div>
    </div>
  )
}

export default TeacherDetailsCard;