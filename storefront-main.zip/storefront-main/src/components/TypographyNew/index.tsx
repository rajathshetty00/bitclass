interface Props {
  children: React.ReactNode,
  className?: string,
}

const TypographyNew = ({ children,className }: Props) => {
  return (
    <div className={`${className}`}>
      {children}
    </div>
  )
}

export default TypographyNew
