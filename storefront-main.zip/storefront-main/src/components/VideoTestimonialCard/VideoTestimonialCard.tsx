import { useState } from "react"
import TypographyNew from "src/components/TypographyNew"
import NextImage from "@/components/Image/Image"
import { useRef } from "react"
import { VIDEO_ICON } from "src/constants/constants"
import { saveDataLayerData } from "utils/gtm"
import { BIT_EVENTS } from "utils/events"

interface IProps {
  card_details: {
    profession: string
    teacher_name: string
    thumbnail_url: string
    video_link: string
  }
}

const VideoTestimonialCard = ({ card_details }: IProps) => {
  const video = useRef(null)
  const { profession, teacher_name, thumbnail_url, video_link } = card_details

  const [show_controls, setShowControls] = useState(false)
  const [show_play, setshowPlay] = useState(true)

  const onClickPlayBtn = () => {
    saveDataLayerData({
      event: BIT_EVENTS.videoActionClicked,
      videoData: {
        action: "play",
        video_page_source: "launchpad",
        video_type: "teacher",
        duration: video?.current?.duration,
      },
    })
    setShowControls(true)
    setshowPlay(false)
    video.current.play()
  }

  const handleVideoInteraction = (e: any) => {
    saveDataLayerData({
      event: BIT_EVENTS.videoActionClicked,
      source: "launchpad",
      videoData: {
        action: e?.type,
        video_page_source: "launchpad",
        video_type: "teacher",
        duration: video?.current?.duration,
      },
    })
  }

  return (
    <>
      <div className="relative w-56 rounded-lg h-72 bg-darkBlue xl:w-420 xl:h-540">
        <video
          ref={video}
          controls={show_controls}
          width="800"
          height="400"
          poster={thumbnail_url}
          onPause={handleVideoInteraction}
          onPlay={handleVideoInteraction}
          className="h-full bg-yellow-100 rounded-lg"
        >
          <source src={video_link} type="video/mp4" />
        </video>
        {show_play && (
          <div
            className="absolute cursor-pointer top-2/4 left-2/4 -translate-y-2/4 -translate-x-2/4"
            onClick={onClickPlayBtn}
          >
            <div className="block xl:hidden">
              <NextImage src={VIDEO_ICON} width="50" height="50" />
            </div>
            <div className="hidden xl:block">
              <NextImage src={VIDEO_ICON} width="80" height="80" />
            </div>
          </div>
        )}
      </div>
      <div className="mt-2 text-left lg:mt-4">
        <TypographyNew className="text-xl font-semibold text-white lg:text-2xl">
          {teacher_name}
        </TypographyNew>
        <TypographyNew className="mt-1 text-sm font-normal text-acadia lg:text-base">
          {profession}
        </TypographyNew>
      </div>
    </>
  )
}

export default VideoTestimonialCard
