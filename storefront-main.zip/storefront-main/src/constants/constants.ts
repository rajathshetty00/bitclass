export const CLOUDINARY_CONFIG = {
  cloud_name: "bitclass",
  upload_preset: "jp936t7u",
  folder: "BitClass",
  sources: ["local", "url"],
  showUploadMoreButton: false,
}

// IMAGES-ICONS URLS
export const UPLOAD_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630446276/Assets/Launchpad/Vector_mphqdw.svg"
  export  const EDIT_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630442350/Assets/Launchpad/red_delete_gpadsg.svg"
  export  const VIDEO_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630309588/Assets/Launchpad/Group_1146_zbq4me.svg"
  export  const CHANGE_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630442349/Assets/Launchpad/Pen_kuyvvk.svg"
  export  const POSTER_URL =
  "https://res.cloudinary.com/bitclass/image/upload/v1630572140/Assets/Launchpad/Screenshot_2021-09-02_at_2.11.55_PM_sq3gu2.png"
  export const COURSE_ICON='https://res.cloudinary.com/bitclass/image/upload/v1630504350/Assets/Launchpad/Vector_2_lyusk0.svg';
  export const STAR_ICON="https://res.cloudinary.com/bitclass/image/upload/v1630500428/Assets/Launchpad/Vector_1_jjv5du.svg"


export const LAUNCH_PAD_LOGO ="https://res.cloudinary.com/bitclass/image/upload/v1630237250/Assets/Launchpad/teacher_launchpad_o5ae1b.svg"
export const BIT_CLASS_LOGO = "https://res.cloudinary.com/bitclass/image/upload/v1630151336/Assets/Launchpad/BitClass_Logo_qbbouv.svg" 

export const DESKTOP_LAUNCH_PAD_LOGO = "https://res.cloudinary.com/bitclass/image/upload/v1630151336/Assets/Launchpad/launchpad_logo_nn5ri5.svg"

export const LEARNER="https://res.cloudinary.com/bitclass/image/upload/v1630151925/Assets/Launchpad/1Mn_Learnings_yh5veg.svg"
export const TEACHERS="https://res.cloudinary.com/bitclass/image/upload/v1630151924/Assets/Launchpad/6400_teachers_bvtjl3.svg"
export const COHORTS="https://res.cloudinary.com/bitclass/image/upload/v1630151924/Assets/Launchpad/2500_cohorts_tgsqyb.svg"
export const MADE_BY="https://res.cloudinary.com/bitclass/image/upload/v1630151924/Assets/Launchpad/2_5_crores_m3irot.svg"

export const LEFT_ARROW = "https://res.cloudinary.com/bitclass/image/upload/v1630326741/Assets/Launchpad/left-arrow_xux96c.svg";
export const RIGHT_ARROW = "https://res.cloudinary.com/bitclass/image/upload/v1630326741/Assets/Launchpad/right_arrow_bqysm5.svg"
;

export const PEOPLE_ENJOYING = "https://res.cloudinary.com/bitclass/image/upload/v1630151337/Assets/Launchpad/who_is_it_for_vczsp5.svg";

export const BACK_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630438614/Assets/Launchpad/Group_687_trwefp.svg"
export const USER_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630442351/Assets/Launchpad/user_zyznqo.svg"
export const BLACK_MAIL_ICON =
  "https://res.cloudinary.com/bitclass/image/upload/v1630442349/Assets/Launchpad/black_mail_icon_et6yqo.svg"
export const DEFAULT_FLAG =
  "https://res.cloudinary.com/bitclass/image/upload/v1630447922/Assets/Launchpad/image_21371_pa7n7d.svg"

 export  const BIT_LOGO =
  "https://res.cloudinary.com/bitclass/image/upload/v1630438120/Assets/Launchpad/Left_Nav_cvkji8.svg"
export const  radioInputConfig = [
  {
    id: "radio1",
    name: "target_audience",
    value: "no_experience",
    label: "No Experience",
  },
  {
    id: "radio2",
    name: "target_audience",
    value: "only_offline",
    label: "Only Offline",
  },
  {
    id: "radio3",
    name: "target_audience",
    value: "only_online",
    label: "Only Online",
  },
  {
    id: "radio4",
    name: "target_audience",
    value: "both",
    label: "Both (Offline+Online)",
  },
];

export const checkboxConfig = [
  { label: "Kids", value: "kids" },
  { label: "Home Makers", value: "home_makers" },
  { label: "College Students", value: "college_students" },
  { label: "Working Professionals", value: "working_professionals" },
];
