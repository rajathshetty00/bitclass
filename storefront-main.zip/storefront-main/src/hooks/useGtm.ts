import { useEffect } from "react"
import { useRouter } from "next/dist/client/router"
import { getPageEventData } from "utils/gtm"
import { getHVCdata } from "utils/courseAnalytics"

export const useGtm = (store) => {
  const router = useRouter()
  const _pathName = router.pathname

  useEffect(() => {
    const { page, eventName } = getPageEventData(_pathName)
    if (page === "high-value") {
      const courseData = getHVCdata({
        ...store.getState().courseData,
        code: router.query.highValueCdp,
      })
      // @ts-ignore
      dataLayer.push({
        course: courseData,
      })
    }

    // @ts-ignore
    dataLayer.push({
      page,
      eventName,
    })
  }, [])
  return
}
