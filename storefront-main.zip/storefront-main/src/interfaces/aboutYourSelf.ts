export interface IFormInput {
    name: string;
    country_code: string;
    phone: number;
    email: string;
    course_name: string;
    course_details: {
      point1: string;
    };
    outcome: string;
    teaching_experience: "";
    target_audience: [];
    social_link: string;
    material_required: string;
    date: string;
  }