import { ReactChild, ReactChildren } from "react"

export interface IButton {
  children: ReactChild | ReactChild[] | ReactChildren | ReactChildren[]
  onClick?: (event) => void
  className?: string
  rightIcon?: any
  id?: string
}
