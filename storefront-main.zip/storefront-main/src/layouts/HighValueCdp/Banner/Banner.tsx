import Button from "@/components/Button/Button"
import Typography from "@/components/Typography/Typography"
import Avatar from "@/components/Avatar/Avatar"
import { useSelector } from "react-redux"
import { optimizeImage } from "utils"
import NextImage from "@/components/Image/Image"

const _playIconWhite =
  "https://res.cloudinary.com/bitclass/image/upload/v1629453393/Assets/empty-image/playButtonWhite_l07ghh.svg"
const liveIcon = (
  <NextImage
    src="https://res.cloudinary.com/bitclass/image/upload/v1630657402/Assets/HVC/redLive_e6nvs6.svg"
    alt=""
    width="22"
    height="15"
  />
)

const _getBannerImageStyle = (image) => ({
  backgroundImage: `url(${optimizeImage(
    {
      src: image,
      width: 640,
    }
  )})`,
  // backgroundSize: "contain",
})
const _getMobileBannerImageStyle = (image) => ({
  backgroundImage: `linear-gradient(0deg, rgba(3, 7, 18, .95) 55%, rgba(3, 7, 18, 0) 100%), url(${optimizeImage(
    {
      src: image,
      width: 640,
    }
  )})`,
  // backgroundSize: "contain",
})

const Banner = ({ setShowModal }) => {
  const state = useSelector((state: any) => state.courseData)
  return (
    <div className="grid w-screen grid-cols-1 text-white md:pr-0 bg-darkBlue justify-items-center md:grid md:grid-cols-2 md:px-24 md:gap-x-8 bannerShadow ">
      <div
        className="relative pb-16 cursor-pointer md:order-2 md:pb-0 md:w-full bannerBg"
        style={_getBannerImageStyle(state.intro_video_thumbnail)}
      >
        <div
          className="absolute pt-4 top-1/3 left-1/2"
          onClick={() => setShowModal(true)}
          id="hvc-video"
        >
          <NextImage
            src={_playIconWhite}
            alt=""
            width="66"
            height="66"
            id="hvc-video"
          />
        </div>
      </div>
      <div
        className="grid grid-cols-1 py-20 justify-items-center md:justify-items-start mobileBanner"
        style={_getMobileBannerImageStyle(state.intro_video_thumbnail)}
      >
        <div
          className="mb-6 md:hidden"
          onClick={() => setShowModal(true)}
          id="hvc-video"
        >
          <NextImage
            src={_playIconWhite}
            alt=""
            width="66"
            height="66"
            id="hvc-video"
          />
        </div>
        <Button
          className="flex items-center px-3 py-1 pl-0"
          rightIcon={liveIcon}
        >
          <span className="ml-2 tracking-widest">ONLINE LIVE COURSE</span>
        </Button>
        <Typography
          text={state.heading}
          className="w-5/6 py-5 text-4xl font-semibold text-center line-height-3 md:leading-tight md:text-6xl md:w-11/12 md:text-left"
        />
        <div className="flex items-center py-4 pb-8 md:justify-start">
          <Avatar src={state.teacher.image} />
          <div className="text-base md:text-xl md:flex md:flex-col md:pl-2">
            <Typography text="With" className="hidden md:block md:pr-1" />
            <Typography
              text={state.teacher.name}
              className="w-24 pl-3 text-xl font-medium md:pl-0 md:w-auto"
            />
          </div>
        </div>
        <Typography
          text={state.description}
          className="hidden md:block md:text-bannerDescriptionColor md:font-normal md:text-lg"
        />
      </div>
    </div>
  )
}

export default Banner
