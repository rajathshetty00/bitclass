import { BaseSyntheticEvent } from "react"
import { useSelector } from "react-redux"

const VideoModal = () => {
  const state = useSelector((state: any) => state.courseData)
  const handleVideo = (e: BaseSyntheticEvent) => {
    // @ts-ignore
    dataLayer.push({
      event: "hvc-video-clicked",
      videoData: {
        state: e.type,
        currentTime: e.target.currentTime,
        duration: e.target.duration,
      },
    })
  }
  return (
    <video
      id="hvc-video"
      autoPlay
      playsInline
      
      controls
      onPause={handleVideo}
      onPlay={handleVideo}
    >
      <source src={state.intro_video} type="video/mp4" />
    </video>
  )
}

export default VideoModal
