import Container from "@/components/Container/Container"
import NextImage from "@/components/Image/Image"
import Typography from "@/components/Typography/Typography"
import React from "react"
import { useSelector } from "react-redux"

const HVCTeacherSection = () => {
  const state = useSelector((state: any) => state.courseData.teacher)

  return (
    <Container className="grid py-16 md:mx-auto md:grid-cols-2 bg-darkBlue">
      <div className="hidden md:block">
        <NextImage
          src={state.image}
          alt="teacher"
          width="467"
          height="382"
          quality={30}
          objectFit="contain"
          className="rounded-lg"
        />
      </div>
      <div className="my-auto text-2xl text-center md:text-3xl md:text-left">
        <Typography
          text={state.qualifications}
          className="text-2xl font-normal text-white"
        />
        <Typography
          text={state.name}
          className="mt-3 mb-6 text-4xl font-semibold text-white md:text-5xl"
        />
        <div className="pb-6 md:hidden">
          <NextImage
            src={state.image}
            alt="teacher"
            width="80"
            height="80"
            quality={30}
            objectFit="contain"
            className="rounded-lg"
          />
        </div>
        <Typography
          text={state.story}
          className="text-base text-greyTextDescription md:text-xl"
        />
      </div>
    </Container>
  )
}

export default HVCTeacherSection
