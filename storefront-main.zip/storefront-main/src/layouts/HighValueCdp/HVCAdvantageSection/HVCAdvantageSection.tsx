import Container from "@/components/Container/Container"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"
import { useSelector } from "react-redux"
import NextImage from "@/components/Image/Image"

const titleSize: string = "text-xl font-semibold md:text-2xl"
const highlightSize: string = "text-xs md:text-sm"
const descriptionSize: string = "text-sm md:text-base pb-6 md:w-5/6"

const HVCAdvantageSection = () => {
  const state = useSelector(
    (state: any) => state.courseData.online_learning_advantages
  )

  return (
    <Container className="grid px-4 text-center">
      <HVCSectionHeader
        title={state.sub_heading}
        highlight={state.heading}
        description={state.description}
        className="grid pb-4 justify-items-center"
      />
      <div className="p-6 text-left border rounded-lg border-borderColor md:p-16 md:mx-52">
        {state.data.map((advantage, index) => (
          <div key={index}>
            <HVCSectionHeader
              title={advantage.sub_heading}
              highlight={advantage.heading}
              description={advantage.description}
              highlightClassName="text-highlightPink font-semibold text-xs md:text-sm"
              titleClassName={titleSize}
              descriptionClassName={descriptionSize}
            />
            <div className="w-full pb-4">
              <NextImage
                src={advantage.image_url}
                width="883"
                height="300"
                quality={60}
              />
            </div>
          </div>
        ))}
      </div>
    </Container>
  )
}

export default HVCAdvantageSection
