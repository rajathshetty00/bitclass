import Container from "@/components/Container/Container"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"
import { useSelector } from "react-redux"
import { useState } from "react"
import { saveDataLayerData } from "utils/gtm"

const HVCCurriculum = () => {
  const state = useSelector((state: any) => state.courseData.curriculum)
  const [curriculumPoints, setCurriculumPoints] = useState(
    state.data.map((curriculum) => curriculum.data.slice(0, 2))
  )
  const handleShowMore = (index) => {
    let newCurriculumPoints = state.data[index].data
    const updatedCurriculumPoints = [...curriculumPoints]
    if (curriculumPoints[index].length === 2) {
      updatedCurriculumPoints[index] = newCurriculumPoints
      setCurriculumPoints(updatedCurriculumPoints)
    } else {
      updatedCurriculumPoints[index] = newCurriculumPoints.slice(0, 2)
      setCurriculumPoints(updatedCurriculumPoints)
    }
    saveDataLayerData({
      event: "curriculum-show-more",
      curriculum: state.data[index],
    })
  }

  return (
    <Container className="grid px-2 text-center rounded-lg bg-containerGreyBackground">
      <HVCSectionHeader
        title={state.sub_heading}
        highlight={state.heading}
        description={state.description}
        className="grid px-6 pb-6 justify-items-center"
      />
      <div className="pb-10 rounded-lg md:mx-auto customShadow md:w-7/12">
        <div className="pl-10 mb-10 text-left">
          <span className="px-4 py-1 text-base font-light text-white rounded-bl-lg rounded-br-lg bg-primaryGreen">
            <strong>{state.weeks}</strong> Weeks .{" "}
            <strong>{state.live_teaching_hours}</strong> Live Hours
          </span>
        </div>
        <div>
          <ul className="px-5 text-left md:px-11 timeline">
            {state.data.map((curriculum, index) => (
              <li className="pb-2" key={index}>
                <span className="pl-4 text-lg font-semibold md:pl-0">
                  {curriculum.heading}
                </span>
                <ul className="mt-2">
                  {curriculumPoints[index]?.map((data, index) => (
                    <li className="p-3 mb-2 curriculumShadow" key={index}>
                      {curriculumPoints[index].length > 1 && `${index + 1}. `} {data}
                    </li>
                  ))}
                  {/* <li className="p-3 mb-2 curriculumShadow">2. Probability</li> */}
                </ul>
                <span
                  className="text-xs font-medium cursor-pointer text-primaryGreen"
                  onClick={() => handleShowMore(index)}
                  id="show-more-btn"
                >
                  {curriculum.data.length > 2
                    ? curriculumPoints[index].length === 2
                      ? "+ Show more"
                      : "- Show less"
                    : ""}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Container>
  )
}

export default HVCCurriculum
