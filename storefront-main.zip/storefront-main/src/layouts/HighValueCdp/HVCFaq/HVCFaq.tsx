import Accordion from "@/components/Accordion/Accordion"
import Container from "@/components/Container/Container"
import { useSelector } from "react-redux"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"

const HVCFaq = () => {
  const state = useSelector((state: any) => state.courseData.faqs)

  return (
    <Container className="px-6">
      <HVCSectionHeader
        title={state?.sub_heading}
        highlight={state.heading}
        className="grid text-center justify-items-center"
      />
      <div className="grid pt-6 justify-items-center">
        {state.data.map((faq) => (
          <Accordion
            title={faq.question}
            description={faq.answer}
            key={faq.question}
          />
        ))}
        {/* <Accordion /> */}
      </div>
    </Container>
  )
}

export default HVCFaq
