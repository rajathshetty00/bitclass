import Container from "@/components/Container/Container"
import Typography from "@/components/Typography/Typography"
import React from "react"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"
import HVCOutcomeCards from "./HVCOutcomeCards"
import { useSelector } from "react-redux"

const HVCOutcome = () => {
  const state = useSelector((state: any) => state.courseData.outcomes)
  return (
    <Container className="grid px-8 py-0 pb-5 my-10 text-center justify-items-center md:justify-items-start md:mx-24 md:text-left md:px-0 md:py-0 md:my-20">
      <HVCSectionHeader
        highlight={state.heading}
        title={state.sub_heading}
        description={state.description}
        className="pb-4"
        titleClassName="text-2xl md:text-3xl md:w-3/4"
      />
      <div className="grid w-full md:grid-cols-3">
        {state.data.map((outcome) => (
          <HVCOutcomeCards
            image={outcome.image_url}
            title={outcome.heading}
            points={outcome.points}
            key={outcome.heading}
          />
        ))}
      </div>
    </Container>
  )
}

export default HVCOutcome
