import NextImage from "@/components/Image/Image"
import Typography from "@/components/Typography/Typography"
import React from "react"
const IMAGE_SRC =
  "https://res.cloudinary.com/bitclass/image/upload/v1628756940/Assets/empty-image/outcomeCover_zl7tcm.svg"

interface IProps {
  image: string
  title: string
  points: Array<string>
}
const HVCOutcomeCards = ({ image, title, points }: IProps) => {
  return (
    <div className="w-full pb-6 md:pb-0 md:pr-4">
      <NextImage
        src={image}
        alt="cover"
        width={405}
        height={276}
        quality={30}
      />
      <Typography
        text={title}
        className="pt-4 pb-2 text-2xl font-medium text-darkBlue"
      />
      <ul className="grid grid-cols-1 justify-items-start">
        {points.map((point) => (
          <li key={point} className="ml-5 text-left list-disc">
            <Typography
              text={point}
              className="text-base font-light text-darkBlue md:w-64"
            />
          </li>
        ))}
      </ul>
    </div>
  )
}

export default HVCOutcomeCards
