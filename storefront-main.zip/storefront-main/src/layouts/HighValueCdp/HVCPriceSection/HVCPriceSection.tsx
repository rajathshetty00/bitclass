import Button from "@/components/Button/Button"
import Container from "@/components/Container/Container"
import Typography from "@/components/Typography/Typography"
import { useSelector } from "react-redux"
import HVCSummary from "../Summary/HVCSummary"

const HVCPriceSection = () => {
  const state = useSelector((state: any) => state.courseData)

  return (
    <Container className="grid hidden bg-darkBlue md:block">
      <Typography
        text="Ready to become an ethical hacker?"
        className="text-3xl font-semibold text-center text-white"
      />
      <div className="my-8 bg-white rounded-lg">
        <HVCSummary
          className="flex justify-between text-center border-b md:py-8 border-borderColor divide-borderColor md:divide-y-0 md:text-left md:px-0 md:mx-20"
        />
      </div>
    </Container>
  )
}

export default HVCPriceSection
