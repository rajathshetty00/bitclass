import Container from "@/components/Container/Container"
import Typography from "@/components/Typography/Typography"
import { arrayFromNumber } from "utils"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"

const HVCRequirementsSection = () => {
  return (
    <Container className="grid justify-items-center md:grid-cols-3 md:justify-start md:flex-row">
      <HVCSectionHeader
        title="Requirements needed for the course"
        highlight="REQUIREMENTS"
        className="grid items-start pb-6 mb-auto text-center justify-items-center md:justify-items-start md:text-left"
      />
      <div className="grid">
        {arrayFromNumber(4).map((value) => (
          <Typography text="Week 1 & 2 : Onboarding and Introduction" className="mb-6" />
        ))}
      </div>
      <div className="grid">
        {arrayFromNumber(4).map((value) => (
          <Typography text="Week 1 & 2 : Onboarding and Introduction" />
        ))}
      </div>
    </Container>
  )
}

export default HVCRequirementsSection
