import Container from "@/components/Container/Container"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"
import ReviewCard from "./ReviewCard"
import { useSelector } from "react-redux"

const HVCReview = () => {
  const state = useSelector((state: any) => state.courseData.testimonials)
  return (
    <Container className="px-4">
      <HVCSectionHeader
        title={state.sub_heading}
        highlight={state.heading}
        className="grid my-6 justify-items-center md:justify-items-start md:mx-0"
        titleClassName="text-center text-3xl"
      />
      <div className="items-start md:grid md:grid-cols-4">
        {state.data.map((review, index) => (
          <ReviewCard
            designation={review.designation}
            profilePicture={review.profile_pic}
            rating={review.rating}
            description={review.review}
            userName={review.username}
            key={index}
          />
        ))}
      </div>
    </Container>
  )
}

export default HVCReview
