import Avatar from "@/components/Avatar/Avatar"
import NextImage from "@/components/Image/Image"
import Typography from "@/components/Typography/Typography"
import StarRatings from "react-star-ratings"

interface IProps {
  designation: string
  profilePicture: string
  rating: string
  description: string
  userName: string
}
const ReviewCard = ({
  designation,
  profilePicture,
  rating,
  userName,
  description,
}: IProps) => {
  return (
    <div className="grid p-8 m-auto rounded-lg md:my-0 customShadow justify-items-center md:justify-items-start md:mr-8 ">
      <div className="pb-4">
        <StarRatings
          rating={rating}
          starDimension="24px"
          starSpacing="2px"
          starRatedColor="#F3CD03"
        />
      </div>
      <Typography text={description} className="text-center md:text-left" />
      <div className="flex items-center py-2 justify-content md:justify-start">
        <NextImage
          src="https://res.cloudinary.com/bitclass/image/upload/v1630922358/Assets/HVC/profile-empty_rephbu.svg"
          width="40px"
          height="40px"
        />

        <div className="pl-2">
          <Typography text={userName} className="text-sm font-medium" />
          <span className="text-xs text-descriptionColor">{designation}</span>
        </div>
      </div>
    </div>
  )
}

export default ReviewCard
