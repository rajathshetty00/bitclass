import Button from "@/components/Button/Button"
import Typography from "@/components/Typography/Typography"
import { useSelector } from "react-redux"

const HVCStickyEnrollSection = () => {
  const state = useSelector((state: any) => state.courseData)

  return (
    <div className="fixed bottom-0 z-50 flex items-center justify-center w-screen py-4 bg-white md:hidden bannerShadow">
      {/* <Typography text={`INR ${state.price}`} className="mr-4 text-xl" /> */}
      <Button
        id="enroll-now"
        className="w-11/12 py-4 rounded px-11 bg-primaryGreen"
        data-position="bottom-navigation"
      >
        <span
          className="text-xl font-semibold"
          id="enroll-now"
          data-position="bottom-navigation"
        >
          Apply Now
        </span>
      </Button>
    </div>
  )
}

export default HVCStickyEnrollSection
