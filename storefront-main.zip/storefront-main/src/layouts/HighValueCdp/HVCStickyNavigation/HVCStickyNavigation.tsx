import Button from "@/components/Button/Button"
import NextImage from "@/components/Image/Image"
import NavLink from "@/components/NavLink/NavLink"
import Head from "next/head"
import { useSelector } from "react-redux"

const NAV_LINKS = [
  { name: "Outcomes", link: "#outcomes" },
  { name: "Topics", link: "#topics" },
  { name: "Teacher", link: "#teacher" },
  { name: "Curriculum", link: "#curriculum" },
  { name: "Reviews", link: "#reviews" },
]
const HVCStickyNavigation = () => {
  const state = useSelector((state: any) => state.courseData)

  return (
    <>
      <Head>
        <title>{state.heading}</title>
      </Head>
      <div className="fixed z-50 bg-white bannerShadow">
        <div className="flex items-center justify-between w-screen md:py-3 navSpacing">
          <NextImage
            src="https://res.cloudinary.com/bitclass/image/upload/v1630923401/Assets/HVC/Left_Nav_nt8g6y.svg"
            width="120px"
            height="36px"
          />
          <div className="flex items-center py-1 md:py-0">
            <div className="flex items-center hidden">
              {NAV_LINKS.map((nav) => (
                <NavLink navData={nav} key={nav.link} />
              ))}
            </div>
            <Button
              id="enroll-now"
              className="hidden px-4 py-2 font-semibold rounded md:ml-4 md:px-8 md:py-4 bg-primaryGreen md:block"
              data-position="top-navigation"
            >
              Join the waitlist
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}

export default HVCStickyNavigation
