import Container from "@/components/Container/Container"
import HVCSectionHeader from "../../../layouts/HighValueCdp/SectionHeader/HVCSectionHeader"
import { useSelector } from "react-redux"

const HVCTopics = () => {
  const state = useSelector((state: any) => state.courseData.topics)

  return (
    <Container className="grid text-center bg-containerGreyBackground justify-items-center md:justify-items-start md:text-left">
      <HVCSectionHeader
        title={state.sub_heading}
        highlight={state.heading}
        description={state.description}
        className="pb-4"
      />
      <div className="grid md:grid-cols-3">
        {state.data.map((value) => (
          <HVCSectionHeader
            key={value.heading}
            title={value.heading}
            description={value.data}
            titleClassName="text-xl md:text-2xl"
            descriptionClassName="text-sm md:text-base"
          />
        ))}
      </div>
    </Container>
  )
}

export default HVCTopics
