import StepDetailedCard from "@/components/StepDetailedCard/StepDetailedCard"
import Typography from "@/components/Typography/Typography"
const step_details = [
  {
    id: 1,
    image_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/1_application_xqdnna.svg",
    title: "Submit application",
    description: "Fill out a short application form",
  },
  {
    id: 2,
    image_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/2_screenig_tphlb5.svg",
    title: "Profile evaluation and guidance",
    description: "Get your profile and subject expertise evaluated",
  },
  {
    id: 3,
    image_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/3_personal_gu3xim.svg",
    title: "Personalised learning plan",
    description: "Avail counselling sessions with the teacher",
  },
  {
    id: 4,
    image_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/4_training_izohc5.svg",
    title: "Start your journey",
    description: "Get selected and kickstart your live learning journey",
  },
]
const HowToEnroll = () => {
  return (
    <div className="pb-16 bg-darkBlue">
      <Typography
        text="How to enroll ?"
        className="pt-10 pb-8 text-2xl font-semibold text-center text-white md:py-16 md:text-3xl"
      />
      <div className="grid grid-cols-2 gap-6 ml-4 gap-y-8 justify-items-center md:grid-cols-4">
        {step_details.map((step_detail) => (
          <div className="" key={step_detail.id}>
            <StepDetailedCard card_details={step_detail} />
          </div>
        ))}
      </div>
    </div>
  )
}

export default HowToEnroll
