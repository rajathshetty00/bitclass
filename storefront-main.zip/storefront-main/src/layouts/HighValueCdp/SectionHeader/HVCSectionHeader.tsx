import Typography from "@/components/Typography/Typography"
import classnames from "classnames"
interface IProps {
  title?: string
  highlight?: string
  description?: string
  className?: string
  highlightClassName?: string
  titleClassName?: string
  descriptionClassName?: string
}
const HVCSectionHeader = ({
  title,
  highlight,
  description,
  className,
  highlightClassName = "text-primaryGreen font-normal text-base md:text-xl",
  titleClassName = "text-2xl md:text-3xl ",
  descriptionClassName = "text-sm md:text-lg pb-6 md:w-2/3 ",
}: IProps) => {
  return (
    <div className={className}>
      {highlight && (
        <Typography
          text={highlight}
          // className={"text-primaryGreen font-normal text-base md:text-xl"}
          className={highlightClassName}
        />
      )}
      {title && (
        <Typography
          text={title}
          // className={`text-darkBlue font-semibold text-2xl md:text-3xl py-1`}
          className={`text-darkBlue font-semibold ${titleClassName} py-1`}
        />
      )}
      {description && (
        <Typography
          text={description}
          className={`text-descriptionColor font-normal ${descriptionClassName} md:w-2/3 pb-6`}
        />
      )}
    </div>
  )
}

export default HVCSectionHeader
