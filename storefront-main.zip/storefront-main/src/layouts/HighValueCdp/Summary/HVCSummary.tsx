import Container from "@/components/Container/Container"
import { FC } from "react"
import SummaryDetails from "./SummaryDetails"
import { useSelector } from "react-redux"
import Button from "@/components/Button/Button"
import Typography from "@/components/Typography/Typography"

interface Props {
  className?: string
  showPrice?: boolean
  price?: number
}
const HVCSummary = ({ className = "", showPrice = false, price }: Props) => {
  const state = useSelector((state: any) => state.courseData.features)

  return (
    <Container
      className={
        className ||
        "grid py-4 md:py-8 text-center border-b divide-y justify-items-center md:justify-between border-borderColor divide-borderColor md:grid-cols-4 md:divide-y-0 md:text-left"
      }
    >
      {state.slice(0, 3).map((feature) => (
        <SummaryDetails
          key={feature.key}
          title={feature.key}
          highlight={feature.value}
          description={""}
        />
      ))}
      <div className="hidden md:grid md:items-center">
        {showPrice && (
          <Typography
            text={`INR ${price}`}
            className="mr-4 text-4xl text-center"
          />
        )}
        <Button
          id="enroll-now"
          className="py-4 rounded px-11 bg-primaryGreen"
          data-position="bottom-price-section"
        >
          <span
            className="font-semibold"
            id="enroll-now"
            data-position="bottom-price-section"
          >
            Apply Now
          </span>
        </Button>
      </div>
    </Container>
  )
}

export default HVCSummary
