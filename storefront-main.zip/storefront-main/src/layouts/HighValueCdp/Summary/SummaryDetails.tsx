import Typography from "@/components/Typography/Typography"
import React from "react"

interface ISummaryDetails {
  title: string
  highlight: string
  description: string
}
const SummaryDetails = ({ title, highlight, description }: ISummaryDetails) => {
  return (
    <div className="inline-block py-4 text-center md:border-borderColor md:border-r md:text-left md:pr-16 courseSummary">
      <Typography
        text={title}
        className="font-normal tracking-wide text-center text-subTitleColor"
      />
      <span className="text-xl font-medium text-center border-b-4 text-titleColor border-primaryGreen min-w-max">
        {highlight}
      </span>
      <Typography
        text={description}
        className="mt-2 text-sm font-normal text-center text-descriptionColor"
      />
    </div>
  )
}

export default SummaryDetails
