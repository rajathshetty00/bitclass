import Container from "@/components/Container/Container"
import NextImage from "@/components/Image/Image"
import Typography from "@/components/Typography/Typography"
import { useSelector } from "react-redux"

const CLASS_DEMO_IMAGE =
  "https://res.cloudinary.com/bitclass/image/upload/v1630646893/Assets/HVC/classDemo_k55tno.svg"

const WhyBitclass = () => {
  const state = useSelector(
    (state: any) => state.courseData.online_learning_advantages
  )
  return (
    <div className="py-10 md:grid md:grid-cols-2 md:py-20">
      <div className="grid items-center grid-cols-2 md:grid-cols-1">
        <NextImage src={state?.image_url} width="575px" height="700px" alt="" />
        <Typography
          text={state?.heading}
          className="mx-4 text-2xl font-semibold pr-7 md:hidden md:w-0"
        />
      </div>
      <div className="grid items-center mx-4 md:py-24">
        <Typography
          text="Why take this course on BitClass ?"
          className="hidden text-3xl font-semibold md:block"
        />
        {state?.data.map(({ highlight, points }) => (
          <div
            className="grid grid-cols-1 md:place-items-start md:justify-items-start md:grid-cols-3"
            key={highlight}
          >
            <Typography
              text={highlight}
              className="pb-6 text-xl font-medium text-center md:mr-6 md:text-left pt-9 md:pt-0"
            />
            <div className="md:col-start-2 md:col-end-4">
              <ul className="grid gap-4 mx-auto ml-8 md:ml-0 md:grid-cols-2">
                {points.map((x) => (
                  <li className="list-disc md:mr-4" key={x}>
                    <Typography text={x} />
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default WhyBitclass
