import NextImage from "@/components/Image/Image"
import Link from 'next/link';
import { BIT_CLASS_LOGO, COHORTS, DESKTOP_LAUNCH_PAD_LOGO, LAUNCH_PAD_LOGO, LEARNER, MADE_BY, TEACHERS } from 'src/constants/constants';

import Button from 'src/components/Button/Button';
import TypographyNew from '@/components/TypographyNew';
import { handleJoinClicked } from "pages/launchpad";

const LaunchPadTopBanner = () => {


  return (
    <>
      <div className="px-5 py-8 text-center xl:pb-16">
          <div className="flex flex-col md:hidden">
            <div className="mb-1">
              <NextImage
                src={BIT_CLASS_LOGO}
                width="90"
                height="32"
                alt="launch pad logo"
          objectFit="contain"

              />  
            </div>
            <NextImage
              src={LAUNCH_PAD_LOGO}
              width="80"
              height="34"
              alt="launch pad logo"
          objectFit="contain"

            />
          </div>
          <div className="hidden md:block">
            <NextImage 
              src={DESKTOP_LAUNCH_PAD_LOGO}
              width="300"
              height="40"
          objectFit="contain"

            />
          </div>
        <TypographyNew className="m-auto mt-4 mb-8 mb-12 text-4xl font-bold text-darkBlue md:max-w-2xl lg:max-w-2xl xl:max-w-5xl xl:text-6xl ">
          We Help Build Highly Successful <span className="underline text-primaryGreen">Online Teaching</span> Businesses.
        </TypographyNew>
        <Link href="/launchpad/apply">
          <Button className="w-full py-3 rounded bg-primaryGreen md:w-80" onClick={handleJoinClicked}>
            <span className="text-base font-semibold xl:text-2xl">
                Join Launchpad
            </span>
          </Button>
        </Link>
      </div>
      <div className="flex flex-wrap justify-between px-5 mb-56 md:px-12 lg:px-16 xl:justify-evenly xl:px-24 " >
        <div className="mb-4">
          <NextImage
            src={LEARNER}
            width="150"
            height="100"
            alt="learner"
          />
          <TypographyNew className="text-sm font-medium text-grey_40 xl:text-lg lg:text-center">
            <span className="font-semibold text-primaryGreen">1M+</span> Learners <br/> Community
          </TypographyNew>
        </div>
        <div className="mb-4">
          <NextImage
            src={TEACHERS}
            width="150"
            height="100"
            alt="teachers"
          />
          <TypographyNew className="text-sm font-medium text-grey_40 xl:text-lg lg:text-center">
          <span className="font-semibold text-primaryGreen">6400+</span> Teachers <br/> at BitClass
          </TypographyNew>
        </div>
        <div className="mb-4">
          <NextImage
            src={COHORTS}
            width="150"
            height="100"
            alt="cohorts"
          />
          <TypographyNew className="text-sm font-medium text-grey_40 xl:text-lg lg:text-center">
          <span className="font-semibold text-primaryGreen">2,500+ Live </span>
            <br/>
            Cohorts Running
          </TypographyNew>
        </div>
        <div className="mb-4">
          <NextImage
            src={MADE_BY}
            width="150"
            height="100"
            alt="made by"
          />
          <TypographyNew className="text-sm font-medium text-grey_40 xl:text-lg lg:text-center">
            <span className="font-semibold text-primaryGreen">2.5Cr+ Earned</span> <br/>
             by top 100 teachers
          </TypographyNew>
        </div>
      </div>
    </>
  )
};

export default LaunchPadTopBanner;