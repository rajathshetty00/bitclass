import React from 'react';

import TypographyNew from '@/components/TypographyNew';
import StepDetailedCard from '@/components/StepDetailedCard/StepDetailedCard';
import TeachersTestimonials from '../TeachersTestimonialSlider/TeachersTestimonialSlider';

import {section_details} from './SectionDetails'; 

const HowLaunchPadWorks = () => {
  
  return (
    <div className="bg-darkBlue relative pb-32 pt-0">
      <div className="relative -top-32">
        <TeachersTestimonials/>
      </div>
      <div className="text-center px-10">
        <TypographyNew className="text-white text-3xl font-medium xl:text-6xl">
          {section_details.heading}
        </TypographyNew>
        <TypographyNew className="text-white text-xl font-light pt-3 pb-8 lg:w-1/2 m-auto xl:text-2xl">
          {section_details.sub_heading}
        </TypographyNew>
      </div>
      <div className="flex flex-wrap justify-between px-5 md:pl-11 md:mt-20 lg:pl-28  md:pr-8 lg:justify-between  xl:pl-52" >
        {
          section_details.step_details.map(step_detail => (
            <div className="mb-9 lg:mr-12 xl:mr-32">
            <StepDetailedCard card_details={step_detail} />
            </div>
          ))
        }
      </div>
    </div>
  )
};

export default HowLaunchPadWorks;