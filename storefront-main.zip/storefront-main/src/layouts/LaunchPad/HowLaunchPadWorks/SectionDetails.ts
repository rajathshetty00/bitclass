export const section_details = {
  heading:'How does Launchpad work ?',
  sub_heading:'Launchpad is an accelerated track for online teachers to engage and start making money',
  step_details:[
  {
    id:1,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/1_application_xqdnna.svg',
    title:'Application',
    description:'Fill out a short online application form'
  },
  {
    id:2,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/2_screenig_tphlb5.svg',
    title:'Screening & Vetting',
    description:'Get your profile & subject expertise evaluated'
  },
  {
    id:3,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/3_personal_gu3xim.svg',
    title:'Personalised Growth strategy',
    description:'Well researched curriculum & course packaging'
  },
  {
    id:4,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/4_training_izohc5.svg',
    title:'Online Teaching Training',
    description:'Specialised training on all aspects of LIVE teaching'
  },
  {
    id:5,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/5_lakhs_ullpuc.svg',
    title:'Rs. 2.5 Lakh+ in Marketing & Branding Support',
    description:'Design, Content & Marketing teams to help you grow'
  },
  {
    id:6,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630151334/Assets/Launchpad/6_teach_yccgme.svg',
    title:'Teach, Monetise, REPEAT!',
    description:'Build a highly successful teaching business.'
  },
]
}