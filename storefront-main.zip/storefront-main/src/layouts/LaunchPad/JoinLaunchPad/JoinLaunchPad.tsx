import Link from 'next/link';
import NextImage from "@/components/Image/Image"

import TypographyNew from '@/components/TypographyNew';
import Button from '@/components/Button/Button';
import { LAUNCH_PAD_LOGO , BIT_CLASS_LOGO } from 'src/constants/constants';
import { handleJoinClicked } from 'pages/launchpad';

const JoinLaunchPad = () => {
  return (
    <div className="px-5 py-8 mx-5 text-center border-2 rounded-lg border-white_lilac md:m-auto md:w-6/12 xl:w-8/12">
      <div className="flex flex-col">
        <div className="mb-1">
          <NextImage
            src={BIT_CLASS_LOGO}
            width="80"
            height="28"
            alt="launch pad logo"
          objectFit="contain"

          />
        </div>
        <NextImage
          src={LAUNCH_PAD_LOGO}
          width="180"
          height="32"
          alt="launch pad logo"
          objectFit="contain"

        />
      </div>
      <TypographyNew className="mt-4 mb-6 text-3xl font-bold leading-12 xl:text-6xl">
        Launch your <br className="xl:hidden" /> Successful <br className="hidden xl:flex" /> Online <br className="xl:hidden" />
        Teaching Business
      </TypographyNew>
      <TypographyNew className="mb-8 text-sm font-normal text-grey_40 xl:text-2xl">
        At BitClass, we’ll take care of <br className="xl:hidden" />
        everything, <br className="hidden xl:flex" /> all you have to do, <br className="xl:hidden" />
        is TEACH!
      </TypographyNew>
      <Link href="/launchpad/apply">
        <Button className="w-full py-3 rounded bg-primaryGreen md:w-80" onClick={handleJoinClicked}>
          <span className="text-base font-semibold">
            Join Launchpad
          </span>
        </Button>
      </Link>
    
    </div>
  )
};

export default JoinLaunchPad;