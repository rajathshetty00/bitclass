import NextImage from "@/components/Image/Image"
import Link from "next/link"
import { handleJoinClicked } from "pages/launchpad"

import Button from "src/components/Button/Button"
import { BIT_CLASS_LOGO } from "src/constants/constants"
import { ROOT_URL } from "utils/constants"

const LaunchPadNav = () => {
  return (
    <div className="flex justify-between px-5 py-2 py-4 bg-white launchpadNavShadow xl:px-10">
      <Link href={ROOT_URL}>
        <NextImage
          src={BIT_CLASS_LOGO}
          alt="bitlogo"
          width="104"
          height="32"
          objectFit="contain"
          className="cursor-pointer"
        />
      </Link>
      <Link href="/launchpad/apply">
        <Button
          className="px-4 py-2 rounded bg-primaryGreen lg:px-8 "
          onClick={() => handleJoinClicked("header")}
        >
          <span className="text-sm font-semibold lg:text-base">
            Join Launchpad
          </span>
        </Button>
      </Link>
    </div>
  )
}

export default LaunchPadNav
