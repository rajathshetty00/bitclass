import React from 'react';
import NextImage from "@/components/Image/Image"
import Button from 'src/components/Button/Button';
import TypographyNew from '@/components/TypographyNew';

import { COHORTS, LAUNCH_PAD_LOGO, LEARNER, MADE_BY, TEACHERS } from 'src/constants/constants';

const ListenToOurTeachers = () => {
  return (
    <>
      <div className="text-center px-5 py-8">
        <NextImage
          src={LAUNCH_PAD_LOGO}
          width="180"
          height="40"
          alt="launch pad logo"
          objectFit="contain"

        />
        <TypographyNew className="text-4xl font-bold mt-4 mb-8 leading-12">
            Build a highly successful <span className="underline text-primaryGreen">online teaching</span> businesses.
        </TypographyNew>
        <Button className="w-full bg-primaryGreen py-3 rounded ">
          <span className="font-semibold text-base">
              Join Launchpad
          </span>
        </Button>
      </div>
      <div className="flex flex-wrap justify-between px-5" >
        <div className="mb-4">
          <NextImage
            src={LEARNER}
            width="150"
            height="100"
            alt="learner"
          />
          <TypographyNew className="font-medium text-grey_40">
            <span className="text-primaryGreen font-semibold">1 Mn+</span> Learners’ <br/> Community
          </TypographyNew>
        </div>
        <div className="mb-4">
          <NextImage
            src={TEACHERS}
            width="150"
            height="100"
            alt="teachers"
          />
          <TypographyNew className="font-medium text-grey_40">
          <span className="text-primaryGreen font-semibold">6000+</span> Teachers
          </TypographyNew>
        </div>
        <div className="mb-4">
          <NextImage
            src={COHORTS}
            width="150"
            height="100"
            alt="cohorts"
          />
          <TypographyNew className="font-medium text-grey_40">
          <span className="text-primaryGreen font-semibold">2500+ Cohorts</span>
            <br/>
            Running in BitClass
          </TypographyNew>
        </div>
        <div className="mb-4">
          <NextImage
            src={MADE_BY}
            width="150"
            height="100"
            alt="made by"
          />
          <TypographyNew className="font-medium text-grey_40">
            Over <span className="text-primaryGreen font-semibold">2.5 Crores</span> <br/>
            Made by teachers 
          </TypographyNew>
        </div>
      </div>
    </>
  )
};

export default ListenToOurTeachers;