import TypographyNew from "@/components/TypographyNew"
import Slider from "react-slick"
import NextImage from "@/components/Image/Image"
import { teachers_testimonials } from "./TeachersTestimonials"
import VideoTestimonialCard from "src/components/VideoTestimonialCard/VideoTestimonialCard"
import { useRef } from "react"
import { LEFT_ARROW, RIGHT_ARROW } from "src/constants/constants"

var slider_settings = {
  dots: false,
  infinite: false,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  variableWidth: true,
  mobileFirst: true,
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: false,
        centerMode: false,
        variableWidth: false,
      },
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        initialSlide: 2,
      },
    },
    {
      breakpoint: 480,
      settings: {
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
      },
    },
  ],
}

const TeachersTestimonials = () => {
  const slider_ref = useRef(null)

  const onLeftClick = () => {
    slider_ref.current.slickPrev()
  }

  const onRightClick = () => {
    slider_ref.current.slickNext()
  }

  return (
    <div>
      <div className="w-full px-10 md:w-full lg:2/3">
        <TypographyNew className="pb-6 text-3xl font-medium text-center text-black lg:pb-12 xl:text-6xl">
          Listen to our Star Teachers
        </TypographyNew>
      </div>
      <div className="pl-4 md:pl-6 lg:pl-0">
        <div className="lg:hidden">
          <Slider ref={slider_ref} {...slider_settings}>
            {teachers_testimonials.map((testimonial) => (
              <div className="inline mr-4 outline-none" key={testimonial.id}>
                <VideoTestimonialCard card_details={testimonial} />
              </div>
            ))}
          </Slider>
        </div>
        <div className="hidden lg:flex lg:justify-center">
          {teachers_testimonials.map((testimonial) => (
            <div className="inline mr-4 outline-none" key={testimonial.id}>
              <VideoTestimonialCard card_details={testimonial} />
            </div>
          ))}
        </div>
      </div>
      <div className="flex justify-center pt-8 md:hidden">
        <div className="mr-8 cursor-pointer" onClick={onLeftClick}>
          <NextImage
            src={LEFT_ARROW}
            height="20"
            width="36"
            objectFit="contain"
          />
        </div>
        <div onClick={onRightClick} className="cursor-pointer">
          <NextImage
            src={RIGHT_ARROW}
            height="20"
            width="36"
            objectFit="contain"
          />
        </div>
      </div>
    </div>
  )
}

export default TeachersTestimonials
