export const teachers_testimonials = [
  {
    id: "1",
    video_link:
      "https://res.cloudinary.com/bitclass/video/upload/v1630991568/Assets/Launchpad/Krunal_Ratio_nkyunl.mp4",
    thumbnail_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630402351/Assets/Launchpad/krunal_thumbnail_hiw7qg.png",
    teacher_name: "Krunal Rindani",
    profession: "Stock Tader & Investor",
  },
  {
    id: "2",
    video_link:
      "https://res.cloudinary.com/bitclass/video/upload/v1630991530/Assets/Launchpad/Era_Kaundal_Ratio_jcakgu.mp4",
    thumbnail_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630402351/Assets/Launchpad/Era_thumbnail_gux4wq.png",
    teacher_name: "Era Kaundal",
    profession: "Korean Teacher",
  },
  {
    id: "3",
    video_link:
      "https://res.cloudinary.com/bitclass/video/upload/v1630991547/Assets/Launchpad/Ruthvi_Ratio_fx8t6x.mp4",
    thumbnail_url:
      "https://res.cloudinary.com/bitclass/image/upload/v1630402351/Assets/Launchpad/Ruthvi_thumbnail_lhi3bw.png",
    teacher_name: "Ruthvi Deev",
    profession: "Bellydance Instructor",
  },
]
