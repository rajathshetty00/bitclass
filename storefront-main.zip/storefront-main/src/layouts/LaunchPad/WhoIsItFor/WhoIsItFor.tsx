import NextImage from "@/components/Image/Image"
import TypographyNew from '@/components/TypographyNew';
import {PEOPLE_ENJOYING} from 'src/constants/constants'

const WhoIsItFor = () => {
  return (
    <>
      <div className="text-center px-10 md:flex md:text-left">
        <div className="w-full md:w-1/2 lg:2/3 lg:pl-12 xl:pl-20">
          <TypographyNew className="text-cyprus text-3xl pb-6 lg:pb-12 font-medium xl:text-6xl">
            Who is it for? <br /> Who all can apply?
          </TypographyNew>
          <TypographyNew className="text-cyprus text-xl font-light  pb-8 lg:pb-12 xl:text-2xl xl:pr-36 xl:pb-18">
            Anyone and Everyone can teach on BitClass. We’ll guide and support you on every step of your teaching journey.
          </TypographyNew>
          <TypographyNew className="text-black text-3xl font-semibold pb-1 border-b-4 mb-8  border-primaryGreen md:w-64 lg:w-420  lg:text-2xl xl:text-4xl xl:w-610">
            “Everyone has a <br className="flex lg:hidden" />
            course in them ”
          </TypographyNew>
        </div>
        <div className="w-full md:w-1/2 lg:1/3">
          <div className="flex justify-center xl:hidden">
            <NextImage
              src={PEOPLE_ENJOYING}
              width="350"
              height="350"
              objectFit="contain"
            />
          </div>
          <div className="hidden xl:flex justify-center">
            <NextImage
              src={PEOPLE_ENJOYING}
              width="440"
              height="440"
              objectFit="contain"
            />
          </div>
        </div>
      </div>
    </>
  )
};

export default WhoIsItFor;