import React, { useState } from "react";
import { useForm } from "react-hook-form";
import swal from "sweetalert";

import TypographyNew from "@/components/TypographyNew";
import FileUploadInput from "@/components/FileUploadInput/FileUploadInput";
import TeachWithUs from "src/layouts/LaunchPadApply/TeachWithUs/TeachWithUs";
import { useRouter } from "next/dist/client/router";
import axios from "axios";
import { saveDataLayerData } from "utils/gtm";
import { BIT_EVENTS } from "utils/events";

import { IFormInput } from "@/interfaces/aboutYourSelf";

import { AboutFormAvailabilityField, AboutFormCourseDetailField, AboutFormCourseTitleField, AboutFormEmailField, AboutFormMaterialField, AboutFormMobileField, AboutFormNameField, AboutFormOutComeField,  AboutFormSocialField,  AboutFormTargetField, AboutFormTeachingField, BackButton } from "@/components/index";


const AboutYourSelfForm = () => {
  const [introUrl, setIntroUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IFormInput>({
    mode: "onBlur",
    reValidateMode: "onChange",
  });

  const onFormSubmit = async (formData) => {
    const {...restData} = formData;
    saveDataLayerData({
      event: BIT_EVENTS.teacherApplicationSubmitClicked,
      teacherApplicationData: formData,
    })

    try {
      setIsLoading(true)
      const res = await axios.post("v2/aarohan/launchpad/teacher-form", {
        ...restData,
        intro_video: introUrl,
      })
      if (res) {
        const successRes = await swal({
          title: "Your application form has been successfully submitted.",
          text: "Our team will review and get back to you.",
          icon: "success",
          buttons: {
            confirm: { text: "Go Back", className: "swal-button-confirm" },
          },
        })
        if (successRes) {
          router.push("/launchpad")
        }
      }
      setIsLoading(false)
    } catch (error) {
      setIsLoading(false)
      if (error?.response?.data?.error) {
        const errorRes = await swal({
          title: "Teacher already applied to Launchpad",
          icon: "error",
        })
        if (errorRes) {
          router.push("/launchpad")
        }
      }
    }
  };

  return (
    <div className="lg:flex">
      <div className="px-5 pb-8 lg:pl-14 lg:6/12 xl:w-7/12">
        <BackButton />
        <div className="m-auto md:w-6/12 lg:w-full">
          <TypographyNew className="mt-8 text-3xl font-medium">
            Tell us about <br className="block md:hidden" /> yourself
          </TypographyNew>
          <TypographyNew className="mt-6 text-base font-light">
            A brief description about course
          </TypographyNew>
        </div>
        <div className="m-auto md:w-6/12 lg:w-full">
          <form onSubmit={handleSubmit(onFormSubmit)}>
            {/* Full Name Component */}
            <AboutFormNameField register={register} errors={errors} />
            {/* // number counntry code */}
            <AboutFormMobileField register={register} errors={errors} />
            {/* email */}
            <AboutFormEmailField register={register} errors={errors} />
            {/*  Course title */}
            <AboutFormCourseTitleField register={register} errors={errors} />
            {/*  Course details */}
            <AboutFormCourseDetailField register={register} errors={errors} />
            {/* OutCome */}
            <AboutFormOutComeField register={register} errors={errors} />
            {/* Social */}
            <AboutFormSocialField register={register}  />
            {/* Material Required*/}
           {/* <AboutFormMaterialField register={register} /> */}
            {/* target audience */}
            <AboutFormTargetField register={register} errors={errors} />
            {/* teaching experience */}
           <AboutFormTeachingField register={register} errors={errors}  />
            {/*  Intro Video */}
            <div className="mb-6 rounded md:w-72 lg:w-80 xl:w-full">
              <FileUploadInput setUrl={setIntroUrl} />
            </div>
            {/*  Availablity */}
            {/* <AboutFormAvailabilityField register={register} errors={errors} /> */}

            <div className="md:text-right xl:w-630">
              <button
                type="submit"
                className="w-full py-3 mt-8 text-white rounded focus:outline-none bg-primaryGreen md:w-80 xl:w-384"
                onClick={handleSubmit(onFormSubmit)}
              >
                {!isLoading ? (
                  <span className="text-base font-semibold text-white xl:text-2xl">
                    Submit Application
                  </span>
                ) : (
                  <TypographyNew className="text-xs text-white lg:text-xl">
                    Sending data...
                  </TypographyNew>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="hidden lg:6/12 xl:w-5/12 xl:px-8 lg lg:flex xl:px-16 ">
        <TeachWithUs />
      </div>
    </div>
  );
};

export default AboutYourSelfForm;
