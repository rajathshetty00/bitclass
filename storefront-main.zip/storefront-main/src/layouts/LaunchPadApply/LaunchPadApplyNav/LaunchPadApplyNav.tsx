import React from 'react';
import NextImage from "@/components/Image/Image"
import Link from 'next/link';
import TypographyNew from '@/components/TypographyNew';

import {BIT_LOGO} from 'src/constants/constants';




const LaunchPadApplyNav = () => {
  return (
    <div className="bg-white flex cursor-pointer justify-center py-4 px-5 launchpadNavShadow lg:justify-between xl:px-10 py-2" >
      <Link href="/launchpad">
        <NextImage 
          src={BIT_LOGO}
          alt="bitlogo"
          width="250"
          height="32"
          objectFit="contain"
        />
      </Link>
      <TypographyNew className="text-sm font-medium hidden lg:flex items-center">
      Teacher Application process
        </TypographyNew>
    </div>
  )
};

export default LaunchPadApplyNav