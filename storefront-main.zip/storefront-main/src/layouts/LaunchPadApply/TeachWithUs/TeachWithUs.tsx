import React from 'react';

import TypographyNew from '@/components/TypographyNew';
import TeacherDetailsCard from '@/components/TeacherDetailsCard/TeacherDetailsCard';
import {teacher_details} from './TeacherDetails';

const TeachWithUs = () => {

  return (
    <div className="bg-apply-pattern bg-no-repeat">
      <div className="text-center px-6 pt-6">
      <TypographyNew className="text-white text-xl font-medium mb-2">Teach With Us</TypographyNew>
      <TypographyNew className="text-white font-normal text-base">Be a mentor and teach students around the globe from the comfort of your home.</TypographyNew>
      </div>
      <div className="mx-12">
      {
        teacher_details.map(item=> (
          <div className="mt-12">
            <TeacherDetailsCard details={item}/>
          </div>
        ))
      }
      </div>
    </div>
  )
};

export default TeachWithUs