export const teacher_details = [
  {
    name:'Krunal Rindani',
    profession:'Stock Tader & Investor',
    rating:4.8,
    courses:14,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630672121/Assets/Launchpad/Krunal_application_banner_qdhuln.svg'
  },
  {
    name:'Era Kaundal',
    profession:'Korean Teacher',
    rating:4.8,
    courses:39,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630672121/Assets/Launchpad/Era_application_banner_qvpddp.svg'
  },
  {
    name:'Ruthvi Deev',
    profession:'Bellydance Instructor',
    rating:4.6,
    courses:61,
    image_url:'https://res.cloudinary.com/bitclass/image/upload/v1630672121/Assets/Launchpad/Ruthvi_application_banner_wxhnyr.svg'
  }
]