const colors = require("tailwindcss/colors")

module.exports = {
  mode: "jit",
  purge: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
    "./src/layouts/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: false, // or 'media' or 'class'
  theme: {
    colors: {
      transparent: "transparent",
      darkBlue: "#070D1D",
      pink500: "#F45C43",
      pink800: "#EB3349",
      white: "#ffffff",
      primaryGreen: "#079893",
      lightGreen: "#rgba(7, 152, 147, 0.44)",
      borderColor: "#C7C7CA",
      titleColor: "#070D1D",
      descriptionColor: "#5F5F64",
      subTitleColor: "#666666",
      bannerDescriptionColor: "#A4ABBE",
      highlightPink: "#B33CDB",
      highlightRed: "#DE2879",
      greyTextDescription: "#A4ABBE",
      acadia:'#71798E',
      cyprus: '#070d1d',
      white_lilac:"#EBEAED",
      // color-hue
      slate_grey:'#71798E',
      lavender_grey:'#B5BDD3',
      magnolia:'#F3F0FF',
      echo_blue:'#9CA8C7',
      brick_red:'#D7333D'
    },
    // screens: {
    //   'sm': '360px',
    //   // => @media (min-width: 640px) { ... } mobile

    //   'md': '768px',
    //   // => @media (min-width: 768px) { ... } ipad

    //   'lg': '1024px',
    //   // => @media (min-width: 1024px) { ... } ipad pro

    //   'xl': '1440px',
    //   // => @media (min-width: 1280px) { ... } desktop
    // },
    fontFamily: {
      sans: ["Poppins", "sans-serif"],
    },
    extend: {
      colors: {
        white_opac: "rgba(113, 121, 142, 1)",
        text_grey: "rgba(46, 58, 89, 1)",
        grey_40:'rgba(21, 20, 57, 0.4)',
        green: {
          dark: "rgba(7, 152, 147, 1)",
        },
        containerGreyBackground: "rgba(209, 217, 239, 0.1)",
        modalOverlay: "rgba(49, 49, 49, 0.5)",
        lineHeight: {
          '16': '5rem',
          '12':"3rem"
         }
      },
      width: {
        '420': "26.875rem",
        '610':"38.125rem",
        '384':'24rem',
        '336':'21rem',
        'input_num':'5.5rem',
        '630':'630px',
       },
      height: {
        '540': "34rem",
        '120':'7.5rem',
        '44':'44px'
      },
      margin:{
        '5.5':'5.5rem',
        '90':'5.625rem'
      },
      backgroundImage: theme => ({
        'apply-pattern': "url('https://res.cloudinary.com/bitclass/image/upload/v1630500433/Assets/Launchpad/green_bg_cztv81.svg')",
        'lp-bg-pattern': "url('https://res.cloudinary.com/bitclass/image/upload/v1630503489/Assets/Launchpad/launchpad_bg_tile_hjso8e.svg')",
       })
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
  corePlugins: {
    fontFamily: false,
  },
}
