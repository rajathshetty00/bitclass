export const assetObject = {
    logoWhiteSmall:
      'public/static/logo/BitClassLogos/LogoSmallForDarkBG.svg',
    logoDarkSmall:
      'public/static/logo/BitClassLogos/LogoSmallForWhiteBG.svg',
    logoWhite: 'public/static/logo/BitClassLogos/LogoForDarkBG.svg',
    logoDark: 'public/static/logo/BitClassLogos/LogoForWhiteBg.svg',
}