export const GTM_ID = process.env.NEXT_PUBLIC_GOOGLE_TAG_MANAGER_ID
export const API_URL = process.env.NEXT_PUBLIC_API_URL
export const ROOT_URL = process.env.NEXT_PUBLIC_ROOT_URL
export const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;
