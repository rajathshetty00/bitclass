export const getHVCdata = (data) => {
  return {
    source: "direct",
    course_title: data.heading,
    course_price: data.price,
    course_code: data.code,
    teacher_name: data.teacher.name,
    course_type: "high-value",
    cdp_type: "high-value",
  }
}
