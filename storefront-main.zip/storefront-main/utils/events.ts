export const BIT_EVENTS = {
  joinLaunchPadClicked: "join_launch_pad_clicked",
  backBtnClicked: "launchpad_back_btn_clicked",
  teacherApplicationSubmitClicked: "teacher_application_submit_clicked",
  videoActionClicked: "video_action_clicked",
}
