import { _pageMap } from "./pages"

export const EVENT_NAMES = { CDP_LANDED: "course_description_page_viewed" }

export const getPageEventData = (path) => {
  return { page: _pageMap[path], eventName: EVENT_NAMES.CDP_LANDED }
}
export const saveDataLayerData = (data:any) => {
  // @ts-ignore
  window.dataLayer?.push(data)
}

