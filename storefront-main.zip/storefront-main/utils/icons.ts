export const ICONS = {
  plus: "https://res.cloudinary.com/bitclass/image/upload/v1628879181/Assets/empty-image/plus_yvluug.svg",
  minusRed:
    "https://res.cloudinary.com/bitclass/image/upload/v1628879150/Assets/empty-image/minusRed_rhm08z.svg",
}