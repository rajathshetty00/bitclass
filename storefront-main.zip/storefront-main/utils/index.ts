import axios from "axios"
import { ImageLoaderProps } from "next/image"
import { API_URL } from "./constants"

export const arrayFromNumber = (number: Number) =>
  Array.from(Array(number), (_, i) => i + 1)

export const optimizeImage = ({
  src,
  width,
  quality = 75,
}: ImageLoaderProps) => {
  if (
    (src.includes("https") || src.includes("http")) &&
    src.includes("cloudinary")
  ) {
    if (!src.includes("https")) {
      // eslint-disable-next-line no-param-reassign
      src = src.replace("http", "https")
    }
    const optimizeURL: any = src.split("upload/")
    const endingUrl: string | [] = optimizeURL[1].split("/").slice(-3).join("/")
    return [
      optimizeURL[0],
      `upload/w_${width},q_${quality},f_auto/`,
      endingUrl,
    ].join("")
  }
  return src
}
export const optimizeCloudinaryImage = ({
  src,
  width,
  quality = 75,
}: ImageLoaderProps) => {
  if (
    (src.includes('https') || src.includes('http')) &&
    src.includes('cloudinary')
  ) {
    if (!src.includes('https')) {
      // eslint-disable-next-line no-param-reassign
      src = src.replace('http', 'https');
    }
    const optimizeURL: any = src.split('upload/');
    const endingUrl: string | [] = optimizeURL[1]
      .split('/')
      .slice(-3)
      .join('/');
    return [
      optimizeURL[0],
      `upload/w_${width},q_${quality},f_auto/`,
      endingUrl,
    ].join('');
  }
  return src;
};

export const initDefaultsRequestHeader = () => {
  axios.defaults.baseURL = API_URL
  axios.defaults.headers.common["platform"] = "web"
  axios.defaults.timeout = 5000
  axios.defaults.headers.post["Content-Type"] =
    "application/x-www-form-urlencoded"
}
