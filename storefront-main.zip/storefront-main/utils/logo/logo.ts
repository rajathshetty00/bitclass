import { EVENTS, LOGOS } from 'utils/logo/logoData';

const CURRENT_LOGO_STATE: string = EVENTS.noEvent;

export const LOGO = LOGOS[CURRENT_LOGO_STATE].logo;
export const LOGO_ICON = LOGOS[CURRENT_LOGO_STATE].icon;
