import { NextRouter, useRouter } from 'next/router';
import { actionCheckRegistration } from 'redux/actions/cdpActions';
import { setModalState, setPlainModalState } from 'redux/reducers/appReducer';
import {
  initialSignInPageViewed,
  onPostLogin,
  startLogin,
} from 'redux/reducers/authReducer';
import {
  clearSelectedBatchDetails,
  updateBatches,
  updateCurriculumCheckoutBtnType,
} from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { getCurriculumGTMData, getHrefLink } from 'utils';
import { hasAuthToken } from 'utils/auth/userInfo';
import { BASE_URL } from 'utils/constants';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';

export const handleRegisteredUser = (
  { course_registration, workshop_registration }: any,
  key: string,
  router: NextRouter,
) => {
  if (key === 'course_batches') {
    if (!course_registration) return;
    if (course_registration?.is_live)
      window.location.href = getHrefLink(
        `${BASE_URL}/live-classes/classroom/${course_registration?.course_code}`,
        router,
      );
    else window.location.href = getHrefLink(`${BASE_URL}/profile`, router);
  } else {
    if (!workshop_registration) return;
    if (workshop_registration?.is_live)
      window.location.href = getHrefLink(
        `${BASE_URL}/live-classes/classroom/${workshop_registration?.course_code}`,
        router,
      );
    else window.location.href = getHrefLink(`${BASE_URL}/profile`, router);
  }
};

const useCheckout = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();

  const { course, courseRegistrationDetails } = useAppSelector(
    (state: AppState) => state.cdp,
  );

  const { full_course_amount } = course;
  const { course_registration, workshop_registration } =
    courseRegistrationDetails;

  const initiateLogin = (fn: Function) => {
    dispatch(setModalState(true));
    dispatch(initialSignInPageViewed(true));
    dispatch(startLogin(true));
    dispatch(
      onPostLogin(() => {
        fn();
      }),
    );
  };
  const getFullCourseButtonText = () => {
    if (!course_registration)
      return `Buy the full course for ₹${full_course_amount}`;
    if (course_registration?.is_live) return `Go to LIVE Class`;
    return 'Go to My Classes';
  };
  const getFreeCourseButtonText = () => {
    if (!workshop_registration) return 'Book A Free Class';
    if (workshop_registration?.is_live) return 'Go to LIVE Workshop';
    return 'Go to My Classes';
  };
  const initiateCheckout = async (key: string) => {
    dispatch(updateCurriculumCheckoutBtnType(key));
    if (hasAuthToken()) {
      handleRegisteredUser(courseRegistrationDetails, key, router);
      const { payload } = await dispatch(actionCheckRegistration(course.code));
      const { course_registration: crs, workshop_registration: wrs } =
        payload.data;

      if (
        (crs && key === 'course_batches') ||
        (wrs && key === 'workshop_batches')
      )
        return;
    }
    saveGtmDataLayerData({
      event: EVENT_NAMES.COURSE_SLOT_SELECTION_POPUP_VIEWED,
      curriculumCdpDetails: getCurriculumGTMData(course),
    });
    dispatch(clearSelectedBatchDetails());
    dispatch(setPlainModalState(true));
    dispatch(updateBatches(course[key]));
  };
  const initiatePaidCheckout = () => initiateCheckout('course_batches');

  const initiateFreeCheckout = () => initiateCheckout('workshop_batches');

  return {
    initiatePaidCheckout,
    initiateFreeCheckout,
    getFullCourseButtonText,
    getFreeCourseButtonText,
    initiateLogin,
  };
};

export default useCheckout;
