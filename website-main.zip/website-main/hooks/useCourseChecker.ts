import { savePageType } from 'redux/reducers/appReducer';
import {
  saveCourseData,
  saveSelectedTmprSlot,
} from 'redux/reducers/cdpReducer';
import { BASE_URL } from 'utils/constants';
import { CDP_TYPE } from 'utils/constants/cdp';
import PAGE_TYPES from 'utils/constants/pageTypes';

interface IuseCourseChecker {
  courseData: any;
  courseCode: string;
  dispatch: any;
}

export const courseChecker = ({
  courseData,
  courseCode,
  dispatch,
}: IuseCourseChecker) => {
  const checkCourseType = async () => {
    dispatch(
      saveCourseData({
        ...courseData,
        actualCourseUrl: `${BASE_URL}/live-classes/${courseCode}`,
      }),
    );

    if (courseData?.tmpr_code) {
      dispatch(savePageType(PAGE_TYPES.CDP_TMPR_PAGE));
      dispatch(saveSelectedTmprSlot(courseData?.slots[0]));
    } else {
      switch (courseData?.type) {
        case CDP_TYPE.subscription:
          dispatch(savePageType(PAGE_TYPES.CDP_SUBSCRIPTION_PAGE));
          break;

        case CDP_TYPE.freemium:
          dispatch(savePageType(PAGE_TYPES.CDP_FREEMIUM_PAGE));
          break;

        case CDP_TYPE.free:
          dispatch(savePageType(PAGE_TYPES.CDP_FREE_COURSE_PAGE));
          break;

        case CDP_TYPE.workshop:
          dispatch(savePageType(PAGE_TYPES.CDP_WORKSHOP_PAGE));
          break;

        default:
          dispatch(savePageType(PAGE_TYPES.CDP_FULL_COURSE_PAGE));
          break;
      }
    }
  };

  return {
    checkCourseType,
  };
};
