import { useEffect, useState } from 'react';
import { cleanQueryParam } from 'utils';
import { getResultsFromDynamicEndPoint } from 'utils/api';

interface IuseDynamicSection {
  source: string;
  sectionType?: string;
}

export const useDynamicSection = ({ source }: IuseDynamicSection) => {
  const [isLoading, setIsLoading] = useState(true);
  const [results, setResults] = useState([]);
  const [nextUrl, setNextUrl] = useState<any>(source);
  const [page, setPage] = useState(1);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const { data } = await getResultsFromDynamicEndPoint(
        cleanQueryParam(nextUrl, `page=${page}&limit=12`),
      );

      // if (sectionType === 'ImageCarouselV2') {
      //   if (data?.images?.length > 0) {
      //     // @ts-ignore
      //     setResults([...results, ...data?.images]);
      //     if (data?.images?.length === 12) {
      //       setPage(page + 1);
      //       setNextUrl(source);
      //     } else {
      //       setNextUrl(null);
      //     }
      //   }
      // }

      if (data?.length > 0) {
        // @ts-ignore
        setResults([...results, ...data]);
        if (data?.length === 12) {
          setPage(page + 1);
          setNextUrl(source);
        } else {
          setNextUrl(null);
        }
      }
    } catch (e) {
      console.log(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return {
    isLoading,
    results,
    source,
    nextUrl,
    fetchData,
  };
};
