import { useEffect } from 'react';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { saveExperimentId } from 'redux/reducers/cdpReducer';
import Cookies from 'js-cookie';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';

export const useExperiment = () => {
  const { expId } = useAppSelector((state: AppState) => state.cdp);

  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(saveExperimentId(Cookies.get('bucket-home')));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.CDP_EXPERIMENT_LANDED,
      cdpVersion: expId === 'b' ? 'minified' : 'normal',
    });
  }, [expId]);

  return {
    expId: expId ?? null,
  };
};
