import { useEffect } from 'react';
import { getUserInfo, hasAuthToken } from 'utils/auth/userInfo';
import PAGE_TYPES from 'utils/constants/pageTypes';
import {
  extractCategoryData,
  extractCdpData,
  extractCollectionData,
} from 'utils/courseAnalytics';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';

export const useGtm = (store: {
  getState: () => { (): any; new (): any; app: any; cdp: any; category: any };
}) => {
  const { pageType } = store.getState().app;

  const { course } = store.getState().cdp;

  const category = store?.getState()?.category;

  const categoryData = category?.categoryData || [];

  const categoryType = category?.categoryType || [];

  useEffect(() => {
    const timer = setTimeout(() => {
      if (hasAuthToken()) {
        saveGtmDataLayerData({
          login_info: getUserInfo(),
        });

        if (pageType === PAGE_TYPES.PROFILE_PAGE) {
          saveGtmDataLayerData({
            event: EVENT_NAMES.DASHBOARD_LANDED,
          });
        }
      }
      if (pageType === PAGE_TYPES.HOME_PAGE) {
        saveGtmDataLayerData({
          event: EVENT_NAMES.HOMEPAGE_VIEWED,
        });
      }
      if (
        pageType === PAGE_TYPES.CDP_SUBSCRIPTION_PAGE ||
        pageType === PAGE_TYPES.CDP_FREEMIUM_PAGE ||
        pageType === PAGE_TYPES.CDP_FULL_COURSE_PAGE ||
        pageType === PAGE_TYPES.CDP_FREE_COURSE_PAGE ||
        pageType === PAGE_TYPES.CDP_WORKSHOP_PAGE ||
        pageType === PAGE_TYPES.CDP_TMPR_PAGE ||
        pageType === PAGE_TYPES.CDP_CURRICULUM_PAGE
      ) {
        saveGtmDataLayerData({
          event: EVENT_NAMES.CDP_LANDED,
          data: extractCdpData(course),
        });
      }

      if (categoryType === PAGE_TYPES.COLLECTION_PAGE) {
        saveGtmDataLayerData({
          event: EVENT_NAMES.COLLECTION_PAGE_VIEWED,
          collectionData: extractCollectionData(categoryData),
        });
      }

      if (categoryType === PAGE_TYPES.CATEGORY_PAGE) {
        saveGtmDataLayerData({
          event: EVENT_NAMES.CATEGORY_PAGE_VIEWED,
          categoryData: extractCategoryData(categoryData),
        });
      }
    }, 3000);

    return () => clearTimeout(timer);

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
};
