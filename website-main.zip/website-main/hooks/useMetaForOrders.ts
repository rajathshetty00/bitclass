import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { setMetaInfoForOrders } from 'redux/reducers/appReducer';

export const useMetaForOrders = () => {
  const { meta } = useAppSelector((state: AppState) => state.app);

  const dispatch = useAppDispatch();

  const router = useRouter();

  useEffect(() => {
    const str: any = router.asPath.split('?')[1];
    const obj = Object.fromEntries(new URLSearchParams(str));
    dispatch(setMetaInfoForOrders(obj));
  }, [dispatch, router]);

  return {
    meta,
  };
};
