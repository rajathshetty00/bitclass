import { useSelector } from 'react-redux';
import { actionCheckRegistration } from 'redux/actions/cdpActions';
import {
  actionCreateOrder,
  actionGetSubscriptionPlan,
  actionRegisterUserForCourse,
} from 'redux/actions/subCdpAction';
import {
  setAlertModalState,
  setPlainModalState,
} from 'redux/reducers/appReducer';
import { checkoutUsingWallet } from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { getComplianceState } from 'utils/auth/userInfo';
import { PAYMENT_MODE } from 'utils/constants';
import PAGE_TYPES from 'utils/constants/pageTypes';
import { EVENT_NAMES, FB_PIXEL_EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { initiatePayment } from 'utils/payments/payments';

const getPixelEvent = (finalAmount: number) => {
  if (!finalAmount) return FB_PIXEL_EVENT_NAMES.FreeCourseRegistered;
  if (finalAmount < 99 && finalAmount > 0)
    return FB_PIXEL_EVENT_NAMES.CoursePurchaseSuccess;
  if (finalAmount > 99) return FB_PIXEL_EVENT_NAMES.FullCourseRegistered;
};

const saveGtmDataPostPayment = (
  finalCourseDetailsBeforePayment: any,
  external_code: string,
) => {
  const { amount, couponDiscount, bitcash } = finalCourseDetailsBeforePayment;
  const finalAmount = Math.round(amount - couponDiscount - bitcash);

  saveGtmDataLayerData({
    event: EVENT_NAMES.PAYMENT_SUCCESSFUL,
    pixelEvent: getPixelEvent(finalAmount),
    orderID: { external_code },
    amount: finalAmount,
    selectedPlan: finalCourseDetailsBeforePayment?.selectedPlan,
    orderDetails: finalCourseDetailsBeforePayment,
  });
};

export const usePayment = () => {
  const dispatch = useAppDispatch();

  const {
    course: { currency },
    couponCode,
    walletBalanceDetails,
    applicableWalletBalanceForCheckout,
    finalCourseDetailsBeforePayment,
    subscriptionSelected,
  } = useSelector((state: AppState) => state.cdp);

  const { pageType } = useSelector((state: AppState) => state?.app);
  const { complianceState } = useSelector((state: AppState) => state?.checkout);

  const { meta } = useAppSelector((state: AppState) => state.app);

  const createPayloadForOrderCreation = () => {
    return {
      coupon_code: couponCode,
      currency,
      item_list: finalCourseDetailsBeforePayment?.itemList,
      compliance_state: complianceState ?? getComplianceState(),
      bitcash: {
        is_bitcash_used: !!applicableWalletBalanceForCheckout,
        bitcash_balance_used: walletBalanceDetails?.wallet_balance,
      },
      meta,
    };
  };

  const handlePostRegistration = async () => {
    switch (pageType) {
      case PAGE_TYPES.CDP_FULL_COURSE_PAGE:
      case PAGE_TYPES.CDP_FREE_COURSE_PAGE:
      case PAGE_TYPES.CDP_WORKSHOP_PAGE:
        await dispatch(
          actionCheckRegistration(finalCourseDetailsBeforePayment?.code),
        );
        break;
      case PAGE_TYPES.CDP_SUBSCRIPTION_PAGE:
      case PAGE_TYPES.CDP_FREEMIUM_PAGE:
        await dispatch(
          actionGetSubscriptionPlan(finalCourseDetailsBeforePayment?.code),
        );
        break;
      case PAGE_TYPES.CDP_CURRICULUM_PAGE:
        await dispatch(
          actionCheckRegistration(finalCourseDetailsBeforePayment?.courseCode),
        );
        break;
      default:
        break;
    }

    dispatch(setPlainModalState(false));
    dispatch(setAlertModalState(true));
    dispatch(checkoutUsingWallet(null));
  };

  const prePayment = async () => {
    const payloadForOrder = createPayloadForOrderCreation();
    try {
      const {
        payload: { data, success },
      } = await dispatch(actionCreateOrder(payloadForOrder));

      if (success) return data;
    } catch (e) {
      return e;
    }
  };

  const postPayment = async (paymentId: any, { external_code }: any) => {
    try {
      const {
        payload: { success },
      } = await dispatch(
        actionRegisterUserForCourse({
          code: finalCourseDetailsBeforePayment?.code,
          orderId: external_code,
          paymentId,
          paymentMode: PAYMENT_MODE,
        }),
      );
      if (success) {
        await handlePostRegistration();
        saveGtmDataPostPayment(
          {
            ...finalCourseDetailsBeforePayment,
            selectedPlan: subscriptionSelected,
          },
          external_code,
        );
      } else {
        saveGtmDataLayerData({
          event: EVENT_NAMES.PAYMENT_FAILED,
        });
      }
    } catch (e) {
      return e;
    }
  };
  const finalAmount: number =
    finalCourseDetailsBeforePayment?.amount -
    finalCourseDetailsBeforePayment?.couponDiscount -
    finalCourseDetailsBeforePayment?.bitcash;

  const processPayment = () =>
    initiatePayment({
      finalCourseDetailsBeforePayment: {
        ...finalCourseDetailsBeforePayment,
        selectedPlan: subscriptionSelected,
      },
      currency: finalCourseDetailsBeforePayment?.currency ?? 'INR',
      amount: finalAmount,
      prePayment,
      postPayment,
    });
  return processPayment;
};
