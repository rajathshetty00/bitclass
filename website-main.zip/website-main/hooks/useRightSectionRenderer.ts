import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import {
  actionCheckRegistration,
  actionCheckRegistrationOfCourse,
  actionCheckRegistrationOfCourseInTmpr,
  actionGetWalletBalanceOfUser,
} from 'redux/actions/cdpActions';
import { actionGetSubscriptionPlan } from 'redux/actions/subCdpAction';
import { setPlainModalState } from 'redux/reducers/appReducer';
import {
  updateCheckoutStatus,
  saveFinalCourseDetails,
  updateRightSectionStatus,
  saveSelectedTmprSlot,
} from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch } from 'redux/store';
import { hasAuthToken } from 'utils/auth/userInfo';
import { CHECKOUT_STATES, RIGHT_SECTION_STATUS } from 'utils/constants/cdp';
import PAGE_TYPES from 'utils/constants/pageTypes';
import useCheckout from './useCheckout';
import { usePayment } from './usePayment';

export const useRightSectionRenderer = () => {
  const {
    course: {
      code,
      amount,
      currency,
      type,
      heading,
      tmpr_code: tmprCode,
      slots,
    },
    rightSectionStatus,
    subscriptionSelected,
    walletBalanceDetails,
    finalCourseDetailsBeforePayment,
    checkoutStatus,
    selectedBatch,
    selectedTmprSlot,
    curriculumCheckoutBtnType,
  } = useSelector((state: AppState) => state.cdp);

  const { pageType } = useSelector((state: AppState) => state?.app);

  const dispatch = useAppDispatch();
  const processPayment = usePayment();
  const { initiateLogin } = useCheckout();

  const fetchDataOnPageType = async () => {
    switch (pageType) {
      case PAGE_TYPES.CDP_SUBSCRIPTION_PAGE:
      case PAGE_TYPES.CDP_FREEMIUM_PAGE:
        await dispatch(actionGetSubscriptionPlan(code));
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        break;
      case PAGE_TYPES.CDP_FULL_COURSE_PAGE:
      case PAGE_TYPES.CDP_FREE_COURSE_PAGE:
      case PAGE_TYPES.CDP_WORKSHOP_PAGE:
        await dispatch(actionCheckRegistrationOfCourse(code));
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        break;
      case PAGE_TYPES.CDP_TMPR_PAGE:
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.slotSelection));

        if (hasAuthToken()) {
          await dispatch(actionCheckRegistrationOfCourseInTmpr(tmprCode));
        } else {
          dispatch(updateRightSectionStatus(RIGHT_SECTION_STATUS.TMPR));
        }
        break;
      case PAGE_TYPES.CDP_CURRICULUM_PAGE:
        await dispatch(actionCheckRegistration(code));
        if (hasAuthToken())
          dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        break;
      default:
    }
  };

  // useEffect to save final course details before order creation/slot selection/batch selection
  useEffect(() => {
    switch (pageType) {
      case PAGE_TYPES.CDP_SUBSCRIPTION_PAGE:
      case PAGE_TYPES.CDP_FREEMIUM_PAGE:
        dispatch(
          saveFinalCourseDetails({
            amount: subscriptionSelected?.selling_price,
            currency,
            itemList: [
              {
                product_id: subscriptionSelected?.id,
                product_type: type,
              },
            ],
            code,
            heading,
            originalAmount: subscriptionSelected?.selling_price,
            couponDiscount: 0,
            bitcash: 0,
          }),
        );
        break;
      case PAGE_TYPES.CDP_FULL_COURSE_PAGE:
      case PAGE_TYPES.CDP_FREE_COURSE_PAGE:
      case PAGE_TYPES.CDP_WORKSHOP_PAGE:
        dispatch(
          saveFinalCourseDetails({
            amount,
            currency,
            itemList: [
              {
                product_code: code,
                product_type: 'course',
              },
            ],
            heading,
            originalAmount: amount,
            couponDiscount: 0,
            bitcash: 0,
            code,
          }),
        );
        break;
      case PAGE_TYPES.CDP_TMPR_PAGE:
        dispatch(
          saveFinalCourseDetails({
            amount,
            currency,
            itemList: [
              {
                product_code: selectedTmprSlot?.course_code,
                product_type: 'course',
              },
            ],
            heading,
            originalAmount: amount,
            couponDiscount: 0,
            bitcash: 0,
            code: selectedTmprSlot?.course_code,
          }),
        );
        break;
      case PAGE_TYPES.CDP_CURRICULUM_PAGE:
        dispatch(
          saveFinalCourseDetails({
            amount: selectedBatch?.amount ?? 0,
            currency,
            itemList: [
              {
                product_code: selectedBatch?.course_code,
                product_type: 'course',
              },
            ],
            heading,
            originalAmount: selectedBatch?.amount ?? 0,
            couponDiscount: 0,
            bitcash: 0,
            code: selectedBatch?.course_code,
            courseCode: code,
          }),
        );
        break;
      default:
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subscriptionSelected, selectedBatch]);

  // useEffect to get wallet of user and setting maximum cap user can use
  useEffect(() => {
    (async () => {
      if (finalCourseDetailsBeforePayment?.amount && hasAuthToken()) {
        await dispatch(
          actionGetWalletBalanceOfUser(finalCourseDetailsBeforePayment?.amount),
        );
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // this function is to handle cta click on footer during checkout flow
  // starts here
  const checkoutFooterHandler = async () => {
    // check wether user is logged in
    if (!hasAuthToken()) {
      return initiateLogin(checkoutFooterHandler);
    }

    if (pageType === PAGE_TYPES.CDP_CURRICULUM_PAGE) {
      const { payload } = await dispatch(actionCheckRegistration(code));
      const { course_registration: crs, workshop_registration: wrs } =
        payload.data;
      if (
        (crs && curriculumCheckoutBtnType === 'course_batches') ||
        (wrs && curriculumCheckoutBtnType === 'workshop_batches')
      ) {
        dispatch(setPlainModalState(false));
      }
    }
    // slot selection and curriculum registration check block
    if (pageType === PAGE_TYPES.CDP_TMPR_PAGE) {
      const {
        payload: { data },
      } = await dispatch(actionCheckRegistrationOfCourseInTmpr(tmprCode));

      if (data?.is_registered) {
        return dispatch(setPlainModalState(false));
      }
    }
    // else

    // check to see if user is in slot selection/batch selection page
    if (
      checkoutStatus === CHECKOUT_STATES.slotSelection ||
      checkoutStatus === CHECKOUT_STATES.batchSelection
    ) {
      if (finalCourseDetailsBeforePayment?.amount > 0) {
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        return;
      }
      // logic to direct user toends here =====
    }
    return processPayment();
  };
  // checkoutfooterhandler ends=========

  // function will be invoked to check original price on the basis of course type before wallet/coupon application
  // starts here=======
  const orderSummaryHandler = () => {
    const price = finalCourseDetailsBeforePayment?.amount ?? 0;
    const { bitcash, couponDiscount } = finalCourseDetailsBeforePayment;
    const couponContainerVisibility = price > 0 && price - bitcash > 0;
    const walletBalanceVisibility =
      walletBalanceDetails?.applicable_wallet_balance > 0 &&
      price > 0 &&
      walletBalanceDetails?.wallet_balance > 0;

    return {
      price,
      couponContainerVisibility,
      pageType,
      currency,
      couponDiscount,
      walletBalanceDetails,
      walletBalanceVisibility,
    };
  };
  // ends here=======

  // this handler will initialise checkoutmodal state to default state based on pagetype
  const initialiseCheckoutModal = () => {
    switch (pageType) {
      case PAGE_TYPES.CDP_SUBSCRIPTION_PAGE:
      case PAGE_TYPES.CDP_FREEMIUM_PAGE:
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        break;
      case PAGE_TYPES.CDP_FULL_COURSE_PAGE:
      case PAGE_TYPES.CDP_FREE_COURSE_PAGE:
      case PAGE_TYPES.CDP_WORKSHOP_PAGE:
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        break;
      case PAGE_TYPES.CDP_TMPR_PAGE:
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.slotSelection));
        dispatch(saveSelectedTmprSlot(slots[0]));
        break;
      case PAGE_TYPES.CDP_CURRICULUM_PAGE:
        dispatch(updateCheckoutStatus(CHECKOUT_STATES.orderSummary));
        break;
      default:
    }
  };

  return {
    rightSectionStatus,
    orderSummaryHandler,
    checkoutFooterHandler,
    fetchDataOnPageType,
    initialiseCheckoutModal,
  };
};
