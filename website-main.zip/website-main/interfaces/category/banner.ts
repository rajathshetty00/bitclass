interface IBanner {
  mobile: string;
  web: string;
}

export interface ICategoryBanner {
  heading: string;
  description?: string;
  banner: IBanner;
  course_count?: number;
  teacher_count?: number;
  circular_icon: string;
}
