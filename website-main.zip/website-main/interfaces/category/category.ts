import { ICategoryBanner } from './banner';

export interface ICategory {
  categoryData: {
    meta: ICategoryBanner;
    section: any;
  };
}
