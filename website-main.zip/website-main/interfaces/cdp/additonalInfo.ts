export interface IAdditional {
  live_class_hours: string;
  certificate_available?: string;
  course_learning_level?: string;
  is_emi_available?: boolean;
}
