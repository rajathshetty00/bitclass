import { ICurriculum } from 'interfaces/curriculumCdp/curriculum';
import { IBatch } from 'interfaces/curriculumCdp/batch';

export interface IInitialState {
  course: ICurriculum;
  subscriptionPlans: null;
  isSubscriptionExists: boolean;
  subscriptionSelected: {};
  pending: boolean;
  error: boolean;
  message: string;
  orderDetails: null;
  registeredDetails: null;
  couponPending: boolean;
  couponData: null;
  couponCode: string;
  subPlanSuccess: boolean;
  checkoutStatus: string;
  batchesList: IBatch[];
  selectedBatch: IBatch;
  courseRegistrationStatus: {};
}
