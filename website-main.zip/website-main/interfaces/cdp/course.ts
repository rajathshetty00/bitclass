export interface ICourse {
  heading: string;
  intro_video_thumbnail: string;
  course_url: string;
  teacher: { name: string; image: string; storefront_url: string };
}
