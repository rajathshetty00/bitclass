export interface IFaq {
  ans: string;
  que: string;
}
