export interface IPaymentItem {
  [key: string]: string;
}
