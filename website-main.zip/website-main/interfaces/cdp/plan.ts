/* eslint-disable camelcase */
export interface IPlan {
  id: number;
  selling_price: number;
  type: string;
  currency: string;
  duration: number;
  classes: number;
}
