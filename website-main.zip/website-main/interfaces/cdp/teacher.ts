/* eslint-disable camelcase */
export interface ITeacher {
  teacher_name: string;
  profile_id: string;
  story: string;
  image: string;
  code: string;
}
