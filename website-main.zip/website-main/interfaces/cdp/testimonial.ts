export interface ITestimonial {
  student_name: string;
  testimonial: string;
}
