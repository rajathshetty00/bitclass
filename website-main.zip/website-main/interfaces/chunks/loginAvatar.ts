export interface ILogin {
  userData: any;
  showAccountMenu?: any;
}
