export interface IClassRoomMetaData {
  amount: number;
  heading: string;
  max_students: number;
  type: string;
}
export interface IDisclaimers {
  highlighted_text: string;
  info_text: string;
}
export interface IZoomConfig {
  meetingNumber: string;
  passWord: string;
  signature: string;
  initCode: string;
  initKey: string;
  userEmail: string;
  userName: string;
  customerKey: string;
}
export interface IZoomToken {
  class_end_ts: number;
  class_start_ts: number;
  classroom_metadata: IClassRoomMetaData;
  classroom_provider: string;
  disclaimers: IDisclaimers[];
  external_lesson_password: string;
  external_lesson_url: string;
  feedback_threshold_time: number;
  initialization_code: string;
  initialization_key: string;
  is_admin: boolean;
  is_class_started: boolean;
  is_teacher: boolean;
  is_zoom_engagement: boolean;
  meeting_id: string;
  meeting_password: string;
  meeting_signature: string;
  teacher_zoom_engagement: boolean;
  use_zoom_sdk: boolean;
  user_stream_id: number;
}
