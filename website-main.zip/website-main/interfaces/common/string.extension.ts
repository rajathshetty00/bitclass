/* eslint-disable no-extend-native */
/* eslint-disable no-unused-vars */
declare global {
  interface String {
    is: (value: string) => boolean;
  }
}
String.prototype.is = function is(value: string) {
  console.log(this);
  return this[0] === value;
};
export {};
