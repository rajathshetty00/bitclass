// CurriculumCdp About teacher  interface

export interface IAboutTeacherContent {
  title: string;
  subtitle: string;
  description: string;
  image: string;
}
export interface IAboutTeacher {
  order: number;
  title: string;
  subtitle: string;
  content: IAboutTeacherContent[];
}
