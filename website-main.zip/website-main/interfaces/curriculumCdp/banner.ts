export interface IBanner {
  intro_video_thumbnail: string | null;
  intro_video: string | null;
}
