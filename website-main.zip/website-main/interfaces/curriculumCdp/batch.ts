import { ITeacher } from '../cdp/teacher';

export interface IBatch {
  course_code: string;
  batch_code: string;
  heading: string;
  slug: null | string;
  amount: Number;
  currency: null | string;
  lesson_duration: Number;
  epoch_schedule: Array<number>;
  start_date: string;
  end_date: string;
  timezone: string;
  teacher: ITeacher;
}
