/* eslint-disable import/no-cycle */
import { IBanner } from './banner';
import { ICertificate } from './certificate';
import { ICurriculum } from './curriculum';
import { ICurriculumCdpFaq } from './curriculumFaq';
import { IFeatured } from './feature';
import { IFreeClass } from './freeClass';
import { IShowCase } from './showCase';
import { ITestimonials } from './testimonial';
import { IWhyBitclass } from './whyBitclass';
import { IWhyBuy } from './whyBuy';

export interface ICdpSection {
  sectionData:
    | ICertificate
    | IBanner
    | IWhyBuy
    | IWhyBitclass
    | ITestimonials
    | IShowCase
    | IFreeClass
    | IFeatured
    | ICurriculumCdpFaq
    | ICurriculum;
}

export interface IBaseSection {
  order: number;
  title: string;
}
