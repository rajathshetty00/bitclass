import { IFreeClass } from 'interfaces/curriculumCdp/freeClass';
import { IWhyBuy } from 'interfaces/curriculumCdp/whyBuy';

// CurriculumCdp Certificate  interface
export interface ICertificate extends IWhyBuy, IFreeClass {
  image: string;
}
