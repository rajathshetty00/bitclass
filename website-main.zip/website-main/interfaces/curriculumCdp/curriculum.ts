import { IWhyBuy } from 'interfaces/curriculumCdp/whyBuy';

export interface ICurriculumContent {
  thumbnail_text: string;
  title: string;
  items: string[];
}
// CurriculumCdp Curriculum  interface
export interface ICurriculum extends IWhyBuy {
  duration: string;
  content: ICurriculumContent[];
}
