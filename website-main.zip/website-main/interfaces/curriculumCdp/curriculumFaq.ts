import { IFaq } from 'interfaces/cdp/faqs';

export interface ICurriculumCdpFaq {
  order: number;
  content: IFaq[];
}
