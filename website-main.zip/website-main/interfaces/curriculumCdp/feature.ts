import { IBaseSection } from 'interfaces/curriculumCdp/cdpSection';

// CurriculumCdp Feture  interface
interface IFeaturedContent {
  image: string;
  link: string;
}
export interface IFeatured extends IBaseSection {
  content: IFeaturedContent[];
}
