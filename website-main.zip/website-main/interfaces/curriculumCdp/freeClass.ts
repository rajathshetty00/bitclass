import { IBaseSection } from 'interfaces/curriculumCdp/cdpSection';

// freeClass Curriculum
export interface IFreeClass extends IBaseSection {
  description: string;
  materials_required: string[];
}
