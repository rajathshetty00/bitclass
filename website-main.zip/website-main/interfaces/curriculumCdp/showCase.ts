import { IWhyBuy } from 'interfaces/curriculumCdp/whyBuy';

export interface IShowcaseContent {
  title: string;
  subtitle: string;
  image: string;
}

export interface IShowCase extends IWhyBuy {
  content: IShowcaseContent[];
}
