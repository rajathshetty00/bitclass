import { IWhyBuy } from 'interfaces/curriculumCdp/whyBuy';

export interface ITestimonialContent {
  title: string;
  description: string;
  video_thumbnail: string;
  video: string | null;
  thumb: string;
}
// CurriculumCdp Testimonial  interface
export interface ITestimonials extends IWhyBuy {
  content: ITestimonialContent[];
}
