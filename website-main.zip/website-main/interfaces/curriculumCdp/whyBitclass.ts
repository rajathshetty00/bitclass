import { IBaseSection } from 'interfaces/curriculumCdp/cdpSection';

// CurriculumCdp Why BitClass  interface
export interface IWhyBitclassContent {
  title: string;
  image: string;
}
export interface IWhyBitclass extends IBaseSection {
  content: IWhyBitclassContent[];
}
