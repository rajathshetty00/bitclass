import { IBaseSection } from 'interfaces/curriculumCdp/cdpSection';

export interface IWhyBuy extends IBaseSection {
  subtitle: string;
}

export interface IWhyBuyContent extends IWhyBuy {
  description: string;
  image: string;
}
