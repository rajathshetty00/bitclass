interface Ianswer {
  steps?: Array<string>;
  title: string;
}
export interface IFaq {
  question: string;
  answer: Ianswer;
}
