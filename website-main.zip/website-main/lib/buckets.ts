export const HOME_BUCKETS = ['a', 'b'] as const;
