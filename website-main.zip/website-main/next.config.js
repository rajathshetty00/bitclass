const path = require('path');

module.exports = {
  basePath: process.env.BASE_PATH,
  swcMinify: false,
  images: {
    domains: ['res.cloudinary.com', 'media.bitclass.live'],
    minimumCacheTTL: 60 * 60 * 24,
  },
  async redirects() {
    return [
      {
        source: '/demo-courses/:slug/:courseCode',
        destination: '/live-classes/:courseCode',
        permanent: true,
      },
      {
        source: '/classroom/:courseCode',
        destination: '/live-classes/classroom/:courseCode',
        permanent: true,
      },
      // {
      //   source: '/referral?referred_by=:referralCode',
      //   destination: '/live-classes/signin?referred_by=:referralCode',
      //   permanent: true,
      // },
    ];
  },
  // eslint-disable-next-line no-unused-vars
  webpack(config, options) {
    config.module.rules.push({
      test: /\.svg$/,
      use: ['@svgr/webpack'],
    });
    config.resolve.modules.push(path.resolve('./'));

    return config;
  },
};
