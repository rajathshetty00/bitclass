import { NextRequest, NextResponse } from 'next/server';
import { getBucket } from 'lib/ab-testing';
import { HOME_BUCKETS } from 'lib/buckets';

const COOKIE_NAME = 'bucket-home';

const ALLOWED_TMPR_CODES = ['dummy'];

export function middleware(req: NextRequest) {
  // Get the bucket cookie
  const bucket = req.cookies[COOKIE_NAME] || getBucket(HOME_BUCKETS);
  const url = req.nextUrl.clone();
  const res = NextResponse.next();
  const courseCode = url.pathname;

  if (ALLOWED_TMPR_CODES.includes(courseCode)) {
    // Add the bucket to cookies if it's not there
    if (!req.cookies[COOKIE_NAME]) {
      return res.cookie(COOKIE_NAME, bucket);
    }
    return res;
  }
  if (courseCode.startsWith('/TMP') || courseCode.startsWith('/C')) {
    return res.clearCookie(COOKIE_NAME);
  }
}
