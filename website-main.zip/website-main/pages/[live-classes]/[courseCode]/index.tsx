/* eslint-disable no-fallthrough */
/* eslint-disable camelcase */
import { NextPage } from 'next';
import CDPLayout from 'src/layouts/CDP/CDPLayout/CDPLayout';
import ChangingBackground from 'src/layouts/CDP/ChangingBackground/ChangingBackground';
import { AppState, initializeStore } from 'redux/store';
import { saveDeviceInfo } from 'redux/reducers/appReducer';
import { saveCourseData } from 'redux/reducers/cdpReducer';
import { getUserAgent, routeToNotFoundPage } from 'utils';
import { getFullCourseV3, getCdpTmprDataV3 } from 'utils/api';
import { useSelector } from 'react-redux';
import dynamic from 'next/dynamic';
import Script from 'next/script';
import { BASE_URL, RAZORPAY_SDK_URL } from 'utils/constants';
import { useMetaForOrders } from 'hooks/useMetaForOrders';
import NextHead from 'src/components/common/NextHead/NextHead';
import { courseChecker } from 'hooks/useCourseChecker';
import axios from 'axios';
import styles from './styles.module.scss';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

const CDP: NextPage = () => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  useMetaForOrders();

  return (
    <div>
      <Script src={RAZORPAY_SDK_URL} strategy="lazyOnload" defer />
      <NextHead />
      <DynamicBitAppHeader />
      <div className={styles.cdpBody}>
        <ChangingBackground />
        <CDPLayout isMobile={isMobile} />
      </div>
    </div>
  );
};

export default CDP;
export const getServerSideProps = async (context: any) => {
  let courseData;
  let data;
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));
  const { query } = context;

  const { courseCode } = context.params;
  axios.interceptors.request.use(
    (request) => {
      request.params = query;
      return request;
    },
    (error) => {
      return Promise.reject(error);
    },
  );

  // code below this line checks if cdp is tmpr/full-course/subscription/free/workshop and assign it a type
  try {
    if (courseCode.startsWith('TMPR')) {
      data = await getCdpTmprDataV3(courseCode);
    } else {
      data = await getFullCourseV3(courseCode);
    }

    courseData = { ...data.data };

    // if-else block to either see if data is fetched  or course-not-found is shown
    if (data.success || courseData?.tmpr_code) {
      dispatch(
        saveCourseData({
          ...courseData,
          actualCourseUrl: `${BASE_URL}/live-classes/${courseCode}`,
        }),
      );

      const { checkCourseType } = courseChecker({
        courseData,
        courseCode,
        dispatch,
      });
      checkCourseType();
    } else {
      routeToNotFoundPage(context.res);
    }
  } catch (error) {
    routeToNotFoundPage(context.res);
  }

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};
