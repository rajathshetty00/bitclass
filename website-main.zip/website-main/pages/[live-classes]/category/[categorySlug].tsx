import axios from 'axios';
import React, { FC } from 'react';
import {
  saveCategories,
  saveDeviceInfo,
  savePageType,
  updateSelectedCategory,
} from 'redux/reducers/appReducer';
import {
  saveCategoryData,
  saveCategoryType,
} from 'redux/reducers/categoryReducer';
import { initializeStore } from 'redux/store';
import CategoryLayout from 'src/layouts/CategoryLayout/CategoryLayout';
import { getUserAgent, routeToNotFoundPage } from 'utils';
import { getAllCategories, getCategoryPublicData } from 'utils/api';
import PAGE_TYPES from 'utils/constants/pageTypes';

interface CategoryProps {}

const Category: FC<CategoryProps> = () => {
  return <CategoryLayout />;
};

export default Category;

export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString: any = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));
  const { query } = context;
  axios.interceptors.request.use(
    (request) => {
      request.params = query;
      return request;
    },
    (error) => {
      return Promise.reject(error);
    },
  );
  const { categorySlug } = context.params;

  try {
    const categories = await getAllCategories();
    dispatch(saveCategories(categories.data));
  } catch (error) {
    console.error(error);
  }
  try {
    const { data, success } = await getCategoryPublicData(categorySlug);
    if (success) {
      dispatch(saveCategoryData(data));
      dispatch(saveCategoryType(PAGE_TYPES.CATEGORY_PAGE));
      dispatch(savePageType(PAGE_TYPES.CATEGORY_PAGE));
      dispatch(updateSelectedCategory(categorySlug));
    } else {
      routeToNotFoundPage(context.res);
    }
  } catch (e) {
    routeToNotFoundPage(context.res);
  }

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};
