import dynamic from 'next/dynamic';
import { saveDeviceInfo, savePageType } from 'redux/reducers/appReducer';
import { initializeStore } from 'redux/store';
import { getUserAgent, routeToNotFoundPage } from 'utils';
import { getCurriculumDetails } from 'utils/api';
import { saveCourseData } from 'redux/reducers/cdpReducer';
import PAGE_TYPES from 'utils/constants/pageTypes';
import CurriculumCdpLayout from 'src/layouts/CurriculumCdp/CurriculumCdpLayout/CurriculumCdpLayout';
import NextHead from 'src/components/common/NextHead/NextHead';
import { useMetaForOrders } from 'hooks/useMetaForOrders';
import styles from './styles.module.scss';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);
const CurriculumCdpPage = () => {
  useMetaForOrders();

  return (
    <>
      <NextHead />
      <DynamicBitAppHeader customClass={styles.customHeader} />
      <CurriculumCdpLayout />
    </>
  );
};

export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));
  const { courseCode } = context.params;
  try {
    const { data: courseData, success } = await getCurriculumDetails(
      courseCode,
    );
    if (success) {
      dispatch(saveCourseData(courseData));
      dispatch(savePageType(PAGE_TYPES.CDP_CURRICULUM_PAGE));
    } else {
      routeToNotFoundPage(context.res);
    }
  } catch (error) {
    return error;
  }
  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};

export default CurriculumCdpPage;
