import { IZoomToken } from 'interfaces/classroom';
import { useRouter } from 'next/router';
// import dynamic from 'next/dynamic';
import { useEffect, memo } from 'react';
import {
  saveZoomEngagementData,
  saveZoomTokenData,
  updatePending,
} from 'redux/reducers/classroomReducer';
import { initializeStore, useAppDispatch } from 'redux/store';
import Classroom from 'src/layouts/ClassRoom/Classroom';
import { getStreamingTokenGeneric, getZoomEngagementData } from 'utils/api';
import axios, { AxiosRequestConfig } from 'axios';
import { exists, getCookie, getUserAgent, loginWithAuthToken } from 'utils';
import { saveDeviceInfo } from 'redux/reducers/appReducer';
import { GetServerSideProps } from 'next';

function ClassRoom({ courseCode }: any) {
  const dispatch = useAppDispatch();
  // Cookie Login
  const router = useRouter();
  const { _auth } = router.query;

  useEffect(() => {
    (async () => {
      if (!getCookie('auth-key') && exists(_auth)) {
        loginWithAuthToken(_auth);
      }
      try {
        const { data: zoomTokenData } = await getStreamingTokenGeneric(
          courseCode,
        );
        const zoomToken: IZoomToken = zoomTokenData;
        const { data: zoomEngagementData, success } =
          await getZoomEngagementData(courseCode);
        if (success) {
          dispatch(saveZoomEngagementData(zoomEngagementData));
          if (zoomToken.is_admin && !zoomEngagementData.pre_class_instruction)
            return window.location.replace(zoomToken.external_lesson_url);
        }
        dispatch(saveZoomTokenData(zoomToken));
        dispatch(updatePending());
      } catch (error) {
        console.log('error while fechig data ', error);
        // console.error(error);
      }
    })();
  }, [_auth, courseCode, dispatch]);

  return <Classroom />;
}

export default memo(ClassRoom);

export const getServerSideProps: GetServerSideProps = async (context: any) => {
  context.res.setHeader('Cross-origin-Embedder-Policy', 'require-corp');
  context.res.setHeader('Cross-origin-Opener-Policy', 'same-origin');
  const { query } = context;
  axios.interceptors.request.use(
    (request: AxiosRequestConfig) => {
      request.params = query;
      return request;
    },
    (error) => {
      return Promise.reject(error);
    },
  );

  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));

  return {
    props: {
      courseCode: context.query.courseCode,
      initialReduxState: reduxStore.getState(),
    },
  };
};
