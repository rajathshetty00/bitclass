import axios from 'axios';
import { saveDeviceInfo, savePageType } from 'redux/reducers/appReducer';
import {
  saveCategoryData,
  saveCategoryType,
} from 'redux/reducers/categoryReducer';
import { initializeStore } from 'redux/store';
import CategoryLayout from 'src/layouts/CategoryLayout/CategoryLayout';
import { getUserAgent, routeToNotFoundPage } from 'utils';
import { getCollectionPublicData } from 'utils/api';
import PAGE_TYPES from 'utils/constants/pageTypes';

const CollectionPage = () => {
  return <CategoryLayout />;
};

export default CollectionPage;

export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString: any = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));
  const { query } = context;
  axios.interceptors.request.use(
    (request) => {
      request.params = query;
      return request;
    },
    (error) => {
      return Promise.reject(error);
    },
  );

  const { collectionSlug } = context.params;

  try {
    const { data, success } = await getCollectionPublicData(collectionSlug);
    if (success) {
      dispatch(saveCategoryData(data));
      dispatch(saveCategoryType(PAGE_TYPES.COLLECTION_PAGE));
      dispatch(savePageType(PAGE_TYPES.COLLECTION_PAGE));
    } else {
      routeToNotFoundPage(context.res);
    }
  } catch (e) {
    routeToNotFoundPage(context.res);
  }

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};
