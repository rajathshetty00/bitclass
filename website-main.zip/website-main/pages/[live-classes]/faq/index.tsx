import dynamic from 'next/dynamic';
import { saveStudentFaqData } from 'redux/reducers/faqReducer';
import { initializeStore } from 'redux/store';
import FAQLayout from 'src/layouts/FAQ/FAQLayout/FAQLayout';
import { routeToNotFoundPage } from 'utils';
import { getMyFaqList } from 'utils/api';
import styles from './styles.module.scss';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);
const FaqPage = () => {
  return (
    <div>
      <DynamicBitAppHeader />
      <div className={styles.faqBody}>
        <FAQLayout />
      </div>
    </div>
  );
};

export default FaqPage;
export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  try {
    const { data: studentfaqs, success } = await getMyFaqList();
    if (success) {
      dispatch(saveStudentFaqData(studentfaqs));
    } else {
      routeToNotFoundPage(context.res);
    }
  } catch (error) {
    return error;
  }

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};
