import dynamic from 'next/dynamic';
import BitPolicy from 'src/components/common/BitPolicy/BitPolicy';
import styles from './styles.module.scss';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

const Policy = () => {
  return (
    <main id="policy" className={styles.policyContainer}>
      <DynamicBitAppHeader />
      <BitPolicy />
    </main>
  );
};

export default Policy;
