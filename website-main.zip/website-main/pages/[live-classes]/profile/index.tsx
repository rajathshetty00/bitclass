import React, { FC } from 'react';
import { saveDeviceInfo, savePageType } from 'redux/reducers/appReducer';
import { AppState, initializeStore, useAppSelector } from 'redux/store';
import DesktopProfileLayout from 'src/layouts/ProfileLayout/DesktopProfileLayout';
import MobileProfileLayout from 'src/layouts/ProfileLayout/MobileProfileLayout';
import { getUserAgent } from 'utils';
import PAGE_TYPES from 'utils/constants/pageTypes';

interface ProfileProps {}

const Profile: FC<ProfileProps> = () => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );
  return <>{isMobile ? <MobileProfileLayout /> : <DesktopProfileLayout />}</>;
};

export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));
  dispatch(savePageType(PAGE_TYPES.PROFILE_PAGE));

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};

export default Profile;
