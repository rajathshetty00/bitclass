/* eslint-disable jsx-a11y/media-has-caption */
import dynamic from 'next/dynamic';
// import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
// import { saveDeviceInfo } from 'redux/reducers/appReducer';
import { saveVideoDoc } from 'redux/reducers/recordingsReducer';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import SocialShareLink from 'src/components/common/SocialShareLink/SocialShareLink';
// import { getUserAgent, routeToNotFoundPage } from 'utils';
import { getRecordingDetailsById } from 'utils/api';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

const RecordingPlayer = ({ recordingId, url }: any) => {
  const dispatch = useDispatch();
  const { viewsCount, vidDoc } = useAppSelector(
    (state: AppState) => state.recordings,
  );

  useEffect(() => {
    if (!recordingId) return;
    (async () => {
      try {
        const { data } = await getRecordingDetailsById(recordingId);
        dispatch(saveVideoDoc(data));
      } catch (error) {
        // error
      }
    })();
  }, []);

  return (
    <div>
      <DynamicBitAppHeader />
      <div className={styles.player}>
        {vidDoc?.url && (
          <video controls width="100%" height="400" controlsList="nodownload">
            <source src={vidDoc?.url} />
          </video>
        )}
        <div className={styles.details}>
          {vidDoc?.teacher_name && (
            <div className={styles.teacherDetails}>
              <div className={styles.profileImage} />
              {vidDoc?.teacher_image && (
                <NextImage src={vidDoc?.teacher_image} width={35} height={35} />
              )}
              <div className={styles.teacher}>
                <h6>Taught by</h6>
                <h5>{vidDoc?.teacher_name}</h5>
              </div>
            </div>
          )}
          <h3 className={styles.title}>{vidDoc?.title}</h3>
          <div className={styles.views}>
            <span className={styles.viewsCount}>{viewsCount} Views</span>
          </div>
          <div className={styles.share}>
            <h4>Share</h4>
            <hr />
            <SocialShareLink
              linkUrl={url}
              linkText={`Check out this course on BitClass - ${vidDoc?.title}`}
              page="recording"
              contentID=""
              contentType="course"
              hideTitle
              className={styles.socialContainer}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export const getServerSideProps = async (context: any) => {
  const { recordingId } = context.query;

  return {
    props: {
      recordingId,
      url: `${BASE_URL}${context.req.url}`,
    },
  };
};

export default RecordingPlayer;
