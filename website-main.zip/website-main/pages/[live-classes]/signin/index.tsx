import { useRouter } from 'next/router';
import React, { FunctionComponent, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { setModalState, saveDeviceInfo } from 'redux/reducers/appReducer';
import {
  initialSignInPageViewed,
  onPostLogin,
  startLogin,
} from 'redux/reducers/authReducer';

import { AppState, initializeStore, useAppDispatch } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import LoginComponent from 'src/components/Login/LoginComponent';
import { getHrefLink, getUserAgent } from 'utils';
import { assetObject } from 'utils/assetFileNames';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';

interface SigninProps {}

const Signin: FunctionComponent<SigninProps> = () => {
  const {
    deviceInfo: { isMobile },
  } = useSelector((state: AppState) => state?.app);

  const dispatch = useAppDispatch();
  const router = useRouter();

  const { loginData } = useSelector((state: AppState) => state?.app);

  const onLoginSuccess = () => {
    if (!loginData?.signup_reward) {
      if (document.referrer) {
        window.location.href = document.referrer;
      } else {
        window.location.href = getHrefLink('/', router);
      }
    }
  };

  dispatch(setModalState(true));
  dispatch(initialSignInPageViewed(true));
  dispatch(onPostLogin(onLoginSuccess));
  dispatch(startLogin(true));

  useEffect(() => {
    saveGtmDataLayerData({
      data: { source: '/signin' },
      eventName: EVENT_NAMES.LOGIN_VIEWED,
    });
  }, []);

  return (
    <div>
      <div className={styles.loginPageWrapper}>
        <div className={styles.loginPageHeader}>
          <NextImage
            src={!isMobile ? assetObject.logoDark : assetObject.logoDarkSmall}
            width={!isMobile ? '108px' : '48px'}
            height={!isMobile ? '40px' : '48px'}
          />
        </div>
        <div className={styles.loginPageContent}>
          <div className={styles.loginPageContentLeft}>
            <img
              src={assetObject.loginPlaceholderBg}
              alt="icon"
              className={styles.placeholderBg}
            />

            <div className={styles.logoInfoBlock}>
              <h2>
                Welcome To <span>BitClass</span>
              </h2>
              <p>
                <span>Your Time</span>
                <span className={styles.dot} />
                <span>Your Space</span>
                <span className={styles.dot} />
                <span>Your Growth</span>
              </p>
            </div>
          </div>
          <div className={styles.loginPageContentRight}>
            <div className={styles.loginFormContainer}>
              <LoginComponent wrapModal={false} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};

export default Signin;
