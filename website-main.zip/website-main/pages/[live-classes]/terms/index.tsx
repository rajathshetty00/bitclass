import dynamic from 'next/dynamic';
import BitTerm from 'src/components/common/BitTerm/BitTerm';
import styles from './styles.module.scss';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

const Terms = () => {
  return (
    <main id="terms" className={styles.termContainer}>
      <DynamicBitAppHeader />
      <BitTerm />
    </main>
  );
};

export default Terms;
