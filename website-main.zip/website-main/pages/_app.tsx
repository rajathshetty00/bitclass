import 'styles/globals.scss';
import type { AppProps } from 'next/app';
import { Provider } from 'react-redux';
import theme from 'themes/theme';
import { useStore } from 'redux/store';
import { CssBaseline, ThemeProvider } from '@mui/material';
import { GTM_ID } from 'utils/constants';
import BitFooter from 'src/components/common/Footer/BitFooter';
import { FC } from 'react';
import { StyledEngineProvider } from '@mui/material/styles';
import { useGtm } from 'hooks/useGtm';
import axios, { AxiosError, AxiosRequestConfig, AxiosResponse } from 'axios';
import { getReqParams } from 'utils/api/request';
import Axios, { errorHandler, responseHandler } from 'utils/api/axios';

const requestHandler = (request: AxiosRequestConfig) => {
  if (typeof window !== 'undefined') {
    request.params = { ...getReqParams(), ...request?.params };
  }
  return request;
};

Axios.interceptors.request.use(
  (request: AxiosRequestConfig) => requestHandler(request),
  (error: AxiosError) => Promise.reject(error),
);

axios.interceptors.request.use(
  (request: AxiosRequestConfig) => requestHandler(request),
  (error) => Promise.reject(error),
);

axios.interceptors.response.use(
  (response) => responseHandler(response),
  (error) => errorHandler(error),
);
Axios.interceptors.response.use(
  (response: AxiosResponse) => responseHandler(response),
  (error: AxiosError) => errorHandler(error),
);

const MyApp: FC<AppProps> = ({ Component, pageProps }) => {
  const store = useStore(pageProps.initialReduxState);
  useGtm(store);
  return (
    <Provider store={store}>
      <StyledEngineProvider>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          <noscript>
            <iframe
              title="gtm"
              src={`https://www.googletagmanager.com/ns.html?id=${GTM_ID}`}
              height="0"
              width="0"
              style={{ display: 'none', visibility: 'hidden' }}
            />
          </noscript>
          <Component {...pageProps} />
          <BitFooter />
        </ThemeProvider>
      </StyledEngineProvider>
    </Provider>
  );
};
export default MyApp;
