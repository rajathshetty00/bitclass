import { NextPage } from 'next';
import { useEffect } from 'react';
import {
  saveCategories,
  saveDeviceInfo,
  savePageType,
  saveTopTeachers,
} from 'redux/reducers/appReducer';
import { saveCategoryData } from 'redux/reducers/categoryReducer';
import { initializeStore, useAppDispatch } from 'redux/store';
import CategoryLayout from 'src/layouts/CategoryLayout/CategoryLayout';
import { getUserAgent } from 'utils';
import {
  getAllCategories,
  getCategoryPublicData,
  getTeacherList,
} from 'utils/api';
import PAGE_TYPES from 'utils/constants/pageTypes';

import StaticContentLayout from 'src/layouts/Homepage/StaticContentLayout';
import axios from 'axios';
import HamburgerLayout from 'src/layouts/Homepage/HamburgerLayout/HamburgerLayout';

const Home: NextPage = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    (async () => {
      try {
        const categories = await getAllCategories();
        dispatch(saveCategories(categories.data));
      } catch (error) {
        console.error(error);
      }
    })();
  }, [dispatch]);

  return (
    <div>
      <CategoryLayout />
      <StaticContentLayout />
      <HamburgerLayout />
    </div>
  );
};
export default Home;

export const getServerSideProps = async (context: any) => {
  const reduxStore = initializeStore({});
  const { dispatch } = reduxStore;
  const uaString: any = context.req.headers['user-agent'];
  dispatch(saveDeviceInfo(getUserAgent(uaString)));
  const { query } = context;
  axios.interceptors.request.use(
    (request) => {
      request.params = query;
      return request;
    },
    (error) => {
      return Promise.reject(error);
    },
  );

  try {
    const { data, success } = await getCategoryPublicData('');
    if (success) {
      dispatch(saveCategoryData(data));
      dispatch(savePageType(PAGE_TYPES.HOME_PAGE));
    }
  } catch (e) {
    console.log(e);
  }
  try {
    const { data } = await getTeacherList();
    dispatch(saveTopTeachers(data));
  } catch (e) {
    console.log(e);
  }

  return {
    props: {
      initialReduxState: reduxStore.getState(),
    },
  };
};
