import { NextPage } from 'next';
import { BASE_URL } from 'utils/constants';

const Referral: NextPage = () => {
  return <div>Loading...</div>;
};

export default Referral;

export const getServerSideProps = async (context: any) => {
  const { referred_by } = context.query;

  context.res.writeHead(302, {
    Location: `${BASE_URL}/live-classes/signin?referred_by=${referred_by}`,
    'Content-Type': 'text/html; charset=utf-8',
  });
  context.res.end();

  return {
    props: {
      initialReduxState: {},
    },
  };
};
