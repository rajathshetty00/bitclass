import { createAsyncThunk } from '@reduxjs/toolkit';
import { generateOTP, getUserInfo, patchUserInfo, userLogin } from 'utils/api';

export const actionGenerateOtp: any = createAsyncThunk(
  'auth/otp',
  async (data) => {
    const response = await generateOTP(data);
    return response;
  },
);

export const actionUserLogin: any = createAsyncThunk(
  'auth/login',
  async (data) => {
    const response = await userLogin(data);
    return response;
  },
);

export const actionGetUserInfo = createAsyncThunk(
  'auth/getUserInfo',
  async () => {
    const response = await getUserInfo();
    return response;
  },
);

export const actionUpdateUserInfo: any = createAsyncThunk(
  'auth/updateUserInfo',
  async (data) => {
    const response = await patchUserInfo(data);
    return response;
  },
);
