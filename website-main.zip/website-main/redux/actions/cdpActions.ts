/* eslint-disable no-param-reassign */
import { createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import {
  checkRegistrations,
  checkRegistrationOfCourse,
  getWalletBalanceOfUser,
  checkRegistrationOfCourseInTmpr,
} from 'utils/api';

export const updateSubscriptionPlans = (
  state: any,
  action: PayloadAction<any>,
) => {
  const {
    payload: { plans, latestSubscriptionDetails },
  } = action;
  const isSubscriptionExists =
    latestSubscriptionDetails === null ? false : latestSubscriptionDetails;
  state.subscriptionPlans = plans;
  state.isSubscriptionExists = isSubscriptionExists;
};

export const actionCheckRegistration = createAsyncThunk(
  'cdp/checkRegistration',
  async (payload: string) => {
    try {
      const response = await checkRegistrations(payload);
      return response;
    } catch (error) {
      return error;
    }
  },
);

export const actionCheckRegistrationOfCourse = createAsyncThunk(
  'cdp/checkRegistrationOfCourse',
  async (payload: string) => {
    try {
      const response = await checkRegistrationOfCourse(payload);
      return response;
    } catch (error) {
      return error;
    }
  },
);

export const actionCheckRegistrationOfCourseInTmpr = createAsyncThunk(
  'cdp/checkRegistrationOfCourseInTmpr',
  async (payload: string) => {
    try {
      const response = await checkRegistrationOfCourseInTmpr(payload);
      return response;
    } catch (error) {
      return error;
    }
  },
);

export const actionGetWalletBalanceOfUser = createAsyncThunk(
  'cdp/getWalletBalance',
  async (payload: any) => {
    try {
      const response = await getWalletBalanceOfUser(payload);
      return response;
    } catch (error) {
      return error;
    }
  },
);
