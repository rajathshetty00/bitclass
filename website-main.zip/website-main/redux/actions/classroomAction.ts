import { IZoomToken } from 'interfaces/classroom';
import { getCode, getEmail, getName } from 'utils/auth/userInfo';

export const extractZoomConfig = (zoomTokenData: IZoomToken) => {
  const {
    meeting_id: meetingNumber,
    meeting_password: passWord,
    meeting_signature: signature,
    initialization_code: initCode,
    initialization_key: initKey,
  } = zoomTokenData;

  const userEmail = getEmail() ?? '';
  const userName = getName();
  const customerKey = getCode();

  return {
    meetingNumber,
    passWord,
    signature,
    initCode,
    initKey,
    userEmail,
    userName,
    customerKey,
  };
};
