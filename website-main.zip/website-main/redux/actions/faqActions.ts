import { createAsyncThunk } from '@reduxjs/toolkit';
import { getMyFaqList } from 'utils/api';

const actionGetFaqs: any = createAsyncThunk('auth/otp', async () => {
  const response = await getMyFaqList();
  return response;
});

export default actionGetFaqs;
