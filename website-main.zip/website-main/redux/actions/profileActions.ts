import { createAsyncThunk } from '@reduxjs/toolkit';
import {
  getProfileDetails,
  getReferralLink,
  patchProfileInfo,
} from 'utils/api';
import { getCode } from 'utils/auth/userInfo';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';

export const actionGetReferralData: any = createAsyncThunk(
  'profile/getReferralLink',
  async () => {
    const response = await getReferralLink();
    if (response?.success) {
      saveGtmDataLayerData({
        referralDetails: { ...response?.data, student_id: getCode() },
      });
    }

    return response;
  },
);

export const actionGetProfileData: any = createAsyncThunk(
  'profile/getProfileDetails',
  async () => {
    const response = await getProfileDetails();
    return response;
  },
);

export const actionPatchProfileData: any = createAsyncThunk(
  'profile/updateProfileDetails',
  async (payload: any) => {
    const response = await patchProfileInfo(payload);
    return response;
  },
);
