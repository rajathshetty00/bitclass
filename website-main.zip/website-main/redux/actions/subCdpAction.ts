import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { getUID } from 'utils/auth/userInfo';

import { createAsyncThunk } from '@reduxjs/toolkit';
import {
  createOrder,
  registerUserForCourse,
  validateCoupon,
  getSubscriptionPlan,
  createV2Order,
} from 'utils/api';
import { exists } from 'utils';

export const actionCreateOrder = createAsyncThunk(
  'cdp/createSubOrder',
  async (data: any) => {
    const response = await createOrder(data);
    return response;
  },
);

export const actionCreateV2Order = createAsyncThunk(
  'cdp/createV2Order',
  async (data: any) => {
    const response = await createV2Order(data);
    return response;
  },
);

export const actionRegisterUserForCourse = createAsyncThunk(
  'cdp/registerForCourse',
  async ({ code, orderId, paymentId, paymentMode }: any) => {
    const payload = {
      order_id: orderId,
      payment_id: paymentId,
      payment_mode: paymentMode,
    };
    const response = await registerUserForCourse(payload, code);
    return response;
  },
);

export const actionApplyCouponForCourse = createAsyncThunk(
  'cdp/applycoupon',
  async (data: any) => {
    const response = await validateCoupon(data);
    return response;
  },
);

export const actionGetSubscriptionPlan = createAsyncThunk(
  'cdp/getSubscriptionPlan',
  async (code: string) => {
    const response = await getSubscriptionPlan(code);
    const {
      success,
      data: { latest_subscription_details: latestSubDetails },
    } = response;

    const details = latestSubDetails === null ? false : latestSubDetails;

    if (success) {
      saveGtmDataLayerData({ subscriptionDetails: details });
      if (exists(latestSubDetails)) {
        if (!latestSubDetails?.is_active) {
          saveGtmDataLayerData({
            event: EVENT_NAMES.SUBSCRIPTION_EXPIRED_SCREEN_SHOWN,
            studentId: getUID(),
          });
        }
      }
    }
    return response;
  },
);
