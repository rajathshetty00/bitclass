import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const initialState = {
  courseData: [],
  showModal: false,
  categories: [],
  deviceInfo: {},
  showPlainModal: false,
  pageType: '',
  showAlertModal: false,
  isModelVisible: false,
  meta: {},
  bitModalState: false,
  showBitDrawer: null,
  showEditDrawer: null,
  cbFunction: null,
  selectedCategory: 'All',
  topTeachers: null,
  showSearchDrawer: null,
};

export const appSlice = createSlice({
  name: 'app',
  initialState,
  reducers: {
    saveCourses: (state, action: PayloadAction<any>) => {
      state.courseData = action.payload;
    },
    setModalState: (state, action: PayloadAction<boolean>) => {
      state.showModal = action.payload;
    },
    setPlainModalState: (state, action: PayloadAction<boolean>) => {
      state.showPlainModal = action.payload;
    },
    saveCategories: (state, action: PayloadAction<any>) => {
      state.categories = action.payload;
    },
    saveDeviceInfo: (state, action: PayloadAction<Object>) => {
      state.deviceInfo = action.payload;
    },
    savePageType: (state, action: PayloadAction<string>) => {
      state.pageType = action.payload;
    },
    setAlertModalState: (state, action: PayloadAction<boolean>) => {
      state.showAlertModal = action.payload;
    },
    setIsModelVisibleState: (state, action: PayloadAction<boolean>) => {
      state.isModelVisible = action.payload;
    },
    setMetaInfoForOrders: (state, action: PayloadAction<any>) => {
      state.meta = action.payload;
    },
    updateBitModalState: (state, action: PayloadAction<boolean>) => {
      state.bitModalState = action.payload;
    },
    updateBitDrawer: (state, action: PayloadAction<any>) => {
      state.showBitDrawer = action.payload;
    },
    updateEditDrawer: (state, action: PayloadAction<any>) => {
      state.showEditDrawer = action.payload;
    },
    loadCbFunction: (state, action: PayloadAction<any>) => {
      state.cbFunction = action.payload;
    },
    updateSelectedCategory: (state, action: PayloadAction<any>) => {
      state.selectedCategory = action.payload;
    },
    saveTopTeachers: (state, action: PayloadAction<any>) => {
      state.topTeachers = action.payload;
    },
    updateSearchDrawer: (state, action: PayloadAction<any>) => {
      state.showSearchDrawer = action.payload;
    },
  },
});

export const {
  saveCourses,
  setModalState,
  saveCategories,
  saveDeviceInfo,
  setPlainModalState,
  savePageType,
  setAlertModalState,
  setMetaInfoForOrders,
  setIsModelVisibleState,
  updateBitModalState,
  updateBitDrawer,
  updateEditDrawer,
  loadCbFunction,
  updateSelectedCategory,
  saveTopTeachers,
  updateSearchDrawer,
} = appSlice.actions;

export default appSlice.reducer;
