import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const initialState = {
  categoryData: [],
  categoryType: null,
};

export const categorySlice = createSlice({
  name: 'category',
  initialState,
  reducers: {
    saveCategoryData: (state, action: PayloadAction<any>) => {
      state.categoryData = action.payload;
    },
    saveCategoryType: (state, action: PayloadAction<any>) => {
      state.categoryType = action.payload;
    },
  },
  extraReducers: () => {},
});

export const { saveCategoryData, saveCategoryType } = categorySlice.actions;

export default categorySlice.reducer;
