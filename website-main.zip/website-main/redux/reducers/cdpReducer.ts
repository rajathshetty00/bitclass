import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import {
  actionCheckRegistration,
  actionCheckRegistrationOfCourse,
  updateSubscriptionPlans,
  actionGetWalletBalanceOfUser,
  actionCheckRegistrationOfCourseInTmpr,
} from 'redux/actions/cdpActions';
import {
  actionCreateOrder,
  actionRegisterUserForCourse,
  actionApplyCouponForCourse,
  actionGetSubscriptionPlan,
  actionCreateV2Order,
} from 'redux/actions/subCdpAction';
import { CHECKOUT_STATES, RIGHT_SECTION_STATUS } from 'utils/constants/cdp';

const initialState = {
  course: {},
  subscriptionPlans: null,
  isSubscriptionExists: false,
  subscriptionSelected: {},
  pending: false,
  error: false,
  message: '',
  orderDetails: null,
  lifeStreamOrderDetails: null,
  registeredDetails: null,
  couponPending: false,
  couponData: null,
  couponCode: '',
  subPlanSuccess: false,
  checkoutStatus: CHECKOUT_STATES.batchSelection,
  batchesList: [],
  selectedBatch: {},
  courseRegistrationDetails: {},
  rightSectionStatus: RIGHT_SECTION_STATUS.LOADING,
  isRegisteredForCourse: false,
  finalCourseDetailsBeforePayment: { bitcash: 0 },
  walletBalanceDetails: null,
  applicableWalletBalanceForCheckout: null,
  courseRegistrationDetailsInTmpr: {},
  selectedTmprSlot: null,
  isBitCashApplied: false,
  isRecommendedSectionExist: false,
  curriculumCheckoutBtnType: '',
  expId: null,
  isNotifyModal: false,
};

const cdpSlice = createSlice({
  name: 'cdp',
  initialState,
  reducers: {
    updateCurriculumCheckoutBtnType: (
      state: any,
      action: PayloadAction<any>,
    ) => {
      state.curriculumCheckoutBtnType = action.payload;
    },
    saveCourseData: (state: any, action: PayloadAction<any>) => {
      state.course = action.payload;
    },
    updateBitCashAppliedStatus: (state: any, action: PayloadAction<any>) => {
      state.isBitCashApplied = action.payload;
    },
    saveSubscriptionPlans: updateSubscriptionPlans,
    selectSubscription: (state, action: PayloadAction<any>) => {
      state.couponCode = '';
      state.couponData = null;
      state.subscriptionSelected = action.payload;
    },
    updateCheckoutStatus: (state, action: PayloadAction<any>) => {
      state.checkoutStatus = action.payload;
    },

    saveCouponCode: (state, action: PayloadAction<any>) => {
      state.couponCode = action.payload;
    },
    clearCouponData: (state) => {
      state.couponData = null;
      state.couponCode = '';
    },
    updateSelectedBatch: (state, action: PayloadAction<any>) => {
      state.selectedBatch = action.payload;
    },
    updateBatches: (state, action: PayloadAction<any>) => {
      state.batchesList = action.payload;
    },
    clearCdpDataForLoggedOutUser: (state) => {
      state.courseRegistrationDetails = {};
      state.registeredDetails = null;
      state.isRegisteredForCourse = false;
      state.courseRegistrationDetailsInTmpr = {};
      state.walletBalanceDetails = null;
    },
    clearSelectedBatchDetails: (state) => {
      state.selectedBatch = {};
      state.checkoutStatus = CHECKOUT_STATES.batchSelection;
      state.couponCode = '';
      state.couponData = null;
    },
    saveFinalCourseDetails: (state, action: PayloadAction<any>) => {
      state.finalCourseDetailsBeforePayment = action.payload;
    },
    checkoutUsingWallet: (state, action: PayloadAction<any>) => {
      state.applicableWalletBalanceForCheckout = action.payload;
    },
    updateRightSectionStatus: (state, action: PayloadAction<any>) => {
      state.rightSectionStatus = action.payload;
    },
    saveSelectedTmprSlot: (state, action: PayloadAction<any>) => {
      state.selectedTmprSlot = action.payload;
    },
    handleRecommendedSectionExist: (state, action: PayloadAction<any>) => {
      state.isRecommendedSectionExist = action.payload;
    },
    saveExperimentId: (state, action: PayloadAction<any>) => {
      state.expId = action.payload;
    },
    showNotifyModal: (state, action: PayloadAction<any>) => {
      state.isNotifyModal = action.payload;
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(actionCreateOrder.pending, (state) => {
        state.pending = true;
      })
      .addCase(
        actionCreateOrder.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          // When the API call is successful and we get some data,the data becomes the `fulfilled` action payload
          state.pending = false;
          if (success) {
            state.orderDetails = data;
          }
        },
      )
      .addCase(actionCreateOrder.rejected, (state) => {
        state.pending = false;
        state.error = true;
      });

    builder
      .addCase(actionCreateV2Order.pending, (state) => {
        state.pending = true;
      })
      .addCase(
        actionCreateV2Order.fulfilled,
        (state, { payload }: PayloadAction<any>) => {
          // When the API call is successful and we get some data,the data becomes the `fulfilled` action payload
          state.pending = false;
          state.lifeStreamOrderDetails = payload;
        },
      )
      .addCase(actionCreateV2Order.rejected, (state) => {
        state.pending = false;
        state.error = true;
      });

    builder
      .addCase(actionCheckRegistration.pending, (state) => {
        state.pending = true;
      })
      .addCase(
        actionCheckRegistration.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          state.pending = false;
          if (success) {
            state.courseRegistrationDetails = data;
          }
        },
      )
      .addCase(actionCheckRegistration.rejected, (state) => {
        state.pending = false;
        state.error = true;
      });

    builder
      .addCase(actionApplyCouponForCourse.pending, (state) => {
        state.couponPending = true;
      })
      .addCase(
        actionApplyCouponForCourse.fulfilled,
        (state, { payload: { data } }: PayloadAction<any>) => {
          state.couponPending = false;
          state.couponData = data;
        },
      )
      .addCase(actionApplyCouponForCourse.rejected, (state) => {
        state.couponPending = false;
        state.error = true;
      });

    builder
      .addCase(actionRegisterUserForCourse.pending, (state) => {
        state.pending = true;
      })
      .addCase(
        actionRegisterUserForCourse.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          // When the API call is successful and we get some data,the data becomes the `fulfilled` action payload
          state.pending = false;
          if (success) {
            state.registeredDetails = data;
          }
        },
      )
      .addCase(actionRegisterUserForCourse.rejected, (state) => {
        state.pending = false;
        state.error = true;
      });

    builder
      .addCase(actionGetSubscriptionPlan.pending, (state) => {
        state.subscriptionPlans = null;
        state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      })
      .addCase(
        actionGetSubscriptionPlan.fulfilled,
        (
          state,
          {
            payload: {
              success,
              data: {
                plans,
                latest_subscription_details: latestSubscriptionDetails,
              },
            },
          }: PayloadAction<any>,
        ) => {
          if (success) {
            // eslint-disable-next-line prefer-destructuring
            state.subscriptionSelected = plans.length ? plans[0] : {};
            state.isSubscriptionExists =
              latestSubscriptionDetails === null
                ? false
                : latestSubscriptionDetails;
            state.subscriptionPlans = plans;
            state.subPlanSuccess = success;
            state.rightSectionStatus = RIGHT_SECTION_STATUS.SUBSCRIPTION;
          }
        },
      )
      .addCase(actionGetSubscriptionPlan.rejected, (state) => {
        state.subscriptionPlans = null;
        state.error = true;
        state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      });

    builder
      .addCase(actionCheckRegistrationOfCourse.pending, (state) => {
        state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      })
      .addCase(
        actionCheckRegistrationOfCourse.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          if (success) {
            // eslint-disable-next-line prefer-destructuring
            state.isRegisteredForCourse = data;
            state.rightSectionStatus = RIGHT_SECTION_STATUS.FULLCOURSE;
          }
        },
      )
      .addCase(actionCheckRegistrationOfCourse.rejected, (state) => {
        state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      });

    builder
      .addCase(actionCheckRegistrationOfCourseInTmpr.pending, (state) => {
        state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      })
      .addCase(
        actionCheckRegistrationOfCourseInTmpr.fulfilled,
        (state, { payload: { data } }: PayloadAction<any>) => {
          if (data) {
            // eslint-disable-next-line prefer-destructuring
            state.courseRegistrationDetailsInTmpr = data;
            state.rightSectionStatus = RIGHT_SECTION_STATUS.TMPR;
          }
        },
      )
      .addCase(actionCheckRegistrationOfCourseInTmpr.rejected, (state) => {
        state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      });

    builder
      .addCase(actionGetWalletBalanceOfUser.pending, () => {
        // state.rightSectionStatus = RIGHT_SECTION_STATUS.LOADING;
      })
      .addCase(
        actionGetWalletBalanceOfUser.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          if (success) {
            // eslint-disable-next-line prefer-destructuring
            state.walletBalanceDetails = data;
          }
        },
      )
      .addCase(actionGetWalletBalanceOfUser.rejected, () => {});
  },
});

export const {
  saveCourseData,
  saveSubscriptionPlans,
  selectSubscription,
  saveCouponCode,
  clearCouponData,
  updateCheckoutStatus,
  updateSelectedBatch,
  updateBatches,
  clearCdpDataForLoggedOutUser,
  clearSelectedBatchDetails,
  saveFinalCourseDetails,
  checkoutUsingWallet,
  updateRightSectionStatus,
  saveSelectedTmprSlot,
  updateBitCashAppliedStatus,
  handleRecommendedSectionExist,
  updateCurriculumCheckoutBtnType,
  saveExperimentId,
  showNotifyModal,
} = cdpSlice.actions;
export default cdpSlice.reducer;
