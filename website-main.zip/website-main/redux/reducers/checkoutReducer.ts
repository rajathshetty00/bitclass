import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const initialState = {
  checkoutBtnType: '',
  complianceState: '',
};

const checkoutButtonSlice = createSlice({
  name: 'checkoutBtn',
  initialState,
  reducers: {
    triggerCheckoutBtn: (state, action: PayloadAction<any>) => {
      state.checkoutBtnType = action.payload;
    },
    updateComplianceState: (state, action: PayloadAction<any>) => {
      state.complianceState = action.payload;
    },
  },
});

export const { triggerCheckoutBtn, updateComplianceState } =
  checkoutButtonSlice.actions;
export default checkoutButtonSlice.reducer;
