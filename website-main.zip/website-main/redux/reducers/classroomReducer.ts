import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { extractZoomConfig } from 'redux/actions/classroomAction';

const classroomScreenStates = {
  classroom: 'classroom',
  blockerScreen: 'blockerScreen',
};
export interface IInitialState {
  zoomDetails: {};
  zoomEngagementDetails: {};
  courseDetails: {};
  couponCode: string;
  courseCode: string;
  zoomConfig: {};
  classroomScreen: string;
  pending: boolean;
  isPreClassTnCAccepted: boolean;
}
const initialState: IInitialState = {
  zoomDetails: {},
  zoomEngagementDetails: {},
  courseDetails: {},
  couponCode: '',
  courseCode: '',
  zoomConfig: {},
  classroomScreen: classroomScreenStates.classroom,
  pending: true,
  isPreClassTnCAccepted: false,
};

const classroom = createSlice({
  name: 'classroom',
  initialState,
  reducers: {
    saveZoomTokenData: (state, action: PayloadAction<any>) => {
      state.zoomDetails = action.payload;
      state.zoomConfig = extractZoomConfig(action.payload);
    },
    saveZoomEngagementData: (state, action: PayloadAction<any>) => {
      state.zoomEngagementDetails = action.payload;
      state.couponCode = action.payload.coupon_code;
      state.courseCode = action.payload.course_code;
    },
    updatePending: (state) => {
      state.pending = false;
    },
    updatePreClassInstructionStatus: (state, action: PayloadAction<any>) => {
      state.isPreClassTnCAccepted = action.payload;
    },
  },
});
export const {
  saveZoomTokenData,
  saveZoomEngagementData,
  updatePending,
  updatePreClassInstructionStatus,
} = classroom.actions;
export default classroom.reducer;
