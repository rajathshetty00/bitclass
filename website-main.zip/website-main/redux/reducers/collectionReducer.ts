import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const initialState = {
  collectionData: [],
};

export const collectionSlice = createSlice({
  name: 'collection',
  initialState,
  reducers: {
    saveCollectionData: (state, action: PayloadAction<any>) => {
      state.collectionData = action.payload;
    },
  },

  extraReducers: () => {},
});

export const { saveCollectionData } = collectionSlice.actions;

export default collectionSlice.reducer;
