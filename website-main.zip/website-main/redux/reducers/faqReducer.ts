import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const initialState = {
  faqList: {},
  pending: false,
  error: false,
};

const faqSlice = createSlice({
  name: 'faq',
  initialState,
  reducers: {
    saveStudentFaqData: (state, action: PayloadAction<any>) => {
      state.faqList = action.payload;
    },
  },
});
export const { saveStudentFaqData } = faqSlice.actions;
export default faqSlice.reducer;
