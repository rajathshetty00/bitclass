import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import {
  actionGetProfileData,
  actionGetReferralData,
  actionPatchProfileData,
} from 'redux/actions/profileActions';
// import { actionGetReferralData } from 'redux/actions/profileActions';

const initialState = {
  referralPending: false,
  idCardPending: false,
  isProfileUpdatePending: false,
  error: false,
  isIdLayoutViewable: false,
  isReferralShowViewable: true,
  isReferAFriendViewable: false,
  istransactionHistoryViewable: false,
  isEditModalViewable: false,
  selectedTab: 0,
  selectedCourseType: '',
  referralDetails: null,
  profileDetails: null,
};

export const profileSlice = createSlice({
  name: 'profile',
  initialState,
  reducers: {
    showIdLayoutPage: (state, action: PayloadAction<any>) => {
      state.isIdLayoutViewable = action.payload;
    },
    showReferralPage: (state, action: PayloadAction<any>) => {
      state.isReferralShowViewable = action.payload;
    },
    showReferAFriendPage: (state, action: PayloadAction<any>) => {
      state.isReferAFriendViewable = action.payload;
    },
    showTransactionHistory: (state, action: PayloadAction<any>) => {
      state.istransactionHistoryViewable = action.payload;
    },
    showEditScreenModal: (state, action: PayloadAction<any>) => {
      state.isEditModalViewable = action.payload;
    },
    updateSelectedTab: (state, action: PayloadAction<any>) => {
      state.selectedTab = action.payload;
    },
    updateSelectedCourseType: (state, action: PayloadAction<any>) => {
      state.selectedCourseType = action.payload;
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(actionGetReferralData.pending, (state) => {
        state.referralPending = true;
      })
      .addCase(
        actionGetReferralData.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          // When the API call is successful and we get some data,the data becomes the `fulfilled` action payload
          state.referralPending = false;
          if (success) {
            state.referralDetails = data;
          }
        },
      )
      .addCase(actionGetReferralData.rejected, (state) => {
        state.referralPending = false;
        state.error = true;
      });

    builder
      .addCase(actionGetProfileData.pending, (state) => {
        state.idCardPending = true;
      })
      .addCase(
        actionGetProfileData.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          state.referralPending = false;
          if (success) {
            state.profileDetails = data;
          }
        },
      )
      .addCase(actionGetProfileData.rejected, (state) => {
        state.idCardPending = false;
        state.error = true;
      });

    builder
      .addCase(actionPatchProfileData.pending, (state) => {
        state.isProfileUpdatePending = true;
      })
      .addCase(
        actionPatchProfileData.fulfilled,
        (state, { payload: { success, data } }: PayloadAction<any>) => {
          state.isProfileUpdatePending = false;
          if (success) {
            state.profileDetails = data;
          }
        },
      )
      .addCase(actionPatchProfileData.rejected, (state) => {
        state.isProfileUpdatePending = false;
        state.error = true;
      });
  },
});

export const {
  showIdLayoutPage,
  showReferralPage,
  showReferAFriendPage,
  showTransactionHistory,
  showEditScreenModal,
  updateSelectedTab,
  updateSelectedCourseType,
} = profileSlice.actions;

export default profileSlice.reducer;
