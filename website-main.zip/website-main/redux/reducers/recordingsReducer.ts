import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface InitialState {
  buttonCtaText: string;
  seriesDoc: {
    _id: string;
    title: string;
    episodes_list: string[];
    intro_url: string;
    is_active: boolean;
    linked_course_code: string;
    slug: string;
    tags: string[];
    teacher_id: string;
    teacher_image: string;
    teacher_name: string;
    thumbnail_url: string;
  };
  vidDoc: {
    _id: string;
    title: string;
    slug: string;
    type: string;
    duration: string;
    teacher_image: string;
    teacher_name: string;
    thumbnail_url: string;
  };
  viewsCount: Number;
}
const initialState: InitialState = {
  buttonCtaText: '',
  seriesDoc: {
    _id: '',
    title: '',
    episodes_list: [],
    intro_url: '',
    is_active: false,
    linked_course_code: '',
    slug: '',
    tags: [],
    teacher_id: '',
    teacher_image: '',
    teacher_name: '',
    thumbnail_url: '',
  },
  vidDoc: {
    _id: '',
    title: '',
    slug: '',
    type: '',
    duration: '',
    teacher_image: '',
    teacher_name: '',
    thumbnail_url: '',
  },
  viewsCount: 0,
};

const recordingSlice = createSlice({
  name: 'recordings',
  initialState,
  reducers: {
    saveVideoDoc: (state, action: PayloadAction<any>) => {
      state.vidDoc = action.payload.vid_doc;
      state.viewsCount = action.payload.views_count;
    },
  },
});
export const { saveVideoDoc } = recordingSlice.actions;
export default recordingSlice.reducer;
