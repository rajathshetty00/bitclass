import { FC } from 'react';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import BitMuiPlainDialog from 'src/components/common/BitMuiPlainDialog/BitMuiPlainDialog';
import OrderSummary from 'src/components/CDP/CheckoutModal/components/OrderSummary';
import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import { setPlainModalState } from 'redux/reducers/appReducer';
import { clearCouponData } from 'redux/reducers/cdpReducer';

import SlotSelection from './components/SlotSelection';
import styles from './styles.module.scss';
import BatchSelection from './components/BatchSelection';
import CheckoutFooter from './components/CheckoutFooter';

interface IComponents {
  [key: string]: any;
}

const components: IComponents = Object.freeze({
  orderSummary: <OrderSummary />,
  batchSelection: <BatchSelection />,
  slotSelection: <SlotSelection />,
});

const CheckoutModal: FC = () => {
  const { checkoutStatus } = useAppSelector((state: AppState) => state.cdp);

  const { showPlainModal } = useAppSelector((state: AppState) => state.app);

  const dispatch = useAppDispatch();

  const { initialiseCheckoutModal } = useRightSectionRenderer();

  const handleCustomclose = () => {
    dispatch(setPlainModalState(false));
    initialiseCheckoutModal();
    dispatch(clearCouponData());
  };

  return (
    <BitMuiPlainDialog
      open={showPlainModal}
      title={<span className={styles.modalTitle}>Registration Details</span>}
      footer={<CheckoutFooter />}
      handleCustomClose={handleCustomclose}
    >
      {components[checkoutStatus]}
    </BitMuiPlainDialog>
  );
};

export default CheckoutModal;
