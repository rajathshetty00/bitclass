import dayjs from 'dayjs';
import { updateSelectedBatch } from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { getCurriculumGTMData, isEmptyObject } from 'utils';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from '../styles.module.scss';

const SINGLE_DATE_FORMAT = 'DD MMM, ddd: h:mm A';
const MULTIPLE_DATE_FORMAT = 'DD MMM';

const formatDate = (epoch: number, format: string) => {
  if (!epoch) return;
  return dayjs.unix(epoch).format(format);
};

export const getSlotLabel = (startDate: number, endDate: number) => {
  const noOfDays = dayjs.unix(endDate).diff(dayjs.unix(startDate));
  if (!noOfDays) return formatDate(startDate, SINGLE_DATE_FORMAT);
  const multipleDates = `${formatDate(startDate, MULTIPLE_DATE_FORMAT)}-
            ${formatDate(endDate, MULTIPLE_DATE_FORMAT)}`;
  const slotLabel = `${multipleDates}`;

  return slotLabel;
};
export const getTimeSlot = (dates: number[]): string | undefined => {
  const startDate = dates[0];
  const endDate = dates[dates.length - 1];

  const noOfDays = dayjs.unix(endDate).diff(dayjs.unix(startDate));
  if (!noOfDays) return;
  const groupByTime: any = {};
  dates.forEach((date: number): void => {
    const formattedDate: string = formatDate(date, 'hh:mm A') || '';
    // eslint-disable-next-line no-prototype-builtins
    if (groupByTime.hasOwnProperty(formattedDate)) {
      if (!groupByTime[formattedDate].includes(formatDate(date, 'ddd')))
        groupByTime[formattedDate].push(formatDate(date, 'ddd'));
    } else {
      groupByTime[formattedDate] = [formatDate(date, 'ddd')];
    }
  });

  const daySlots: string[] = [];
  Object.entries(groupByTime).forEach(([key, values]: any) => {
    if (values.length === 7) daySlots.push(`Daily: ${key}`);
    if (values.length > 2 && values.length < 7)
      daySlots.push(`${values[0]}-${values[values.length - 1]}: ${key} `);
    if (values.length < 2) daySlots.push(`${values.join(', ')}: ${key} `);
  });
  return daySlots.join(', ');
};

const BatchSelection = () => {
  const { batchesList, selectedBatch, course } = useAppSelector(
    (state: AppState) => state.cdp,
  );

  const dispatch = useAppDispatch();
  const saveSelectedBatch = (batch: any) => {
    const additonalObject = {
      batch_course_code: batch?.course_code || '',
      batch_code: batch?.batch_code || '',
    };
    saveGtmDataLayerData({
      event: EVENT_NAMES.COURSE_SLOT_SELECTION,
      curriculumCdpDetails: getCurriculumGTMData(course, additonalObject),
    });
    dispatch(updateSelectedBatch(batch));
  };

  const getBatchStyle = (batch: any) => {
    if (isEmptyObject(batch)) return;
    return selectedBatch?.course_code === batch?.course_code
      ? styles.selectedBatch
      : styles.batch;
  };

  return (
    <div className={styles.batchSelection}>
      {batchesList?.length > 0 ? (
        <h3>Select your preferred slot</h3>
      ) : (
        <div className={styles.loading}>Loading...</div>
      )}
      <div className={styles.batches}>
        {batchesList.map((batch: any) => (
          <BitButton
            className={getBatchStyle(batch)}
            key={batch?.course_code}
            onClick={() => saveSelectedBatch(batch)}
          >
            <span className={styles.batchDate}>
              {getSlotLabel(
                batch?.epoch_schedule[0],
                batch?.epoch_schedule[batch?.epoch_schedule.length - 1],
              )}
            </span>
            <span className={styles.batchTime}>
              {getTimeSlot(batch.epoch_schedule)}
            </span>
          </BitButton>
        ))}
      </div>
    </div>
  );
};

export default BatchSelection;
