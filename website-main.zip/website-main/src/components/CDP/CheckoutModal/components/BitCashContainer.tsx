import { Checkbox, FormControlLabel } from '@mui/material';
import React, { FunctionComponent } from 'react';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import styles from 'src/components/CDP/CheckoutModal/styles.module.scss';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import {
  checkoutUsingWallet,
  saveFinalCourseDetails,
  updateBitCashAppliedStatus,
} from 'redux/reducers/cdpReducer';

interface BitCashContainerProps {
  applicableWalletBalance: number;
}

const BitCashContainer: FunctionComponent<BitCashContainerProps> = ({
  applicableWalletBalance,
}) => {
  const dispatch = useAppDispatch();

  const { finalCourseDetailsBeforePayment, isBitCashApplied } = useAppSelector(
    (state: AppState) => state.cdp,
  );

  const applyBitCash = (e: any) => {
    const checkedStatus = e.target.checked;
    dispatch(updateBitCashAppliedStatus(checkedStatus));
    if (checkedStatus) {
      dispatch(checkoutUsingWallet(applicableWalletBalance));
      dispatch(
        saveFinalCourseDetails({
          ...finalCourseDetailsBeforePayment,
          bitcash: applicableWalletBalance,
        }),
      );
    } else {
      dispatch(checkoutUsingWallet(null));
      dispatch(
        saveFinalCourseDetails({
          ...finalCourseDetailsBeforePayment,
          bitcash: 0,
        }),
      );
    }
  };

  return (
    <div className={styles.bitcashContainer}>
      <FormControlLabel
        control={
          <Checkbox checked={isBitCashApplied} onChange={applyBitCash} />
        }
        label={
          <div className={styles.bitcashLining}>
            <NextImage
              className={styles.bitcashLogo}
              src={assetObject.bitcashLogo}
              width="24"
              height="24"
            />
            <b> {applicableWalletBalance} BitCash</b>
          </div>
        }
      />
    </div>
  );
};

export default BitCashContainer;
