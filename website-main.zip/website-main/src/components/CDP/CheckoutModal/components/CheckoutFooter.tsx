import { FC } from 'react';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import { checkoutModalFooterText } from 'strings/cdp';
import styles from 'src/components/CDP/CheckoutModal/styles.module.scss';
import { AppState, useAppSelector } from 'redux/store';
import { CHECKOUT_STATES } from 'utils/constants/cdp';
import Script from 'next/script';
import { RAZORPAY_SDK_URL } from 'utils/constants';
import { getCurriculumGTMData } from 'utils';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import { extractCdpData } from 'utils/courseAnalytics';
import { getComplianceState } from 'utils/auth/userInfo';

interface ICheckoutFooter {
  buttonText?: string;
}

const CheckoutFooter: FC<ICheckoutFooter> = ({ buttonText }) => {
  const {
    checkoutStatus,
    selectedBatch,
    finalCourseDetailsBeforePayment,
    course,
  } = useAppSelector((state: AppState) => state.cdp);
  const { complianceState } = useAppSelector(
    (state: AppState) => state.checkout,
  );
  const amount =
    finalCourseDetailsBeforePayment?.amount -
    finalCourseDetailsBeforePayment?.bitcash -
    finalCourseDetailsBeforePayment?.couponDiscount;

  const { checkoutFooterHandler } = useRightSectionRenderer();

  const onClickHandler = () => {
    checkoutFooterHandler();
    saveGtmDataLayerData({
      event: EVENT_NAMES.PAY_AND_BOOK_CLICKED,
      data: extractCdpData({
        ...course,
        course_code: finalCourseDetailsBeforePayment?.courseCode,
        bitcash_used: finalCourseDetailsBeforePayment?.bitcash,
        coupon_used: finalCourseDetailsBeforePayment?.couponDiscount,
      }),
    });
    saveGtmDataLayerData({
      event: EVENT_NAMES.SLOT_SELECTION_CONFIRM_SLOT_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, {
        batch_course_code: selectedBatch?.course_code,
        batch_code: selectedBatch?.batch_code,
      }),
    });
  };

  const { pending } = useAppSelector((state: AppState) => state.cdp);

  const payButtonText = amount
    ? buttonText || checkoutModalFooterText
    : 'Click to Book';

  const getFooterButtonText = () =>
    checkoutStatus === CHECKOUT_STATES.batchSelection ||
    checkoutStatus === CHECKOUT_STATES.slotSelection
      ? 'Choose & Continue'
      : payButtonText;

  const isStateExist = complianceState || getComplianceState();
  const isOrderSummaryScreen = checkoutStatus === CHECKOUT_STATES.orderSummary;
  const isDisabled =
    Boolean(amount) && (pending || (!isStateExist && isOrderSummaryScreen));
  return (
    <>
      <Script src={RAZORPAY_SDK_URL} strategy="lazyOnload" />

      <CustomDefaultButton
        onClick={onClickHandler}
        className={styles.payButton}
        size="large"
        loading={pending}
        disabled={isDisabled}
      >
        {getFooterButtonText()}
      </CustomDefaultButton>
    </>
  );
};
CheckoutFooter.defaultProps = {
  buttonText: 'Pay and Book',
};
export default CheckoutFooter;
