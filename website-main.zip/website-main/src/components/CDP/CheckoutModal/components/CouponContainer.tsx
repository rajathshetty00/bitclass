import { FC, useEffect, useState } from 'react';
import { TextField, Typography } from '@mui/material';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import styles from 'src/components/CDP/CheckoutModal/styles.module.scss';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { actionApplyCouponForCourse } from 'redux/actions/subCdpAction';
import {
  checkoutUsingWallet,
  clearCouponData,
  saveCouponCode,
  saveFinalCourseDetails,
  updateBitCashAppliedStatus,
} from 'redux/reducers/cdpReducer';
import { XCircle } from 'react-feather';
import { useRouter } from 'next/router';
import { actionGetWalletBalanceOfUser } from 'redux/actions/cdpActions';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';

interface CouponContainerProps {}

const CouponContainer: FC<CouponContainerProps> = () => {
  const { query } = useRouter();
  const [coupon, setCoupon] = useState(query?.couponCode ?? '');

  const dispatch = useAppDispatch();

  const {
    course: { code, type },
    subscriptionSelected,
    couponPending,
    couponData,
    couponCode,
    selectedBatch,
    finalCourseDetailsBeforePayment,
  } = useAppSelector((state: AppState) => state.cdp);

  const { id } = subscriptionSelected || {};
  const onCouponChangeHandler = (e: any) => {
    setCoupon(e.target.value);
  };
  const courseCode = type === 'curriculum' ? selectedBatch?.course_code : code;

  const couponClickHandler = async () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.APPLY_COUPON_CLICKED,
    });

    try {
      const {
        payload: {
          data: { success, amount },
        },
      } = await dispatch(
        actionApplyCouponForCourse({
          coupon_code: coupon,
          pricing_plan_code: id,
          product_code: courseCode,
        }),
      );
      if (success) {
        dispatch(saveCouponCode(coupon));
        saveGtmDataLayerData({
          event: EVENT_NAMES.COUPON_STATUS,
          couponDetails: {
            coupon,
            status: 'success',
          },
        });
        if (amount) {
          await dispatch(actionGetWalletBalanceOfUser(amount));
        }
        dispatch(updateBitCashAppliedStatus(false));

        dispatch(
          saveFinalCourseDetails({
            ...finalCourseDetailsBeforePayment,
            bitcash: 0,
            couponDiscount: (
              finalCourseDetailsBeforePayment?.originalAmount - amount
            ).toFixed(1),
          }),
        );
        setCoupon('');
      } else {
        saveGtmDataLayerData({
          event: EVENT_NAMES.COUPON_STATUS,
          couponDetails: {
            coupon: '',
            status: 'failed',
          },
        });
      }
    } catch (e) {
      return e;
    }
  };
  useEffect(() => {
    // eslint-disable-next-line no-prototype-builtins
    if (query.hasOwnProperty('couponCode')) {
      couponClickHandler();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const couponDeleteHandler = async () => {
    dispatch(saveCouponCode(''));
    dispatch(clearCouponData());
    const { payload } = await dispatch(
      actionGetWalletBalanceOfUser(finalCourseDetailsBeforePayment?.amount),
    );
    dispatch(checkoutUsingWallet(payload.data.applicable_wallet_balance));
    dispatch(
      saveFinalCourseDetails({
        ...finalCourseDetailsBeforePayment,
        bitcash: payload.data.applicable_wallet_balance,
        couponDiscount: 0,
      }),
    );
  };

  return (
    <div className={styles.couponWrapper}>
      {!couponCode ? (
        <>
          <Typography
            gutterBottom
            variant="body2"
            className={styles.couponTitle}
          >
            Do you have a coupon?
          </Typography>
          <div className={styles.couponContainer}>
            <TextField
              name="coupon"
              id="outlined-basic"
              variant="outlined"
              label="Enter here"
              size="small"
              value={coupon}
              onChange={onCouponChangeHandler}
            />
            <CustomDefaultButton
              variant="contained"
              onClick={couponClickHandler}
              className={styles.button}
              loading={couponPending}
              disabled={!coupon}
            >
              Apply
            </CustomDefaultButton>
          </div>
          <Typography color="red" variant="caption">
            {couponData?.msg}
          </Typography>
        </>
      ) : (
        <div className={styles.couponMsgContainer}>
          <div className={styles.applied}>
            <Typography>
              <b>{couponCode}</b> is applied
            </Typography>
            <XCircle onClick={couponDeleteHandler} />
          </div>

          <Typography className={styles.msg} variant="body2">
            {couponData?.msg}
          </Typography>
        </div>
      )}
    </div>
  );
};

export default CouponContainer;
