import dayjs from 'dayjs';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import ScheduleTags from 'src/layouts/CDP/RightStickySection/Components/ScheduleTags/ScheduleTags';
import { assetObject } from 'utils/assetFileNames';
import { getSlotLabel } from '../BatchSelection';
import styles from './styles.module.scss';

const CourseDetails = () => {
  const { selectedTmprSlot, course } = useAppSelector(
    (state: AppState) => state.cdp,
  );
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );
  const thumbnail =
    course?.intro_video_thumbnail ?? assetObject.defaultCdpImage;

  const {
    weekly_schedule: weeklySchedule,
    duration: weeklyDuration,
    start_ts: startDate,
    end_ts: endDate,
  } = course;
  return (
    <div className={styles.courseDetails}>
      <div className={styles.courseHeadingImg}>
        <div>
          <NextImage
            src={thumbnail}
            width={150}
            height={80}
            objectFit="cover"
            className={styles.courseThumbnail}
          />
        </div>
        <div className={styles.courseHeading}>
          <h3>{course?.heading}</h3>
          <span>{course?.teacher?.teacher_name}</span>
        </div>
      </div>

      <div className={styles.schedule}>
        <div>
          <div className={styles.timing}>
            <div className={styles.dateRange}>
              <span className={styles.title}>Your Class Timing</span>
              {selectedTmprSlot?.timing?.length && (
                <span className={styles.date}>
                  {selectedTmprSlot?.timing && (
                    <>
                      {selectedTmprSlot?.timing?.length > 1 ? (
                        <span className={styles.dateText}>
                          {dayjs
                            .unix(selectedTmprSlot.timing[0])
                            .format('DD MMM')}
                          &nbsp;-&nbsp;
                          {dayjs
                            .unix(
                              selectedTmprSlot.timing[
                                selectedTmprSlot.timing.length - 1
                              ],
                            )
                            .format('DD MMM')}
                        </span>
                      ) : (
                        <span className={styles.dateText}>
                          {dayjs
                            .unix(selectedTmprSlot.timing[0])
                            .format('DD MMM')}
                        </span>
                      )}
                    </>
                  )}
                </span>
              )}
              <span className={styles.dateText}>
                {getSlotLabel(startDate, endDate)}
              </span>
            </div>
            <NextImage
              src={assetObject.calendarIcon}
              width={isMobile ? 40 : 48}
              height={isMobile ? 40 : 48}
              className={styles.successImg}
            />
          </div>
          <ScheduleTags
            mainContainerClass={styles.scheduleContainer}
            weeklySchedule={weeklySchedule}
            duration={weeklyDuration}
          />
        </div>
      </div>
    </div>
  );
};

export default CourseDetails;
