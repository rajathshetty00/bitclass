import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import { FC, useEffect } from 'react';
import Features from 'src/layouts/CDP/RightStickySection/Subscription/Features/Features';
import PAGE_TYPES from 'utils/constants/pageTypes';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { AppState, useAppSelector } from 'redux/store';
import { getCurriculumGTMData, isEmptyObject } from 'utils';
import dynamic from 'next/dynamic';
import CouponContainer from './CouponContainer';
import PricingContainer from './PricingContainer';
import BitCashContainer from './BitCashContainer';
import styles from '../styles.module.scss';
import CourseDetails from './CourseDetails/CourseDetails';

const StateInput = dynamic(() => import('./StateInput/StateInput'), {
  ssr: false,
});

interface IOrderSummaryProps {}

const OrderSummary: FC<IOrderSummaryProps> = () => {
  const { selectedBatch, course } = useAppSelector(
    (state: AppState) => state.cdp,
  );
  const { orderSummaryHandler } = useRightSectionRenderer();
  const {
    price,
    walletBalanceDetails,
    couponContainerVisibility,
    walletBalanceVisibility,
    pageType,
    couponDiscount,
    currency,
  } = orderSummaryHandler();

  useEffect(() => {
    if (!isEmptyObject(selectedBatch)) {
      const additionalData = {
        batch_course_code: selectedBatch?.course_code,
        batch_code: selectedBatch?.batch_code,
        course_price: selectedBatch?.amount,
        course_category: course?.category,
      };
      saveGtmDataLayerData({
        event: EVENT_NAMES.COURSE_ORDER_SUMMARY_SCREEN_VIEWED,
        curriculumCdpDetails: getCurriculumGTMData(course, additionalData),
      });
    }
  }, [selectedBatch, course]);

  return (
    <>
      <CourseDetails />
      {couponContainerVisibility && <CouponContainer />}
      {price - couponDiscount > 0 && walletBalanceVisibility && (
        <BitCashContainer
          applicableWalletBalance={
            walletBalanceDetails?.applicable_wallet_balance
          }
        />
      )}
      {price > 0 && <StateInput />}

      <PricingContainer currency={currency} />
      {pageType === PAGE_TYPES.CDP_CURRICULUM_PAGE && (
        <div className={styles.featuresContainer}>
          <Features />
        </div>
      )}
    </>
  );
};

export default OrderSummary;
