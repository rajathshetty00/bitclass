import { FC } from 'react';
import { Divider, Typography } from '@mui/material';
import { AppState, useAppSelector } from 'redux/store';
import styles from 'src/components/CDP/CheckoutModal/styles.module.scss';
import { getFinalAmount } from 'utils';
import { getCurrencySymbol } from 'utils/currency';
// import { useEffect } from 'hoist-non-react-statics/node_modules/@types/react';

interface PricingContainerProps {
  currency: string;
}

const PricingContainer: FC<PricingContainerProps> = ({ currency }) => {
  const {
    couponCode,
    couponData,
    course: { heading },
    applicableWalletBalanceForCheckout,
    finalCourseDetailsBeforePayment,
    isBitCashApplied,
  } = useAppSelector((state: AppState) => state?.cdp);
  const amount =
    finalCourseDetailsBeforePayment?.amount -
    finalCourseDetailsBeforePayment?.couponDiscount -
    finalCourseDetailsBeforePayment?.bitcash;
  return (
    <div className={styles.priceContainer}>
      <Typography fontWeight="700" variant="h6">
        PRICE
      </Typography>
      <Divider style={{ margin: '4px 0' }} />

      <div className={styles.flex}>
        <Typography variant="h6">{heading}</Typography>
        <Typography variant="h6">
          {getCurrencySymbol(currency)}
          {finalCourseDetailsBeforePayment?.amount}
        </Typography>
      </div>
      <Divider style={{ margin: '8px 0' }} />

      {couponCode && (
        <>
          <div className={styles.flex}>
            <Typography variant="h6">Discount</Typography>
            <Typography
              variant="h6"
              fontWeight="700"
              className={styles.discountedAmount}
            >
              - {getCurrencySymbol(couponData?.currency)}{' '}
              {finalCourseDetailsBeforePayment?.couponDiscount}
            </Typography>
          </div>
          <Divider style={{ margin: '8px 0' }} />
        </>
      )}

      {applicableWalletBalanceForCheckout > 0 && isBitCashApplied && (
        <>
          <div className={styles.flex}>
            <Typography variant="h6">Bitcash Discount</Typography>
            <Typography
              variant="h6"
              fontWeight="700"
              className={styles.discountedAmount}
            >
              - {applicableWalletBalanceForCheckout}
            </Typography>
          </div>
          <Divider style={{ margin: '8px 0' }} />
        </>
      )}

      <div className={styles.flex}>
        <Typography fontWeight="600"> Total</Typography>
        <Typography fontWeight="600">
          {getFinalAmount({
            currency,
            finalAmount: amount,
          }) || 'FREE'}
        </Typography>
      </div>
    </div>
  );
};

export default PricingContainer;
