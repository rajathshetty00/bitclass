import { FunctionComponent } from 'react';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import ScheduleTags from 'src/layouts/CDP/RightStickySection/Components/ScheduleTags/ScheduleTags';
import { assetObject } from 'utils/assetFileNames';
import dayjs from 'dayjs';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import clsx from 'clsx';
import { saveSelectedTmprSlot } from 'redux/reducers/cdpReducer';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import styles from '../styles.module.scss';

interface SlotSelectionProps {}

const SlotSelection: FunctionComponent<SlotSelectionProps> = () => {
  const {
    course: { slots },
    selectedTmprSlot,
  } = useAppSelector((state: AppState) => state.cdp);

  const dispatch = useAppDispatch();

  const handleSlotOptionClick = (item: any) => {
    dispatch(saveSelectedTmprSlot(item));
    saveGtmDataLayerData({
      selectedTmprSlot: item,
      event: EVENT_NAMES.COURSE_SLOT_SELECTION,
    });
  };

  return (
    <div className={styles.slotSelectionContainer}>
      {/* <div> */}{' '}
      <NextImage width="60px" height="60px" src={assetObject.calendarIcon} />
      {/* </div> */}
      <h3>Select your preferred slot</h3>
      {slots.map((item: any) => (
        <BitButton
          className={clsx({
            [styles.slotOption]: true,
            [styles.slotSelected]:
              item?.course_code === selectedTmprSlot?.course_code,
          })}
          onClick={() => handleSlotOptionClick(item)}
          variant="text"
        >
          {item?.timing && (
            <>
              {item?.timing?.length > 1 ? (
                <b>
                  {dayjs.unix(item.timing[0]).format('DD MMM')}
                  &nbsp;-&nbsp;
                  {dayjs
                    .unix(item.timing[item.timing.length - 1])
                    .format('DD MMM')}
                </b>
              ) : (
                <b>{dayjs.unix(item.timing[0]).format('DD MMM')}</b>
              )}
            </>
          )}

          <ScheduleTags
            weeklySchedule={item.timing}
            duration={item.duration}
            mainContainerClass={styles.newScheduleContainer}
          />
        </BitButton>
      ))}
    </div>
  );
};

export default SlotSelection;
