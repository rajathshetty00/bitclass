import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
} from '@mui/material';
import indianStates from 'utils/constants/json/indianStates.json';

import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { updateComplianceState } from 'redux/reducers/checkoutReducer';
import { getComplianceState } from 'utils/auth/userInfo';
import styles from './styles.module.scss';

interface IState {
  slno: Number;
  abb: string;
  name: string;
  state: string;
}

const StateInput = () => {
  const { complianceState } = useAppSelector(
    (state: AppState) => state.checkout,
  );

  const dispatch = useAppDispatch();

  const newComplianceState = complianceState || getComplianceState();
  const handleChange = (event: SelectChangeEvent) => {
    localStorage.setItem('state', event.target.value);
    dispatch(updateComplianceState(event?.target?.value));
  };
  return (
    <FormControl fullWidth className={styles.states}>
      <InputLabel id="state-select-label">
        State <span style={{ color: 'red' }}>*&nbsp;</span>{' '}
      </InputLabel>
      <Select
        labelId="state-select-label"
        id="state-select"
        defaultValue={newComplianceState}
        value={newComplianceState}
        label="State"
        onChange={handleChange}
      >
        {indianStates.map((state: IState) => (
          <MenuItem value={state.abb} key={state?.abb}>
            {state.name}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default StateInput;
