import { FunctionComponent } from 'react';

interface TimingContainerProps {}

const TimingContainer: FunctionComponent<TimingContainerProps> = () => {
  return (
    <div>
      <p>Timings:</p>
    </div>
  );
};

export default TimingContainer;
