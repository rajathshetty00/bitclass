import { BitButton } from 'src/components/common/BitButton/BitButton';
// import styles from './styles.module.scss';

const RegisterButton = () => {
  return <BitButton variant="contained">Join this course for free</BitButton>;
};

export default RegisterButton;
