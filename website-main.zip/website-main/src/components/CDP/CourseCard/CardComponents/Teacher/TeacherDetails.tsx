import { useRouter } from 'next/router';
import NextImage from 'src/components/common/NextImage/NextImage';
import { getHrefLink } from 'utils';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

const DEFAULT_TEACHER_IMAGE =
  'https://res.cloudinary.com/bitclass/image/upload/v1643643631/Website%20ICONS/profile-empty_nlfvlq.svg';

const TeacherDetails = ({ teacherDetails }: any) => {
  const { image, name, profile_handle } = teacherDetails || {};
  const teacherImage = image ?? DEFAULT_TEACHER_IMAGE;
  const router = useRouter();

  return (
    <a
      href={getHrefLink(`${BASE_URL}/new/teacher/${profile_handle}`, router)}
      className={styles.teacherDetails}
    >
      <NextImage
        src={teacherImage}
        objectFit="cover"
        width={40}
        height={40}
        quality={40}
        className={styles.teacherImage}
        unoptimized
      />

      <div className={styles.teacherName}>
        <span>Taught By</span>
        <span className={styles.name}>{name}</span>
      </div>
    </a>
  );
};

export default TeacherDetails;
