// import { AppState, useAppSelector } from 'redux/store';
import { FC } from 'react';
import { Typography } from '@mui/material';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { ICourse } from 'interfaces/cdp/course';
import { AppState, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import styles from './styles.module.scss';

interface ICourseCardProps {
  course: ICourse;
}
const CourseCardLite: FC<ICourseCardProps> = ({ course }) => {
  const { heading, course_url, teacher, intro_video_thumbnail } = course;
  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );
  return (
    <div className={styles.courseCard}>
      <NextImage
        src={intro_video_thumbnail ?? assetObject.defaultCourseCardLiteImg}
        width={100}
        height={isMobile ? 180 : 200}
        className={styles.thumbnail}
        quality={60}
        // objectFit="cover"
      />
      <div className={styles.cardContent}>
        {/* <div> */}
        <Typography component="div" variant="h5" className={styles.courseTitle}>
          {heading}
        </Typography>
        <div className={styles.teacherContainer}>
          <NextImage
            src={teacher?.image ?? assetObject.profileEmpty}
            width={50}
            height={50}
            quality={30}
            className={styles.teacherImage}
          />
          <div className={styles.teacherDetails}>
            <div className={styles.teacherNameContainer}>
              <span className={styles.teacherSubtitle}>Taught by</span>
              <span className={styles.teacherName}>{teacher?.name}</span>
            </div>
            {!isMobile && (
              <BitButton
                className={styles.registerBtn}
                onClick={() => window.open(course_url, '_blank')}
              >
                Register for FREE
              </BitButton>
            )}
          </div>
        </div>
        {isMobile && (
          <BitButton
            className={styles.registerBtn}
            onClick={() => window.open(course_url, '_blank')}
          >
            Register for FREE
          </BitButton>
        )}
        {/* </div> */}
      </div>
    </div>
  );
};

export default CourseCardLite;
