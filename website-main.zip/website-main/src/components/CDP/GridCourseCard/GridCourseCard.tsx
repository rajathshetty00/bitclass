/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/interactive-supports-focus */
import TeacherDetails from 'src/components/CDP/CourseCard/CardComponents/Teacher/TeacherDetails';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import dayjs from 'dayjs';
import { useRouter } from 'next/router';
import { CDP_TYPE } from 'utils/constants/cdp';
import { BASE_URL } from 'utils/constants';
import { getCurrencySymbol } from 'utils/currency';
import styles from './styles.module.scss';

const DEFAULT_CARD_IMAGE: string =
  'https://res.cloudinary.com/bitclass/image/upload/v1643644391/Website%20ICONS/defaultCourseImage_rvyyxz.svg';

const GridCourseCard = ({ courseDetails }: any) => {
  const { intro_video_thumbnail, teacher, rating, start_ts, end_ts, code } =
    courseDetails || {};
  const router = useRouter();

  const openLiveClass = (courseCode: string) =>
    window.open(`${BASE_URL}/live-classes/classroom/${courseCode}`);

  const getCourseCardText = (course: any) => {
    if (course?.is_live)
      return <BitButton className={styles.joinBtn}>Attend NOW</BitButton>;

    if (course?.type === CDP_TYPE.subscription)
      return (
        <BitButton className={styles.joinBtn}>Get started for FREE</BitButton>
      );

    if (course?.amount > 0) {
      const currency = getCurrencySymbol(course?.currency ?? 'INR');
      return (
        <BitButton className={styles.joinBtn}>
          Join this course for {currency}
          {course?.amount}
        </BitButton>
      );
    }
    return <BitButton className={styles.joinBtn}>Register for FREE</BitButton>;
  };

  const handleCourseCardClicked = () => {
    if (courseDetails?.is_live) return openLiveClass(code);
    router.push(`${code}`);
  };
  return (
    <div
      className={styles.courseCard}
      onClick={handleCourseCardClicked}
      role="button"
    >
      <div className={styles.topSection}>
        <img
          src={intro_video_thumbnail ?? DEFAULT_CARD_IMAGE}
          className={styles.image}
          alt="course card"
        />
        <div className={styles.cardGradient} />
        <div className={styles.rating}>
          <span>★</span>
          {rating}
        </div>
        {courseDetails?.is_live && (
          <div className={styles.liveTag}>
            <span>LIVE</span>
          </div>
        )}
        <div className={styles.schedule}>
          {dayjs.unix(start_ts).format('DD MMM ')}-
          {dayjs.unix(end_ts).format(' DD MMM')}
        </div>
      </div>
      <div className={styles.details}>
        <h4 className={styles.heading}>{courseDetails?.heading}</h4>
        <div className={styles.teacherDetails}>
          <TeacherDetails teacherDetails={teacher} />
        </div>
        {getCourseCardText(courseDetails)}
      </div>
    </div>
  );
};

export default GridCourseCard;
