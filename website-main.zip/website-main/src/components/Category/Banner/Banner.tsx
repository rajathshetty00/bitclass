import { Breadcrumbs, Link } from '@mui/material';
import clsx from 'clsx';
import { ICategory } from 'interfaces/category/category';
import { useRouter } from 'next/router';
import { FC } from 'react';
import { ChevronLeft } from 'react-feather';
import { useSelector } from 'react-redux';
import { AppState, useAppSelector } from 'redux/store';
import { getHrefLink } from 'utils';
import { assetObject } from 'utils/assetFileNames';
import { BASE_URL } from 'utils/constants';
import NextImage from '../../common/NextImage/NextImage';
import styles from './styles.module.scss';

const BannerTitle: FC<any> = ({ children, isMobile }) => (
  <h1 className={clsx(styles.title, { [styles.lg]: !isMobile })}>{children}</h1>
);
const AnalyticsComponent: FC<any> = ({ courseCount, TeacherCount }) => (
  <div className={styles.countContainer}>
    {courseCount !== 0 && (
      <>
        <span className={styles.base}>{courseCount}</span>
        <span className={styles.subfield}>Courses</span>{' '}
      </>
    )}

    {TeacherCount !== 0 && (
      <>
        <span className={styles.vl} />
        <span className={styles.base}>{TeacherCount}</span>
        <span className={styles.subfield}>Teachers</span>{' '}
      </>
    )}
  </div>
);

const Banner = ({ isHome }: any) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const {
    categoryData: { meta },
  }: ICategory = useAppSelector((state: AppState) => state.category);
  const router = useRouter();
  const gotoBack = () => router.back();

  const styling = {
    background: `url(${
      isMobile ? meta?.banner?.mobile : meta?.banner?.web
    }) no-repeat`,
    width: '100%',
    height: isMobile ? '100px' : '292px',
    backgroundPosition: 'center',
    backgroundSize: 'cover',
  };
  return (
    <section id="category_banner">
      <div className={styles.banner_container}>
        <div className={styles.bgImg} style={styling} />
        <div
          className={clsx(styles.contentDiv, {
            [styles.isMobileContainer]: isMobile,
          })}
        >
          {isMobile ? (
            <div className={styles.heading}>
              <ChevronLeft
                role="button"
                className={styles.backIcon}
                size={34}
                onClick={gotoBack}
              />
              <BannerTitle isMobile={isMobile}>
                {meta?.heading || 'Creative club'}
              </BannerTitle>
            </div>
          ) : (
            <div className={styles.innerContainer}>
              {!isHome && (
                <Breadcrumbs
                  aria-label="breadcrumb"
                  className={styles.breadcrumb}
                >
                  <Link
                    href={getHrefLink(`${BASE_URL}`, router)}
                    className={styles.link}
                  >
                    <p>Home</p>
                  </Link>
                  <Link href={`${router.asPath}`} className={styles.link}>
                    <span>
                      {meta?.heading || 'Creative club for bussiness'}
                    </span>
                  </Link>
                </Breadcrumbs>
              )}
              <BannerTitle>
                {meta?.heading || 'Creative club for bussiness'}
              </BannerTitle>
              <p className={styles.banner_description}>{meta?.description}</p>
              <AnalyticsComponent
                courseCount={meta?.course_count || 0}
                TeacherCount={meta?.teacher_count || 0}
              />
              <div
                className={clsx(
                  styles.cicleContainer,
                  styles.gredientContainer,
                  {
                    [styles.desktopCicleImg]: !isMobile,
                  },
                )}
              >
                <NextImage
                  src={
                    meta?.circular_icon || assetObject?.defaultCourseCardLiteImg
                  }
                  width={isMobile ? 220 : 260}
                  height={isMobile ? 220 : 260}
                  className={styles.circleImage}
                />
              </div>
            </div>
          )}
          {isMobile && (
            <AnalyticsComponent
              courseCount={meta?.course_count || 0}
              TeacherCount={meta?.teacher_count || 0}
            />
          )}
        </div>
        {/* circles */}
        {isMobile && (
          <div
            className={`${styles.cicleContainer} ${styles.gredientContainer}`}
          >
            <NextImage
              src={meta?.circular_icon || assetObject.defaultCourseCardLiteImg}
              width={110}
              height={110}
              className={styles.circleImage}
            />
          </div>
        )}
      </div>
      {isMobile && <p className={styles.discription}>{meta?.description}</p>}
    </section>
  );
};

export default Banner;
