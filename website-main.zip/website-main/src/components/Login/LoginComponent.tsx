import { FC, useEffect } from 'react';
import InitialPhoneSignInLayout from 'src/layouts/AuthLayout/InitialPhoneSignInLayout/InitialPhoneSignInLayout';
import SignInByOtpLayout from 'src/layouts/AuthLayout/SignInByOtpLayout/SignInByOtpLayout';
import SignUpLayout from 'src/layouts/AuthLayout/SignUpLayout/SignUpLayout';
import {
  startLogin,
  initialSignInPageViewed,
  otpClicked,
  signUpViewed,
  clearMessage,
} from 'redux/reducers/authReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { Typography } from '@mui/material';
import { BitMuiDialog } from 'src/components/common/BitMuiDialog/BitMuiDialog';

interface LoginProps {
  wrapModal?: Boolean;
}

const LoginComponent: FC<LoginProps> = ({ wrapModal }) => {
  const dispatch = useAppDispatch();

  const {
    isOtpButtonClicked,
    isInitialPageOpen,
    isSignUpStarted,
    message,
    isLoginSuccess,
    postLogin,
  } = useAppSelector((state: AppState) => state.auth);

  useEffect(() => {
    if (isLoginSuccess && postLogin) postLogin();
  }, [isLoginSuccess, postLogin]);

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        dispatch(clearMessage());
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [dispatch, message]);

  const onCancelHandler = () => {
    dispatch(startLogin(false));
    dispatch(otpClicked(false));
    dispatch(initialSignInPageViewed(false));
    dispatch(signUpViewed(false));
  };

  return (
    <div>
      {wrapModal ? (
        <BitMuiDialog onCancel={onCancelHandler}>
          {isInitialPageOpen && <InitialPhoneSignInLayout />}
          {isOtpButtonClicked && <SignInByOtpLayout />}
          {isSignUpStarted && <SignUpLayout />}
          {message && (
            <Typography marginTop="16px" fontWeight="600" color="red">
              {message.toString()}
            </Typography>
          )}
        </BitMuiDialog>
      ) : (
        <>
          {isInitialPageOpen && <InitialPhoneSignInLayout />}
          {isOtpButtonClicked && <SignInByOtpLayout />}
          {isSignUpStarted && <SignUpLayout />}
          {message && (
            <Typography marginTop="16px" fontWeight="600" color="red">
              {message.toString()}
            </Typography>
          )}
        </>
      )}
    </div>
  );
};

LoginComponent.defaultProps = {
  wrapModal: true,
};

export default LoginComponent;
