import Link from 'next/link';
import React from 'react';
import clsx from 'clsx';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { BASE_URL } from 'utils/constants';
import { useRouter } from 'next/router';
import { getHrefLink } from 'utils';
import NextImage from '../common/NextImage/NextImage';
import styles from './styles.module.scss';

interface IOtherCategory {
  key: number;
  item: any;
}

const OtherCategory = ({ key, item }: IOtherCategory) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const router = useRouter();
  const { display_text, icon } = item;

  return (
    <div key={key} className={styles.otherCategoryWrapper}>
      <Link
        href={getHrefLink(
          `${BASE_URL}/live-classes/category/${display_text}?channel=category_page_other_category&platform=${
            isMobile ? 'mweb' : 'web'
          }`,
          router,
        )}
      >
        <div className={styles.otherContainer}>
          <div className={styles.gredientContainer}>
            <NextImage
              src={icon}
              width={isMobile ? 116 : 200}
              height={isMobile ? 116 : 200}
              unoptimized
              className={styles.otherCategoryImg}
              objectFit="cover"
              objectPosition="center"
            />
          </div>
          <p
            className={clsx(styles.categoryLabel, {
              [styles.mobileLabel]: isMobile,
            })}
          >
            {display_text}
          </p>
        </div>
      </Link>
    </div>
  );
};

export default OtherCategory;
