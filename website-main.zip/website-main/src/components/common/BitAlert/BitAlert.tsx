import { Alert, AlertColor, Snackbar } from '@mui/material';
import { useState, forwardRef, useImperativeHandle } from 'react';

const BitAlert = forwardRef((props, ref) => {
  const [openAlert, setOpenAlert] = useState<boolean>(false);
  const [msg, setMsg] = useState<string>('');
  const [status, setMsgStatus] = useState<AlertColor>('info');

  const [time, SetTime] = useState<number | null>(null);

  useImperativeHandle(ref, () => ({
    toggleOpenAlert(s: AlertColor, m: string, t: number) {
      setOpenAlert(true);
      setMsg(m);
      setMsgStatus(s);
      if (t) {
        SetTime(t);
      }
    },
  }));
  const handleCloseAlert = () => {
    setOpenAlert(false);
  };

  return (
    <Snackbar
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      open={openAlert}
      autoHideDuration={time || 4000}
      onClose={handleCloseAlert}
      key="top-center"
    >
      <Alert onClose={() => {}} severity={status} sx={{ width: '100%' }}>
        {msg}
      </Alert>
    </Snackbar>
  );
});

export default BitAlert;
