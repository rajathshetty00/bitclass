import { FunctionComponent } from 'react';
import { useSelector } from 'react-redux';
import { setModalState } from 'redux/reducers/appReducer';
import {
  initialiseSignIn,
  initialSignInPageViewed,
  onPostLogin,
  startLogin,
} from 'redux/reducers/authReducer';
import { AppState, useAppDispatch } from 'redux/store';
import { BASE_URL } from 'utils/constants';
import LoginComponent from 'src/components/Login/LoginComponent';
import { getUserInfo } from 'utils/auth/userInfo';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { LOGO, LOGO_ICON } from 'utils/logo/logo';
import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import { getHrefLink, getQuery } from 'utils';
import { useRouter } from 'next/router';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { CustomDefaultButton } from '../BitMuiButton';
import NextImage from '../NextImage/NextImage';
import styles from './styles.module.scss';
import LoggedIn from './Chunks/LoggedIn';
import {
  CurriculumCdpContents,
  ProfileContents,
} from './Chunks/PageTypeComponents';
import { BitButton } from '../BitButton/BitButton';
import Search from './Chunks/PageTypeComponents/Search/Search';

interface BitAppHeaderProps {
  customClass?: string;
}

const DiscoveryButton = () => {
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const appendQueryParamAndNavigate = useBitRouter();
  return (
    <BitButton
      variant="contained"
      onClick={() =>
        appendQueryParamAndNavigate(
          `${BASE_URL}?channel=home&platform=${isMobile ? 'mweb' : 'web'}`,
          getQuery(router),
        )
      }
      className="shimmerButton"
    >
      Discover Courses
    </BitButton>
  );
};
const BitAppHeader: FunctionComponent<BitAppHeaderProps> = ({
  customClass,
}) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const { userInfo } = useSelector((state: AppState) => state?.auth);
  const { pageType } = useSelector((state: AppState) => state?.app);
  const router = useRouter();

  const dispatch = useAppDispatch();
  const userData = userInfo || getUserInfo();

  const { fetchDataOnPageType } = useRightSectionRenderer();

  const onLoginSuccess = () => {
    fetchDataOnPageType();
  };

  const handleClickOpen = () => {
    saveGtmDataLayerData({
      data: { source: 'header' },
      eventName: EVENT_NAMES.LOGIN_VIEWED,
    });
    dispatch(initialiseSignIn());
    dispatch(setModalState(true));
    dispatch(initialSignInPageViewed(true));
    dispatch(onPostLogin(onLoginSuccess));
    dispatch(startLogin(true));
  };

  const PrependComponentBeforeLogo: any = Object.freeze({
    PROFILE_PAGE: <ProfileContents />,
    HOME_PAGE: <ProfileContents />,
  });

  const Components: any = Object.freeze({
    CDP_CURRICULUM_PAGE: <CurriculumCdpContents />,
    PROFILE_PAGE: <DiscoveryButton />,
    HOME_PAGE: <Search />,
    CDP_SUBSCRIPTION_PAGE: <Search />,
    CDP_FREEMIUM_PAGE: <Search />,
    CDP_FULL_COURSE_PAGE: <Search />,
    CDP_FREE_COURSE_PAGE: <Search />,
    CDP_WORKSHOP_PAGE: <Search />,
    CDP_TMPR_PAGE: <Search />,
    COLLECTION_PAGE: <Search />,
    CATEGORY_PAGE: <Search />,
  });

  return (
    <div className={customClass}>
      <header className={styles.headerContainer}>
        {PrependComponentBeforeLogo[pageType]}
        <a
          href={getHrefLink(
            `${BASE_URL}?channel=home&platform=${isMobile ? 'mweb' : 'web'}`,
            router,
          )}
        >
          <NextImage
            src={!isMobile ? LOGO.dark : LOGO_ICON.dark}
            width={!isMobile ? 120 : 48}
            height={!isMobile ? 64 : 48}
            objectFit="contain"
            unoptimized
          />
        </a>
        <div className={styles.headerRightSide}>
          {Components[pageType]}

          {userData ? (
            <LoggedIn userData={userData} />
          ) : (
            <CustomDefaultButton
              className={styles.buttonContainer}
              onClick={handleClickOpen}
              variant="contained"
            >
              login
            </CustomDefaultButton>
          )}
        </div>
      </header>
      <LoginComponent />
    </div>
  );
};

BitAppHeader.defaultProps = {
  customClass: '',
};

export default BitAppHeader;
