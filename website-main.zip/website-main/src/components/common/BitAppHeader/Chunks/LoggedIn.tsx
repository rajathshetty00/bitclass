import { FC, useState, MouseEvent } from 'react';
import Popover from '@mui/material/Popover';
import { BASE_URL } from 'utils/constants';
import { Typography } from '@mui/material';
import styles from 'src/components/common/BitAppHeader/styles.module.scss';
import { clearUserInfo, loginSuccessful } from 'redux/reducers/authReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { deleteAuthToken, deleteCookie, getHrefLink } from 'utils';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { clearCdpDataForLoggedOutUser } from 'redux/reducers/cdpReducer';
import PAGE_TYPES from 'utils/constants/pageTypes';
import { actionGetSubscriptionPlan } from 'redux/actions/subCdpAction';
import { setRole } from 'utils/auth/userInfo';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';
import LoggedInAvatar from './LoggedInAvatar';

interface LoggedInProps {
  userData: Object | null;
}

const LoggedIn: FC<LoggedInProps> = ({ userData }) => {
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const dispatch = useAppDispatch();

  const { pageType } = useAppSelector((state: AppState) => state?.app);

  const {
    course: { code },
  } = useAppSelector((state: AppState) => state?.cdp);

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const initialiseCdpRightSection = async () => {
    switch (pageType) {
      case PAGE_TYPES.CDP_SUBSCRIPTION_PAGE:
      case PAGE_TYPES.CDP_FREEMIUM_PAGE:
        await dispatch(actionGetSubscriptionPlan(code));
        break;
      default:
        dispatch(clearCdpDataForLoggedOutUser());
    }
  };

  const handleLogout = () => {
    setAnchorEl(null);
    localStorage.clear();
    dispatch(loginSuccessful(false));
    dispatch(clearUserInfo(false));
    deleteCookie('auth-key');
    deleteAuthToken();
    initialiseCdpRightSection();
    setRole('student');
    saveGtmDataLayerData({
      event: EVENT_NAMES.LOGOUT_CLICKED,
    });
    if (router.asPath.includes('profile')) {
      window.location.replace(
        getHrefLink(
          `${BASE_URL}?platform=${isMobile ? 'mweb' : 'web'}`,
          router,
        ),
      );
    }
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  return (
    <div className="cursorCss">
      <LoggedInAvatar showAccountMenu={handleClick} userData={userData} />
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
      >
        <div className={styles.popoverContainer}>
          <Typography
            onClick={() => {
              setAnchorEl(null);
              window.location.href = getHrefLink(
                `${BASE_URL}/live-classes/profile?platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              );
            }}
            variant="body2"
          >
            My Classes
          </Typography>
          <Typography variant="body2" onClick={handleLogout}>
            Logout
          </Typography>
        </div>
      </Popover>
    </div>
  );
};

export default LoggedIn;
