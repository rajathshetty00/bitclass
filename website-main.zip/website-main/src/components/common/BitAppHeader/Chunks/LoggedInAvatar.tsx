import React, { FC } from 'react';
import clsx from 'clsx';

import styles from 'src/components/common/BitAppHeader/styles.module.scss';
import { ChevronDown } from 'react-feather';
import { ILogin } from 'interfaces/chunks/loginAvatar';

const LoggedInAvatar: FC<ILogin> = ({ userData, showAccountMenu }) => {
  const { username, image, firstName } = userData;

  return (
    <div className={styles.profilePicContainer}>
      <div
        className={clsx(styles.profilePic)}
        style={
          image
            ? { backgroundImage: `url(${image})` }
            : { backgroundColor: `orange` }
        }
        role="img"
        aria-hidden
        onClick={(e: any) => showAccountMenu(e)}
      >
        {!image && <span>{firstName ? firstName?.[0] : username?.[0]}</span>}
      </div>
      <ChevronDown
        className={styles.iconColor}
        size="16"
        onClick={(e: any) => showAccountMenu(e)}
      />
    </div>
  );
};

export default LoggedInAvatar;
