import SearchIcon from '@mui/icons-material/Search';
import { useRouter } from 'next/router';
import { debounce } from 'lodash';
import { getQuery, sanitizeSpecialCharacter } from 'utils';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { BASE_URL } from 'utils/constants';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { updateSearchDrawer } from 'redux/reducers/appReducer';
import styles from './styles.module.scss';
import SearchDrawer from '../SearchDrawer/SearchDrawer';

const Search = () => {
  const dispatch = useAppDispatch();

  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );

  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();
  const onSearch = (e: any) =>
    appendQueryParamAndNavigate(
      `${BASE_URL}/new/search-result-page?q=${sanitizeSpecialCharacter(
        e.target.value,
      )}&channel=home_page_search&platform=${isMobile ? 'mweb' : 'web'}`,
      getQuery(router),
      false,
    );

  const onSearchIconClickHandler = () => {
    dispatch(updateSearchDrawer({ anchor: 'top', show: 'true' }));
  };

  const handleChange = debounce(onSearch, 600);
  return (
    <>
      {isMobile ? (
        <SearchIcon
          className={styles.mobileSearchIcon}
          onClick={onSearchIconClickHandler}
        />
      ) : (
        <div className={styles.searchContainer}>
          <div className={styles.searchInputWrapper}>
            <SearchIcon />
            <input placeholder="Search LIVE Classes" onChange={handleChange} />
          </div>

          <BitButton
            variant="outlined"
            onClick={() =>
              appendQueryParamAndNavigate(
                `${BASE_URL}/n/launchpad?channel=home_page_search&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                getQuery(router),
              )
            }
            className={styles.teachOnBitClassBtn}
          >
            Teach on BitClass
          </BitButton>
        </div>
      )}

      <SearchDrawer handleChange={handleChange} />
    </>
  );
};

export default Search;
