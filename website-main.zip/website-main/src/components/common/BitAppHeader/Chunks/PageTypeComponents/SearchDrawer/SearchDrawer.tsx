import { FC } from 'react';
import { updateSearchDrawer } from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import BitDrawer from 'src/components/common/BitDrawer/BitDrawer';
import styles from './styles.module.scss';

interface SearchDrawerProps {
  handleChange: any;
}

const SearchDrawer: FC<SearchDrawerProps> = ({ handleChange }) => {
  const { showSearchDrawer } = useAppSelector((state: AppState) => state?.app);

  const dispatch = useAppDispatch();

  const onDrawerClose = () => {
    return dispatch(updateSearchDrawer({ anchor: 'top', show: false }));
  };

  return (
    <BitDrawer onDrawerClose={onDrawerClose} showBitDrawer={showSearchDrawer}>
      <div className={styles.searchDrawerWrapper}>
        <input placeholder="Search LIVE Classes" onChange={handleChange} />
      </div>
    </BitDrawer>
  );
};

export default SearchDrawer;
