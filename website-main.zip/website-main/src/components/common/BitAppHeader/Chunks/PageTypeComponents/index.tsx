import useCheckout from 'hooks/useCheckout';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { useRouter } from 'next/router';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import clsx from 'clsx';
import { hasAuthToken } from 'utils/auth/userInfo';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { getCurriculumGTMData, getQuery } from 'utils';
import MenuIcon from '@mui/icons-material/Menu';
import { updateBitDrawer } from 'redux/reducers/appReducer';
import { useBitRouter } from 'src/hooks/useBitRouter';
import styles from '../../styles.module.scss';

const addtionalObject = { location: 'header' };

export const CurriculumCdpContents = () => {
  const { initiateFreeCheckout, getFreeCourseButtonText } = useCheckout();
  const { has_full_course_ended, has_workshop_ended } = useAppSelector(
    (state: AppState) => state.cdp.course,
  );
  const { courseRegistrationDetails, course } = useAppSelector(
    (state: AppState) => state.cdp,
  );

  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();

  const { asPath: path } = router;

  const { workshop_registration, course_registration } =
    courseRegistrationDetails;

  const getRoute = () =>
    path.includes('curriculum-content') ? path : `${path}#curriculum-content`;

  const handleFreeCheckout = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.BOOK_FREE_CLASS_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, addtionalObject),
    });
    initiateFreeCheckout();
  };

  const handleBuyFullCourse = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.BUY_FULL_COURSE_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, addtionalObject),
    });

    appendQueryParamAndNavigate(getRoute(), getQuery(router));
  };

  return (
    <div
      className={
        hasAuthToken()
          ? styles.curriculumLinkContainer
          : clsx(styles.curriculumLinkContainer, styles.mr2)
      }
    >
      {!has_full_course_ended && !course_registration ? (
        <BitButton
          className={styles.buyFullCourse}
          onClick={handleBuyFullCourse}
        >
          Checkout Full Course
        </BitButton>
      ) : (
        <div />
      )}
      {!has_workshop_ended && !workshop_registration && (
        <BitButton
          variant="contained"
          onClick={handleFreeCheckout}
          className={clsx(styles.freeCourseBtn, 'shimmerButton')}
        >
          {getFreeCourseButtonText()}
        </BitButton>
      )}
    </div>
  );
};

export const ProfileContents = () => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const dispatch = useAppDispatch();

  return (
    <>
      {isMobile && (
        <MenuIcon
          onClick={() =>
            dispatch(updateBitDrawer({ anchor: 'left', show: true }))
          }
          className={styles.hamburgerButton}
        />
      )}
    </>
  );
};
