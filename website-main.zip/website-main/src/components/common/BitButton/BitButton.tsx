import { FC } from 'react';
import {
  Button,
  ButtonBase,
  ButtonProps,
  IconButton,
  IconButtonProps,
} from '@mui/material';

interface IButton extends ButtonProps {}
interface IIconButton extends IconButtonProps {}

export const BitBaseButton: FC<IButton> = (props) => {
  const { children } = props;
  return <ButtonBase {...props}>{children}</ButtonBase>;
};

export const BitButton: FC<IButton> = (props) => {
  const { children } = props;
  return <Button {...props}>{children}</Button>;
};

export const BitIconButtonV2: FC<IIconButton> = (props) => {
  const { children } = props;
  return <IconButton {...props}>{children}</IconButton>;
};
