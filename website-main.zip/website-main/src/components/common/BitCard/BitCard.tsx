import clsx from 'clsx';
import styles from './styles.module.scss';

const BitCard = ({ customClass, width, children }: any) => {
  return (
    <div
      style={{ width: width || '100%' }}
      className={clsx(styles.cardSection, customClass)}
    >
      {children}
    </div>
  );
};

export default BitCard;
