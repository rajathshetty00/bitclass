import { useDynamicSection } from 'hooks/useDynamicSection';
import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import RectangularSkeletonLoader from 'src/components/profile/RectangularSkeletonLoader/RectangularSkeletonLoader';
import BitSlickSlider from '../BitSlickSlider/BitSlickSlider';
import CourseCardV2 from '../CourseCard/CourseCardV2/CourseCardV2';
import styles from './styles.module.scss';

interface BitCardCarouselProps {
  source: string;
  sectionType: string;
  heading?: string;
}

const BitCardCarousel: FC<BitCardCarouselProps> = ({
  source,
  sectionType,
  heading = '',
}) => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const { results, isLoading } = useDynamicSection({
    source,
  });

  return (
    <div className={styles.bitCardCarouselWrapper}>
      {isLoading && <RectangularSkeletonLoader height={isMobile ? 600 : 340} />}
      {results?.length > 0 && (
        <div key={heading} className={styles.sectionContainer}>
          <h3>{heading}</h3>
          <BitSlickSlider
            customSettings={{
              slidesToShow: isMobile ? 1.1 : 3.5,
              slidesToScroll: isMobile ? 1 : 3,
              arrows: !isMobile,
            }}
            customClass={styles.customSlick}
          >
            {results?.map((item: any, index: number) => (
              <CourseCardV2
                sectionHeading={heading}
                item={{ ...item, position: index + 1, sectionType }}
              />
            ))}
          </BitSlickSlider>
        </div>
      )}
    </div>
  );
};

export default BitCardCarousel;

BitCardCarousel.defaultProps = {
  heading: '',
};
