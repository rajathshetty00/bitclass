/* eslint-disable no-return-assign */
import Slider from 'react-slick';
import { ChevronLeft, ChevronRight } from 'react-feather';
import { FC, ReactNode } from 'react';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import clsx from 'clsx';
import styles from './styles.module.scss';

const NextArrow = ({ onClick }: any) => (
  <button
    onClick={onClick}
    type="button"
    className={clsx(styles.nextArrow, styles.navArrow)}
  >
    <ChevronRight />
  </button>
);
const PreviousArrow = ({ onClick }: any) => (
  <button
    onClick={onClick}
    type="button"
    className={clsx(styles.prevArrow, styles.navArrow)}
  >
    <ChevronLeft />
  </button>
);

interface IProps {
  children: ReactNode | ReactNode[];
  carouselSettings?: any;
  isMobile?: boolean;
  handleAfterChange?: Function;
}

const BitPureCarousel: FC<IProps> = ({ children, carouselSettings }) => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    swipeToSlide: true,
    ...carouselSettings,
  };

  return (
    <div className={styles.slider}>
      {/* @ts-ignore */}
      <Slider
        {...settings}
        nextArrow={carouselSettings?.arrows && <NextArrow />}
        prevArrow={carouselSettings?.arrows && <PreviousArrow />}
      >
        {children}
      </Slider>
    </div>
  );
};

BitPureCarousel.defaultProps = {
  isMobile: false,
  handleAfterChange: () => null,
  carouselSettings: { autoPlay: false },
};
export default BitPureCarousel;
