import { useDynamicSection } from 'hooks/useDynamicSection';
import React, { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import OtherCategory from 'src/components/OtherCategory';
import RectangularSkeletonLoader from 'src/components/profile/RectangularSkeletonLoader/RectangularSkeletonLoader';
import BitSlickSlider from '../BitSlickSlider/BitSlickSlider';
import styles from './styles.module.scss';

interface BitCategoryCarouselProps {
  source: string;
  heading: string;
}

const BitCategoryCarousel: FC<BitCategoryCarouselProps> = ({
  source,
  heading,
}) => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const { results, isLoading } = useDynamicSection({
    source,
  });

  return (
    <div className={styles.bitCategoryCarouselWrapper}>
      {results?.length > 0 && <h3>{heading}</h3>}

      <BitSlickSlider
        customClass={styles.customSlick}
        customSettings={{
          slidesToShow: isMobile ? 3.2 : 5.2,
          slidesToScroll: isMobile ? 3 : 5,
          arrows: !isMobile,
          dots: false,
        }}
      >
        {isLoading && (
          <RectangularSkeletonLoader height={isMobile ? 600 : 340} />
        )}

        {results?.map((item: any) => (
          <OtherCategory key={item?.id} item={item} />
        ))}
      </BitSlickSlider>
    </div>
  );
};

export default BitCategoryCarousel;
