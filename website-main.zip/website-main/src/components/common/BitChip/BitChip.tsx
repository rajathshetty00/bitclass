import clsx from 'clsx';
import React, { FC } from 'react';
import styles from './styles.module.scss';

interface BitChipProps {
  text: React.ReactNode;
  customClass: string;
}

const BitChip: FC<BitChipProps> = ({ text, customClass }) => {
  return <div className={clsx(styles.bitChipWrapper, customClass)}>{text}</div>;
};

export default BitChip;
