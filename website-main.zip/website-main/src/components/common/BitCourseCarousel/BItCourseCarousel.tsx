/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/interactive-supports-focus */
import clsx from 'clsx';
import { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'react-feather';
import { AppState, useAppSelector } from 'redux/store';

import styles from './styles.module.scss';

const BitCourseCarousel = ({ itemCount, children, itemSize = 300 }: any) => {
  const ref = useRef();
  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );
  const [allowScrollRight, setAllowScrollRight] = useState(false);
  const [allowScrollLeft, setAllowScrollLeft] = useState(false);

  const scrollLeft = () => {
    // @ts-ignore
    const currentElement = ref?.current.childNodes[0];
    currentElement.scrollLeft -= itemSize;
    setAllowScrollRight(
      currentElement.scrollLeft + currentElement.clientWidth ===
        currentElement.scrollWidth,
    );
    setAllowScrollLeft(currentElement.scrollLeft > 0);

    // trackEvent(BIT_EVENTS.CAROUSEL_ARROW_CLICKED, {
    //   position: 'left',
    //   src: page,
    // });
  };
  const scrollRight = () => {
    // @ts-ignore
    const currentElement = ref?.current.childNodes[0];
    // @ts-ignore
    ref.current.childNodes[0].scrollLeft += itemSize + 100;
    setAllowScrollRight(
      currentElement.scrollLeft + currentElement.clientWidth + 100 >
        currentElement.scrollWidth,
    );
    setAllowScrollLeft(currentElement.scrollLeft > 0);
    // trackEvent(BIT_EVENTS.CAROUSEL_ARROW_CLICKED, {
    //   position: 'right',
    //   src: page,
    // });
  };

  return (
    <div className={styles.slider}>
      {!isMobile && itemCount > 3 && allowScrollLeft && (
        <div
          onClick={scrollLeft}
          className={clsx(styles.left, styles.arrow)}
          role="button"
        >
          <ChevronLeft />
        </div>
      )}
      {/* @ts-ignore */}
      <div className={styles.carousel} ref={ref}>
        {children}
      </div>
      {!isMobile && !allowScrollRight && itemCount > 3 && (
        <div
          onClick={scrollRight}
          className={clsx(styles.right, styles.arrow)}
          role="button"
        >
          <ChevronRight />
        </div>
      )}
    </div>
  );
};

export default BitCourseCarousel;
