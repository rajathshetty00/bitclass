import React, { FC } from 'react';
import Drawer from '@mui/material/Drawer';
import { useAppDispatch } from 'redux/store';
import { updateBitDrawer } from 'redux/reducers/appReducer';

type Anchor = 'top' | 'left' | 'bottom' | 'right';

interface BitDrawerProps {
  children: React.ReactNode;
  showBitDrawer: IBitDrawerProps;
  onDrawerClose?: () => void;
}

interface IBitDrawerProps {
  anchor: Anchor;
  show: boolean;
}

const BitDrawer: FC<BitDrawerProps> = ({
  children,
  showBitDrawer,
  onDrawerClose,
}) => {
  const dispatch = useAppDispatch();

  const toggleDrawer =
    () => (event: React.KeyboardEvent | React.MouseEvent) => {
      if (
        event.type === 'keydown' &&
        ((event as React.KeyboardEvent).key === 'Tab' ||
          (event as React.KeyboardEvent).key === 'Shift')
      ) {
        return;
      }
      // code here
      // @ts-ignore
      onDrawerClose();
      return dispatch(updateBitDrawer({ ...showBitDrawer, show: false }));
    };

  return (
    <Drawer
      open={showBitDrawer?.show}
      anchor={showBitDrawer?.anchor}
      onClose={toggleDrawer()}
    >
      {children}
    </Drawer>
  );
};

export default BitDrawer;

BitDrawer.defaultProps = {
  onDrawerClose: () => undefined,
};
