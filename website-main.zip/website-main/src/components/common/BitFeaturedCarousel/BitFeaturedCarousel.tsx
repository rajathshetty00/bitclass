import { useDynamicSection } from 'hooks/useDynamicSection';
import React, { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import RectangularSkeletonLoader from 'src/components/profile/RectangularSkeletonLoader/RectangularSkeletonLoader';
import BitSlickSlider from '../BitSlickSlider/BitSlickSlider';
import FeaturedCourseCard from '../CourseCard/FeaturedCourseCard/FeaturedCourseCard';
import styles from './styles.module.scss';

interface BitFeaturedCarouselProps {
  source: string;
  heading: string;
}

const BitFeaturedCarousel: FC<BitFeaturedCarouselProps> = ({
  source,
  heading,
}) => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const { results, isLoading } = useDynamicSection({
    source,
  });

  return (
    <div className={styles.bitFeaturedCarouselWrapper}>
      {results?.length > 0 && <h3>{heading}</h3>}

      <BitSlickSlider
        customClass={styles.customSlick}
        customSettings={{
          slidesToShow: isMobile ? 1 : 1.1,
          slidesToScroll: 1,
          arrows: true,
          dots: true,
          autoplay: true,
        }}
      >
        {isLoading && (
          <RectangularSkeletonLoader height={isMobile ? 600 : 340} />
        )}

        {results?.map((item: any) => (
          <FeaturedCourseCard
            sectionHeading={heading}
            key={item?.code}
            item={item}
          />
        ))}
      </BitSlickSlider>
    </div>
  );
};

export default BitFeaturedCarousel;
