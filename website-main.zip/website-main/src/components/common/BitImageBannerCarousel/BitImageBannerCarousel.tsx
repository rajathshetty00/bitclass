import { useDynamicSection } from 'hooks/useDynamicSection';
import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import RectangularSkeletonLoader from 'src/components/profile/RectangularSkeletonLoader/RectangularSkeletonLoader';
import BitSlickSlider from '../BitSlickSlider/BitSlickSlider';
import ImageBanner from '../ImageBanner/ImageBanner';
import styles from './styles.module.scss';

interface BitImageBannerCarouselProps {
  source: string;
  sectionType: string;
  heading?: string;
  sectionHeading?: string;
}

const BitImageBannerCarousel: FC<BitImageBannerCarouselProps> = ({
  source,
  sectionType,
  heading = '',
  sectionHeading = '',
}) => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const { results, isLoading } = useDynamicSection({
    source,
    sectionType,
  });

  return (
    <div className={styles.bitImageBannerCarouselWrapper}>
      {results?.length > 0 && <h3>{heading}</h3>}
      <BitSlickSlider
        customSettings={{
          slidesToShow: isMobile ? 1.08 : 2,
          slidesToScroll: isMobile ? 1 : 2,
          arrows: !isMobile,
          dots: true,
          // infinite: results?.length > 1,
          autoplay: true,
        }}
        customClass={styles.customSlick}
      >
        {isLoading && (
          <RectangularSkeletonLoader height={isMobile ? 600 : 340} />
        )}
        {results?.map((item: any, index: number) => (
          // @ts-ignore
          <ImageBanner
            item={{ ...item, positon: index, sectionType }}
            sectionHeading={sectionHeading}
          />
        ))}
      </BitSlickSlider>
    </div>
  );
};

export default BitImageBannerCarousel;

BitImageBannerCarousel.defaultProps = {
  heading: '',
  sectionHeading: '',
};
