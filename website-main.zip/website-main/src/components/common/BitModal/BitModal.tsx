import { FC, ReactNode } from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogProps,
  DialogTitle,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useAppDispatch } from 'redux/store';
import { updateBitModalState } from 'redux/reducers/appReducer';
import clsx from 'clsx';
import styles from './styles.module.scss';
import { BitIconButtonV2 } from '../BitButton/BitButton';

interface IModal extends DialogProps {
  children: ReactNode;
  title?: string;
  dialogActions?: null | ReactNode;
  customClass?: string;
  onClose?: any;
}
const BitModal: FC<IModal> = ({
  title,
  dialogActions,
  children,
  customClass,
  onClose,
  ...props
}) => {
  const dispatch = useAppDispatch();
  return (
    <Dialog
      {...props}
      aria-describedby="dialog-container"
      className={clsx(styles.dialog, customClass)}
    >
      <DialogTitle className={styles.dialogTitle}>
        <span>{title}</span>
        <BitIconButtonV2
          onClick={() =>
            onClose ? onClose() : dispatch(updateBitModalState(false))
          }
        >
          <CloseIcon />
        </BitIconButtonV2>
      </DialogTitle>
      <DialogContent>{children}</DialogContent>
      <DialogActions>{dialogActions}</DialogActions>
    </Dialog>
  );
};

BitModal.defaultProps = {
  title: '',
  dialogActions: null,
  customClass: '',
  onClose: null,
};
export default BitModal;
