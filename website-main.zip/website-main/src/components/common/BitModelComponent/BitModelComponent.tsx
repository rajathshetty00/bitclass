import * as React from 'react';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import { IBitMuiModelComponentProps } from 'utils/interfaces';
import Slide, { SlideProps } from '@mui/material/Slide';

const Transition = React.forwardRef<unknown, SlideProps>((props, ref) => (
  <Slide direction="up" ref={ref} {...props} />
));

const BootstrapDialog = styled(Dialog)(
  () =>
    ` 
     .MuiDialog-paper{
       border-radius: 8px;
       margin:0;
    }
  `,
);

const BitModelComponent = ({
  children,
  handleClose,
  isModalOpen,
  className,
  ...props
}: IBitMuiModelComponentProps) => {
  return (
    <div className={`${className}`}>
      <BootstrapDialog
        onClose={handleClose}
        open={isModalOpen}
        TransitionComponent={Transition}
        {...props}
        className={className}
      >
        {children}
      </BootstrapDialog>
    </div>
  );
};

export default BitModelComponent;
