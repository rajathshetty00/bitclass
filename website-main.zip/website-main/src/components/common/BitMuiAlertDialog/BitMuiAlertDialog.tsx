import * as React from 'react';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import { AppState, useAppSelector } from 'redux/store';
import { IBitMuiAlertDialogProps } from 'utils/interfaces';
import Slide, { SlideProps } from '@mui/material/Slide';

const Transition = React.forwardRef<unknown, SlideProps>((props, ref) => (
  <Slide direction="up" ref={ref} {...props} />
));

const BootstrapDialog = styled(Dialog)(
  () => `
     .MuiDialog-paper{
         padding: 32px 24px;
      @media screen and (max-width: 376px){
        margin: 16px;
      }
    }
  `,
);

export default function BitMuiAlertDialog({
  children,
  handleClose,
  ...props
}: IBitMuiAlertDialogProps) {
  const { showAlertModal } = useAppSelector((state: AppState) => state.app);

  return (
    <div>
      <BootstrapDialog
        onClose={handleClose}
        open={showAlertModal}
        TransitionComponent={Transition}
        {...props}
      >
        {children}
      </BootstrapDialog>
    </div>
  );
}
