import { Button, LinearProgress, styled } from '@mui/material';
import { BitMuiButtonInterface } from 'utils/interfaces';

const DefaultButton = styled(Button)(
  ({ className }: any) => `
      @media screen and (max-width: 768px){
        height: 40px;
      }

      width: 100%;
      font-weight: 600;
      height: 48px;
      box-shadow: 0px 1px 20px rgba(0, 0, 0, 0.15);
      &:hover {
        box-shadow: 0px 1px 20px rgba(0, 0, 0, 0.15);
      }
      &:active {
        box-shadow: 0px 1px 20px rgba(0, 0, 0, 0.15);
      }
      text-transform: capitalize;
      .MuiLinearProgress-indeterminate {
        width: 100%;
        bottom: 0px;
        border-radius: 0 0 4px 4px;
        position: absolute;
        }
        .MuiLinearProgress-barColorPrimary{
          background-color: #079693ab;
        }
      }
      ${className}
`,
);

const OutlinedButton = styled(Button)(
  ({ className }: any) => `
      text-transform: capitalize;
      ${className}
      
`,
);

export const CustomDefaultButton = ({
  children,
  variant,
  ...props
}: BitMuiButtonInterface) => {
  return (
    <DefaultButton
      variant={variant || 'contained'}
      color="primary"
      size="large"
      fullWidth
      {...props}
    >
      {children}
      {props?.loading && <LinearProgress color="primary" />}
    </DefaultButton>
  );
};

export const CustomOutlinedButton = ({
  children,
  ...props
}: BitMuiButtonInterface) => (
  <OutlinedButton
    variant="outlined"
    color="primary"
    size="large"
    fullWidth
    {...props}
  >
    {children}
  </OutlinedButton>
);
