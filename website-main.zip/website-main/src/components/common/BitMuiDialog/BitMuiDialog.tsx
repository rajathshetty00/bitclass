import React from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import Dialog from '@mui/material/Dialog';
import List from '@material-ui/core/List';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Slide from '@mui/material/Slide';
import { TransitionProps } from '@mui/material/transitions';
import { X } from 'react-feather';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import { BitMuiDialogInterface } from 'utils/interfaces';
import { setModalState } from 'redux/reducers/appReducer';
import { styled } from '@mui/material';
import { assetObject } from 'utils/assetFileNames';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      '& .MuiList-root': {
        backgroundColor: '#FFFFFF',
        borderRadius: '8px 8px 0 0',
        height: '100%',
        padding: theme.spacing(3),
      },
    },

    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    iconButton: {
      padding: '0 12px',
    },
    logoContainer: {
      width: '80%',
      textAlign: 'center',
    },
  }),
);

const Transition = React.forwardRef(
  (props: TransitionProps & {}, ref: React.Ref<unknown>) => (
    <Slide direction="up" ref={ref} {...props} />
  ),
);

const CustomizedFullScreenDialog = styled(Dialog)(
  ({ theme }: any) => `
    .MuiDialog-paper{
      @media screen and (min-width: 768px){
       height:572px;
      }
    }

  .MuiPaper-root{
    background-color: ${theme.palette.background.secondary};
      box-shadow: 'none'; 
      @media screen and (min-width: 768px){
        max-width: 528px;
      }
    }
         
`,
);

// eslint-disable-next-line import/prefer-default-export
export const BitMuiDialog = ({
  children,
  onCancel = () => {},
  ...props
}: BitMuiDialogInterface) => {
  const classes = useStyles();
  const dispatch = useAppDispatch();
  const showModal = useAppSelector((state: AppState) => state.app.showModal);

  const handleClose = () => {
    dispatch(setModalState(false));
    onCancel();
  };

  return (
    <div>
      <CustomizedFullScreenDialog
        fullScreen
        open={showModal}
        onClose={handleClose}
        TransitionComponent={Transition}
        className={classes.root}
        {...props}
      >
        <AppBar className={classes.appBar}>
          <Toolbar>
            <IconButton
              className={classes.iconButton}
              edge="start"
              color="inherit"
              onClick={handleClose}
              aria-label="close"
            >
              <X width="32px" height="32px" />
            </IconButton>
            <div className={classes.logoContainer}>
              <NextImage width="120" height="40" src={assetObject.logoWhite} />
            </div>
          </Toolbar>
        </AppBar>
        <List>{children}</List>
      </CustomizedFullScreenDialog>
    </div>
  );
};
