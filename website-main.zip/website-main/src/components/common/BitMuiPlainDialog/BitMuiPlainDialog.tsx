import { ReactNode } from 'react';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { BitMuiPlainDialogInterface } from 'utils/interfaces';
import styles from './styles.module.scss';

interface DialogTitleProps {
  id: string;
  children: ReactNode;
  onClose: () => void;
}

const BootstrapDialog = styled(Dialog)(
  ({ theme }) =>
    ` 
     .MuiDialog-paper{
       border-radius: 4px;
      @media screen and (min-width: 768px){
       max-height:90%;
       width: 650px;
      }
    }
    & .MuiDialogContent-root: {
      padding: ${theme.spacing(2)};
    }
    & .MuiDialogActions-root : {
      padding: ${theme.spacing(1)};
    }

  `,
);

const BootstrapDialogTitle = (props: DialogTitleProps) => {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, px: 3 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

export default function BitMuiPlainDialog({
  title,
  children,
  footer = null,
  open,
  handleCustomClose,
  ...props
}: BitMuiPlainDialogInterface) {
  const handleClose = () => {
    handleCustomClose();
  };

  return (
    <div>
      <BootstrapDialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
        fullScreen
        {...props}
      >
        <BootstrapDialogTitle
          id="customized-dialog-title"
          onClose={handleClose}
          // @ts-ignore
          className={styles.dialogTitle}
        >
          {title}
        </BootstrapDialogTitle>
        <DialogContent dividers className={styles.dialogBody}>
          {children}
        </DialogContent>
        {footer ? (
          <DialogActions className={styles.dialogFooter}>
            {footer}
          </DialogActions>
        ) : null}
      </BootstrapDialog>
    </div>
  );
}
