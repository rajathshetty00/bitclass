import clsx from 'clsx';
import { FC, useState } from 'react';
import styles from './styles.module.scss';

interface IProps {
  /* eslint-disable no-unused-vars */
  onChange: (otp: string) => void;
  numInputs: number;
  isInputNum: boolean;
  containerStyle: string;
  inputStyle: string;
  focusStyle: string;
  onSubmit?: () => void;
  onFocus?: (e: any) => void;
}
interface IOtp {
  [key: string]: string;
}
const BitOtpInput: FC<IProps> = ({
  onChange,
  numInputs,
  isInputNum,
  containerStyle,
  inputStyle,
  focusStyle,
  onFocus,
  onSubmit,
}) => {
  const [otp, setOtp] = useState<IOtp>({});
  const handleInputFocus = (e: any) => {
    let next = 0;
    const numberRegex = /^[0-9]+$/;
    if (e.code === 'Backspace' || e.code === 'Delete')
      next = e.target.tabIndex - 1;
    else if (!e.key.match(numberRegex)) return;
    else next = e.target.tabIndex + 1;
    if (next <= numInputs && next > -1) e.target.form.elements[next].focus();
  };

  const handleOtpChange = (e: any) => {
    const { value, tabIndex } = e.target;
    if (value.length > 1) return;
    const newOtp = { ...otp, [tabIndex]: value };
    setOtp(newOtp);
    const otpInNumber = Object.values(newOtp).join('');
    onChange(otpInNumber);
  };

  return (
    <form
      id="myForm"
      className={clsx(styles.otpContainer, containerStyle)}
      onSubmit={(e) => {
        e.preventDefault();
        if (onSubmit) onSubmit();
      }}
    >
      {Array(numInputs)
        .fill('x')
        .map((_, index) => (
          <input
            autoComplete="off"
            type={isInputNum ? 'number' : 'text'}
            value={otp[index.toString(10)]}
            // eslint-disable-next-line react/no-array-index-key
            key={index}
            name={`otp${index}`}
            className={clsx(styles.otpInput, inputStyle)}
            tabIndex={index}
            min={0}
            max={9}
            onChange={handleOtpChange}
            onFocus={(e) => {
              e.target.classList.add(focusStyle);
              if (onFocus) onFocus(e);
            }}
            onKeyUp={handleInputFocus}
          />
        ))}
      <button type="submit" style={{ display: 'none' }}>
        submit
      </button>
    </form>
  );
};

BitOtpInput.defaultProps = {
  onFocus: () => {},
  onSubmit: () => {},
};
export default BitOtpInput;
