import { Skeleton, Stack } from '@mui/material';
import { FunctionComponent } from 'react';
import { AppState, useAppSelector } from 'redux/store';

interface BitSkeletonLoaderProps {}

const BitSkeletonLoader: FunctionComponent<BitSkeletonLoaderProps> = () => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  return (
    <>
      {isMobile ? (
        <Stack spacing={1}>
          <Skeleton variant="text" component="h6" width="90%" />
          <Skeleton variant="text" component="h6" width="180px" />
          <Skeleton variant="text" component="h6" width="180px" />
          <div style={{ marginBottom: '16px' }} />
          <Skeleton variant="text" component="h6" width="144px" />
          <Skeleton variant="text" component="h6" width="240px" />
          <Skeleton variant="text" component="h6" width="240px" />
          <Skeleton variant="text" component="h6" width="240px" />
        </Stack>
      ) : (
        <Stack spacing={1}>
          <Skeleton variant="text" component="h4" width="90%" />
          <Skeleton variant="text" component="h6" width="180px" />
          <Skeleton variant="text" component="h6" width="180px" />
          <div style={{ marginBottom: '24px' }} />
          <Skeleton variant="text" component="h4" width="144px" />
          <Skeleton variant="text" component="h6" width="240px" />
          <Skeleton variant="text" component="h6" width="240px" />
          <Skeleton variant="text" component="h6" width="240px" />
          <div style={{ marginBottom: '24px' }} />
          <Skeleton variant="text" component="h4" width="144px" />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr' }}>
            <Skeleton variant="text" component="h5" width="80%" />
            <Skeleton variant="text" component="h5" width="80%" />
            <Skeleton variant="text" component="h5" width="80%" />
            <Skeleton variant="text" component="h5" width="80%" />
          </div>
          <div style={{ marginBottom: '24px' }} />
          <Skeleton variant="rectangular" width="100%" height={56} />
        </Stack>
      )}
    </>
  );
};

export default BitSkeletonLoader;
