import React, { FC } from 'react';
import Slider from 'react-slick';

interface BitSlickSliderProps {
  children: React.ReactNode;
  customSettings: object;
  customClass?: string;
}

const BitSlickSlider: FC<BitSlickSliderProps> = ({
  children,
  customSettings = {},
  customClass = '',
}) => {
  const settings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    arrows: true,
    ...customSettings,
  };

  return (
    <Slider className={customClass} {...settings}>
      {children}
    </Slider>
  );
};

export default BitSlickSlider;

BitSlickSlider.defaultProps = {
  customClass: '',
};
