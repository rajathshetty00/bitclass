import { Snackbar } from '@material-ui/core';
import { Alert } from '@mui/material';
import { FC, ReactNode } from 'react';

interface BitSnackBarProps {
  visible: boolean;
  vertical: 'top' | 'bottom';
  horizontal: 'left' | 'center' | 'right';
  message: ReactNode;
  onClose: any;
}

const BitSnackBar: FC<BitSnackBarProps> = ({
  vertical,
  horizontal,
  message,
  onClose,
  visible,
}) => {
  // const [open, setOpen] = useState(true);

  return (
    <Snackbar
      anchorOrigin={{ vertical, horizontal }}
      open={visible}
      onClose={onClose}
      message={message}
      key={vertical + horizontal}
      autoHideDuration={1000}
    >
      <Alert onClose={onClose} severity="success" sx={{ width: '100%' }}>
        {message}
      </Alert>
    </Snackbar>
  );
};

export default BitSnackBar;
