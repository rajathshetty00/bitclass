import React, { FC } from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { updateSelectedTab } from 'redux/reducers/profileReducer';

interface TabPanelProps {
  children: React.ReactNode;
  index: number;
  value: number;
}

interface BitTabProps {
  tabArray: tabArrayKey[];
  tabChildren: React.ReactNode;
}

interface tabArrayKey {
  label: string;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
    >
      {value === index && <div>{children}</div>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const BitTab: FC<BitTabProps> = ({ tabArray, tabChildren }) => {
  const dispatch = useAppDispatch();
  const { selectedTab } = useAppSelector((state: AppState) => state.profile);
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    dispatch(updateSelectedTab(newValue));
  };

  return (
    <div>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 0, borderColor: 'divider' }}>
          <Tabs
            value={selectedTab}
            onChange={handleChange}
            aria-label="basic tabs example"
          >
            {tabArray.map((item, index) => (
              <Tab label={item.label} {...a11yProps(index)} />
            ))}
          </Tabs>
        </Box>

        {tabArray.map((item, index) => (
          <TabPanel value={selectedTab} index={index}>
            {tabChildren}
          </TabPanel>
        ))}
      </Box>
    </div>
  );
};

export default BitTab;
