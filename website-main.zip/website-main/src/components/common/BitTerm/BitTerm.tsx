import Head from 'next/head';
import Link from 'next/link';
import { BASE_URL } from 'utils/constants';
import ContactInfo from '../ContactInfo/ContactInfo';
import styles from './styles.module.scss';

const BitTerm = () => {
  return (
    <>
      <Head>
        <title>Terms and Conditions | Bitclass </title>
      </Head>

      <div className={styles.policyContainer}>
        <strong>Terms &amp; Conditions</strong>
        <ol type="I">
          <li className={styles.subtitle}>Introduction</li>
          <p>
            Welcome to{' '}
            <a href={BASE_URL} target="_blank" rel="noreferrer">
              www.bitclass.live
            </a>{' '}
            <b>Website</b> including sub-domains, and/or mobile application.{' '}
            <b>Application</b> (the Website and Application are hereinafter
            collectively referred to as “Platform”). The Platform is owned and
            managed by Livestream Infra Technologies Private limited{' '}
            <b>Company</b>. The Platform helps teachers, trainers, educators,
            coaches etc., to set up their online presence, build a personal
            brand, launch a cohort-based course and build own community of
            learners. The Company offers the live learning Platform and provides
            live online classes. <b>Services</b>. It is clarified that the
            Company is not the creator of the content/ course made available on
            the Platform and the same are being offered directly by the
            teachers/educators to the students/ learners and the Company is a
            mere facilitator to ensure that the teachers and educators could
            effectively reach out to the appropriate audience.
          </p>
          <p>
            These terms of use <b>Terms of Use</b> is an electronic contract
            between the Company (hereinafter referred to as <b>we</b>,<b>our</b>
            ,<b>us</b>) and the user (hereinafter referred to as <b>you</b>,
            <b>your</b> and <b>user</b>) formed under the Information Technology
            Act, 2000 read with relevant rules made thereunder and any other
            applicable statues, as amended from time to time. These Terms of Use
            along with the privacy policy{' '}
            <Link href="/policy">Privacy Policy</Link> as provided at the
            Website at the link [-] and the same shall govern your visit, use
            and access of the Platform. Further, your continued use of the
            Services shall be constituted as your acceptance to these Terms of
            Use as revised from time to time. If you do not agree with these
            Terms of Use, please do not use or access the Platform and/or avail
            the Services.
          </p>
          <p>
            We reserve the right to update or modify these Terms of Use at any
            time without any prior notice to you. Your access and use of the
            Platform and/or Services following any such change constitutes your
            agreement to follow and be bound by these Terms of Use, as updated
            or modified. For this reason, we encourage you to review these Terms
            of Use each time you access Platform and avail the Services.
          </p>
          <li className={styles.subtitle}>Availing of service</li>
          <section id="availing of service">
            <p>
              The Company will provide Services to its users in accordance with
              these Terms of Use and Privacy Policy. The Company may, at its
              sole discretion update, discontinue, modify or offer new Services
              at the Platform without any prior notice to the users. Further,
              the user shall at all times avail the Services only for lawful
              purposes.{' '}
            </p>
            <p>
              The Company, subject to these Terms of Use and Privacy Policy
              grants a non-exclusive, non-transferable, non-assignable license
              to access and use the Platform, only for your own purpose.
            </p>
          </section>
          <li className={styles.subtitle}>Security and Accounts</li>
          <section id="security">
            <p>
              To avail the Services, you shall create an account with us, as
              provided on the Platform. In order to create an account, you shall
              confirm that you are above 18 (eighteen) years of age and all the
              information provided to us is complete and accurate at all times.
              In case, you are below 18 (eighteen) years of age, the account
              must be created by your parents/ legal guardian.
            </p>
            <p>
              You shall, after the successful creation of your account, be
              provided with login credentials which will include a ‘login id’
              and ‘password’ <b>Login Credentials</b>. You shall at all times be
              responsible for maintaining confidentiality of the Login
              Credentials and any activity or actions that are performed on your
              account. Further, you shall immediately inform/ intimate/ notify
              us at hello@bitclass.live upon becoming aware of any security
              breach or unauthorised use of your account.{' '}
            </p>

            <p>
              We shall not be responsible for any liability that may arise due
              to the misuse or illegal use of the account by you or any third
              party. We reserve the right to terminate, suspend or remove user
              accounts at our sole discretion.{' '}
            </p>
          </section>
          <strong>Additional Confirmation</strong>
          <p>
            <ol type="1">
              <li>
                That the user will use the Services provided by the Platform,
                its affiliates, consultants and contracted companies, for lawful
                purposes only and comply with all applicable laws and
                regulations while using and transacting on the Platform.
              </li>
              <li>
                The user will provide authentic and true information in all
                instances where such information is requested of you. The
                Company reserves the right to confirm and validate the
                information and other details provided by the user at any point
                of time. If upon confirmation the user’s details are found not
                to be true (wholly or partly), the Company has the right in its
                sole discretion to reject the registration and debar the user
                from using the Services and the Platform without prior
                intimation whatsoever.
              </li>
              <li>
                The user authorises the Company to contact the user for any
                transactional purposes related to the order/account.
              </li>
              <li>
                The user is accessing the Services available on the Platform and
                transacting at its sole risk and is using its best and prudent
                judgment before entering into any transaction through this
                Platform.
              </li>
            </ol>
          </p>
          <li className={styles.subtitle}>Payment of consideration</li>
          <section id="payment_of_consideration">
            <p>
              The Company is not responsible for setting the pricing of any of
              the courses/ contents available on the Platform, the prices for
              courses/ contents are set by the educator/ teacher. The price for
              each course/ content is described along with course description.
            </p>
            <p>
              The users, in order to access the course/ content of a relevant
              teacher/ educator, shall pay the fee/charges as provided on the
              Platform. The course/ content creator reserves the right to revise
              (increase or decrease), introduce new fees/ charges for the
              course/ content (“Fee Revisions”) as provided on the Platform. The
              Fee Revisions will be effective immediately as and when updated on
              the Platform. The user shall be solely responsible to comply with
              the applicable laws in order to make payments for accessing the
              courses/ content. The Company shall assume no liability for the
              losses/ damages incurred by the user on account of decline of
              transaction by the payment gateway, lack of authorization, and any
              other payment issues.
            </p>
          </section>
          <li className={styles.subtitle}>Cancellation and Refund Policies</li>
          <section id="cancellation">
            <p>
              <strong>Company Refund Policy in case of :</strong>
              <p>
                <ol type="A">
                  <li>
                    {' '}
                    <b>Workshop (INR 0 – 99)</b> : Cancellation received at
                    least 24 (twenty four) hours before the scheduled class is
                    refundable or adjusted for upcoming classes, refund process
                    normally takes 5-7 business days and cancel request received
                    before the 24 (twenty four) hours of scheduled class is not
                    refundable but can be adjustable.
                  </li>
                  <li>
                    {' '}
                    <b>Full Course (INR above 99) </b> : Cancellation received
                    at least 24 (twenty four) hours before the scheduled class
                    is refundable or adjusted for upcoming classes, refund
                    process normally takes 5-7 business days and cancel request
                    received before the 24 (twenty four) hours of scheduled
                    class is not refundable but can be adjustable.
                  </li>
                </ol>
              </p>
            </p>
          </section>
          <li className={styles.subtitle}>communication</li>
          <p>
            <section id="communication">
              <p>
                The user while registering his account with us will share his
                contact number, address, email etc. Accepting these Terms of
                Use, implies your express consent to be contacted by us, our
                agents, representatives, affiliates, or anyone calling on our
                behalf at any contact number, or physical or electronic address
                provided by you while registering your account. The Company may
                use the provided contact information to send information about
                the Services, new courses/ contents, important updates,
                promotional material including newsletters, etc., via various
                electronic and telecommunication modes. The user may opt out of
                receiving the abovementioned communications by following the
                unsubscribe link or sending us an email at hello@bitclass.live .{' '}
              </p>
            </section>
          </p>
          <li className={styles.subtitle}>Content</li>
          <p>
            You are allowed to manage, post, store, share certain information
            including graphic, audio or video materials, etc., (“Contents”) on
            the Platform. You shall be solely responsible for the legality,
            reliability and correctness of the Content posted on the Platform.
            The user represents and warrant that the Content posted by him/ her
            do not violate any copyrights, contracts, privacy rights or rights
            of any other property or entity.
            <br />
            <p>
              The user shall not host, display, upload, modify, publish,
              transmit, update or share any Content that:
            </p>
            <ol type="a">
              <li>
                belongs to another person and to which the user does not have
                any right to;
              </li>
              <li>
                is grossly harmful, harassing, blasphemous; defamatory, obscene,
                pornographic, paedophilic, libellous, invasive of another&apos;s
                privacy, hateful, or racially, ethnically objectionable,
                disparaging, relating or encouraging money laundering or
                gambling, or otherwise unlawful in any manner whatever;
              </li>
              <li>harm minors in any way;</li>
              <li>
                infringes any patent, trademark, copyright or other proprietary
                rights;
              </li>
              <li>violates any law for the time being in force;</li>
              <li>
                deceives or misleads the addressee about the origin of such
                messages or communicates any information which is grossly
                offensive or menacing in nature; impersonate another person;
              </li>
              <li>impersonate another person;</li>
              <li>
                contains software viruses or any other computer code, files or
                programs designed to interrupt, destroy or limit the
                functionality of any computer resource;
              </li>
              <li>
                threatens the unity, integrity, defence, security or sovereignty
                of India, friendly relations with foreign states, or public
                order or causes incitement to the commission of any cognisable
                offence or prevents investigation of any offence or is insulting
                any other nation.
              </li>
            </ol>
            <p>
              The Company has no responsibility for the Content posted by the
              user on the Platform and the Company shall not assume any
              liability which might arise relating to user’s Content and/or
              breach of these Terms of Use or any other applicable law. The
              Company shall have the right to monitor, edit, delete the Content
              provided by the users on the Platform and may decline to publish
              any Content that is not in compliance with these Terms of Use.
              Further, under no circumstances, the Company shall be liable for
              any unlawful act of the user or its affiliates, relatives,
              employees, agents including but not limited to misuse of any data,
              unfair trade practices, fraud, cybersquatting, hacking and other
              cybercrimes.
            </p>
            <p>
              You understand that the Company has the right at all times to
              disclose any information (including the identity of the user
              providing Content, information or materials on the Platform) as
              necessary to satisfy any law, regulation or valid governmental
              request, or in response to any court order or summons. In
              addition, the Company can (and you hereby expressly authorize us
              to) disclose any information about you to law enforcement or other
              government officials, as we, in our sole discretion, believe
              necessary or appropriate in connection with the investigation
              and/or resolution of possible crimes, especially those that may
              involve personal injury.
            </p>
          </p>
          <li className={styles.subtitle}>Intellectual Property</li>
          <p>
            The original content on the Platform (apart from the Content
            provided by the user) including interface, graphics, photographs,
            trademarks, logos, sounds, computer codes, etc.<b>Company Data</b>{' '}
            shall be the sole property of the Company. The Platform is protected
            by copyright, trademark, and other applicable laws in the
            jurisdiction applicable to the operations of the Company.
          </p>
          <p>
            Except as expressly provided in these Terms of Use, no part of the
            Platform and no Company Data may be copied, reproduced, republished,
            uploaded, posted, publicly displayed, encoded, translated,
            transmitted or distributed in any way (including “mirroring”) to any
            other computer, server, website or other medium for publication or
            distribution or for any commercial use, without the Company&apos;s
            express prior written consent. Company Data on the Platform is
            solely for your personal, limited and non-exclusive use. Use of the
            Company Data on any other website or networked computer environment
            or use of the Company Data for any purpose other than personal,
            non-commercial use is a violation of the copyrights, trademarks, and
            other proprietary rights, and is prohibited.
          </p>
          <li className={styles.subtitle}>Indemnification</li>
          <p>
            The user agrees to protect, defend and indemnify us and hold us and
            our representatives harmless from and against any and all claims,
            damages, costs and expenses, including attorney&apos;fees, arising
            from or related to his access and use of the Platform and Services
            in violation of these Terms of Use and/or your infringement, or
            infringement by any other user of your account, of any intellectual
            property or other right of anyone.
          </p>
          <p>
            The user agrees to protect, defend and indemnify us and hold us and
            our representatives harmless from and against any and all claims,
            damages, costs and expenses, including attorneys&apos;fees, arising
            from or related to his access and use of the Platform and Services
            in violation of these Terms of Use and/or your infringement, or
            infringement by any other user of your account, of any intellectual
            property or other right of anyone.
          </p>
          <li className={styles.subtitle}>Limitation of Liability</li>
          <p>
            In no event shall we be liable for any direct, indirect, punitive,
            Incidental, special or consequential damages or for any damages
            Whatsoever including, without limitation, damages for loss of use,
            Data or profits, arising out of or in any way connected with the
            Access, use or performance of the platform&apos;s functions and
            features Or for interruptions, delay, etc.Even if we were advised of
            the Possibility of damages resulting from the cost of getting
            substitute Facilities on the platform, any products, data,
            information or Services purchased or obtained or messages received
            or transactions Entered into through or from the platform,
            unauthorized access to or Alteration of your transmissions or data
            statements or conduct of Anyone on the platform, or inability to use
            the services, the Provision of or failure to provide the functions
            and features, Hether based on contract, tort, negligence, or
            otherwise. This Clause shall survive in perpetuity.
          </p>
          <li className={styles.subtitle}>Termination</li>
          <p>
            We may terminate the use of the Services at any time at our sole
            discretion without giving any prior notice or intimation. If you
            wish to terminate your account, you may simply discontinue using
            Service.
          </p>
          <p>
            Upon termination, the rights and license granted to you herein shall
            terminate and you must cease all use of the Platform and Services.
          </p>
          <li className={styles.subtitle}>Governing Law</li>
          <p>
            These Terms of Use shall be governed and construed in accordance
            with the laws of India, and any disputes relating to these Terms of
            Use will be subject to the exclusive jurisdiction of the courts of
            Bengaluru, Karnataka, India.
          </p>
          <li className={styles.subtitle}>Assignment</li>
          <p>
            The Company may transfer, sub-contract or otherwise deal with its
            rights and/or obligations under these Terms of Use without notifying
            you or obtaining your consent.
          </p>
          <p>
            You may not transfer, sub-contract or otherwise deal with your
            rights and/or obligations under these Terms of Use.
          </p>
          <li className={styles.subtitle}>Waiver</li>
          <p>
            Any failure on the part of the Company to require performance of any
            provision of these Terms of Use shall not affect its right to full
            performance thereof at any time thereafter, and any waiver by the
            Company of a breach of any provision hereof shall not constitute a
            waiver of a similar breach in the future or of any other breach.
          </p>
          <li className={styles.subtitle}>Severability</li>
          <p>
            The provisions contained in these Terms of Use are enforceable
            independent of each other. If any provision is determined by the
            competent court to be unenforceable, the other provisions will
            continue in effect.
          </p>
          <li className={styles.subtitle}>Contact </li>
          <p>
            If you have questions concerning your account, please contact
            hello@bitclass.live If you have (i) questions concerning these Terms
            of Use or Privacy Policy and/or (ii) any grievance, concern,
            discrepancy, or complaints, including with respect to processing of
            your personal information, the treatment of your personal
            information, and/or our use of cookies and other technologies,
            please contact us:
          </p>
          <ContactInfo />
          <p>
            The Grievance officer shall acknowledge the receipt of any complaint
            within 48 (forty eight) hours and redresses the complaint within 1
            (one) month from the date of receipt of the complaint.
          </p>
        </ol>
      </div>
    </>
  );
};

export default BitTerm;
