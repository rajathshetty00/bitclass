import { FC } from 'react';

interface BitThreeDotLoaderProps {}

const BitThreeDotLoader: FC<BitThreeDotLoaderProps> = () => {
  return <div>--</div>;
};

export default BitThreeDotLoader;
