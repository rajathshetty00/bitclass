import { useState } from 'react';
import BottomNavigation from '@mui/material/BottomNavigation';
import BottomNavigationAction from '@mui/material/BottomNavigationAction';
import RestoreIcon from '@mui/icons-material/Restore';
// import FavoriteIcon from '@mui/icons-material/Favorite';
import ClassIcon from '@mui/icons-material/Class';
// import LocationOnIcon from '@mui/icons-material/LocationOn';
import SchoolIcon from '@mui/icons-material/School';
import HeadsetMicIcon from '@mui/icons-material/HeadsetMic';
import styles from './styles.module.scss';

export default function BitBottomNavigation() {
  const [value, setValue] = useState(0);

  return (
    <div className={styles.bottomNavigation}>
      <BottomNavigation
        showLabels
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
      >
        <BottomNavigationAction label="Learn" icon={<SchoolIcon />} />
        <BottomNavigationAction label="Recordings" icon={<HeadsetMicIcon />} />
        <BottomNavigationAction label="OTO" icon={<RestoreIcon />} />
        <BottomNavigationAction label="Classes" icon={<ClassIcon />} />
      </BottomNavigation>
    </div>
  );
}
