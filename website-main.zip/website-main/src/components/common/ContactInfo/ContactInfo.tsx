import styles from './styles.module.scss';

const ContactInfo = () => {
  return (
    <>
      <p>
        via email at <b>hello@bitclass.live</b> to Grievance Officer as per the
        details given below:
      </p>
      <p>
        <p className={styles.contactInfo}>
          <b className={styles.labelInfo}>Name</b>: Livestrem Infra Technologies
          Pvt Ltd
        </p>
        <p className={styles.contactInfo}>
          <b className={styles.labelInfo}>Email</b>:{'  '}
          <a
            href="mailto:shello@bitclass.live"
            target="_blank"
            rel="noreferrer"
          >
            hello@bitclass.live{' '}
          </a>
        </p>
        <p className={styles.contactInfo}>
          {' '}
          <b className={styles.labelInfo}>Contact no </b>: 08047186300
        </p>
      </p>
    </>
  );
};

export default ContactInfo;
