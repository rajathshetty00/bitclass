/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/interactive-supports-focus */
import { courseChecker } from 'hooks/useCourseChecker';
import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { loadCbFunction, setPlainModalState } from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { assetObject } from 'utils/assetFileNames';
import { BASE_URL } from 'utils/constants';
import PAGE_TYPES, {
  channeQueryMaker,
  getChannel,
} from 'utils/constants/pageTypes';
import { extractCdpData } from 'utils/courseAnalytics';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { convertUnderScoreText, getQuery } from 'utils';
import NextImage from '../../NextImage/NextImage';
import CtaButton from '../common/CtaButton/CtaButton';
import ScheduleComponent from '../common/ScheduleComponent/ScheduleComponent';
import Teacherdetails from '../common/TeacherDetails/TeacherCompDetails';
import styles from './styles.module.scss';

const CourseCardV2 = ({ item, sectionHeading }: any) => {
  const {
    heading,
    intro_video_thumbnail,
    teacher,
    is_live,
    code,
    course_url,
    rating,
    position,
  } = item || {};

  const { pageType } = useAppSelector((state: AppState) => state?.app);

  const dispatch = useAppDispatch();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();

  const { fetchDataOnPageType } = useRightSectionRenderer();

  const { checkCourseType } = courseChecker({
    courseData: item,
    courseCode: item?.tmpr_code || code,
    dispatch,
  });

  const coursesChannelQuery = channeQueryMaker(
    `${getChannel(router.pathname)}${
      sectionHeading
        ? `_${convertUnderScoreText(sectionHeading)}_course_cards`
        : ''
    }`,
    isMobile,
  );

  useEffect(() => {
    if (pageType) {
      fetchDataOnPageType();
    }
  }, [pageType]);

  const cb = () => router.reload();

  const onClickHandler = async (event: any) => {
    event.preventDefault();
    event.stopPropagation();

    if (!(pageType === PAGE_TYPES.HOME_PAGE)) {
      saveGtmDataLayerData({
        course_card_clicked_details: {
          ...extractCdpData(item),
          source: pageType,
          section_type: 'course_card',
          position,
        },
        event: EVENT_NAMES.COURSE_CARD_CLICKED,
      });

      if (is_live) {
        appendQueryParamAndNavigate(
          `${BASE_URL}/live-classes/classroom/${code}?${coursesChannelQuery}`,
          getQuery(router),
        );
      }

      if (item?.is_registered) {
        appendQueryParamAndNavigate(
          `${BASE_URL}/live-classes/profile?${coursesChannelQuery}`,
          getQuery(router),
        );
      }

      if (item?.tmpr_code || item?.amount === 0) {
        saveGtmDataLayerData({
          event: EVENT_NAMES.QUICK_CHECKOUT_OPENED,
        });

        checkCourseType();
        await dispatch(setPlainModalState(true));
        await dispatch(loadCbFunction(() => cb()));
      } else {
        appendQueryParamAndNavigate(
          `${course_url}?${coursesChannelQuery}`,
          getQuery(router),
        );
      }
    } else {
      saveGtmDataLayerData({
        course_card_clicked_details: {
          ...extractCdpData(item),
          source: pageType,
          position,
          section_type: 'course_card',
        },
        event: EVENT_NAMES.COURSE_CARD_CLICKED,
      });

      if (is_live) {
        appendQueryParamAndNavigate(
          `${BASE_URL}/live-classes/classroom/${code}`,
          getQuery(router),
        );
        return;
      }

      if (item?.tmpr_code) {
        appendQueryParamAndNavigate(
          `${BASE_URL}/live-classes/${item?.tmpr_code}?${coursesChannelQuery}`,
          getQuery(router),
        );
      } else {
        appendQueryParamAndNavigate(
          `${course_url}?${coursesChannelQuery}`,
          getQuery(router),
        );
      }
    }
  };

  return (
    <div
      role="button"
      onClick={(e) => onClickHandler(e)}
      className={styles.courseCardContainer}
    >
      <div className={styles.thumbnail}>
        <div className={styles.thumbnailImg}>
          <NextImage
            src={intro_video_thumbnail ?? assetObject.defaultCdpImage}
            height={isMobile ? '204' : '252'}
            width="100%"
            objectFit="cover"
            quality={60}
          />
        </div>
        <div className={styles.overlay} />

        {item?.registration_count > 1 && (
          <div className={styles.rating}>
            <NextImage
              src={assetObject.starRating}
              width={16}
              height={16}
              className={styles.starRating}
              unoptimized
            />
            <div className={styles.value}>{rating}</div>
          </div>
        )}

        {is_live ? (
          <div className={styles.liveClass}>
            <NextImage
              src={assetObject.liveClassIconWhite}
              width="16"
              height="16"
              unoptimized
            />
            <span className={styles.liveText}>Live</span>
          </div>
        ) : (
          <div className={styles.schedule}>
            <ScheduleComponent item={item} />
          </div>
        )}
        <div className={styles.title}>
          <h5>{heading}</h5>
        </div>
      </div>
      <div className={styles.courseDetails}>
        <Teacherdetails teacher={teacher} />
        <div className={styles.buttonContainer}>
          <CtaButton
            customClass={styles.customClass}
            onClickHandler={(e) => onClickHandler(e)}
            item={item}
          />
        </div>
      </div>
    </div>
  );
};

export default CourseCardV2;
