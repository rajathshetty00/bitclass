import { useRouter } from 'next/router';
import { AppState, useAppSelector } from 'redux/store';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { convertUnderScoreText, getQuery } from 'utils';
import { assetObject } from 'utils/assetFileNames';
import { BASE_URL } from 'utils/constants';
import { channeQueryMaker, getChannel } from 'utils/constants/pageTypes';
import { extractCdpData } from 'utils/courseAnalytics';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { BitButton } from '../../BitButton/BitButton';
import NextImage from '../../NextImage/NextImage';
import ScheduleComponent from '../common/ScheduleComponent/ScheduleComponent';
import Teacherdetails from '../common/TeacherDetails/TeacherCompDetails';
import { renderCourseCardCTAText } from '../common/utils';
import styles from './styles.module.scss';

const FeaturedCourseCard = ({ item, key, sectionHeading }: any) => {
  const {
    heading,
    intro_video_thumbnail,
    rating,
    teacher,
    amount,
    goal_without_html,
    course_url,
    has_ended,
    is_live,
    currency,
  } = item;

  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );
  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();

  const { pageType } = useAppSelector((state: AppState) => state?.app);

  const featuredChannelQuery = channeQueryMaker(
    `${getChannel(router.pathname)}${
      sectionHeading
        ? `_${convertUnderScoreText(sectionHeading)}__featured`
        : ''
    }`,
    isMobile,
  );

  const onClickSeeMoreHandler = () => {
    if (item?.tmpr_code) {
      appendQueryParamAndNavigate(
        `${BASE_URL}/live-classes/${item?.tmpr_code}?${featuredChannelQuery},`,
        getQuery(router),
      );
    } else {
      appendQueryParamAndNavigate(
        `${course_url}?${featuredChannelQuery}`,
        getQuery(router),
      );
    }
  };

  const onClickHandler = () => {
    saveGtmDataLayerData({
      course_card_clicked_details: {
        ...extractCdpData(item),
        source: pageType,
        section_type: 'featured_course_card',
      },
      event: EVENT_NAMES.COURSE_CARD_CLICKED,
    });

    if (item?.tmpr_code) {
      appendQueryParamAndNavigate(
        `${BASE_URL}/live-classes/${item?.tmpr_code}?${featuredChannelQuery}`,
        getQuery(router),
      );
    } else {
      appendQueryParamAndNavigate(
        `${course_url}?${featuredChannelQuery}`,
        getQuery(router),
      );
    }
  };

  return (
    <div key={key} className={styles.featuredCourseCardWrapper}>
      <div className={styles.featuredCourseCard}>
        <div className={styles.courseCardContainer}>
          <div className={styles.mainImageContainer}>
            <NextImage
              src={intro_video_thumbnail ?? assetObject.defaultCdpImage}
              width="100%"
              height={isMobile ? '180' : '100%'}
              quality={100}
            />
            <div className={styles.overlay} />

            {isMobile && amount > 0 && (
              <div className={styles.courseFeatureWrapper}>
                <div className={styles.courseFeatures}>
                  <section>
                    <NextImage
                      src={assetObject.recorderIconWhite}
                      className={styles.clock}
                      width={20}
                      height={20}
                      unoptimized
                    />
                    <span className={styles.text}>Recordings</span>
                  </section>
                  <section>
                    <NextImage
                      src={assetObject.liveClassIconWhite}
                      className={styles.clock}
                      width={20}
                      height={20}
                      unoptimized
                    />
                    <span className={styles.text}>Liveclasses</span>
                  </section>
                  <section>
                    <NextImage
                      src={assetObject.certificateIconWhite}
                      className={styles.clock}
                      width={20}
                      height={20}
                      unoptimized
                    />
                    <span className={styles.text}>Certificates</span>
                  </section>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className={styles.courseDetails}>
          <div className={styles.heading}>{heading}</div>
          <div className={styles.teacherSection}>
            <Teacherdetails
              teacherClassName={styles.teacherClass}
              teacher={teacher}
            />
            <div className={styles.rating}>
              <NextImage
                src={assetObject.starRating}
                width={16}
                height={16}
                className={styles.starRating}
                unoptimized
              />
              <div className={styles.value}>
                {rating} &nbsp;
                {Boolean(item?.registration_count) && (
                  <>
                    <span style={{ fontSize: '1rem' }}>|</span> &nbsp;
                    {item?.registration_count}
                  </>
                )}
              </div>
            </div>
          </div>
          <div className={styles.descriptionContainer}>
            <div role="none" className={styles.description}>
              {goal_without_html}
            </div>
            <h5 role="none" onClick={onClickSeeMoreHandler}>
              View details{' '}
            </h5>
          </div>

          <div className={styles.footerBtns}>
            {!isMobile && amount > 0 && (
              <div className={styles.courseFeatureWrapper}>
                <div className={styles.courseFeatures}>
                  <section>
                    <NextImage
                      src={assetObject.recorderIcon}
                      className={styles.clock}
                      width={16}
                      height={16}
                      unoptimized
                    />
                    <span className={styles.text}>Recordings</span>
                  </section>
                  <section>
                    <NextImage
                      src={assetObject.liveClassIcon}
                      className={styles.clock}
                      width={16}
                      height={16}
                      unoptimized
                    />
                    <span className={styles.text}>Live Classes </span>
                  </section>
                  <section>
                    <NextImage
                      src={assetObject.certificateIcon}
                      className={styles.clock}
                      width={16}
                      height={16}
                      unoptimized
                    />
                    <span className={styles.text}>Certificates</span>
                  </section>
                </div>
              </div>
            )}

            <div className={styles.ctaContainer}>
              <div className={styles.duration}>
                <ScheduleComponent
                  customClass={styles.customDuration}
                  item={item}
                />
              </div>
              <div className={styles.buttonContainer}>
                <BitButton
                  onClick={onClickHandler}
                  // className={customClass}
                  variant="contained"
                  disabled={has_ended}
                >
                  {renderCourseCardCTAText({
                    amount,
                    currency,
                    ended: has_ended,
                    isLive: is_live,
                    isRegisteredForCourse: item?.is_registered,
                  })}
                </BitButton>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturedCourseCard;
