import { FC } from 'react';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { renderCourseCardCTAText } from '../utils';

interface CtaButtonProps {
  item: any;
  customClass?: string;
  // eslint-disable-next-line no-unused-vars
  onClickHandler: (e: any) => {};
}

const CtaButton: FC<CtaButtonProps> = ({
  item,
  customClass,
  onClickHandler,
}) => {
  const { amount, currency, has_ended, is_live } = item || {};

  return (
    <BitButton
      onClick={(e) => onClickHandler(e)}
      className={customClass}
      variant="contained"
      disabled={has_ended}
    >
      {renderCourseCardCTAText({
        amount,
        currency,
        ended: has_ended,
        isLive: is_live,
        isRegisteredForCourse: item?.is_registered,
      })}
    </BitButton>
  );
};

export default CtaButton;

CtaButton.defaultProps = {
  customClass: '',
};
