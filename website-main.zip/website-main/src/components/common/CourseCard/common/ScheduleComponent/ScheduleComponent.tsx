import { FC } from 'react';
import { getDuration } from 'utils';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import DateRangeIcon from '@mui/icons-material/DateRange';
import clsx from 'clsx';
import styles from './styles.module.scss';

interface ScheduleComponentProps {
  item: any;
  customClass?: string;
}

const ScheduleComponent: FC<ScheduleComponentProps> = ({
  item,
  customClass,
}: any) => {
  const { amount, start_ts, end_ts, duration } = item || {};

  return (
    <div className={clsx(styles.scheduleContainer, customClass)}>
      {amount === 0 ? (
        <>
          <AccessTimeIcon />
          <span className={styles.dateRange}>{duration} mins</span>
        </>
      ) : (
        <>
          <DateRangeIcon />
          <span className={styles.dateRange}>
            {getDuration({ start_ts, end_ts })}
          </span>
        </>
      )}
    </div>
  );
};

export default ScheduleComponent;

ScheduleComponent.defaultProps = {
  customClass: '',
};
