import { FC } from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import clsx from 'clsx';
import styles from './styles.module.scss';

interface TeacherdetailsProps {
  teacher: any;
  teacherClassName?: string;
}

const Teacherdetails: FC<TeacherdetailsProps> = ({
  teacher,
  teacherClassName,
}) => {
  const { name, image } = teacher || {};

  return (
    <div className={styles.teacherContainer}>
      <NextImage
        src={image ?? assetObject.teacherEmpty}
        height={32}
        width={32}
        className={styles.teacherAvatar}
        quality={20}
      />

      <div className={styles.teacherDetails}>
        <span className={styles.taughtBy}>Taught by</span>
        <span className={clsx(styles.teacherName, teacherClassName)}>
          {name}
        </span>
      </div>
    </div>
  );
};

export default Teacherdetails;

Teacherdetails.defaultProps = {
  teacherClassName: '',
};
