import { getCurrencySymbol } from 'utils/currency';

export const renderCourseCardCTAText = ({
  amount,
  currency,
  isRegisteredForCourse,
  courseRegistrationDetailsInTmpr,
  ended,
  isLive,
}: any) => {
  if (ended) {
    return `Course Ended!`;
  }

  if (isRegisteredForCourse) {
    return `Go to LIVE Class`;
  }

  if (courseRegistrationDetailsInTmpr?.is_registered) {
    return `Go to LIVE Class`;
  }

  // course card cta text
  if (isLive) {
    return `Attend NOW`;
  }

  if (amount > 0) {
    const amountWithCurrency = `${getCurrencySymbol(currency)}${amount}`;
    return `Join for ${amountWithCurrency}`;
  }
  return `Register for FREE`;
};
