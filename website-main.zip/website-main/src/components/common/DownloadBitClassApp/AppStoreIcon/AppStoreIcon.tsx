import { FC } from 'react';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { assetObject } from 'utils/assetFileNames';
import NextImage from '../../NextImage/NextImage';

interface IPlayStore {
  channel?: string;
}
const AppStoreIcon: FC<IPlayStore> = ({ channel }) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const url = `https://apps.apple.com/us/app/bitclass/id1498797590&utm_source=web&utm_medium=home-footer&utm_campaign=gplayicon&channel=${channel}&platform=${
    isMobile ? 'mweb' : 'web'
  }`;

  return (
    <div>
      <a target="_blank" href={url} rel="noreferrer">
        <NextImage
          unoptimized
          src={assetObject.appStore}
          width={155}
          height={45}
        />
      </a>
    </div>
  );
};
AppStoreIcon.defaultProps = {
  channel: '',
};

export default AppStoreIcon;
