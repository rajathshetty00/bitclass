import clsx from 'clsx';

import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { assetObject } from 'utils/assetFileNames';

import NextImage from '../NextImage/NextImage';
import AppStoreIcon from './AppStoreIcon/AppStoreIcon';
import { staticData } from './DownloadBitClassData';
import LearnerCount from './LearnerCount/LearnerCount';
import PlayStoreIcon from './PlayStoreIcon/PlayStoreIcon';
import styles from './styles.module.scss';

const DownloadBitClassApp = ({
  channel = 'home_page',
}: {
  channel?: string;
}) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  return (
    <section
      id="downloadBitclassApp"
      className={clsx(styles.downloadBitclassAppContainer, {
        [styles.downloadBitclassAppWebContainer]: !isMobile,
      })}
    >
      <div className={styles.contentContainer}>
        <div className={styles.description}>
          <h3>
            Learn from Anywhere with{' '}
            <span className={styles.bitclassText}>BitClass</span> app
          </h3>
          <p className={styles.descriptionText}>
            Take Live classes on the go with the BitClass app. Download to watch
            on the bus, the metro, or from wherever you learn the best.
          </p>
        </div>
        {/* section statistics of bitclass start  */}
        <div className={styles.itemContainer}>
          <section id="bitclassInfo" className={styles.bitclassInfoContainer}>
            <LearnerCount
              count={staticData.learnerCount}
              countText={staticData.leanerText}
              imageSrc={assetObject.userIcon}
            />
            <div className={styles.verticalLine} />
            <LearnerCount
              count={staticData.rating}
              countText={staticData.ratingText}
              imageSrc={assetObject.blueStarIcon}
            />
          </section>
          {/* section statistics of bitclass end  */}
          {/* best App section start */}
          {!isMobile && <div className={styles.verticalLine} />}
          <section className={styles.bestAppSection}>
            <div className={styles.bestAppContent}>
              <NextImage
                unoptimized
                src={assetObject.bestAppIcon}
                width={60}
                height={60}
              />
              <div className={styles.bestAppText}>
                <h1 className={styles.bestAppLabel}>Best App of the year</h1>
                <p className={styles.bestAppYear}>(2021 - India)</p>
              </div>
            </div>
          </section>
        </div>
        {/* best App section start */}

        {/* Play stores icons start */}
        <div className={styles.downloadButtons}>
          <PlayStoreIcon channel={channel} />
          <AppStoreIcon channel={channel} />
        </div>
        {/* Play Stores icons start */}
      </div>
      {/* Right banner start */}
      {!isMobile && (
        <div className={styles.image}>
          <NextImage
            src={assetObject.bannerIcon}
            unoptimized
            width={600}
            height={500}
          />
        </div>
      )}
      {/* Right banner ends */}
    </section>
  );
};
DownloadBitClassApp.defaultProps = {
  channel: '',
};

export default DownloadBitClassApp;
