export const staticData = {
  learnerCount: '1.1M+',
  leanerText: 'Learners',
  rating: '4.5+',
  ratingText: 'Ratings (6k+)',
  subHeading:
    'Take Live classes on the go with the BitClass app. Download to watch on the bus, the metro, or from wherever you learn the best.',
};
