import { FC } from 'react';
import NextImage from '../../NextImage/NextImage';
import styles from './styles.module.scss';

interface ILearnerCount {
  count: string;
  countText: string;
  imageSrc: string;
}

const LearnerCount: FC<ILearnerCount> = ({ countText, imageSrc, count }) => {
  return (
    <section id="bitclass_statistics" className={styles.bitclassStatistics}>
      <div className={styles.statisticsContent}>
        <NextImage unoptimized src={imageSrc} width={24} height={24} />
        <p>{count}</p>
      </div>
      <p className={styles.staticsText}>{countText}</p>
    </section>
  );
};

export default LearnerCount;
