/* eslint-disable no-nested-ternary */
import clsx from 'clsx';
import { CheckCircle, Loader, Plus } from 'react-feather';
import React, { useState, useEffect } from 'react';
import { debounce } from 'lodash';
import { followTeacher, getMyFollowingList, unfollowTeacher } from 'utils/api';
import { getCode, getUserInfo } from 'utils/auth/userInfo';
import {
  initialSignInPageViewed,
  startLogin,
} from 'redux/reducers/authReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { setModalState } from 'redux/reducers/appReducer';
import styles from './styles.module.scss';
import { BitButton } from '../BitButton/BitButton';

const FollowButton = () => {
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const dispatch = useAppDispatch();
  const { userInfo } = useAppSelector((state: AppState) => state?.auth);

  const userData = userInfo || getUserInfo();

  useEffect(() => {
    if (userData) {
      (async () => {
        const userCode = getCode();
        try {
          const { following } = await getMyFollowingList();
          setIsFollowing(following.includes(userCode));
          setIsLoading(false);
        } catch (error) {
          setIsLoading(true);
        }
      })();
    } else {
      setIsLoading(false);
      setIsFollowing(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getFollowButtonStyle = () => {
    if (isFollowing) return clsx(styles.followBtn, styles.following);
    return styles.followBtn;
  };
  const handleFollow = debounce(async () => {
    const userCode = getCode();
    if (userData) {
      try {
        setIsLoading(true);
        if (isFollowing) {
          const { success } = await unfollowTeacher(userCode);
          if (success) setIsFollowing(false);
        } else {
          const { success } = await followTeacher(userCode);
          if (success) setIsFollowing(true);
        }
        setIsLoading(false);
      } catch (error) {
        setIsLoading(false);
      }
    } else {
      dispatch(setModalState(true));
      dispatch(initialSignInPageViewed(true));
      dispatch(startLogin(true));
    }
  }, 500);
  return (
    <BitButton
      className={getFollowButtonStyle()}
      onClick={handleFollow}
      variant="outlined"
    >
      {isLoading ? (
        <>
          <Loader className={styles.loader} />
          Loading..
        </>
      ) : isFollowing ? (
        <>
          <CheckCircle />
          Following
        </>
      ) : (
        <>
          <Plus />
          Follow Teacher
        </>
      )}
    </BitButton>
  );
};

export default FollowButton;
