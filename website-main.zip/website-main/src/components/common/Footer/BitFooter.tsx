import NextImage from 'src/components/common/NextImage/NextImage';
import Socials from 'src/components/common/Socials/Socials';
import Link from 'next/link';
import { BASE_URL, ROOT_URL } from 'utils/constants';
import EmailIcon from '@mui/icons-material/Email';

import { LOGO } from 'utils/logo/logo';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { useRouter } from 'next/router';
import { getHrefLink } from 'utils';
import { AppState } from 'redux/store';
import { useSelector } from 'react-redux';
import styles from './footer.module.scss';

const SEARCH_LINKS = [
  { name: 'Arts', link: `${ROOT_URL}/new/search-result-page?q=art` },
  { name: 'Music', link: `${ROOT_URL}/new/search-result-page?q=music` },
  { name: 'Dance', link: `${ROOT_URL}/new/search-result-page?q=dance` },
  { name: 'Crypto', link: `${ROOT_URL}/new/search-result-page?q=crypto` },
  { name: 'Baking', link: `${ROOT_URL}/new/search-result-page?q=baking` },
  { name: 'Health', link: `${ROOT_URL}/new/search-result-page?q=Health` },
];
const BLOG_URL = 'https://blog.bitclass.live/';

const CURRENT_YEAR = new Date().getFullYear();

const BitFooter = () => {
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const disableFooter =
    router.asPath.includes('classroom') || router.asPath.includes('profile');
  if (disableFooter) return <div />;
  return (
    <div className={styles.footer}>
      <div className={styles.footerAbout}>
        <div className={styles.details}>
          <NextImage
            src={LOGO.dark}
            width={160}
            height={64}
            objectFit="contain"
            unoptimized
          />
          <p>
            BitClass is the largest LIVE learning platform. Get started for FREE
            and explore 100s of classes across several categories.
          </p>
          <Socials />
        </div>
        <div className={styles.copyright}>
          Livestream Infra Technologies Pvt Ltd © {CURRENT_YEAR}
        </div>
      </div>
      {/* pages */}
      <div className={styles.pagesSearchesContainer}>
        <div className={styles.footerPage}>
          <h3>Useful Links</h3>
          <div className={styles.links}>
            <a
              className={EVENT_NAMES.FOOTER_HOME_CLICKED}
              id="social-link"
              href={getHrefLink(`${BASE_URL}`, router)}
              rel="noreferrer"
            >
              Home
            </a>
            <a
              className={EVENT_NAMES.FOOTER_ABOUT_CLICKED}
              id="social-link"
              rel="noreferrer"
              href={getHrefLink(
                `${BASE_URL}/new/about?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              About
            </a>
            <a
              className={EVENT_NAMES.FOOTER_CONTACT_US_CLICKED}
              id="social-link"
              href={getHrefLink(
                `${BASE_URL}/new/contact?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              Contact
            </a>
            <a
              className={EVENT_NAMES.FOOTER_CAREERS_CLICKED}
              id="social-link"
              href={getHrefLink(
                `${BASE_URL}/new/careers?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              Careers
            </a>
            <a
              className={EVENT_NAMES.TEACH_ON_BITCLASS_CLICKED}
              id="social-link"
              href={getHrefLink(
                `${BASE_URL}/n/launchpad?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              Teach On BitClass
            </a>
            <a
              className={EVENT_NAMES.FOOTER_BLOG_CLICKED}
              id="social-link"
              href={getHrefLink(
                `${BLOG_URL}?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              Blog
            </a>
            <Link
              href={getHrefLink(
                `/live-classes/policy?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              <span
                className={EVENT_NAMES.FOOTER_POLICY_CLICKED}
                id="social-link"
              >
                Policy
              </span>
            </Link>

            <Link
              href={getHrefLink(
                `/live-classes/terms?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              <span
                className={EVENT_NAMES.FOOTER_TERM_CLICKED}
                id="social-link"
              >
                Terms & conditions
              </span>
            </Link>

            <Link
              href={getHrefLink(
                `/live-classes/faq?channel=footer&platform=${
                  isMobile ? 'mweb' : 'web'
                }`,
                router,
              )}
            >
              <span className={EVENT_NAMES.FAQ_CLICKED} id="social-link">
                FAQs
              </span>
            </Link>
          </div>
        </div>
        <div className={styles.popularSearches}>
          <h3>Popular Searches</h3>
          <div className={styles.links}>
            {SEARCH_LINKS.map((item) => (
              <Link
                href={getHrefLink(
                  `${item?.link}&channel=footer&platform=${
                    isMobile ? 'mweb' : 'web'
                  }`,
                  router,
                )}
                key={item?.link}
              >
                {item?.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
      <div className={styles.contact}>
        <h3>Contact Us</h3>
        <div className={styles.footerContacts}>
          <p>For Students</p>
          <div className={styles.footerContactDiv}>
            <EmailIcon />
            <p>
              <a
                className={EVENT_NAMES.FOOTER_EMAIL_CLICKED}
                id="social-link"
                href="mailto:hello@bitclass.live"
              >
                hello@bitclass.live
              </a>
            </p>
          </div>
          <p>For Teachers</p>
          <div className={styles.footerContactDiv}>
            <EmailIcon />
            <p>
              <a
                className={EVENT_NAMES.FOOTER_EMAIL_CLICKED}
                id="social-link"
                href="mailto:teachers@bitclass.live"
              >
                teachers@bitclass.live
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BitFooter;
