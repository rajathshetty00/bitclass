import styles from './bitHeader.module.scss';

const BitHeader = () => (
  // functions
  <div className={styles.header}>
    <div>Left</div>
    <div>Right</div>
  </div>
);
export default BitHeader;
