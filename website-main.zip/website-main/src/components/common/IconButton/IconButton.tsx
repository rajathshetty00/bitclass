import { ReactNode } from 'react';
import IconButton from '@mui/material/IconButton';

interface IIconButtonProps {
  onClick: () => void;
  children: ReactNode;
  mobileMenuId: string;
  size: 'small' | 'large' | 'medium' | undefined;
  ariaLabel: string;
}

const BitIconButton = ({
  onClick,
  children,
  mobileMenuId,
  size,
  ariaLabel,
}: IIconButtonProps) => (
  <IconButton
    size={size}
    aria-label={ariaLabel}
    aria-controls={mobileMenuId}
    aria-haspopup="true"
    onClick={onClick}
    color="inherit"
  >
    {children}
  </IconButton>
);

export default BitIconButton;
