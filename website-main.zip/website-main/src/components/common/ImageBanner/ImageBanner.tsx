import { useRouter } from 'next/router';
import { FC } from 'react';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { getHrefLink, isQueryURl } from 'utils';
import NextImage from '../NextImage/NextImage';
import styles from './styles.module.scss';

const ImageBanner: FC<any> = ({ item, sectionHeading }) => {
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const generateLink = isQueryURl(item?.action)
    ? `${item?.action}&channel=${sectionHeading}&platform=${
        isMobile ? 'mweb' : 'web'
      } `
    : `${item?.action}?channel=${sectionHeading}&platform=${
        isMobile ? 'mweb' : 'web'
      }`;

  const link = getHrefLink(`${generateLink}`, router);
  return (
    <div className={styles.imageBannerContainer}>
      <a href={link}>
        <NextImage
          className={styles.image}
          src={item?.imageUrl}
          width="624"
          height={320}
        />
      </a>
    </div>
  );
};

export default ImageBanner;
