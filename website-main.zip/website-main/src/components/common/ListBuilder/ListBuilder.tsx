interface IListBuilder {
  list: any;
  builder: any;
}
const ListBuilder = ({ list, builder }: IListBuilder) => {
  return list.map((item: any, index: number) => builder(item, index));
};

export default ListBuilder;
