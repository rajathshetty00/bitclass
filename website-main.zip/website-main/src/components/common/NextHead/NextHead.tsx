/* eslint-disable react/no-danger */
import React from 'react';
import { AppState, useAppSelector } from 'redux/store';
import Head from 'next/head';
import Homepage from './PageWiseContent/Homepage';
import Cdp from './PageWiseContent/CourseDetailsMeta';
import Category from './PageWiseContent/CategoryMeta';

interface IPageWiseMeta {
  [key: string]: React.ReactNode;
}

const NextHead = () => {
  const { pageType } = useAppSelector((state: AppState) => state.app);

  const pageWiseMeta: IPageWiseMeta = {
    HOME_PAGE: <Homepage />,
    CDP_SUBSCRIPTION_PAGE: <Cdp />,
    CDP_FREEMIUM_PAGE: <Cdp />,
    CDP_FULL_COURSE_PAGE: <Cdp />,
    CDP_FREE_COURSE_PAGE: <Cdp />,
    CDP_TMPR_PAGE: <Cdp />,
    CDP_CURRICULUM_PAGE: <Cdp />,
    CDP_WORKSHOP_PAGE: <Cdp />,
    COLLECTION_PAGE: <Category />,
    CATEGORY_PAGE: <Category />,
    PROFILE_PAGE: <Homepage />,
  };

  return (
    <div>
      {pageWiseMeta[pageType] || (
        <Head>
          <title>Search live courses | Bitclass</title>
          <meta
            name="viewport"
            content="width=device-width, initial-scale=1, maximum-scale=1"
          />
          <meta name="theme-color" content="#2E3A59" />
          <meta
            name="google-site-verification"
            content="m3kR-wqiju62QzrF-jYZLtziE4r4-JSI27_qHg1uqlc"
          />
          <meta
            name="facebook-domain-verification"
            content="9d33hmy9p8ico6niubuj9cxs291vc0"
          />
          <link rel="apple-touch-icon" href="/static/logoNew.svg" />
          <link rel="manifest" href="/static/manifest.json" />
          <link rel="shortcut icon" href="/static/logoNew.svg" />
          <link rel="shortcut icon" href="/static/favicon.ico" />
          <meta
            name="description"
            content="Search for live instructor-led course online on BitClass."
          />
          <meta
            name="keywords"
            content="Live Online Course, Online Class, Live courses, BitClass Classes"
          />
          <meta property="og:title" content="Search live courses | Bitclass" />
          <meta
            property="og:description"
            content="BitClass is your own Campus On The Internet, where you can come to learn what you want, from the best teachers around the world, via super-engaging live sessions - you also get to network with your fellow classmates, be a part of the campus buzz and attend fun events online - exactly how it works for an offline campus."
          />
          <meta
            property="og:image"
            content="https://res.cloudinary.com/bitclass/image/upload/f_auto,q_auto/Assets/Frame_892_ikhor0.png"
          />
          <meta
            property="og:url"
            content="https://www.bitclass.live/search-result-page"
          />
          <meta name="twitter:title" content="Search live courses | Bitclass" />
          <meta
            name="twitter:description"
            content="Search for live instructor-led course online on BitClass."
          />
          <meta
            name="twitter:image"
            content="https://res.cloudinary.com/bitclass/image/upload/v1617623261/Assets/Frame_892_ikhor0.png"
          />
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:site" content="" />
          <meta property="og:site_name" content="BitClass" />
          <meta name="next-head-count" content="23" />
        </Head>
      )}
    </div>
  );
};

export default NextHead;
