import Head from 'next/head';
import { useRouter } from 'next/router';
import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import { getSlicedString, optimizeCloudinaryImage } from 'utils';
import { BASE_URL } from 'utils/constants';

interface CategoryProps {}

const Category: FC<CategoryProps> = () => {
  const { categoryData } = useAppSelector((state: AppState) => state.category);

  const router = useRouter();

  const url = `${BASE_URL}/${router.asPath}`;

  const {
    meta: { heading, description, circular_icon },
  } = categoryData;

  return (
    <Head>
      <title>{heading} | Bitclass</title>
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1"
      />
      <meta name="theme-color" content="#2E3A59" />
      <link rel="apple-touch-icon" href="/static/logoNew.svg" />
      <link rel="manifest" href="/static/manifest.json" />
      <link rel="shortcut icon" href="/static/logoNew.svg" />
      <link rel="shortcut icon" href="/static/favicon.ico" />
      <meta name="description" content={getSlicedString(description, 100)} />
      <meta
        name="keywords"
        content="Live Online Course, Online Class, Live courses, BitClass Classes"
      />
      <meta property="og:title" content={`${heading} | Bitclass`} />
      <meta
        property="og:description"
        content={getSlicedString(description, 100)}
      />
      <meta
        property="og:image"
        content={optimizeCloudinaryImage({
          src: circular_icon,
          width: 80,
          quality: 50,
        })}
      />
      <meta property="og:url" content={url} />
      <meta name="twitter:title" content={`${heading} | Bitclass`} />
      <meta
        name="twitter:description"
        content={getSlicedString(description, 100)}
      />
      <meta
        name="twitter:image"
        content={optimizeCloudinaryImage({
          src: circular_icon,
          width: 80,
          quality: 40,
        })}
      />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="" />
      <meta property="og:site_name" content="BitClass" />
    </Head>
  );
};

export default Category;
