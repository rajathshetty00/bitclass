import Head from 'next/head';
import { useRouter } from 'next/router';
import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import { getSlicedString, htmlSanitizer, optimizeCloudinaryImage } from 'utils';
import { BASE_URL } from 'utils/constants';

interface CdpProps {}

const Cdp: FC<CdpProps> = () => {
  const router = useRouter();

  const url = `${BASE_URL}/${router.asPath}`;

  const DEFAULT_PAGE_META_IMAGE =
    'https://res.cloudinary.com/bitclass/image/upload/w_400,q_50/v1617623261/Assets/Frame_892_ikhor0.png';

  const course = useAppSelector((state: AppState) => state.cdp.course);
  const { intro_video_thumbnail, heading, goal, intro_video } = course ?? {};
  const video = intro_video ?? null;
  const thumbnail = intro_video_thumbnail ?? DEFAULT_PAGE_META_IMAGE;
  const meta = course?.sections?.meta;
  const title = meta?.title ?? heading;
  const description = meta?.description ?? goal;

  return (
    <Head>
      <title>{getSlicedString(title, 10)}</title>
      {/* default tags start  */}
      <meta
        name="description"
        content={htmlSanitizer(getSlicedString(description, 140))}
      />
      <meta name="keywords" content={meta?.keywords} />
      <meta property="og:title" content={getSlicedString(title, 25)} />
      <meta property="og:url" content={url} />
      {/* default tags end  */}

      {/* og tags start  */}
      <meta
        property="og:description"
        content={htmlSanitizer(getSlicedString(description, 70))}
      />
      <meta
        property="og:image"
        content={optimizeCloudinaryImage({
          src: thumbnail,
          width: 400,
          quality: 50,
        })}
      />
      <meta
        property="og:image:url"
        itemProp="image"
        content={optimizeCloudinaryImage({
          src: thumbnail,
          width: 400,
          quality: 50,
        })}
      />
      <meta property="og:image:type" content="image/png" />
      <meta property="og:type" content="website" />
      {video && <meta property="og:video" content={video} />}
      <meta property="og:site_name" content="BitClass" />
      {/* og tags end  */}

      {/* twitter tags start */}
      <meta name="twitter:card" content={description} />
      <meta name="twitter:title" content={title} />
      <meta
        name="twitter:description"
        content={htmlSanitizer(getSlicedString(description, 140))}
      />
      <meta name="twitter:image" content={thumbnail} />
      <meta name="twitter:site" content={url} />
      {/* twitter tags end */}
    </Head>
  );
};

export default Cdp;
