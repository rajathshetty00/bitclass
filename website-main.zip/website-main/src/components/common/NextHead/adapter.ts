const DEFAULT_PAGE_META_DATA = { title: 'BitClass - Live Class' };

const getHomepageData = () => {
  const homepageData = { ...DEFAULT_PAGE_META_DATA };
  return { ...homepageData };
};

const getNextHeadDataByPage = (route: string) => {
  switch (route) {
    case '/':
      return getHomepageData();

    default:
      return DEFAULT_PAGE_META_DATA;
  }
};

export default getNextHeadDataByPage;
