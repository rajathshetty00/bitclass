import { FC } from 'react';
import Image, { ImageProps } from 'next/image';
import { optimizeCloudinaryImage } from 'utils';

interface INextImageProps extends ImageProps {
  className?: string;
}
const NextImage: FC<INextImageProps> = ({ className, src, ...props }) => (
  <Image
    src={src}
    loader={optimizeCloudinaryImage}
    className={className}
    {...props}
  />
);
NextImage.defaultProps = { className: '' };

export default NextImage;
