import { FC } from 'react';
import { BitButton } from 'src/components/common/BitButton/BitButton';

interface IPaymentButton {
  btnText: string;
}
const PaymentButton: FC<IPaymentButton> = ({ btnText }) => {
  return <BitButton>{btnText}</BitButton>;
};

export default PaymentButton;
