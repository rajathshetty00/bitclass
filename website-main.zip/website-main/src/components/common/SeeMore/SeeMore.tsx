import { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronUp } from 'react-feather';
import clsx from 'clsx';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import styles from './styles.module.scss';

const SeeMore = ({
  size = 10,
  children,
  overlayColor,
  bgColor,
  customClass,
  showSeeMore = true,
}: any) => {
  // const totalWords = text?.split(" ").length
  const [seeMore, setSeeMore] = useState(true);

  const handleToggle = () => {
    setSeeMore(!seeMore);
    saveGtmDataLayerData({
      event: EVENT_NAMES.CDP_SHOW_MORE_CLICKED,
      see_more: !seeMore,
    });
  };

  const [contentHeight, setContentHeight] = useState<any>(false);
  const aboutRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // @ts-ignore
    setContentHeight(aboutRef?.current?.clientHeight >= size * 14);
  }, [size]);

  return (
    <div className={clsx(styles.container, customClass)}>
      <div className={styles.fullHtml}>
        <div
          className={seeMore ? styles.summary : styles.html}
          style={seeMore && contentHeight ? { height: `${size}rem` } : {}}
          ref={aboutRef}
        >
          {children}
        </div>
        {seeMore && contentHeight && (
          <div
            className={styles.overlay}
            style={{
              height: `${size}rem`,
              background: `linear-gradient(180deg, rgba(255,255,255,0) 60%, ${
                overlayColor || 'rgba(255,255,255,1)'
              } 100%)`,
            }}
          />
        )}
      </div>
      {showSeeMore && (
        <button
          onClick={handleToggle}
          className={styles.showMore}
          style={{ backgroundColor: bgColor || 'white' }}
          type="button"
        >
          {seeMore ? (
            <div className={styles.seeMoreElement}>
              <span>See more</span>
              <ChevronDown />
            </div>
          ) : (
            <div className={styles.seeMoreElement}>
              <span>See less</span>
              <ChevronUp />
            </div>
          )}
        </button>
      )}
    </div>
  );
};

export default SeeMore;
