import { FC } from 'react';

interface SeperatorProps {
  customClass: string;
}

const Seperator: FC<SeperatorProps> = ({ customClass }) => {
  return <div className={customClass} />;
};

export default Seperator;
