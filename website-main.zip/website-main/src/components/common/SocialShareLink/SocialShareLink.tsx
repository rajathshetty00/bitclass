import {
  FacebookShareButton,
  WhatsappShareButton,
  WhatsappIcon,
  TwitterShareButton,
  TelegramShareButton,
  FacebookIcon,
  TwitterIcon,
  TelegramIcon,
} from 'react-share';
import BitAlert from 'src/components/common/BitAlert/BitAlert';
import { useRef } from 'react';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import clsx from 'clsx';
import styles from './styles.module.scss';

const SocialShareLink = ({
  linkText,
  linkUrl,
  className = '',
  hideTitle = false,
}: any) => {
  const alertRef = useRef<any>();
  const copytoClipBoard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const shareClickHandler = (type: string) => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.SHARE_CLICKED,
      cdpInviteSection: {
        share_type: type,
      },
    });
  };

  const copyTextFn = () => {
    copytoClipBoard(linkUrl);
    shareClickHandler('copy');
    alertRef.current.toggleOpenAlert('success', 'Link copied', 5000);
  };

  return (
    <div className={clsx(styles.popup_section, className)}>
      {!hideTitle && (
        <>
          <p>Learn with a friend</p>
          <hr />
        </>
      )}

      <div className={styles.icon_section}>
        <WhatsappShareButton
          title={linkText}
          url={linkUrl}
          className={styles.icon_content}
          onClick={() => shareClickHandler('whatsapp')}
          // style={{ outline: "none", marginRight: 12, display: "flex" }}
        >
          <WhatsappIcon size={32} round />
        </WhatsappShareButton>
        <FacebookShareButton
          title={linkText}
          url={linkUrl}
          className={styles.icon_content}
          onClick={() => shareClickHandler('facebook')}
        >
          <FacebookIcon size={32} round />
        </FacebookShareButton>
        <TwitterShareButton
          title={linkText}
          url={linkUrl}
          className={styles.icon_content}
          onClick={() => shareClickHandler('twitter')}
        >
          <TwitterIcon size={32} round />
        </TwitterShareButton>
        <TelegramShareButton
          title={linkText}
          url={linkUrl}
          className={styles.icon_content}
          onClick={() => shareClickHandler('telegram')}
        >
          <TelegramIcon size={32} round />
        </TelegramShareButton>
        <div
          title="Copy Link"
          style={{
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            cursor: 'pointer',
            marginTop: '-5px',
          }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="32"
            height="32"
            viewBox="0 0 32 32"
            fill="none"
            stroke="#5d5d5d"
            strokeWidth="1"
            strokeLinecap="round"
            strokeLinejoin="round"
            onClick={copyTextFn}
          >
            <rect x="4" y="4" width="18" height="21" rx="2" ry="2" />
            <rect
              x="8"
              y="8"
              width="18"
              height="21"
              rx="2"
              ry="2"
              style={{ fill: '#fff' }}
            />
          </svg>
        </div>
        <BitAlert ref={alertRef} />
      </div>
    </div>
  );
};

export default SocialShareLink;
