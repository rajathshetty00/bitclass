import SOCIAL_DATA from 'src/components/common/Socials/socialData';
import styles from './styles.module.scss';

const Socials = () => (
  <div className={styles.social}>
    {SOCIAL_DATA.map(({ name, link, Icon, event }) => (
      <a
        target="_blank"
        className={event}
        id="social-link"
        href={link}
        key={name}
        rel="noreferrer"
      >
        <Icon />
      </a>
    ))}
  </div>
);

export default Socials;
