import LinkedInIcon from '@mui/icons-material/LinkedIn';
import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import { EVENT_NAMES } from 'utils/gtm/eventNames';

const SOCIAL_DATA = [
  {
    name: 'linkedIn',
    link: 'https://www.linkedin.com/company/bitclass-live/',
    Icon: LinkedInIcon,
    event: EVENT_NAMES.FOOTER_LINKEDIN_CLICKED,
  },
  {
    name: 'facebook',
    link: 'https://www.facebook.com/Bitclasscommunity',
    Icon: FacebookIcon,
    event: EVENT_NAMES.FOOTER_FB_CLICKED,
  },
  {
    name: 'instagram',
    link: 'https://www.instagram.com/bitclass/',
    Icon: InstagramIcon,
    event: EVENT_NAMES.FOOTER_INSTAGRAM_CLICKED,
  },
  {
    name: 'twitter',
    link: 'https://twitter.com/bitclass_live',
    Icon: TwitterIcon,
    event: EVENT_NAMES.FOOTER_TWITTER_CLICKED,
  },
];

export default SOCIAL_DATA;
