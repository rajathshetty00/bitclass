import { ReactNode } from 'hoist-non-react-statics/node_modules/@types/react';

interface ISpacer {
  size: number;
  axis?: string;
  classes?: string;
  children?: ReactNode;
}

const Spacer = ({ size, axis, classes, children }: ISpacer) => {
  const width = axis === 'vertical' ? 1 : size;
  const height = axis === 'horizontal' ? 1 : size;
  return (
    <div
      style={{
        width,
        minWidth: width,
        height,
        minHeight: height,
      }}
      className={`${classes}`}
    >
      {children}
    </div>
  );
};

Spacer.defaultProps = {
  axis: '',
  classes: '',
  children: '',
};

export default Spacer;
