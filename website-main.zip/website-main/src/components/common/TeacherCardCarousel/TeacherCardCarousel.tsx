import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import TeacherCard from 'src/layouts/Homepage/TeacherCard/TeacherCard';
import BitSlickSlider from '../BitSlickSlider/BitSlickSlider';

import styles from './styles.module.scss';

interface TeacherCardCarouselProps {}

const TeacherCardCarousel: FC<TeacherCardCarouselProps> = () => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );

  const { topTeachers } = useAppSelector((state: AppState) => state.app);

  return (
    <div className={styles.teacherCardCarouselWrapper}>
      <h2>Live Classes - Exclusively by Star Teachers</h2>
      <p>
        BitClass teachers are icons, experts, and industry rock stars excited to
        share their experience, wisdom, and trusted tools with you.
      </p>

      <BitSlickSlider
        customSettings={{
          slidesToShow: isMobile ? 1.6 : 4.5,
          slidesToScroll: isMobile ? 1 : 4,
          arrows: !isMobile,
        }}
        customClass={styles.customSlick}
      >
        {topTeachers?.map((item: any) => (
          <TeacherCard teacher={item} />
        ))}
      </BitSlickSlider>
    </div>
  );
};

export default TeacherCardCarousel;
