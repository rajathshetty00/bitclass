import clsx from 'clsx';
import ReactPlayer from 'react-player';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import NextImage from '../NextImage/NextImage';
import styles from './styles.module.scss';

interface IVideoPlayer {
  videoRef: any;
  customClass?: string;
  url: string;
}

const VideoPlayer = ({ videoRef, customClass, url }: IVideoPlayer) => {
  const handleError = () => {};
  return (
    <>
      {url && (
        <ReactPlayer
          ref={videoRef}
          className={clsx(styles.courseVideo, customClass)}
          width="100%"
          height="100%"
          controls
          loop={false}
          autoplay
          playing
          url={url}
          onPlay={() => {
            saveGtmDataLayerData({
              event: EVENT_NAMES.CDP_VIDEO_CLICKED,
              cdpVideoDetails: {
                action: 'play',
              },
            });
          }}
          onPause={() => {
            saveGtmDataLayerData({
              event: EVENT_NAMES.CDP_VIDEO_CLICKED,
              cdpVideoDetails: {
                action: 'pause',
              },
            });
          }}
          onError={handleError}
        />
      )}
      {!url && (
        <div className={styles.image_container}>
          <NextImage
            src="https://bitclass-assets.s3.ap-south-1.amazonaws.com/no-video.svg"
            width={700}
            height={380}
            className={styles.bannerImage}
          />
        </div>
      )}
    </>
  );
};

VideoPlayer.defaultProps = {
  customClass: '',
};

export default VideoPlayer;
