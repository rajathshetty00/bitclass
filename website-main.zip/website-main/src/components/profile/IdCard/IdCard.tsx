import clsx from 'clsx';
import { useRouter } from 'next/router';
import { FC, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { actionGetProfileData } from 'redux/actions/profileActions';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import BitThreeDotLoader from 'src/components/common/BitThreeDotLoader/BitThreeDotLoader';
import NextImage from 'src/components/common/NextImage/NextImage';
import Spacer from 'src/components/common/Spacer/Spacer';
import { getHrefLink } from 'utils';
import { assetObject } from 'utils/assetFileNames';
import { BASE_URL } from 'utils/constants';
import DetailsContainer from './chunks/DetailsContainer/DetailsContainer';
import ExtraDetails from './chunks/ExtraDetails/ExtraDetails';
import styles from './styles.module.scss';

interface IdCardProps {
  isMinified: boolean;
}

const IdCard: FC<IdCardProps> = ({ isMinified }) => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const { profileDetails } = useAppSelector((state: AppState) => state.profile);

  useEffect(() => {
    (async () => {
      await dispatch(actionGetProfileData());
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogoClicked = () => {
    if (!isMinified) return;
    return window.location.replace(
      getHrefLink(
        `${BASE_URL}?channel=home&platform=${isMobile ? 'mweb' : 'web'}`,
        router,
      ),
    );
  };
  return (
    <div className={styles.idCardWrapper}>
      <div className={clsx(styles.flashLogo, { [styles.link]: isMinified })}>
        <NextImage
          src={assetObject.logoWhite}
          width="90"
          height="24"
          onClick={handleLogoClicked}
        />
      </div>

      {profileDetails?.profile_pic ? (
        <NextImage
          src={profileDetails?.profile_pic}
          width={144}
          height={144}
          className={styles.imageAvatar}
        />
      ) : (
        <div className={styles.avatar}>
          {profileDetails?.name?.[0] || <BitThreeDotLoader />}
        </div>
      )}
      <h3>{profileDetails?.name || <BitThreeDotLoader />}</h3>
      {!isMinified && (
        <>
          <ExtraDetails profileDetails={profileDetails} />
          <Spacer size={32} axis="vertical" />
        </>
      )}

      <DetailsContainer profileDetails={profileDetails} />
    </div>
  );
};

export default IdCard;
