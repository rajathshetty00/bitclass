import { FC } from 'react';
// import BitThreeDotLoader from 'src/components/common/BitThreeDotLoader/BitThreeDotLoader';
import Seperator from 'src/components/common/Separator/Separator';
import styles from './styles.module.scss';

interface DetailsContainerProps {
  profileDetails: any;
}

const DetailsContainer: FC<DetailsContainerProps> = ({ profileDetails }) => {
  return (
    <div className={styles.detailsWrapper}>
      <section>
        <h5>{profileDetails?.classes || 0}</h5>
        <p>Classes</p>
      </section>

      <Seperator customClass={styles.separator} />

      <section>
        <h5>{profileDetails?.courses || 0}</h5>
        <p>Courses</p>
      </section>

      <Seperator customClass={styles.separator} />

      <section>
        <h5>{profileDetails?.learning_hours || 0}</h5>
        <p>Hours</p>
      </section>
    </div>
  );
};

export default DetailsContainer;
