import { FC } from 'react';
import BitChip from 'src/components/common/BitChip/BitChip';
import BitThreeDotLoader from 'src/components/common/BitThreeDotLoader/BitThreeDotLoader';
import NextImage from 'src/components/common/NextImage/NextImage';
import Spacer from 'src/components/common/Spacer/Spacer';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

interface ExtraDetailsProps {
  profileDetails: any;
}

const ExtraDetails: FC<ExtraDetailsProps> = ({ profileDetails }) => {
  const gender = profileDetails?.meta_info?.gender;
  return (
    <div className={styles.extraDetailsContainer}>
      <div className={styles.flexContainer1}>
        <div className={styles.gender}>
          {gender && (
            <NextImage
              src={
                gender === 'male'
                  ? assetObject.genderMaleEmoji
                  : assetObject.genderFeMaleEmoji
              }
              width={20}
              height={20}
            />
          )}
          <div className={styles.text}>
            <span>
              {profileDetails?.meta_info?.age || <BitThreeDotLoader />}
            </span>
            <span>&nbsp;/&nbsp;</span>
            <span>
              {(gender && gender[0]?.toUpperCase()) || <BitThreeDotLoader />}
            </span>
          </div>
        </div>
        <Spacer size={10} />
        {profileDetails?.meta_info?.location && (
          <div className={styles.location}>
            <NextImage src={assetObject.homeEmoji} width={20} height={20} />
            <p>{profileDetails?.meta_info?.location} </p>
          </div>
        )}
      </div>

      {profileDetails?.meta_info?.profession && (
        <p>I am a {profileDetails?.meta_info?.profession} </p>
      )}

      {profileDetails?.star_student && (
        <BitChip customClass={styles.chip} text={<span>Star Student</span>} />
      )}
    </div>
  );
};

export default ExtraDetails;
