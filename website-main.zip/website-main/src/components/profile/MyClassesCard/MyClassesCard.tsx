import { forwardRef } from 'react';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import SensorsIcon from '@mui/icons-material/Sensors';
import MapsUgcIcon from '@mui/icons-material/MapsUgc';
import PlayCircleIcon from '@mui/icons-material/PlayCircle';
import DoNotDisturbIcon from '@mui/icons-material/DoNotDisturb';
import BoltIcon from '@mui/icons-material/Bolt';
import dayjs from 'dayjs';
import { BASE_URL } from 'utils/constants';

import { useRouter } from 'next/router';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { getQuery } from 'utils';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import styles from './styles.module.scss';

interface IMyClassesCardProps {
  courseDetails: any;
}

const MyClassesCard = forwardRef(
  ({ courseDetails }: IMyClassesCardProps, ref: any) => {
    const router = useRouter();
    const appendQueryParamAndNavigate = useBitRouter();
    const { isMobile } = useSelector(
      (state: AppState) => state?.app?.deviceInfo,
    );

    const handleRenewClicked = (e: any) => {
      e.stopPropagation();
      appendQueryParamAndNavigate(
        `/live-classes/${courseDetails?.code}?channel=my_classes&platform=${
          isMobile ? 'mweb' : 'web'
        }#checkout`,
        getQuery(router),
        false,
      );
    };

    const handleCardClicked = () => {
      appendQueryParamAndNavigate(
        `/live-classes/${courseDetails?.code}?channel=my_classes&platform=${
          isMobile ? 'mweb' : 'web'
        }`,
        getQuery(router),
        false,
      );
    };
    return (
      <div
        style={{
          backgroundImage: `url(${courseDetails.intro_video_thumbnail})`,
        }}
        className={styles.myClassCardWrapper}
        ref={ref}
        role="button"
        tabIndex={0}
        aria-hidden="true"
        onClick={handleCardClicked}
      >
        <div className={styles.myClassCardContainer}>
          <div className={styles.tag}>
            {courseDetails?.type?.toUpperCase().replace('_', ' ')}
          </div>
          <h3>{courseDetails.heading}</h3>
          <div className={styles.flexContainer1}>
            {!courseDetails?.has_ended ? (
              <div>
                <p>Your Next Class</p>
                <h5>
                  {dayjs
                    .unix(courseDetails?.upcoming_lesson_ts[0])
                    .format('DD MMM, hh:mmA')}
                </h5>
              </div>
            ) : (
              <div />
            )}
            <BitButton
              startIcon={<SensorsIcon />}
              className={styles.goToLiveClass}
              onClick={(e) => {
                e.stopPropagation();
                appendQueryParamAndNavigate(
                  `${BASE_URL}/live-classes/classroom/${
                    courseDetails.code
                  }?channel=my_classes&platform=${isMobile ? 'mweb' : 'web'}`,
                  getQuery(router),
                );
              }}
            >
              Go to Live Class
            </BitButton>
          </div>
          <div className={styles.flexContainer2}>
            <BitButton
              startIcon={<PlayCircleIcon />}
              variant="contained"
              className={styles.recordBtn}
              onClick={(e) => {
                e.stopPropagation();
                appendQueryParamAndNavigate(
                  `${BASE_URL}/course/summary/${
                    courseDetails.code
                  }?channel=my_classes&platform=${
                    isMobile ? 'mweb' : 'web'
                  }#recordings`,
                  getQuery(router),
                );
              }}
            >
              View Recordings
            </BitButton>
            <BitButton
              className={styles.grpchat}
              startIcon={<MapsUgcIcon />}
              variant="outlined"
              onClick={(e) => {
                e.stopPropagation();
                appendQueryParamAndNavigate(
                  `${BASE_URL}/course/summary/${
                    courseDetails.code
                  }?channel=my_classes&platform=${
                    isMobile ? 'mweb' : 'web'
                  }#chats`,
                  getQuery(router),
                );
              }}
            >
              Group Chat
            </BitButton>
          </div>

          {courseDetails?.latest_subscription_details && (
            <div className={styles.renewalContainer}>
              <h6>
                {courseDetails?.latest_subscription_details?.is_active ? (
                  <div className={styles.expiringOn}>
                    Your Trial period is expiring on{' '}
                    {dayjs
                      .unix(
                        courseDetails?.latest_subscription_details?.expiring_on,
                      )
                      .format('DD MMM, YYYY')}
                  </div>
                ) : (
                  <>
                    Your current plan has expired
                    <DoNotDisturbIcon />
                  </>
                )}
              </h6>
              <BitButton
                className={styles.renew}
                startIcon={<BoltIcon />}
                onClick={handleRenewClicked}
                variant="contained"
              >
                {courseDetails?.latest_subscription_details?.is_active
                  ? 'Click to Renew'
                  : 'Buy Now'}
              </BitButton>
            </div>
          )}
        </div>
      </div>
    );
  },
);

export default MyClassesCard;
