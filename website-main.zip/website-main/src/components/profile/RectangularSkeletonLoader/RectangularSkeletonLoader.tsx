import { Skeleton } from '@mui/material';
import { FC } from 'react';
import styles from './styles.module.scss';

interface RectangularSkeletonLoaderProps {
  height: number;
}

const RectangularSkeletonLoader: FC<RectangularSkeletonLoaderProps> = ({
  height,
}) => {
  return (
    <Skeleton
      animation="wave"
      variant="rectangular"
      width="100%"
      height={height}
      className={styles.skeletonContainer}
    />
  );
};

export default RectangularSkeletonLoader;
