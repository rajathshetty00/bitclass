import { useRouter } from 'next/router';
import React, { FC } from 'react';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import { getHrefLink } from 'utils';
import { getDefaultRouteForLoggedIn, setRole } from 'utils/auth/userInfo';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

interface SwitchToTeacherProps {}

const SwitchToTeacher: FC<SwitchToTeacherProps> = () => {
  const router = useRouter();
  const switchToTeacherHandler = async () => {
    setRole('teacher');
    const r = await getDefaultRouteForLoggedIn();
    window.location.href = getHrefLink(`${BASE_URL}/${r}`, router);
  };
  return (
    <div className={styles.switchToTeacherWrapper}>
      <CustomDefaultButton
        onClick={switchToTeacherHandler}
        className={styles.button}
      >
        Switch To Teacher
      </CustomDefaultButton>
    </div>
  );
};

export default SwitchToTeacher;
