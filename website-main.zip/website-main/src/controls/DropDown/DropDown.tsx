/* eslint-disable react/jsx-props-no-spreading */

import { MenuItem, Select } from '@mui/material';
import { styled } from '@mui/material/styles';
import { FC } from 'react';
import InputBase from '@mui/material/InputBase';
import styles from './styles.module.scss';

interface IDropdown {
  optionList: String[];
  placeholder?: string;
  [props: string]: any;
}

const BootstrapInput = styled(InputBase)(({ theme }) => ({
  'label + &': {
    marginTop: theme.spacing(3),
  },
  '& .MuiInputBase-input': {
    borderRadius: 4,
    position: 'relative',
    backgroundColor: theme.palette.background.paper,
    border: '1px solid #ced4da',
    fontSize: 16,
    padding: '10px 26px 10px 12px',
    transition: theme.transitions.create(['border-color', 'box-shadow']),
    // Use the system font instead of the default Roboto font.
    fontFamily: ['Poppins'].join(','),
    '&:focus': {
      borderRadius: 4,
      borderColor: '#b4bcd0',
    },
  },
}));

const DropDown: FC<IDropdown> = ({ optionList, placeholder, ...props }) => {
  return (
    <div>
      <Select
        displayEmpty
        className={styles.dropDownSelect}
        {...props}
        input={<BootstrapInput />}
        defaultValue={optionList[0]}
      >
        <MenuItem className={styles.selectPlaceholder} value="" disabled>
          {placeholder}
        </MenuItem>
        {optionList.map((item: any) => {
          return (
            <MenuItem key={item} className={styles.optionList} value={item}>
              {item}
            </MenuItem>
          );
        })}
      </Select>
    </div>
  );
};

DropDown.defaultProps = {
  placeholder: 'Please choose your profession',
};

export default DropDown;
