import React, { FC, ReactNode } from 'react';
import styles from './styles.module.scss';

interface IErrorMsg {
  children: ReactNode;
}

const ErrorMsg: FC<IErrorMsg> = ({ children }) => {
  return <p className={styles.iserror}>{children}</p>;
};

export default ErrorMsg;
