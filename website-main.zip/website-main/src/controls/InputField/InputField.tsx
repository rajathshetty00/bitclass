/* eslint-disable react/jsx-props-no-spreading */
import clsx from 'clsx';
import { FC, ReactNode } from 'react';
import styles from './styles.module.scss';

interface IInputField {
  className?: string;
  placeholder?: string;
  [props: string]: any;
  suffix?: ReactNode;
}

const InputField: FC<IInputField> = ({ className, suffix, ...props }) => {
  return (
    <div className={styles.inputFieldContainer}>
      <input
        className={clsx(styles.inputField, className, {
          [styles.suffixExists]: suffix,
        })}
        {...props}
      />
      {suffix && suffix}
    </div>
  );
};

InputField.defaultProps = {
  className: '',
  placeholder: '',
  suffix: null,
};

export default InputField;
