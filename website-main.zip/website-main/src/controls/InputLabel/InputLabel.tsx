import clsx from 'clsx';
import { FC, ReactChild, ReactNode } from 'react';
import styles from './styles.module.scss';

interface IInputLabel {
  children: ReactNode | ReactChild;
  className?: string;
}

const InputLabel: FC<IInputLabel> = ({ children, className }) => {
  return <div className={clsx(styles.inputLabel, className)}>{children}</div>;
};

InputLabel.defaultProps = {
  className: '',
};

export default InputLabel;
