import Router from 'next/router';

export const useBitRouter = () => {
  const nextPush = (url: string, queryParams?: any, isWindow = true) => {
    const additionQuery = queryParams ? `&${queryParams}` : '';
    const initialQuery = queryParams ? `?${queryParams}` : '';
    if (isWindow && typeof window !== 'undefined') {
      const newURl = new URL(url);
      newURl.search = newURl.search
        ? `${newURl.search}${additionQuery}`
        : `${newURl.search}${initialQuery}`;
      window.open(`${newURl}`);
    }

    if (!isWindow) {
      const newUrl = url.split('?')[1];
      Router.push(newUrl ? `${url}${additionQuery}` : `${url}${initialQuery}`);
    }
  };
  return nextPush;
};
