import { useState, useEffect } from 'react';
import { CLOUDINARY_CONFIG } from 'utils/constants';

export const useCloudinary = () => {
  const [cloudinaryInfo, setCloudinaryInfo] = useState<any>(null);
  const [url, setUrl] = useState<string>('');
  const openCloudinaryUpload = () => {
    try {
      // @ts-ignore
      window.cloudinary
        .createUploadWidget(
          {
            ...CLOUDINARY_CONFIG,
            multiple: false,
            resource_type: 'image',
            cropping: true,
          },
          (error: any, result: any) => {
            const { secure_url } = result.info || {};
            if (secure_url) {
              setCloudinaryInfo(result.info);
              setUrl(secure_url);
            }
          },
        )
        .open(); // open up the widget after creation
    } catch (error) {
      console.error('Error while initilize the cloudinary', error);
    }
  };
  useEffect(() => {}, []);
  return { openCloudinaryUpload, cloudinaryInfo, url };
};
