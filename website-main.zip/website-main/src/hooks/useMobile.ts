import { useState, useEffect } from 'react';

export const useMobileView = () => {
  const [width, setWidth] = useState<number>(1200);
  function handleWindowSizeChange() {
    setWidth(window.innerWidth);
  }
  useEffect(() => {
    window.addEventListener('resize', handleWindowSizeChange);
    setWidth(window.innerWidth);
    return () => {
      window.removeEventListener('resize', handleWindowSizeChange);
    };
  }, []);
  const isMobile = width <= 768;
  return { isMobile };
};
