import { useEffect } from 'react';
import { actionGetSubscriptionPlan } from 'redux/actions/subCdpAction';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { validBoolean } from 'utils';

export const usePostLogin = () => {
  const dispatch = useAppDispatch();

  const { isLoginSuccess } = useAppSelector((state: AppState) => state?.auth);
  const {
    course: { code },
  } = useAppSelector((state: AppState) => state?.cdp);

  useEffect(() => {
    if (validBoolean(isLoginSuccess)) {
      dispatch(actionGetSubscriptionPlan(code));
    }
  }, [dispatch, isLoginSuccess, code]);
};
