/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import Typography from '@mui/material/Typography';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  initialSignInPageViewed,
  otpClicked,
  userData,
} from 'redux/reducers/authReducer';
import { useForm, FormProvider, SubmitHandler } from 'react-hook-form';
import FormInput from 'src/controls/Input/FormInput';

import CountryCodes from 'utils/constants/json/countryCodes.json';

import useYupValidationResolver from 'hooks/useYupValidationResolver';
import { FormControl } from '@mui/material';
import { phoneNumberValidationSchema } from 'utils/validationSchema/authValidation';
import { actionGenerateOtp } from 'redux/actions/authActions';
import { unwrapResult } from '@reduxjs/toolkit';
import SignInByGoogleLayout from 'src/layouts/AuthLayout/SignInByGoogleLayout/SignInByGoogleLayout';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { useSelector } from 'react-redux';
import { deleteAuthToken, deleteCookie } from 'utils';
import styles from './styles.module.scss';

interface IFormInput {
  phoneNumber: Number;
}

const InitialSignInLayout = () => {
  const dispatch = useAppDispatch();
  const resolver = useYupValidationResolver(phoneNumberValidationSchema);
  const { pageType } = useSelector((state: AppState) => state?.app);

  const methods = useForm<IFormInput>({ resolver });

  const [countryCode, setCountryCode] = useState('+91');

  const {
    handleSubmit,
    setError,
    register,
    formState: { errors },
  } = methods;

  const { otpPending } = useAppSelector((state: AppState) => state.auth);

  const handleChangeCountryCode = (e: any) => {
    setCountryCode(e.target.value);
  };

  const onSubmit: SubmitHandler<IFormInput> = (data) => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.LOGIN_SIGNIN_WITH_OTP_CLICKED,
      login_info: {
        page_type: pageType,
        source: 'phone',
        mobile_number: data?.phoneNumber,
      },
    });
    dispatch(
      actionGenerateOtp({
        attempt_count: 0,
        country_code: countryCode,
        phone: data?.phoneNumber,
      }),
    )
      .then(unwrapResult)
      .then(() => {
        dispatch(userData({ ...data, countryCode }));
        dispatch(otpClicked(true));
        dispatch(initialSignInPageViewed(false));
      });
  };

  useEffect(() => {
    if (sessionStorage.getItem('_auth')) {
      deleteAuthToken();
    }
  }, []);

  return (
    <div className={styles.signInWrapper}>
      <>
        <Typography variant="h6" component="h6" className={styles.heading}>
          Login to continue
        </Typography>

        <div className={styles.flexContainer}>
          <FormProvider {...methods}>
            <form onSubmit={handleSubmit(onSubmit)}>
              <FormControl variant="outlined" fullWidth>
                <div className={styles.rowOne}>
                  <Select
                    labelId="country-code-label"
                    id="country-code"
                    className={styles.selectContainer}
                    defaultValue={countryCode}
                    onChange={handleChangeCountryCode}
                  >
                    {CountryCodes.map((dt) => (
                      <MenuItem
                        value={dt.dial_code}
                        key={`${dt.name}`}
                        // label={dt.dial_code}
                        // className="item"
                      >
                        {/* <span className={styles.icon}>
                          {countryToFlag(dt.code)}
                        </span> */}
                        <span className={styles.text}>
                          ({dt.dial_code}) {dt.name}
                        </span>
                      </MenuItem>
                    ))}
                  </Select>

                  <FormInput
                    name="phoneNumber"
                    // id="filled-number"
                    label="Enter WhatsApp Number"
                    errorobj={errors}
                    setError={setError}
                    type="tel"
                    register={register}
                  />
                </div>
                <Typography variant="caption" className={styles.lightFont}>
                  Your Whatsapp number is required only for sending important
                  updates about your class.
                </Typography>
                <CustomDefaultButton
                  loading={otpPending}
                  className={styles.button}
                  type="submit"
                >
                  Send OTP
                </CustomDefaultButton>
              </FormControl>
            </form>
          </FormProvider>
        </div>
      </>

      <div className={styles.separator}>
        <hr />
        <span>OR</span>
        <hr />
      </div>

      <SignInByGoogleLayout />
    </div>
  );
};

export default InitialSignInLayout;
