const ReferralSignup = () => {
  return <div>logo</div>;
};

export default ReferralSignup;
