import { FunctionComponent, useEffect } from 'react';
import GoogleIcon from '@mui/icons-material/Google';

import GoogleLogin from 'react-google-login';

import { ENV, GOOGLE_CLIENT_ID } from 'utils/constants';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import clsx from 'clsx';
import { actionGetUserInfo, actionUserLogin } from 'redux/actions/authActions';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { saveUserInfo } from 'utils/auth/userInfo';
import axios from 'axios';
import { setCookie } from 'utils';
import {
  initialSignInPageViewed,
  loginSuccessful,
  otpClicked,
  signUpViewed,
  userData,
  updateSignupType,
} from 'redux/reducers/authReducer';
import { setModalState } from 'redux/reducers/appReducer';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { useSelector } from 'react-redux';
import styles from './styles.module.scss';

interface SignInByGoogleLayoutProps {}

interface IGoogleProps {
  email: string;
  idToken: string;
}

const SignInByGoogleLayout: FunctionComponent<SignInByGoogleLayoutProps> =
  () => {
    const dispatch = useAppDispatch();
    const { pageType } = useSelector((state: AppState) => state?.app);

    const { userInfo, pending } = useAppSelector(
      (state: AppState) => state.auth,
    );

    useEffect(() => {
      if (userInfo) {
        saveUserInfo(userInfo);
      }
    }, [userInfo]);

    const userInfoHandler = async ({ success, data }: any) => {
      if (success) {
        try {
          if (ENV === 'local') {
            axios.defaults.headers.Authorization = data?.auth_token;
            setCookie('auth-key', data?.auth_token, 365);
          }
          if (!data?.new_user) {
            // eslint-disable-next-line no-shadow
            const { payload } = await dispatch(actionGetUserInfo());
            if (payload?.success) {
              dispatch(loginSuccessful(true));
              dispatch(setModalState(false));
              saveGtmDataLayerData({
                login_info: { ...payload?.data, source: 'email' },
                event: EVENT_NAMES.LOGIN_SUCCESSFUL,
              });
            }
          } else {
            dispatch(initialSignInPageViewed(false));
            dispatch(otpClicked(false));
            dispatch(signUpViewed(true));
            dispatch(updateSignupType('email'));
            saveGtmDataLayerData({
              event: EVENT_NAMES.SIGNUP_PAGE_VIEWED,
            });
          }
        } catch (e) {
          return e;
        }
      }
    };

    const signInHandler = async ({ email, idToken }: IGoogleProps) => {
      const params = new URLSearchParams(window.location.search);
      const referredBy = params.get('referred_by');
      if (referredBy) {
        localStorage.setItem('referred_by', referredBy);
      }

      try {
        const data = await dispatch(
          actionUserLogin({
            email,
            google_id_tk: idToken,
            referred_by: referredBy,
          }),
        ).unwrap();
        await userInfoHandler(data);
      } catch (e) {
        return e;
      }
    };

    const googleResponse = async (response: any) => {
      const email = response.getBasicProfile().getEmail();
      const idToken = response.getAuthResponse().id_token;
      dispatch(userData({ email, idToken }));
      await signInHandler({ email, idToken });
    };

    return (
      <div className={styles.googleLoginContainer}>
        <GoogleLogin
          clientId={GOOGLE_CLIENT_ID}
          buttonText="Login with Google"
          onSuccess={googleResponse}
          onFailure={() => console.log('google login failed')}
          render={(renderProps) => (
            <CustomDefaultButton
              startIcon={<GoogleIcon />}
              onClick={renderProps.onClick}
              className={clsx(styles.lightButton, styles.button)}
              loading={pending}
            >
              Sign in with google
            </CustomDefaultButton>
          )}
          onRequest={() => {
            saveGtmDataLayerData({
              event: EVENT_NAMES.LOGIN_GOOGLE_LOGIN_CLICKED,
              login_info: {
                source: pageType,
              },
            });
          }}
        />
      </div>
    );
  };

export default SignInByGoogleLayout;
