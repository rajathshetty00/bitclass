/* eslint-disable react/no-unescaped-entities */
import { FormControl, Typography } from '@mui/material';
import {
  initialSignInPageViewed,
  otpClicked,
  signUpViewed,
  // initialiseSignIn,
  loginSuccessful,
  updateSignupType,
} from 'redux/reducers/authReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  CustomDefaultButton,
  CustomOutlinedButton,
} from 'src/components/common/BitMuiButton';
// import OtpInput from 'react-otp-input';
import { useEffect, useState } from 'react';
import {
  actionGenerateOtp,
  actionGetUserInfo,
  actionUserLogin,
} from 'redux/actions/authActions';
import { setModalState } from 'redux/reducers/appReducer';
import { saveUserInfo } from 'utils/auth/userInfo';
import { setCookie } from 'utils';
import { ENV } from 'utils/constants';
import axios from 'axios';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
// import { usePostLogin } from 'src/hooks/usePostLogin';
import BitOtpInput from 'src/components/common/BitOtpInput/BitOtpInput';
import { useSelector } from 'react-redux';
import styles from './styles.module.scss';

const SignInByOtpLayout = () => {
  const { pageType } = useSelector((state: AppState) => state?.app);

  // const { query } = useRouter();

  const [otp, setOtp] = useState<Number | any>(null);
  const [disabledButton, setDisabledButton] = useState<boolean>(true);
  const [attemptCount, setAttemptCount] = useState(0);

  const dispatch = useAppDispatch();

  const { userData, userInfo, pending, otpPending } = useAppSelector(
    (state: AppState) => state.auth,
  );

  const userInfoHandler = async ({ success, data }: any) => {
    if (success) {
      try {
        if (ENV === 'local') {
          axios.defaults.headers.Authorization = data?.auth_token;
          setCookie('auth-key', data?.auth_token, 365);
        }
        if (!data?.new_user && data.basic_profile_complete) {
          // eslint-disable-next-line no-shadow
          const { payload } = await dispatch(actionGetUserInfo());
          if (payload?.success) {
            dispatch(loginSuccessful(true));
            dispatch(setModalState(false));
            saveGtmDataLayerData({
              login_info: { ...payload?.data, source: 'mobile' },
              event: EVENT_NAMES.LOGIN_SUCCESSFUL,
            });
          }
        } else {
          dispatch(initialSignInPageViewed(false));
          dispatch(otpClicked(false));
          dispatch(signUpViewed(true));
          dispatch(updateSignupType('phone'));
          saveGtmDataLayerData({
            event: EVENT_NAMES.SIGNUP_PAGE_VIEWED,
          });
        }
      } catch (e) {
        return e;
      }
    }
  };

  useEffect(() => {
    if (otp?.length === 4) {
      setDisabledButton(false);
    } else setDisabledButton(true);
  }, [otp]);

  useEffect(() => {
    if (userInfo) {
      saveUserInfo(userInfo);
    }
  }, [userInfo]);

  useEffect(() => {
    (async () => {
      if (attemptCount) {
        saveGtmDataLayerData({
          event: EVENT_NAMES.LOGIN_SIGNIN_WITH_OTP_CLICKED,
          login_info: {
            source: pageType,
          },
        });
        dispatch(
          actionGenerateOtp({
            attempt_count: attemptCount === 3 ? attemptCount : 0,
            country_code: userData?.countryCode,
            phone: userData?.phoneNumber,
          }),
        );
      }
    })();
  }, [
    attemptCount,
    dispatch,
    userData?.countryCode,
    userData?.phoneNumber,
    pageType,
  ]);

  const changeNumberHandler = () => {
    dispatch(initialSignInPageViewed(true));
    dispatch(otpClicked(false));
  };

  const resendOtpHandler = async () => {
    setAttemptCount(attemptCount + 1);
  };

  const signInHandler = async () => {
    const params = new URLSearchParams(window.location.search);
    const referredBy = params.get('referred_by');
    if (referredBy) {
      localStorage.setItem('referred_by', referredBy);
    }

    try {
      const data = await dispatch(
        actionUserLogin({
          country_code: userData?.countryCode,
          otp,
          phone: userData?.phoneNumber,
          referred_by: referredBy,
        }),
      ).unwrap();
      await userInfoHandler(data);
    } catch (e) {
      return e;
    }
  };

  const handleChangeOtp = (value: string) => {
    setOtp(value);
  };

  return (
    <div className={styles.otpLayoutContainer}>
      <Typography variant="button" className={styles.lightFont}>
        YOUR WHATSAPP NUMBER
      </Typography>

      <div className={styles.rowOne}>
        <Typography variant="body1">{userData?.phoneNumber}</Typography>
        <CustomOutlinedButton
          onClick={changeNumberHandler}
          size="small"
          fullWidth={false}
        >
          Change Number
        </CustomOutlinedButton>
      </div>

      <Typography variant="body1" className={styles.textotp}>
        An OTP has been sent to the above number
      </Typography>

      <FormControl fullWidth>
        <BitOtpInput
          onChange={handleChangeOtp}
          numInputs={4}
          isInputNum
          onSubmit={signInHandler}
          containerStyle={styles.otpContainer}
          inputStyle={styles.inputContainer}
          focusStyle={styles.focus}
        />
        {attemptCount === 3 ? (
          <div className={styles.rowTwo}>
            <Typography variant="body1">
              You will receive otp over call...
            </Typography>
          </div>
        ) : (
          <div className={styles.rowTwo}>
            <Typography variant="body2">Didn't receive OTP?</Typography>
            <CustomOutlinedButton
              onClick={resendOtpHandler}
              size="small"
              fullWidth={false}
              variant="text"
            >
              Resend
            </CustomOutlinedButton>
          </div>
        )}
        <CustomDefaultButton
          className={styles.button}
          disabled={disabledButton}
          onClick={signInHandler}
          loading={pending || otpPending}
        >
          Sign In
        </CustomDefaultButton>
      </FormControl>
    </div>
  );
};

export default SignInByOtpLayout;
