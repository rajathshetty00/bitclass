import { FormControl, Typography } from '@mui/material';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import { useEffect, useState } from 'react';
import FormInput from 'src/controls/Input/FormInput';
import useYupValidationResolver from 'hooks/useYupValidationResolver';
import { userNameValidationSchema } from 'utils/validationSchema/authValidation';
import { useForm, FormProvider } from 'react-hook-form';
import Checkbox from '@mui/material/Checkbox';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  actionGetUserInfo,
  actionUpdateUserInfo,
} from 'redux/actions/authActions';
import { loginSuccessful, signUpViewed } from 'redux/reducers/authReducer';
import { setAlertModalState, setModalState } from 'redux/reducers/appReducer';
import { saveUserInfo } from 'utils/auth/userInfo';
// import { useRouter } from 'next/router';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import BitMuiAlertDialog from 'src/components/common/BitMuiAlertDialog/BitMuiAlertDialog';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

interface IFormInput {
  userName: String;
  email: String;
}

const SignUpLayout = () => {
  const [checked, setChecked] = useState(true);
  const resolver = useYupValidationResolver(userNameValidationSchema);
  const methods = useForm<IFormInput>({ resolver });
  const dispatch = useAppDispatch();
  const { pending, userInfo, userData } = useAppSelector(
    (state: AppState) => state.auth,
  );

  const {
    loginData: { signup_reward },
    signupType,
  } = useAppSelector((state: AppState) => state.auth);

  const {
    handleSubmit,
    setError,
    register,
    formState: { errors },
  } = methods;

  useEffect(() => {
    if (userInfo) {
      saveUserInfo(userInfo);
    }
  }, [userInfo]);

  const handleChange = () => {
    setChecked(!checked);
  };

  const onSubmit = async ({ email, userName, phone }: any) => {
    try {
      await dispatch(
        actionUpdateUserInfo({
          communication_email: userData?.email || email,
          communication_phone: userData?.phoneNumber || phone,
          username: userName,
          whatsapp_optin: checked,
        }),
      ).unwrap();
      const { payload } = await dispatch(actionGetUserInfo());
      if (payload?.success) {
        if (signup_reward) {
          dispatch(setAlertModalState(true));
          saveGtmDataLayerData({
            event: EVENT_NAMES.REFERRAL_SUCCESS_SCREEN_SHOWN,
          });
          return;
        }
        dispatch(loginSuccessful(true));
        dispatch(signUpViewed(false));
        dispatch(setModalState(false));
        saveGtmDataLayerData({
          userInfo: { ...payload.data, source: signupType },
          event: EVENT_NAMES.SIGNUP_SUCCESSFUL,
        });
      }
    } catch (e) {
      return e;
    }
  };

  return (
    <div className={styles.signUpContainer}>
      <Typography variant="h6">Welcome, New Student !</Typography>

      <FormProvider {...methods}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <FormControl className={styles.signUpForm} fullWidth>
            <FormInput
              name="userName"
              id="outlined-basic"
              label="Your name"
              variant="outlined"
              size="medium"
              className={styles.textcontainer}
              errorobj={errors}
              setError={setError}
              register={register}
            />

            {/* Google sign up or not  */}
            {userData?.email ? (
              <FormInput
                name="phone"
                id="outlined-basic"
                variant="outlined"
                label="Phone number"
                size="medium"
                className={styles.textcontainer}
                errorobj={errors}
                setError={setError}
                register={register}
              />
            ) : (
              <FormInput
                name="email"
                id="outlined-basic"
                variant="outlined"
                label="Email (Mandatory)"
                size="medium"
                className={styles.textcontainer}
                errorobj={errors}
                setError={setError}
                register={register}
              />
            )}

            <CustomDefaultButton
              loading={pending}
              className={styles.button}
              type="submit"
            >
              Sign Up
            </CustomDefaultButton>

            <div className={styles.rowTwo}>
              <Checkbox
                name="waOptIn"
                checked={checked}
                onChange={handleChange}
                inputProps={{ 'aria-label': 'controlled' }}
              />
              <Typography variant="body2">
                Keep me updated about important communication over WhatsApp
              </Typography>
            </div>
          </FormControl>
        </form>
      </FormProvider>

      <BitMuiAlertDialog>
        <div className={styles.signupRewardContainer}>
          <NextImage
            src={assetObject.signupRewardLogo}
            width="120"
            height="108"
          />
          <h1>{signup_reward?.heading_1}</h1>
          <h6
            dangerouslySetInnerHTML={{ __html: signup_reward?.sub_heading_1 }}
          />

          <h3 dangerouslySetInnerHTML={{ __html: signup_reward?.heading_2 }} />

          <h5>{signup_reward?.sub_heading_2}</h5>

          <a href={signup_reward?.navigation_url}>{signup_reward?.btn_cta}</a>
        </div>
      </BitMuiAlertDialog>
    </div>
  );
};

export default SignUpLayout;
