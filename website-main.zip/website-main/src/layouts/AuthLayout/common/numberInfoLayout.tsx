import { Button, Typography } from '@material-ui/core';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    lightColor: {
      color: theme.palette.primary.main,
      fontWeight: theme.typography.body1.fontWeight,
    },
    flexContainer: {
      display: 'flex',
      alignItems: 'center',
    },
    changeButton: {
      marginLeft: theme.spacing(2),
      textTransform: 'capitalize',
    },
    otpHeader: {
      marginTop: theme.spacing(3),
    },
    signInButton: {
      marginTop: theme.spacing(2),
      width: '100%',
      fontSize: '18px',
      fontWeight: 600,
      height: '64px',
      boxShadow: '0px 1px 20px rgba(0, 0, 0, 0.15)',
      textTransform: 'capitalize',
      '&:active': {
        boxShadow: '0px 1px 20px rgba(0, 0, 0, 0.15)',
      },
      '&:hover': {
        boxShadow: '0px 1px 20px rgba(0, 0, 0, 0.15)',
      },
    },
  }),
);

const NumberInfoLayout = () => {
  const classes = useStyles();
  return (
    <div className={classes.flexContainer}>
      <Typography variant="body1">+91-8277740694</Typography>
      <Button
        className={classes.changeButton}
        color="secondary"
        variant="outlined"
      >
        Change Number
      </Button>
    </div>
  );
};

export default NumberInfoLayout;
