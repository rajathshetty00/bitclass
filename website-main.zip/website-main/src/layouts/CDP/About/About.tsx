/* eslint-disable react/no-danger */
import SeeMore from 'src/components/common/SeeMore/SeeMore';
import clsx from 'clsx';
import SectionHeading from 'src/layouts/CDP/SectionHeading/SectionHeading';
import { AppState, useAppSelector } from 'redux/store';
import { ABTestingObject } from 'utils/constants/cdp';
import styles from './styles.module.scss';

const OVERLAY_COLOR = 'rgb(255,255,255,1)';

const AboutSection = ({ course, isMobile, customClass = '' }: any) => {
  const {
    expId,
    course: { tmpr_code },
  } = useAppSelector((state: AppState) => state.cdp);

  return (
    <>
      <article className={clsx(styles.aboutSectionWrapper, customClass)}>
        <SectionHeading>
          About this <span>Course</span>
        </SectionHeading>

        {expId !== 'b' ? (
          <div className={styles.seeMoreContainer}>
            <SeeMore
              size={isMobile ? 10 : 20}
              overlayColor={OVERLAY_COLOR}
              bgColor="transparent"
              customClass={styles.seeMoreWrapper}
            >
              <span
                dangerouslySetInnerHTML={{
                  __html: course?.goal,
                }}
              />
            </SeeMore>
          </div>
        ) : (
          // <div className={styles.seeMoreContainer}>
          <SeeMore
            // eslint-disable-next-line no-nested-ternary
            size={50}
            overlayColor="none"
            bgColor="transparent"
            customClass={styles.seeMoreWrapper}
            showSeeMore={false}
          >
            <span
              dangerouslySetInnerHTML={{
                __html: ABTestingObject[tmpr_code].about,
              }}
            />
          </SeeMore>
          // </div>
        )}
      </article>
    </>
  );
};

export default AboutSection;
