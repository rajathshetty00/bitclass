import BitCard from 'src/components/common/BitCard/BitCard';
import { assetObject } from 'utils/assetFileNames';
import NextImage from 'src/components/common/NextImage/NextImage';
import { exists } from 'utils/index';
import styles from './styles.module.scss';
import LevelBeginner from '../../../../public/static/common/level-beginner.svg';
import LevelInter from '../../../../public/static/common/level-intermediate.svg';
import LevelAdvanced from '../../../../public/static/common/level-advanced.svg';

export const getCourseLevel = (data: string) => {
  let courseLevel;
  // eslint-disable-next-line prefer-const
  courseLevel = data || 'additional_info.course_learning_level';
  if (exists(courseLevel)) {
    return courseLevel.split(',');
  }
  return [];
};

export const renderLevelImg = (courseLearning: string[]) => {
  if (courseLearning.length === 1) {
    return <LevelBeginner className={`${styles.towerImg} ${styles.level} `} />;
  }
  if (courseLearning.length === 2) {
    return <LevelInter className={`${styles.towerImg} ${styles.level} `} />;
  }
  return <LevelAdvanced className={`${styles.towerImg} ${styles.level} `} />;
};

const AdditionalInfo = ({ additionalInfo }: any) => {
  return (
    <div className={styles.AdditionalInfo}>
      <BitCard>
        <div className={styles.infoSection}>
          <h1>
            Additional <span className={styles.info}>Info</span>
          </h1>
          <div className={styles.infoWrapper}>
            <div className={styles.infoItem}>
              <NextImage
                src={assetObject.liveTeaching}
                className={styles.img}
                width={44}
                height={36}
              />
              <p className={styles.infoTitle}>
                {additionalInfo.live_class_hours} hours LIVE teaching
              </p>
            </div>
            {additionalInfo.is_emi_available && (
              <div className={styles.infoItem}>
                <NextImage
                  src={assetObject.payWithEmi}
                  className={styles.img}
                  width={36}
                  height={32}
                />
                <p className={styles.infoTitle}>Pay through EMI now</p>
              </div>
            )}
            {additionalInfo.certificate_available && (
              <div className={styles.infoItem}>
                <NextImage
                  src={assetObject.certificate}
                  className={styles.img}
                  width={36}
                  height={28}
                />
                <p className={styles.infoTitle}>Certificate of completion</p>
              </div>
            )}
            <div className={styles.infoItem}>
              {renderLevelImg(
                getCourseLevel(additionalInfo.course_learning_level),
              )}

              <p className={styles.title}>
                {getCourseLevel(additionalInfo.course_learning_level).map(
                  (item, ind) => {
                    return `${ind === 0 ? 'For' : ','} ${item} ${
                      ind > 0 ? 'Level' : ''
                    } `;
                  },
                )}
              </p>
            </div>
          </div>
        </div>
      </BitCard>
    </div>
  );
};

export default AdditionalInfo;
