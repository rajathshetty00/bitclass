import { FC, useRef, useState } from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import PlayCircleIcon from '@mui/icons-material/PlayCircle';
import VideoPlayer from 'src/components/common/VideoPlayer/VideoPlayer';
import { AppState, useAppSelector } from 'redux/store';
import { ABTestingObject } from 'utils/constants/cdp';
import styles from './styles.module.scss';

interface IProps {
  heading: string;
  introVideoThumbnail: string;
  introVideo: null | string;
}

const Banner: FC<IProps> = ({ heading, introVideoThumbnail, introVideo }) => {
  const [isVideoOpen, setIsVideoOpen] = useState<boolean>(false);
  const vidRef = useRef<any>(null);
  const handleisVideoOpen = () => {
    setIsVideoOpen(true);
  };

  const {
    expId,
    course: { tmpr_code },
  } = useAppSelector((state: AppState) => state.cdp);

  return (
    <div className={styles.banner}>
      <h1>{heading}</h1>
      {!isVideoOpen && (
        <div className={styles.image_container}>
          <NextImage
            src={
              expId === 'b'
                ? ABTestingObject[tmpr_code].thumbnail
                : introVideoThumbnail
            }
            width={700}
            height={380}
            className={styles.bannerImage}
          />
          {introVideo && expId !== 'b' && (
            <PlayCircleIcon
              className={styles.video_icon}
              onClick={handleisVideoOpen}
            />
          )}
        </div>
      )}
      {isVideoOpen && introVideo && (
        <VideoPlayer videoRef={vidRef} url={introVideo} />
      )}
    </div>
  );
};

export default Banner;
