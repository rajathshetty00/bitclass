import InviteSection from 'src/layouts/CDP/Invite/Invite';
import AdditionalInfo from 'src/layouts/CDP/AdditionalInfo/AdditionalInfo';
import clsx from 'clsx';
import { useSelector } from 'react-redux';
import { AppState, useAppDispatch } from 'redux/store';
import Banner from 'src/layouts/CDP/Banner/Banner';
import getCourseDetails from 'utils/cdp/courseData';
import AboutSection from 'src/layouts/CDP/About/About';
import TeacherSection from 'src/layouts/CDP/TeacherSection/TeacherSection';
import Highlights from 'src/layouts/CDP//Highlights/Highlights';
import Testimonials from 'src/layouts/CDP/Testimonials/Testimonials';
import Faq from 'src/layouts/CDP/Faq/Faqs';
import BottomSticky from 'src/layouts/CDP/components/BottomSticky/BottomSticky';
import CheckoutModal from 'src/components/CDP/CheckoutModal/CheckoutModal';
import RegistrationModal from 'src/layouts/CDP/components/RegistrationModal/RegistrationModal';
import Spacer from 'src/components/common/Spacer/Spacer';
import useSWR from 'swr';
import { axiosGet } from 'utils/api/request';
import { useEffect } from 'react';
import { handleRecommendedSectionExist } from 'redux/reducers/cdpReducer';
import { setPlainModalState } from 'redux/reducers/appReducer';
import { useRouter } from 'next/router';
import NotifyMeModel from 'src/layouts/CDP/RightStickySection/Components/NotifyMeModel/NotifyMeModel';
import styles from './styles.module.scss';
import RightStickySection from '../RightStickySection/RightStickySection';
import Recommendation from '../Recommendation/Recommendation';

export const getFree = (
  category = '',
  teacherId = '',
  type = 'free',
  pageNum = 1,
) => {
  let url = `v2/discovery/search?course_type=${type}&pageNum=${pageNum}&limit=10`;
  if (category)
    url += `&categories=${encodeURIComponent(
      category === 'All' ? '' : category,
    )}`;

  if (teacherId) url += `&teacher_profile_id=${teacherId}`;

  return axiosGet(url);
};

const CDPLayout = ({ isMobile }: any) => {
  const { course, isRegisteredForCourse, expId } = useSelector(
    (state: AppState) => state.cdp,
  );

  const {
    banner,
    teacherDetails,
    highlights,
    testimonials,
    faqs,
    additionalInfo,
    heading,
    code,
    courseUrl,
  } = getCourseDetails(course);

  const { data } = useSWR('getFreeRecommendations', () =>
    getFree(course?.categories[0], course?.teacher?.code),
  );
  const { data: fcd } = useSWR('getFullCoursesRecommendations', () =>
    getFree(course?.categories[0], course?.teacher?.code, 'full_course'),
  );
  const courses = data?.data ?? [];
  const fullCourses = fcd?.data ?? [];
  // const isFullCourse = type === 'full_course';

  const dispatch = useAppDispatch();

  useEffect(() => {
    if (courses?.length || fullCourses?.length > 0) {
      dispatch(handleRecommendedSectionExist(true));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courses, fullCourses]);

  const router = useRouter();

  useEffect(() => {
    if (router.asPath.includes('#checkout') && !isRegisteredForCourse)
      dispatch(setPlainModalState(true));
    else dispatch(setPlainModalState(false));
  }, [dispatch, isRegisteredForCourse, router.asPath]);

  return (
    <>
      <div className={styles.layout}>
        <aside className={styles.cdpContent}>
          <Banner {...banner} />
          <div className={clsx(styles.stickyDetails, 'mobile')}>
            <RightStickySection />
          </div>

          {course?.goal && <AboutSection course={course} isMobile={isMobile} />}
          <Spacer size={32} axis="vertical" />

          {expId !== 'b' && (
            <>
              <InviteSection
                courseURL={courseUrl}
                courseHeading={heading}
                courseCode={code}
              />
              <Spacer size={16} axis="vertical" />
              {highlights && <Highlights highlights={highlights} />}
              <Spacer size={40} axis="vertical" />
              {additionalInfo && (
                <AdditionalInfo additionalInfo={additionalInfo} />
              )}
            </>
          )}

          <hr className={styles.horizontalLine} />
          {teacherDetails && (
            <TeacherSection
              isMobile={isMobile}
              teacherDetails={teacherDetails}
            />
          )}
          <Spacer size={16} axis="vertical" />
          {faqs && <Faq faqs={faqs} />}
          <Spacer size={16} axis="vertical" />
          {testimonials?.length > 0 && (
            <Testimonials testimonials={testimonials} />
          )}
        </aside>
        <div className={clsx(styles.stickyDetails, 'desktop')}>
          <RightStickySection />
        </div>
      </div>
      <div id="free-classes" className={clsx(styles.recommendation)}>
        <div className={styles.freeCourses}>
          {courses.length > 0 && <h2>More Free Classes</h2>}
          <Recommendation
            sectionHeading="more_free_classes"
            courses={courses}
          />
        </div>
        <div className={styles.fullCourses}>
          {fullCourses.length > 0 && <h2>More Courses</h2>}
          <Recommendation
            sectionHeading="more_full_classes"
            courses={fullCourses}
          />
        </div>
      </div>
      {isMobile && <BottomSticky />}
      <CheckoutModal />
      <RegistrationModal />
      <NotifyMeModel />
    </>
  );
};

export default CDPLayout;
