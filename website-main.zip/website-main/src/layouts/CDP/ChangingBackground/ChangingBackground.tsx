import styles from './styles.module.scss';

// const GRADIENT_BACKGROUNDS = [
//   'linear-gradient(90deg, #00274C 0%, #091A36 100%)',
//   'linear-gradient(90.88deg, #070D1D 0.09%, #182138 100%)',
//   'linear-gradient(90deg, #1488CC 0%, #2B32B2 100%)',
//   'linear-gradient(90deg, #CC2B5E 0%, #753A88 100%)',
//   'linear-gradient(90deg, #AA076B 0%, #61045F 100%)',
//   'linear-gradient(90deg, #41295A 0%, #2F0743 100%)',
// ];
const ChangingBackground = () => (
  <div
    style={{
      background: 'linear-gradient(90deg, #00274C 0%, #091A36 100%)',
      // GRADIENT_BACKGROUNDS[Math.round(5 * Math.random())]
    }}
    className={styles.bgContainer}
  />
);

export default ChangingBackground;
