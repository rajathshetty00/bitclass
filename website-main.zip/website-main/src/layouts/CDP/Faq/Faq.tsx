import { IFaq } from 'interfaces/cdp/faqs';
import { FC } from 'react';

interface IProps {
  faq: IFaq;
}
const Faq: FC<IProps> = ({ faq }) => {
  const { que, ans } = faq;
  return (
    <div>
      {que}
      {ans}
    </div>
  );
};

export default Faq;
