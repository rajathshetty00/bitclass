import {
  Accordion,
  AccordionSummary,
  Typography,
  AccordionDetails,
} from '@mui/material';
import SectionHeading from 'src/layouts/CDP/SectionHeading/SectionHeading';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';

import CurriculumTitle from 'src/layouts/CurriculumCdp/CurriculumTitle/CurriculumTitle';
import { SyntheticEvent } from 'hoist-non-react-statics/node_modules/@types/react';
import clsx from 'clsx';
import { IFaq } from 'interfaces/cdp/faqs';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import styles from './styles.module.scss';

type faqProps = {
  faqs: IFaq[];
  isDefaultIcon?: boolean;
  faqTitle?: string;
  faqSubTitle?: string;
  handleExpandFaq?: any;
};
const Faqs = ({
  faqs,
  isDefaultIcon = true,
  faqTitle,
  faqSubTitle,
  handleExpandFaq,
}: faqProps) => {
  const [expanded, setExpanded] = useState<number | false | null>(null);

  const handleChange =
    ({ ind, ans, que }: any) =>
    (event: SyntheticEvent, newExpanded: boolean) => {
      saveGtmDataLayerData({
        event: EVENT_NAMES.CDP_FAQ_CLICK,
        faqData: {
          faq_question: que,
          faq_ans: ans,
        },
      });

      setExpanded(newExpanded ? ind : false);
      if (!isDefaultIcon) {
        handleExpandFaq(ind);
      }
    };
  const expandIcon = (ind: number) => {
    switch (isDefaultIcon) {
      case true:
        return <ExpandMoreIcon />;
      case false:
        if (expanded === ind)
          return <RemoveIcon className={styles.minusIcon} />;
        return <AddIcon className={styles.plusIcon} />;
      default:
        return <ExpandMoreIcon />;
    }
  };
  return (
    <div className={styles.highlights}>
      {!faqTitle && (
        <SectionHeading>
          Frequently Asked
          <span>&nbsp;Question</span>
        </SectionHeading>
      )}
      {faqTitle && (
        <CurriculumTitle className={styles.faqHeading}>
          {faqTitle}
        </CurriculumTitle>
      )}
      {faqSubTitle && <p className={styles.faqSubTitle}>{faqSubTitle}</p>}
      {faqs.map(({ ans, que }: any, ind: number) => {
        return (
          <div className={styles.accordionWrapper} key={que}>
            <Accordion
              className={clsx(styles.accordionSection, {
                [styles.faqPanel]: !isDefaultIcon,
              })}
              expanded={expanded === ind}
              onChange={handleChange({ ind, ans, que })}
            >
              <AccordionSummary
                expandIcon={expandIcon(ind)}
                aria-controls={`panel1a-${ind}`}
                id={`panel1a-${ind}`}
                className={clsx(styles.expandIcon, {
                  [styles.expanded]: expanded,
                })}
              >
                <Typography
                  className={styles.question}
                  variant="subtitle1"
                  gutterBottom
                >
                  {que}
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <div
                  className={styles.accordion_description}
                  dangerouslySetInnerHTML={{
                    __html: ans,
                  }}
                />
              </AccordionDetails>
            </Accordion>
          </div>
        );
      })}
    </div>
  );
};
Faqs.defaultProps = {
  isDefaultIcon: true,
  faqTitle: '',
  faqSubTitle: '',
  handleExpandFaq: () => {},
};

export default Faqs;
