import styles from './styles.module.scss';

const GRADIENT_BACKGROUNDS = [
  'linear-gradient(225.92deg, #33D2FF 5.73%, #3D68DE 54.65%, #9845E8 96.75%)',
  'linear-gradient(135deg, #B65FC4 2.88%, #DB6E4E 100%)',
  'linear-gradient(224.86deg, #73CCD8 4.87%, #2B6B9F 96.04%)',
  'linear-gradient(135deg, #6964DE 2.88%, #FCA6E9 100%)',
  'linear-gradient(315deg, #21BDB8 0%, #280684 100%)',
];
const Highlight = ({ highlight, index }: any) => (
  <div
    className={styles.highlight}
    style={{ background: GRADIENT_BACKGROUNDS[index % 5] }}
  >
    <p className={styles.number}>0{index + 1}</p>
    <p className={styles.details}>{highlight}</p>
  </div>
);

export default Highlight;
