import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import BitPureCarousel from 'src/components/common/BitCarousel/BitCarousel';
import Highlight from 'src/layouts/CDP/Highlights/Highlight';
import SectionHeading from 'src/layouts/CDP/SectionHeading/SectionHeading';
import styles from './styles.module.scss';

const Highlights = ({ highlights }: any) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const carouselSettings = {
    slidesToShow: isMobile ? 1 : 2,
    autoplay: false,
    dots: !isMobile,
  };

  return (
    <div className={styles.highlights}>
      <SectionHeading>
        Course <span>Highlights</span>
      </SectionHeading>
      <BitPureCarousel carouselSettings={carouselSettings}>
        {highlights &&
          highlights.map((highlight: string, index: number) => (
            <Highlight key={highlight} highlight={highlight} index={index} />
          ))}
      </BitPureCarousel>
    </div>
  );
};

export default Highlights;
