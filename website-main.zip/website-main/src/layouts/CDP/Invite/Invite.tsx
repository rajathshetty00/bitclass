import { Button, Popover } from '@mui/material';
import BitCard from 'src/components/common/BitCard/BitCard';
import ShareIcon from '@mui/icons-material/Share';
import { useState } from 'react';
import SocialShareLink from 'src/components/common/SocialShareLink/SocialShareLink';
import { MouseEvent } from 'hoist-non-react-statics/node_modules/@types/react';
import styles from './styles.module.scss';

const InviteSection = ({ courseURL, courseHeading, courseCode }: any) => {
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  return (
    <div className={styles.invite_wrapper}>
      <BitCard>
        <div className={styles.invite_section}>
          Learn together with your friends
          <Button
            variant="outlined"
            startIcon={<ShareIcon />}
            sx={{ textTransform: 'none' }}
            onClick={handleClick}
          >
            Invite
          </Button>
          <Popover
            id={id}
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
          >
            <SocialShareLink
              linkUrl={courseURL}
              linkText={`Check out this course on BitClass - ${courseHeading}`}
              page="cdp-demo"
              contentID={courseCode}
              contentType="course"
            />
          </Popover>
        </div>
      </BitCard>
    </div>
  );
};

export default InviteSection;
