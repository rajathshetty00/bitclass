import CourseCard from 'src/components/CDP/CourseCard/CourseCard/CourseCard';
import BitCourseCarousel from 'src/components/common/BitCourseCarousel/BItCourseCarousel';
import styles from './styles.module.scss';

const Recommendation = ({ courses, sectionHeading }: any) => {
  return (
    <div className={styles.courses}>
      <BitCourseCarousel itemCount={courses.length}>
        <div className={styles.coursesList}>
          {courses?.map((courseDetails: any) => (
            <CourseCard
              sectionHeading={sectionHeading}
              courseDetails={courseDetails}
            />
          ))}
        </div>
      </BitCourseCarousel>
    </div>
  );
};

export default Recommendation;
