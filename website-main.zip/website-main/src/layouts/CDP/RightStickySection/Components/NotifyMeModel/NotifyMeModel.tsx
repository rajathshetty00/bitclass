import { Modal } from '@mui/material';
import { useRouter } from 'next/router';
import EarlyScreen from 'public/static/common/early-screen.svg';
import { XCircle } from 'react-feather';
import { useSelector } from 'react-redux';
import { showNotifyModal } from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch } from 'redux/store';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import { getHrefLink } from 'utils';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

const NotifyMeModel = () => {
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const {
    course: { teacher },
    isNotifyModal,
  } = useSelector((state: AppState) => state.cdp);

  const dispatch = useAppDispatch();

  const { teacher_name, profile_handle } = teacher;

  const gotoTeacherCourse = () => {
    window.location.href = getHrefLink(
      `${BASE_URL}/new/teacher/${profile_handle}?channel=cdp&platform=${
        isMobile ? 'mweb' : 'web'
      }`,
      router,
    );
  };

  const handleClose = () => {
    dispatch(showNotifyModal(false));
  };

  return (
    <div>
      <Modal
        open={isNotifyModal}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <div className={styles.bodyStyle}>
          <EarlyScreen className={styles.modalImage} />
          <div className={styles.title}>
            You will be notified when this course starts
          </div>
          {profile_handle && (
            <div className={styles.description}>
              Meanwhile, checkout these <br />
              other courses by <strong>{teacher_name}</strong>
            </div>
          )}
          <XCircle className={styles.closeIcon} onClick={handleClose} />
          <CustomDefaultButton
            variant="contained"
            className={styles.exploreBtn}
            onClick={gotoTeacherCourse}
          >
            Explore more courses
          </CustomDefaultButton>
        </div>
      </Modal>
    </div>
  );
};

export default NotifyMeModel;
