import { FormControlLabel, Radio, RadioGroup } from '@mui/material';
import { IPlan } from 'interfaces/cdp/plan';
import { useSelector } from 'react-redux';
import { selectSubscription } from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch } from 'redux/store';
import { getCurrencySymbol } from 'utils/currency';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';

interface IRadioGroup {
  subscriptionPlans: IPlan[];
  courseType: string;
}

const RadioGroupComponent = ({
  subscriptionPlans,
  courseType,
}: IRadioGroup) => {
  const dispatch = useAppDispatch();
  const getDuration = (duration: any) => {
    const month = Math.floor(duration / 30);
    const remainingDays = duration % 30;

    const calculatedMonth =
      month >= 1 ? `${month} ${month >= 2 ? 'months' : 'month'}` : '';

    const calculatedDays =
      remainingDays >= 1
        ? `${remainingDays} ${remainingDays >= 2 ? 'days' : 'day'}`
        : `${duration > 1 ? `${duration} days` : `${duration} day`}`;
    return `${calculatedMonth} ${remainingDays ? calculatedDays : ''} `;
  };

  const handleChange = (e: any, item: any) => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.SUBSCRIPTION_PLAN_SELECTED,
      selectedPlan: item,
    });

    dispatch(selectSubscription(item));
  };

  const renderPlanLabel = (
    type: string,
    currency: string,
    sellingPrice: number,
    duration: number,
    classes: number,
  ) => {
    switch (courseType) {
      case 'freemium':
        if (type === 'free') {
          return `First ${
            classes > 1 ? `${classes} classes` : `${classes} class`
          }  for FREE`;
        }
        return `${getCurrencySymbol(
          currency,
        )} ${sellingPrice} for the full course`;
      case 'subscription':
        return `${
          type === 'free'
            ? 'FREE'
            : `${getCurrencySymbol(currency)}${sellingPrice}`
        } for ${getDuration(duration)}`;
      default:
        return null;
    }
  };

  return (
    <RadioGroup
      aria-label="gender"
      defaultValue={subscriptionPlans?.[0]?.id}
      name="radio-buttons-group"
      className={styles.plans}
    >
      {subscriptionPlans?.map((item: IPlan) => {
        const {
          currency,
          id,
          selling_price: sellingPrice,
          type,
          duration,
          classes,
        } = item;

        return (
          <FormControlLabel
            // @ts-ignore
            key={id}
            className={styles.plan}
            value={id}
            control={<Radio />}
            onChange={(e) => {
              handleChange(e, item);
            }}
            label={renderPlanLabel(
              type,
              currency,
              sellingPrice,
              duration,
              classes,
            )}
          />
        );
      })}
    </RadioGroup>
  );
};
const RenderPlans = () => {
  const {
    subscriptionPlans,
    isSubscriptionExists,
    course: { type: courseType },
  } = useSelector((state: AppState) => state.cdp);
  return (
    <>
      {(() => {
        switch (courseType) {
          case 'freemium':
            if (isSubscriptionExists?.type === 'paid') {
              return null;
            }
            return (
              <RadioGroupComponent
                subscriptionPlans={subscriptionPlans}
                courseType={courseType}
              />
            );
          case 'subscription':
            return (
              <RadioGroupComponent
                subscriptionPlans={subscriptionPlans}
                courseType={courseType}
              />
            );
          default:
            return null;
        }
      })()}
    </>
  );
};

export default RenderPlans;
