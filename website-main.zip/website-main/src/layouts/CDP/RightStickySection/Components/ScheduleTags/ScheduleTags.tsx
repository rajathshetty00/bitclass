/* eslint-disable no-underscore-dangle */
import { useState, useEffect } from 'react';
import clsx from 'clsx';
import { getCourseScheduleDetails } from 'utils/dateFns';
import styles from './styles.module.scss';

const ScheduleTags = ({
  weeklySchedule,
  duration = 60,
  noTimeClass = '',
  mainContainerClass = '',
  showEveryDay = false,
  onlyStartTime = false,
}: any) => {
  const [days, setDays] = useState<any[]>([]);

  useEffect(() => {
    const _days = getCourseScheduleDetails(
      weeklySchedule,
      duration,
      onlyStartTime,
    );
    setDays(_days);
  }, []);

  return !weeklySchedule || days.length <= 0 ? (
    <span className={noTimeClass}>Time Not Added Yet</span>
  ) : (
    <div className={clsx(styles.scheduleContainer, mainContainerClass)}>
      {!showEveryDay &&
        days.map((dateVal, dateIndex) => (
          <span key={dateIndex.toString()} className={styles.schedule}>
            <span className={styles.scheduleLabel}>{dateVal.label}</span>
            <span className={styles.scheduleData}>{dateVal.data}</span>
          </span>
        ))}
      {showEveryDay && (
        <span className={styles.schedule}>
          <span className={styles.scheduleLabel}>Everyday:</span>
          <span className={styles.scheduleData}>{days[0].data}</span>
        </span>
      )}
    </div>
  );
};

export default ScheduleTags;
