import React from 'react';
import { getDateFormat } from 'utils';
import styles from './styles.module.scss';

const SubStartDate = ({ sDate }: any) => {
  return (
    <div className={styles.dateContainer}>
      <h5 className={styles.plansTitle}>STARTS FROM</h5>
      <span className={styles.dateLabel}>
        {getDateFormat(sDate, 'MMM DD, YYYY')}
      </span>{' '}
    </div>
  );
};

export default SubStartDate;
