import React, { FC } from 'react';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import LocalOfferOutlinedIcon from '@mui/icons-material/LocalOfferOutlined';
import { AppState, useAppSelector } from 'redux/store';
import { determineCourseDate, determineCoursePrice } from 'utils';
import ScheduleTags from 'src/layouts/CDP/RightStickySection/Components/ScheduleTags/ScheduleTags';
import styles from './styles.module.scss';
import CourseCTA from '../../components/CourseCTA/CourseCTA';

interface CourseSectionProps {}

const CourseSection: FC<CourseSectionProps> = () => {
  const {
    course: {
      weekly_schedule: weeklySchedule,
      duration: weeklyDuration,
      start_ts: StartDate,
      end_ts: EndDate,
      currency,
      amount,
    },
  } = useAppSelector((state: AppState) => state.cdp);

  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  return (
    <div className={styles.courseSectionContainer}>
      <div className={styles.durationAndPriceContainer}>
        <div className={styles.firstBlock}>
          <p>
            {' '}
            <AccessTimeOutlinedIcon />
            DURATION
          </p>
          <h6>{determineCourseDate({ StartDate, EndDate })}</h6>
        </div>
        <div>
          <p>
            {' '}
            <LocalOfferOutlinedIcon /> PRICE
          </p>
          <h6 className={styles.price}>
            {determineCoursePrice({ currency, amount })}
          </h6>
        </div>
      </div>

      <div className={styles.timingsContainer}>
        <p>TIMINGS</p>
        <ScheduleTags
          mainContainerClass={styles.scheduleContainer}
          weeklySchedule={weeklySchedule}
          duration={weeklyDuration}
        />
      </div>

      {!isMobile && <CourseCTA />}
    </div>
  );
};

export default CourseSection;
