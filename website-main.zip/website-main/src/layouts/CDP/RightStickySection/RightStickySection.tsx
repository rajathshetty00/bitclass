import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import React, { useEffect } from 'react';
import BitSkeletonLoader from 'src/components/common/BitSkeletonLoader/BitSkeletonLoader';
import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import styles from './styles.module.scss';
import Subscription from './Subscription/Subscription';
import CourseSection from './CourseSection/CourseSection';
import TmprSection from './TmprSection/TmprSection';

interface IRightStickyProps {
  [key: string]: React.ReactNode;
}

const RightStickySection = () => {
  const { rightSectionStatus } = useSelector((state: AppState) => state.cdp);

  const { fetchDataOnPageType } = useRightSectionRenderer();

  useEffect(() => {
    fetchDataOnPageType();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const rightStickyComponents: IRightStickyProps = {
    LOADING: <BitSkeletonLoader />,
    SUBSCRIPTION: <Subscription />,
    FULLCOURSE: <CourseSection />,
    TMPR: <TmprSection />,
  };

  return (
    <div className={styles.rightStickySection}>
      {rightStickyComponents[rightSectionStatus]}
    </div>
  );
};

export default RightStickySection;
