import PlayCircleFilledIcon from '@mui/icons-material/PlayCircleFilled';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import PodcastsIcon from '@mui/icons-material/Podcasts';
import LanguageIcon from '@mui/icons-material/Language';
import { AppState, useAppSelector } from 'redux/store';
import { FC } from 'react';
import clsx from 'clsx';
import ForumIcon from '@mui/icons-material/Forum';
import styles from './styles.module.scss';

interface IProps {
  customClass?: null | string;
}

const Features: FC<IProps> = ({ customClass }) => {
  const { subscriptionSelected, course, expId } = useAppSelector(
    (state: AppState) => state.cdp,
  );

  const totalNoOfClass = subscriptionSelected?.classes ?? course?.num_classes;
  return (
    <div className={clsx(styles.featuresSection, customClass)}>
      <h5>WHAT’S INCLUDED ?</h5>

      {expId === 'b' ? (
        <div className={styles.features}>
          <div className={styles.feature}>
            <PodcastsIcon />
            <span>{totalNoOfClass} LIVE Interactive Class</span>
          </div>
          <div className={styles.feature}>
            <AccountCircleIcon />
            <span>Doubt Clearing</span>
          </div>
          <div className={styles.feature}>
            <PlayCircleFilledIcon />
            <span>Recordings For Practice</span>
          </div>
          <div className={styles.feature}>
            <ForumIcon />
            <span>Group Chat</span>
          </div>
        </div>
      ) : (
        <div className={styles.features}>
          <div className={styles.feature}>
            <PodcastsIcon />
            <span>{totalNoOfClass} LIVE Classes</span>
          </div>
          <div className={styles.feature}>
            <AccountCircleIcon />
            <span>Personal Mentorship</span>
          </div>
          <div className={styles.feature}>
            <PlayCircleFilledIcon />
            <span>Recordings For Practice</span>
          </div>
          <div className={styles.feature}>
            <LanguageIcon />
            <span>Global Community</span>
          </div>
        </div>
      )}
    </div>
  );
};

Features.defaultProps = {
  customClass: '',
};
export default Features;
