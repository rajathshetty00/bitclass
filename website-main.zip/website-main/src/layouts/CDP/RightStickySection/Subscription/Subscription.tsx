/* eslint-disable no-nested-ternary */
/* eslint-disable camelcase */
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';

import Features from 'src/layouts/CDP/RightStickySection/Subscription/Features/Features';
import ScheduleTags from 'src/layouts/CDP/RightStickySection/Components/ScheduleTags/ScheduleTags';
import SubscriptionCTA from 'src/layouts/CDP/components/SubscriptionCTA/SubscriptionCTA';
import { CustomOutlinedButton } from 'src/components/common/BitMuiButton';
import { BASE_URL } from 'utils/constants';
import { RenderSubWarningText } from 'src/layouts/CDP/RightStickySection/Subscription/utils';
import { FC } from 'react';
import FreemiumCTA from 'src/layouts/CDP/components/FreemiumCTA/FreemiumCTA';
import { getDateFormat, getHrefLink } from 'utils';
import { useRouter } from 'next/router';
import styles from './styles.module.scss';
import FreemiumDate from '../Components/FreemiumDate/FreemiumDate';
import RenderPlans from '../Components/RenderPlans/RenderPlans';
import SubStartDate from '../Components/SubStartDate/SubStartDate';

const Subscription: FC = () => {
  const {
    subscriptionPlans,
    isSubscriptionExists,
    course: {
      code,
      weekly_schedule: weeklySchedule,
      duration: weeklyDuration,
      type: courseType,
      start_ts: StartDate,
      end_ts: EndDate,
    },
  } = useSelector((state: AppState) => state.cdp);

  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const router = useRouter();

  const liveClassHandler = () => {
    window.location.href = getHrefLink(
      `${BASE_URL}/live-classes/classroom/${code}?channel=cdp&platform=${
        isMobile ? 'mweb' : 'web'
      }`,
      router,
    );
  };

  return (
    <div className={styles.subscriptionContainer}>
      {isSubscriptionExists && (
        <RenderSubWarningText
          courseType={courseType}
          isSubscriptionExists={isSubscriptionExists}
        />
      )}

      {(() => {
        switch (courseType) {
          case 'freemium':
            if (isSubscriptionExists?.type !== 'paid') {
              return (
                <h5 className={styles.plansTitle}>
                  Please choose from one of the plans to continue
                </h5>
              );
            }
            return null;
          case 'subscription':
            return (
              <h5 className={styles.plansTitle}>
                Please choose from one of the plans to continue
              </h5>
            );
          default:
            return null;
        }
      })()}
      <RenderPlans />
      {courseType === 'freemium' && (
        <FreemiumDate sDate={StartDate} eDate={EndDate} />
      )}
      {courseType === 'subscription' &&
        new Date() < new Date(getDateFormat(StartDate, 'MM DD, YYYY')) && (
          <SubStartDate sDate={StartDate} />
        )}

      <h5>TIMING</h5>
      <ScheduleTags weeklySchedule={weeklySchedule} duration={weeklyDuration} />
      <Features customClass={styles.subsFeatures} />

      {!isMobile && (
        <div style={{ marginTop: '16px' }}>
          {(() => {
            switch (courseType) {
              case 'freemium':
                return <FreemiumCTA />;
              case 'subscription':
                return <SubscriptionCTA />;
              default:
                <p>No CTA found</p>;
            }
          })()}
        </div>
      )}

      {!isSubscriptionExists && (
        <p className={styles.tncText}>
          {courseType === 'freemium' &&
            ` *After the end of the trial period, you can purchase the full course for ${subscriptionPlans?.[1]?.currency}
          ${subscriptionPlans?.[1]?.selling_price}`}
          {courseType === 'subscription' &&
            ` *After the end of the trial period, you can renew your
          subscription starting from ${subscriptionPlans?.[1]?.currency}
          ${subscriptionPlans?.[1]?.selling_price}`}
        </p>
      )}
      {(() => {
        switch (courseType) {
          case 'freemium':
            if (
              isSubscriptionExists &&
              isSubscriptionExists?.type !== 'paid' &&
              isSubscriptionExists?.is_active
            ) {
              return (
                <div className={styles.freemiumRow}>
                  <CustomOutlinedButton onClick={liveClassHandler}>
                    Go to live Class{' '}
                  </CustomOutlinedButton>
                </div>
              );
            }
            return null;
          case 'subscription':
            if (isSubscriptionExists && isSubscriptionExists?.is_active) {
              return (
                <div className={styles.row}>
                  <CustomOutlinedButton onClick={liveClassHandler}>
                    Go to live Class{' '}
                  </CustomOutlinedButton>
                </div>
              );
            }
            return null;
          default:
            return null;
        }
      })()}
    </div>
  );
};

export default Subscription;
