import { getDateFormat } from 'utils';
import styles from 'src/layouts/CDP/RightStickySection/Subscription/styles.module.scss';
import { AlertTriangle, Slash } from 'react-feather';
import clsx from 'clsx';

// eslint-disable-next-line import/prefer-default-export
export const RenderSubWarningText = ({
  isSubscriptionExists: { is_active: isActive, expiring_on: expiringOn, type },
  courseType,
}: any) => {
  return (() => {
    switch (type) {
      case 'free':
        return isActive ? (
          <h4 className={clsx(styles.yellow, styles.common)}>
            Your TRIAL PERIOD is expiring on{' '}
            {getDateFormat(expiringOn, 'MMM DD, YYYY')} <AlertTriangle />
          </h4>
        ) : (
          <h4 className={clsx(styles.red, styles.common)}>
            Your TRIAL PERIOD has ended <Slash />
          </h4>
        );
      case 'paid':
        if (courseType === 'freemium') {
          return null;
        }
        return isActive ? (
          <h4 className={clsx(styles.yellow, styles.common)}>
            Your plan period is expiring on{' '}
            {getDateFormat(expiringOn, 'MMM DD, YYYY')}
            <AlertTriangle />
          </h4>
        ) : (
          <h4 className={clsx(styles.red, styles.common)}>
            Your plan period has ended <Slash />
          </h4>
        );
      default:
        return <p>nothing</p>;
    }
  })();
};
