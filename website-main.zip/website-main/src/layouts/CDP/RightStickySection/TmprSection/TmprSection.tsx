import React, { FunctionComponent } from 'react';
import { determineCoursePrice, exists } from 'utils';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import LocalOfferOutlinedIcon from '@mui/icons-material/LocalOfferOutlined';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import dayjs from 'dayjs';
import { AppState, useAppSelector } from 'redux/store';
import styles from './styles.module.scss';
import ScheduleTags from '../Components/ScheduleTags/ScheduleTags';
import TmprCTA from '../../components/TmprCTA/TmprCTA';
import Features from '../Subscription/Features/Features';

interface TmprSectionProps {}

const TmprSection: FunctionComponent<TmprSectionProps> = () => {
  const {
    course: { currency, amount, duration, slots },
  } = useAppSelector((state: AppState) => state.cdp);

  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const { expId } = useAppSelector((state: AppState) => state.cdp);

  return (
    <div className={styles.tmprSectionContainer}>
      <div className={styles.durationAndPriceContainer}>
        <div className={styles.firstBlock}>
          <p>
            {' '}
            <AccessTimeOutlinedIcon />
            DURATION
          </p>
          <h6>{duration} min</h6>
        </div>
        <div>
          <p>
            {' '}
            <LocalOfferOutlinedIcon /> PRICE
          </p>
          <h6 className={styles.price}>
            {determineCoursePrice({ currency, amount })}
          </h6>
        </div>
      </div>
      <div className={styles.slotContainer}>
        <p>
          {' '}
          <CalendarTodayIcon />
          AVAILABLE SLOTS
        </p>
        {exists(slots) ? (
          slots?.map((item: any) => (
            <div className={styles.slotTags} key={item?.course_code}>
              {item?.timing && (
                <b>
                  {item.timing.length > 1 ? (
                    <>
                      {dayjs.unix(item.timing[0]).format('DD MMM')}
                      &nbsp;-&nbsp;
                      {dayjs
                        .unix(item.timing[item.timing.length - 1])
                        .format('DD MMM')}
                    </>
                  ) : (
                    <>{dayjs.unix(item.timing[0]).format('DD MMM')}</>
                  )}
                </b>
              )}
              <ScheduleTags
                weeklySchedule={item.timing}
                duration={item.duration}
                hideDay
                mainContainerClass={styles.newScheduleContainer}
              />
            </div>
          ))
        ) : (
          <p className={styles.noSlot}>No Slots Available</p>
        )}
      </div>
      {expId === 'b' && <Features customClass={styles.subsFeatures} />}
      {!isMobile && <TmprCTA />}
    </div>
  );
};

export default TmprSection;
