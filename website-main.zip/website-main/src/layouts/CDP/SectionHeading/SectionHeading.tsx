import clsx from 'clsx';
import { FC, ReactNode } from 'react';
import styles from './styles.module.scss';

interface IProps {
  children: ReactNode | string;
  className?: string;
}
const SectionHeading: FC<IProps> = ({ children, className }) => (
  <div className={clsx(styles.sectionHeading, className)}>{children}</div>
);
SectionHeading.defaultProps = {
  className: '',
};
export default SectionHeading;
