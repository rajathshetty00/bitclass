/* eslint-disable camelcase */
import { FC } from 'react';
import Link from 'next/link';
import clsx from 'clsx';
import SeeMore from 'src/components/common/SeeMore/SeeMore';
import { BASE_URL } from 'utils/constants';
import { ITeacher } from 'interfaces/cdp/teacher';
import NextImage from 'src/components/common/NextImage/NextImage';
import { Button } from '@mui/material';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/router';
import { getHrefLink } from 'utils';
import styles from './styles.module.scss';

const DynamicFollowButton = dynamic(
  () => import('src/components/common/FollowButton/FollowButton'),
  { ssr: false },
);
interface IProps {
  teacherDetails: ITeacher;
  isMobile: boolean;
}
const TeacherSection: FC<IProps> = ({ teacherDetails, isMobile }) => {
  const router = useRouter();
  const { teacher_name, profile_id, story, image } = teacherDetails;
  const moreClassUrl = getHrefLink(
    `${BASE_URL}/new/teacher/${profile_id}?platform=${
      isMobile ? 'mweb' : 'web'
    }`,
    router,
  );

  return (
    <div className={clsx(styles.teacherSection)}>
      <div className={styles.teacherDetails}>
        <NextImage
          src={image}
          width={isMobile ? 144 : 184}
          height={isMobile ? 144 : 168}
          className={styles.profileImage}
          // unoptimized
        />
        <div className={styles.details}>
          <p>Your Teacher</p>
          <h5>{teacher_name}</h5>
          <div className={styles.buttonContainer}>
            {/* <Button className={styles.follow} variant="contained">
              Follow
            </Button> */}

            <Button
              className={styles.follow}
              variant="contained"
              sx={{ textTransform: 'capitalize' }}
            >
              <Link href={moreClassUrl}>More classes</Link>
            </Button>
            <div className={styles.follow}>
              <DynamicFollowButton />
            </div>
          </div>
        </div>
      </div>
      <SeeMore size={50} showSeeMore={false}>
        <span
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: story,
          }}
        />
      </SeeMore>
    </div>
  );
};
export default TeacherSection;
