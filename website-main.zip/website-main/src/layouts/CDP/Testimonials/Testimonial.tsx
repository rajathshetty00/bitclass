import { ITestimonial } from 'interfaces/cdp/testimonial';
import { FC } from 'react';
import BitCard from 'src/components/common/BitCard/BitCard';
import { assetObject } from 'utils/assetFileNames';
import SeeMore from 'src/components/common/SeeMore/SeeMore';

import NextImage from 'src/components/common/NextImage/NextImage';
import styles from './styles.module.scss';

const OVERLAY_COLOR = 'rgb(255,255,255,1)';

interface IProps {
  testimonial: ITestimonial;
}
const Testimonial: FC<IProps> = ({ testimonial }) => {
  return (
    <div className={styles.testimonial}>
      <BitCard>
        <div className={styles.innerWrapper}>
          <div className={styles.titleWrapper}>
            <NextImage
              width={40}
              height={40}
              src={assetObject.profileEmpty}
              className={styles.img}
            />
            <p className={styles.student}>{testimonial.student_name}</p>
          </div>
          <div className={styles.testimonial_desc}>
            <SeeMore
              text={testimonial?.testimonial}
              size={4}
              overlayColor={OVERLAY_COLOR}
              bgColor="transparent"
              customClass={styles.seeMoreWrapper}
            >
              <span
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{
                  __html: testimonial?.testimonial,
                }}
              />
            </SeeMore>
          </div>
        </div>
      </BitCard>
    </div>
  );
};

export default Testimonial;
