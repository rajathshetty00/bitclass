/* eslint-disable camelcase */
import BitPureCarousel from 'src/components/common/BitCarousel/BitCarousel';
import { FC } from 'react';
import SectionHeading from 'src/layouts/CDP/SectionHeading/SectionHeading';
import Testimonial from 'src/layouts/CDP/Testimonials/Testimonial';
import { ITestimonial } from 'interfaces/cdp/testimonial';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import styles from './styles.module.scss';

interface IProps {
  testimonials: ITestimonial[];
}
const Testimonials: FC<IProps> = ({ testimonials }) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const viewNoOfSlider = (sliderTestimonial: ITestimonial[]) => {
    return sliderTestimonial?.length > 1 ? 2 : 1;
  };
  const carouselSettings = {
    slidesToShow: isMobile ? 1 : viewNoOfSlider(testimonials),
    autoplay: false,
    dots: !isMobile,
  };
  return (
    <div className={styles.testimonials}>
      <SectionHeading>Testimonials</SectionHeading>
      <BitPureCarousel carouselSettings={carouselSettings}>
        {testimonials?.map((testimonial: ITestimonial) => (
          <Testimonial
            testimonial={testimonial}
            key={testimonial.student_name}
          />
        ))}
      </BitPureCarousel>
    </div>
  );
};

export default Testimonials;
