import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import React, { FunctionComponent, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { updateRightSectionStatus } from 'redux/reducers/cdpReducer';
import { AppState } from 'redux/store';
import SubscriptionCTA from 'src/layouts/CDP/components/SubscriptionCTA/SubscriptionCTA';
import { CDP_TYPE, RIGHT_SECTION_STATUS } from 'utils/constants/cdp';
import CourseCTA from '../CourseCTA/CourseCTA';
import FreemiumCTA from '../FreemiumCTA/FreemiumCTA';
import TmprCTA from '../TmprCTA/TmprCTA';
import styles from './styles.module.scss';

interface IBottomStickyProps {
  [key: string]: React.ReactNode;
}

const BottomStickyCTA: FunctionComponent = () => {
  const {
    course: { type },
  } = useSelector((state: AppState) => state.cdp);
  const { rightSectionStatus } = useRightSectionRenderer();

  useEffect(() => {
    if (type === CDP_TYPE.advancedCourse) {
      updateRightSectionStatus(RIGHT_SECTION_STATUS.FREEMIUM);
    }
  }, [type]);

  const BottomStickyContent: IBottomStickyProps = {
    SUBSCRIPTION: <SubscriptionCTA />,
    FREEMIUM: <FreemiumCTA />,
    FULLCOURSE: <CourseCTA />,
    TMPR: <TmprCTA />,
  };

  return (
    <div className={styles.fixedContainer}>
      {BottomStickyContent[rightSectionStatus]}
    </div>
  );
};

export default BottomStickyCTA;
