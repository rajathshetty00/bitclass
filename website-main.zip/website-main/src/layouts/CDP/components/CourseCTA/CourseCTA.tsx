import { usePayment } from 'hooks/usePayment';
import React, { FunctionComponent } from 'react';
import { actionCheckRegistrationOfCourse } from 'redux/actions/cdpActions';
import { setModalState, setPlainModalState } from 'redux/reducers/appReducer';
import {
  initialiseSignIn,
  initialSignInPageViewed,
  onPostLogin,
  startLogin,
} from 'redux/reducers/authReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  CustomDefaultButton,
  CustomOutlinedButton,
} from 'src/components/common/BitMuiButton';
import { hasAuthToken } from 'utils/auth/userInfo';
import { BASE_URL } from 'utils/constants';
import clsx from 'clsx';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { extractCdpData } from 'utils/courseAnalytics';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { useRouter } from 'next/router';
import { getHrefLink } from 'utils';
import { useSelector } from 'react-redux';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { saveNotifyUser } from 'utils/api';
import { showNotifyModal } from 'redux/reducers/cdpReducer';
import { renderCourseCTAText } from '../../utils';
import styles from './styles.module.scss';

interface CourseCTAProps {
  openCheckoutModal?: boolean;
}

const CourseCTA: FunctionComponent<CourseCTAProps> = ({
  openCheckoutModal = false,
}) => {
  const {
    course,
    isRegisteredForCourse,
    // couponData,
    finalCourseDetailsBeforePayment,
    pending,
  } = useAppSelector((state: AppState) => state.cdp);

  const dispatch = useAppDispatch();
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const processPayment = usePayment();

  const { code, currency, amount, has_ended } = course;

  // this function will invoke on primary cta click in full course, free classes and workshops.
  const onLoginSuccess = async () => {
    const {
      payload: { data },
    } = await dispatch(actionCheckRegistrationOfCourse(code));
    if (!data) {
      // logic for free courses to by-pass ordersummary page.
      // processpayment() a hook function will be called directly to start payment process
      if (finalCourseDetailsBeforePayment?.amount === 0) {
        processPayment();
        // logic for free courses ends here.
      } else dispatch(setPlainModalState(true));
    }
  };
  // onLoginSuccess() ends here=========

  const onClickHandler = () => {
    saveGtmDataLayerData({
      data: extractCdpData(course),
      event: EVENT_NAMES.CDP_JOIN_CLICKED,
    });
    if (!hasAuthToken()) {
      dispatch(initialiseSignIn());
      dispatch(setModalState(true));
      dispatch(initialSignInPageViewed(true));
      dispatch(startLogin(true));
      dispatch(onPostLogin(onLoginSuccess));
      return;
    }

    if (isRegisteredForCourse) {
      window.location.href = getHrefLink(
        `${BASE_URL}/live-classes/classroom/${code}?channel=cdp&platform=${
          isMobile ? 'mweb' : 'web'
        }`,
        router,
      );
      return;
    }

    if (finalCourseDetailsBeforePayment?.amount === 0) {
      return processPayment();
    }

    if (!openCheckoutModal) {
      return dispatch(setPlainModalState(true));
    }
  };

  const handleNotify = async () => {
    try {
      await saveNotifyUser(code);
      dispatch(showNotifyModal(true));
      // eslint-disable-next-line no-empty
    } catch (error) {}
  };

  return (
    <div className={styles.courseCTAContainer}>
      <CustomDefaultButton
        onClick={onClickHandler}
        className={clsx({
          [styles.button]: true,
          [styles.ended]: has_ended,
        })}
        size="large"
        loading={pending}
        disabled={has_ended}
      >
        {renderCourseCTAText({
          amount,
          currency,
          code,
          isRegisteredForCourse,
          finalCourseDetailsBeforePayment,
          ended: has_ended,
        })}
      </CustomDefaultButton>
      {has_ended && (
        <CustomOutlinedButton
          onClick={handleNotify}
          variant="outlined"
          startIcon={<NotificationsIcon />}
          className={styles.notifyButton}
        >
          Notify me
        </CustomOutlinedButton>
      )}
    </div>
  );
};

CourseCTA.defaultProps = {
  openCheckoutModal: false,
};

export default CourseCTA;
