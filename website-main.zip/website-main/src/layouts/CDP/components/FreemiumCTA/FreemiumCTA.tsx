import { FunctionComponent } from 'react';
import { setModalState, setPlainModalState } from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  CustomDefaultButton,
  CustomOutlinedButton,
} from 'src/components/common/BitMuiButton';
import { BASE_URL } from 'utils/constants';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import Spacer from 'src/components/common/Spacer/Spacer';
import { saveNotifyUser } from 'utils/api';

import NotifyMeModel from 'src/layouts/CDP/RightStickySection/Components/NotifyMeModel/NotifyMeModel';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { hasAuthToken } from 'utils/auth/userInfo';
import {
  initialSignInPageViewed,
  onPostLogin,
  startLogin,
} from 'redux/reducers/authReducer';
import { usePayment } from 'hooks/usePayment';
import { actionGetSubscriptionPlan } from 'redux/actions/subCdpAction';
import { useRouter } from 'next/router';
import { getHrefLink } from 'utils';
import { showNotifyModal } from 'redux/reducers/cdpReducer';
import { renderFreeCTAtext } from '../../utils/freemiumCTA';

import styles from './styles.module.scss';

interface FreemiumCTAProps {
  openCheckoutModal?: boolean;
}

const FreemiumCTA: FunctionComponent<FreemiumCTAProps> = ({
  openCheckoutModal = false,
}) => {
  const dispatch = useAppDispatch();
  const router = useRouter();

  const { subscriptionSelected, pending, course, isSubscriptionExists } =
    useAppSelector((state: AppState) => state.cdp);

  const { type, is_active: isActive } = isSubscriptionExists || {};

  const { code } = course;

  const processPayment = usePayment();

  const liveClassHandler = () => {
    window.location.href = getHrefLink(
      `${BASE_URL}/live-classes/classroom/${code}`,
      router,
    );
  };

  const onLoginSuccess = async () => {
    await dispatch(actionGetSubscriptionPlan(course?.code));
  };

  const onClickHandler = async () => {
    if (!hasAuthToken()) {
      dispatch(setModalState(true));
      dispatch(initialSignInPageViewed(true));
      dispatch(startLogin(true));
      dispatch(onPostLogin(onLoginSuccess));

      return;
    }
    if (type === 'paid' && isActive) {
      liveClassHandler();
      return;
    }

    if (!openCheckoutModal) {
      return dispatch(setPlainModalState(true));
    }

    processPayment();

    return null;
  };

  const handleNotify = async () => {
    try {
      await saveNotifyUser(code);

      dispatch(showNotifyModal(true));

      // eslint-disable-next-line no-empty
    } catch (error) {}
  };

  return (
    <>
      <div className={styles.subCTAContainer}>
        {(() => {
          switch (type) {
            case 'paid':
              if (isActive === false) {
                return (
                  <>
                    <hr />
                    <span className={styles.endButton}>
                      <WarningAmberIcon />
                      {renderFreeCTAtext(
                        isSubscriptionExists,
                        subscriptionSelected,
                      )}{' '}
                    </span>
                  </>
                );
              }

              return (
                <CustomDefaultButton
                  onClick={onClickHandler}
                  className={styles.button}
                  size="large"
                  loading={pending}
                  disabled={pending}
                >
                  {renderFreeCTAtext(
                    isSubscriptionExists,
                    subscriptionSelected,
                  )}
                </CustomDefaultButton>
              );

            case 'free':
              return (
                <CustomDefaultButton
                  onClick={onClickHandler}
                  className={styles.button}
                  size="large"
                  loading={pending}
                  disabled={pending}
                >
                  {renderFreeCTAtext(
                    isSubscriptionExists,
                    subscriptionSelected,
                  )}
                </CustomDefaultButton>
              );
            default:
              return (
                <CustomDefaultButton
                  onClick={onClickHandler}
                  className={styles.button}
                  size="large"
                  loading={pending}
                  disabled={pending}
                >
                  {renderFreeCTAtext(
                    isSubscriptionExists,
                    subscriptionSelected,
                  )}
                </CustomDefaultButton>
              );
          }
        })()}

        <Spacer size={10} axis="vertical" />
        {isSubscriptionExists && type === 'paid' && isActive === false && (
          <>
            {/* <hr /> */}
            <div className={styles.row}>
              <CustomOutlinedButton
                onClick={handleNotify}
                variant="contained"
                startIcon={<NotificationsIcon />}
              >
                Notify me
              </CustomOutlinedButton>
            </div>
          </>
        )}

        <NotifyMeModel />
      </div>
    </>
  );
};

FreemiumCTA.defaultProps = {
  openCheckoutModal: false,
};

export default FreemiumCTA;
