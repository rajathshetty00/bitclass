import { FC } from 'react';
import { setAlertModalState } from 'redux/reducers/appReducer';
import { useAppDispatch } from 'redux/store';
import BitMuiAlertDialog from 'src/components/common/BitMuiAlertDialog/BitMuiAlertDialog';

import SubscriptionRegisterSummary from './components/SubscriptionRegisterSummary/SubscriptionRegisterSummary';

interface IRegistrationModalProps {}

const RegistrationModal: FC<IRegistrationModalProps> = () => {
  const dispatch = useAppDispatch();
  const handleClose = () => {
    dispatch(setAlertModalState(false));
  };

  return (
    <BitMuiAlertDialog handleClose={handleClose}>
      <SubscriptionRegisterSummary />
    </BitMuiAlertDialog>
  );
};

export default RegistrationModal;
