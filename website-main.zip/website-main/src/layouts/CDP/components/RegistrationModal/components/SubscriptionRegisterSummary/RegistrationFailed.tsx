import { FC } from 'react';
import { setAlertModalState } from 'redux/reducers/appReducer';
import { useAppDispatch } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import NextImage from 'src/components/common/NextImage/NextImage';
import styles from './styles.module.scss';

interface RegistrationFailedProps {}

const FAILED_REGISTRATION: string =
  'https://res.cloudinary.com/bitclass/image/upload/v1643971540/Website%20ICONS/ES_illustration_Figma_-_data_issues_teaching_classes_copy_5_1_1_liospi.svg';

const RegistrationFailed: FC<RegistrationFailedProps> = () => {
  const dispatch = useAppDispatch();
  const handleClose = () => {
    dispatch(setAlertModalState(false));
  };
  return (
    <div className={styles.registrationFailed}>
      <NextImage
        src={FAILED_REGISTRATION}
        width={250}
        height={250}
        quality={40}
      />
      <h3>Failed to Register</h3>
      <BitButton
        variant="contained"
        className={styles.tryAgainBtn}
        onClick={handleClose}
      >
        Try Again
      </BitButton>
    </div>
  );
};

export default RegistrationFailed;
