import { Typography } from '@mui/material';
import { FC } from 'react';
import styles from 'src/layouts/CDP/components/RegistrationModal/components/SubscriptionRegisterSummary/styles.module.scss';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { getDateFormat, isEmptyObject } from 'utils/index';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import {
  setAlertModalState,
  updateBitModalState,
} from 'redux/reducers/appReducer';
import { onPostLogin } from 'redux/reducers/authReducer';
import { formatDate } from 'utils/dateFns';
import { CDP_TYPE, RIGHT_SECTION_STATUS } from 'utils/constants/cdp';
import { useRightSectionRenderer } from 'hooks/useRightSectionRenderer';
import ScheduleTags from 'src/layouts/CDP/RightStickySection/Components/ScheduleTags/ScheduleTags';
import dayjs from 'dayjs';
import { determineCourseDate } from 'utils';

interface IRegistrationSuccessProps {}

const RegistrationSuccess: FC<IRegistrationSuccessProps> = () => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const { cbFunction } = useAppSelector((state: AppState) => state?.app);

  const {
    registeredDetails,
    course,
    selectedBatch,
    selectedTmprSlot,
    rightSectionStatus,
    isRecommendedSectionExist,
  } = useAppSelector((state: AppState) => state?.cdp);
  const dispatch = useAppDispatch();
  const { fetchDataOnPageType } = useRightSectionRenderer();

  const {
    weekly_schedule: weeklySchedule,
    duration: weeklyDuration,
    start_ts: StartDate,
    end_ts: EndDate,
    type,
  } = course;

  const onDone = () => {
    fetchDataOnPageType();
  };
  const handleClick = () => {
    fetchDataOnPageType();
    dispatch(setAlertModalState(false));
    dispatch(onPostLogin(onDone));
    if (type === CDP_TYPE.curriculum) {
      dispatch(updateBitModalState(true));
      return;
    }
    const freeClassesSection = document.getElementById('free-classes');
    if (isRecommendedSectionExist) {
      freeClassesSection?.scrollIntoView({ behavior: 'smooth' });
    } else {
      cbFunction();
    }
  };

  const printRegisterFooterText = () => {
    if (type === CDP_TYPE.curriculum) return 'Done';
    return isRecommendedSectionExist ? 'Done' : 'Explore More';
  };

  const courseTimingTitle =
    selectedBatch?.epoch_schedule?.length > 1
      ? 'Your course starts on'
      : 'Your class is on';

  return (
    <div className={styles.successContainer}>
      <div className={styles.header}>
        <NextImage
          src={assetObject.successContainer}
          width={isMobile ? 40 : 64}
          height={isMobile ? 40 : 64}
          className={styles.successImg}
        />
        <Typography gutterBottom variant="h6">
          Congratulations
        </Typography>
        {type === 'subscription' ? (
          <Typography align="center">
            You have successfully registered. Your registration is valid till{' '}
            <b>
              {getDateFormat(registeredDetails?.expiring_on, 'MMM DD, YYYY')}
            </b>
          </Typography>
        ) : (
          <Typography>You have successfully registered.</Typography>
        )}
      </div>

      {/* for curriculum */}
      {!isEmptyObject(selectedBatch) && (
        <div className={styles.slotsContainer}>
          <NextImage
            src={assetObject.calendarIcon}
            width={isMobile ? 40 : 64}
            height={isMobile ? 40 : 64}
            className={styles.successImg}
          />
          <div className={styles.schedule}>
            <span className={styles.timingTitle}>{courseTimingTitle}</span>

            <div className={styles.slots}>
              <div className={styles.slot}>
                {formatDate(
                  selectedBatch.epoch_schedule[0],
                  'dddd, DD MMM, hh:mm A',
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* for tmpr page */}
      {selectedTmprSlot && (
        <div className={styles.tmprContainer}>
          <div className={styles.timingContainer}>
            <div>
              <div className={styles.timingTitle}>YOUR CLASS TIMINGS</div>
              <div className={styles.schedule}>
                {selectedTmprSlot?.timing && (
                  <>
                    {selectedTmprSlot?.timing?.length > 1 ? (
                      <b>
                        {dayjs
                          .unix(selectedTmprSlot.timing[0])
                          .format('DD MMM')}
                        &nbsp;-&nbsp;
                        {dayjs
                          .unix(
                            selectedTmprSlot.timing[
                              selectedTmprSlot.timing.length - 1
                            ],
                          )
                          .format('DD MMM')}
                      </b>
                    ) : (
                      <b>
                        {dayjs
                          .unix(selectedTmprSlot.timing[0])
                          .format('DD MMM')}
                      </b>
                    )}
                  </>
                )}

                <ScheduleTags
                  weeklySchedule={selectedTmprSlot.timing}
                  duration={selectedTmprSlot.duration}
                  mainContainerClass={styles.newScheduleContainer}
                />
              </div>
            </div>
          </div>
          <div>
            <NextImage
              src={assetObject.calendarIcon}
              width={isMobile ? 40 : 64}
              height={isMobile ? 40 : 64}
              className={styles.successImg}
            />
          </div>
        </div>
      )}

      {/* for workshops/full-course/free classes */}

      {rightSectionStatus === RIGHT_SECTION_STATUS.FULLCOURSE && (
        <div className={styles.tmprContainer}>
          <div className={styles.timingContainer}>
            <div>
              <div className={styles.timingTitle}>YOUR CLASS TIMINGS</div>
              <div className={styles.schedule}>
                <b>{determineCourseDate({ StartDate, EndDate })}</b>

                <ScheduleTags
                  weeklySchedule={weeklySchedule}
                  duration={weeklyDuration}
                  mainContainerClass={styles.scheduleContainer}
                />
              </div>
            </div>
          </div>
          <div>
            <NextImage
              src={assetObject.calendarIcon}
              width={isMobile ? 40 : 64}
              height={isMobile ? 40 : 64}
              className={styles.successImg}
            />
          </div>
        </div>
      )}

      <div className={styles.body}>
        <div className={styles.flex}>
          <NextImage src={assetObject.chat} width={40} height={24} />
          <Typography variant="body1">
            Meet your classmates & connect with your teacher in the group chat.
          </Typography>
        </div>

        <div className={styles.flex}>
          <NextImage src={assetObject.bell} width={32} height={32} />
          <Typography variant="body1">
            We will send you a reminder before the LIVE class starts.
          </Typography>
        </div>
      </div>

      <div className={styles.footer}>
        <CustomDefaultButton onClick={handleClick} className={styles.button}>
          {printRegisterFooterText()}
        </CustomDefaultButton>
      </div>
    </div>
  );
};

export default RegistrationSuccess;
