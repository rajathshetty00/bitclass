import { FC, useEffect } from 'react';
import {
  saveSubscriptionPlans,
  selectSubscription,
} from 'redux/reducers/cdpReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import styles from 'src/layouts/CDP/components/RegistrationModal/components/SubscriptionRegisterSummary/styles.module.scss';
import { getSubscriptionPlan } from 'utils/api';
import RegistrationFailed from './RegistrationFailed';
import RegistrationSuccess from './RegistrationSuccess';

interface ISubscriptionRegisterSummaryProps {}

const SubscriptionRegisterSummary: FC<ISubscriptionRegisterSummaryProps> =
  () => {
    const {
      registeredDetails,
      course: { code },
    } = useAppSelector((state: AppState) => state.cdp);

    const dispatch = useAppDispatch();

    useEffect(() => {
      (async () => {
        try {
          const {
            data: {
              plans,
              latest_subscription_details: latestSubscriptionDetails,
            },
            success: planSuccess,
          } = await getSubscriptionPlan(code);
          if (planSuccess)
            dispatch(
              saveSubscriptionPlans({ plans, latestSubscriptionDetails }),
            );
          dispatch(selectSubscription(plans[0]));
        } catch (error) {
          return error;
        }
      })();
    }, [code, dispatch]);

    return (
      <div className={styles.registerSummary}>
        {registeredDetails ? <RegistrationSuccess /> : <RegistrationFailed />}
      </div>
    );
  };

export default SubscriptionRegisterSummary;
