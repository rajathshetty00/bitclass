import { FunctionComponent } from 'react';
// import {
//   actionCreateOrder,
//   actionRegisterUserForCourse,
// } from 'redux/actions/subCdpAction';
import {
  // setAlertModalState,
  setModalState,
  setPlainModalState,
} from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
// import { processSubscriptionPayment } from 'utils/payments/workflow';
import { renderSubCTAtext } from 'src/layouts/CDP/utils';
import { hasAuthToken } from 'utils/auth/userInfo';
import {
  initialSignInPageViewed,
  onPostLogin,
  startLogin,
} from 'redux/reducers/authReducer';
import { Skeleton } from '@mui/material';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { extractCdpData } from 'utils/courseAnalytics';
import { usePayment } from 'hooks/usePayment';
import { actionGetSubscriptionPlan } from 'redux/actions/subCdpAction';
import styles from './styles.module.scss';

interface SubscriptionCTAProps {
  openCheckoutModal?: boolean;
}

const SubscriptionCTA: FunctionComponent<SubscriptionCTAProps> = ({
  openCheckoutModal = false,
}) => {
  const dispatch = useAppDispatch();

  const {
    subscriptionSelected,
    pending,
    course,
    isSubscriptionExists,
    subscriptionPlans,
  } = useAppSelector((state: AppState) => state.cdp);

  const processPayment = usePayment();
  const onLoginSuccess = async () => {
    await dispatch(actionGetSubscriptionPlan(course?.code));
    dispatch(setPlainModalState(true));
  };

  const onClickHandler = async () => {
    saveGtmDataLayerData({
      data: extractCdpData(course),
      event: isSubscriptionExists
        ? EVENT_NAMES.SUBSCRIPTION_RENEW_CLICKED
        : EVENT_NAMES.CDP_JOIN_CLICKED,
    });
    if (!hasAuthToken()) {
      dispatch(setModalState(true));
      dispatch(initialSignInPageViewed(true));
      dispatch(startLogin(true));
      dispatch(onPostLogin(onLoginSuccess));
      return;
    }

    if (!openCheckoutModal) {
      return dispatch(setPlainModalState(true));
    }
    processPayment();

    return null;
  };

  return (
    <>
      <div className={styles.subCTAContainer}>
        {subscriptionPlans ? (
          <CustomDefaultButton
            onClick={onClickHandler}
            className={styles.button}
            size="large"
            loading={pending}
            disabled={pending}
          >
            {renderSubCTAtext(isSubscriptionExists, subscriptionSelected)}
          </CustomDefaultButton>
        ) : (
          <Skeleton variant="rectangular" height="56px" />
        )}
      </div>
    </>
  );
};

SubscriptionCTA.defaultProps = {
  openCheckoutModal: false,
};

export default SubscriptionCTA;
