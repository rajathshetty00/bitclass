import { FunctionComponent } from 'react';
import { setPlainModalState } from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  CustomDefaultButton,
  CustomOutlinedButton,
} from 'src/components/common/BitMuiButton';
import { BASE_URL } from 'utils/constants';
import clsx from 'clsx';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { extractCdpData } from 'utils/courseAnalytics';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { getHrefLink } from 'utils';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { saveNotifyUser } from 'utils/api';
import { showNotifyModal } from 'redux/reducers/cdpReducer';
import styles from '../CourseCTA/styles.module.scss';

import { renderCourseCTAText } from '../../utils';

interface TmprCTAProps {}

const TmprCTA: FunctionComponent<TmprCTAProps> = () => {
  const {
    course,
    isRegisteredForCourse,
    // couponData,
    finalCourseDetailsBeforePayment,
    pending,
    courseRegistrationDetailsInTmpr,
  } = useAppSelector((state: AppState) => state.cdp);

  const dispatch = useAppDispatch();
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const { code, currency, amount, has_ended } = course;

  const handleNotify = async () => {
    try {
      await saveNotifyUser(code);
      dispatch(showNotifyModal(true));
      // eslint-disable-next-line no-empty
    } catch (error) {}
  };

  // onLoginSuccess() ends here=========

  const onClickHandler = () => {
    saveGtmDataLayerData({
      data: extractCdpData(course),
      event: EVENT_NAMES.CDP_JOIN_CLICKED,
    });

    if (courseRegistrationDetailsInTmpr?.is_registered) {
      window.location.href = getHrefLink(
        `${BASE_URL}/profile?channel=cdp&platform=${isMobile ? 'mweb' : 'web'}`,
        router,
      );

      return;
    }

    return dispatch(setPlainModalState(true));

    // handleCtaClickAfterRegistrationStatus();
  };

  return (
    <div className={styles.courseCTAContainer}>
      <CustomDefaultButton
        onClick={onClickHandler}
        className={clsx({
          [styles.button]: true,
          [styles.ended]: has_ended,
        })}
        size="large"
        loading={pending}
        disabled={has_ended}
      >
        {renderCourseCTAText({
          amount,
          currency,
          code,
          isRegisteredForCourse,
          finalCourseDetailsBeforePayment,
          courseRegistrationDetailsInTmpr,
          ended: has_ended,
        })}
      </CustomDefaultButton>

      {has_ended && (
        <CustomOutlinedButton
          onClick={handleNotify}
          variant="outlined"
          startIcon={<NotificationsIcon />}
          className={styles.notifyButton}
        >
          Notify me
        </CustomOutlinedButton>
      )}
    </div>
  );
};
export default TmprCTA;
