import { getCurrencySymbol } from 'utils/currency';

export const renderFreeCTAtext = (
  isSubscriptionExists: any,
  { selling_price: amount, currency }: any,
) => {
  if (isSubscriptionExists?.type === 'free')
    return `Join this course for ${getCurrencySymbol(currency)}${amount}`;

  if (!isSubscriptionExists) {
    if (amount)
      return `Join this course for ${getCurrencySymbol(currency)}${amount}`;

    return `Get started for FREE`;
  }
  if (isSubscriptionExists?.is_active) return `Go to Live class`;

  return `This course has ended`;
};
