import { getCurrencySymbol } from 'utils/currency';

export const renderSubCTAtext = (
  isSubscriptionExists: any,
  { selling_price: amount, currency }: any,
) => {
  if (isSubscriptionExists) return `Click to renew`;

  if (amount > 0) {
    const finalAmount = `${getCurrencySymbol(currency)}${amount}`;
    return `Register for ${finalAmount}`;
  }
  return `Get started for FREE`;
};

// showing registration for normal course page
export const renderCourseCTAText = ({
  amount,
  currency,
  isRegisteredForCourse,
  courseRegistrationDetailsInTmpr,
  ended,
}: any) => {
  if (ended) {
    return `Course Ended!`;
  }

  if (isRegisteredForCourse) {
    return `Go to LIVE Class`;
  }

  if (courseRegistrationDetailsInTmpr?.is_registered) {
    return `Go to LIVE Class`;
  }

  if (amount > 0) {
    const amountWithCurrency = `${getCurrencySymbol(currency)}${amount}`;
    return `Join this course for ${amountWithCurrency}`;
  }
  return `Register for FREE`;
};
