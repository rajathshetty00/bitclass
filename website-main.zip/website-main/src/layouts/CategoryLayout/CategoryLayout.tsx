import dynamic from 'next/dynamic';
import React, { FC } from 'react';
import BitCardCarousel from 'src/components/common/BitCardCarousel/BitCardCarousel';
import BitFeaturedCarousel from 'src/components/common/BitFeaturedCarousel/BitFeaturedCarousel';
import Banner from 'src/components/Category/Banner/Banner';
import { useAppSelector, AppState } from 'redux/store';
import CheckoutModal from 'src/components/CDP/CheckoutModal/CheckoutModal';
import PAGE_TYPES, { getChannel } from 'utils/constants/pageTypes';
import BitImageBannerCarousel from 'src/components/common/BitImageBannerCarousel/BitImageBannerCarousel';
import NextHead from 'src/components/common/NextHead/NextHead';
import DownloadBitClassApp from 'src/components/common/DownloadBitClassApp/DownloadBitClassApp';
import { useRouter } from 'next/router';
import styles from './styles.module.scss';
import RegistrationModal from '../CDP/components/RegistrationModal/RegistrationModal';
import CollectionSections from '../CollectionLayout/CollectionSections/CollectionSections';
import CategoryCarousel from '../Homepage/CategoryCarousel/CategoryCarousel';

const BitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

interface CategoryLayoutProps {}

const CategoryLayout: FC<CategoryLayoutProps> = () => {
  const { categoryData, categoryType } = useAppSelector(
    (state: AppState) => state.category,
  );

  const { pageType } = useAppSelector((state: AppState) => state.app);
  const { sections } = categoryData ?? {};
  const router = useRouter();

  return (
    <div className={styles.categoryLayoutWrapper}>
      <NextHead />
      <header>
        <BitAppHeader />
        {getChannel(router.pathname) !== 'collection_page' && (
          <CategoryCarousel />
        )}
      </header>

      <div className={styles.categoryLayoutBody}>
        {pageType === PAGE_TYPES.CATEGORY_PAGE && (
          <div className={styles.bannerWrapper}>
            <Banner />
          </div>
        )}

        {pageType === PAGE_TYPES.COLLECTION_PAGE && (
          <div className={styles.bannerWrapper}>
            <Banner />
          </div>
        )}

        {categoryType === PAGE_TYPES.COLLECTION_PAGE ? (
          <>
            <CollectionSections />
          </>
        ) : (
          sections?.map(({ heading, source, type }: any) => {
            let result;

            if (type === 'ImageCarouselV2') {
              result = (
                <div key={heading} className={styles.sectionContainer}>
                  <BitImageBannerCarousel
                    heading={heading}
                    source={source}
                    sectionType={type}
                    sectionHeading="home_page_web_banner"
                  />
                </div>
              );
            }

            if (type === 'CourseCards') {
              result = (
                <div key={heading} className={styles.sectionContainer}>
                  <BitCardCarousel
                    heading={heading}
                    source={source}
                    sectionType={type}
                  />
                </div>
              );
            }

            if (type === 'FeaturedCourses') {
              result = (
                <div key={heading} className={styles.sectionContainer}>
                  <BitFeaturedCarousel heading={heading} source={source} />
                </div>
              );
            }

            return result;
          })
        )}

        {getChannel(router.pathname) !== 'home_page' && (
          <DownloadBitClassApp channel={getChannel(router.pathname)} />
        )}
      </div>
      <CheckoutModal />
      <RegistrationModal />
    </div>
  );
};

CategoryLayout.defaultProps = {
  isHome: true,
};
export default CategoryLayout;
