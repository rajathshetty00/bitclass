import { FC, useEffect } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import styles from './styles.module.scss';

interface AppBannerProps {}

const AppBanner: FC<AppBannerProps> = () => {
  const { zoomDetails } = useAppSelector((state: AppState) => state.classroom);

  useEffect(() => {
    window.location.href = zoomDetails.external_lesson_url;
  }, []);

  return (
    <div className={styles.appBannerContainer}>
      <NextImage
        src="https://media.bitclass.live/image/upload/v1646393624/animation_640_l0c5psed_xepysn"
        width={200}
        height={200}
        crossOrigin=""
      />
      <h1>Setting up your classroom ...</h1>
    </div>
  );
};

export default AppBanner;
