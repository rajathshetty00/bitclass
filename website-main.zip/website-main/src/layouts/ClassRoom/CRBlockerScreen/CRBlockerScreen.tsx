import { useRouter } from 'next/router';
import { FC } from 'react';
import { Zap } from 'react-feather';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { getQuery } from 'utils';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

interface IProps {
  screenType: string;
}
const blockerScreenDetails: any = {
  NOT_REGISTERED: {
    title: 'Looks like you have not registered fo this courses',
    buttonText: 'Buy Now',
  },
  FREEMIUM_EXPIRED: {
    title:
      'Looks like your FREE trial period has expired please buy the full course',
    buttonText: 'Buy Now',
  },
  SUBSCRIPTION_EXPIRED: {
    title:
      'Oops ! Looks like your current plan has expired. To continue learning LIVE, please renew your subscription',
    buttonText: 'Renew Now',
  },
};
const CRBlockerScreen: FC<IProps> = ({ screenType }) => {
  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const redirectToCdp = () => {
    appendQueryParamAndNavigate(
      `${BASE_URL}/live-classes/${
        router.query.courseCode
      }?channel=classroom&platform=${isMobile ? 'mweb' : 'web'}#checkout`,
      getQuery(router),
      false,
    );
  };

  const blockerScreenTitle: string = blockerScreenDetails[screenType].title;

  const blockerScreenButtonText: string =
    blockerScreenDetails[screenType].buttonText;

  return (
    <div className={styles.blockerScreen}>
      <div className={styles.blockerContainer}>
        <h4>{blockerScreenTitle}</h4>
        <BitButton
          onClick={redirectToCdp}
          className={styles.upgradeButton}
          variant="contained"
        >
          <h5>
            <Zap /> <span>{blockerScreenButtonText}</span>
          </h5>
        </BitButton>
      </div>
    </div>
  );
};

export default CRBlockerScreen;
