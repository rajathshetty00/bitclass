import dynamic from 'next/dynamic';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import { isEmptyObject } from 'utils';
import React, { useEffect, useState } from 'react';
import CRBlockerScreen from './CRBlockerScreen/CRBlockerScreen';
import Instruction from './Instruction/Instruction';
import styles from './styles.module.scss';
import TimerScreen from './TimerScreen/TimerScreen';
import EarlyScreen from './EarlyScreen/EarlyScreen';
import AppBanner from './AppBanner/AppBanner';

const ZoomWebSdk = dynamic(
  () => import('src/layouts/ClassRoom/Zoom/ZoomWebSdk'),
  {
    ssr: false,
  },
);

const blockerScreen = {
  NOT_REGISTERED: 'NOT_REGISTERED',
  FREEMIUM_EXPIRED: 'FREEMIUM_EXPIRED',
  SUBSCRIPTION_EXPIRED: 'SUBSCRIPTION_EXPIRED',
  LOADING: 'LOADING',
};
const Classroom = () => {
  const { zoomDetails, pending, zoomEngagementDetails } = useAppSelector(
    (state: AppState) => state.classroom,
  );

  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );

  const { classStartTime } = zoomDetails;
  const isClassStarted = classStartTime - Date.now() / 1000 > 60;
  const [timerScreenVisibility, setTimerScreenVisibility] = useState(
    !isClassStarted,
  );
  const [earlyScreenVisibility, setEarlyScreenVisibility] = useState(false);

  useEffect(() => {
    if (zoomDetails?.is_class_started) {
      setTimerScreenVisibility(!zoomDetails?.is_class_started);
    }
  }, [zoomDetails?.is_class_started]);

  const getBlockerScreenType = () => {
    if (isEmptyObject(zoomDetails)) return blockerScreen.NOT_REGISTERED;
    if (zoomDetails.is_subscription_expired)
      return blockerScreen.SUBSCRIPTION_EXPIRED;
    return blockerScreen.LOADING;
  };
  if (pending)
    return (
      <div className={styles.loader}>
        <NextImage
          src="https://media.bitclass.live/image/upload/v1646393624/animation_640_l0c5psed_xepysn"
          width={200}
          height={200}
          crossOrigin=""
        />
        <h1>Setting up your classroom ...</h1>
      </div>
    );
  if (earlyScreenVisibility)
    return (
      <EarlyScreen
        startTime={zoomDetails.class_start_ts}
        startClassroom={() => setEarlyScreenVisibility(false)}
      />
    );
  if (isEmptyObject(zoomDetails) || zoomDetails.is_subscription_expired)
    return <CRBlockerScreen screenType={getBlockerScreenType()} />;
  if (zoomEngagementDetails.pre_class_instruction)
    return (
      <Instruction
        instructions={zoomEngagementDetails.pre_class_instruction}
        isTeacher={zoomDetails.is_teacher}
      />
    );
  return (
    <div className={styles.classroom}>
      {!isMobile ? (
        <>
          {timerScreenVisibility && (
            <TimerScreen
              zoomDetails={zoomDetails}
              closeTimer={() => setTimerScreenVisibility(false)}
            />
          )}
          <ZoomWebSdk />
        </>
      ) : (
        <>
          <AppBanner />
        </>
      )}
    </div>
  );
};

export default Classroom;
