import React from 'react';

const ClassroomModal = () => {
  return <div>ClassroomModal</div>;
};

export default ClassroomModal;
