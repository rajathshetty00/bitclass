import dayjs from 'dayjs';
import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import NextImage from 'src/components/common/NextImage/NextImage';
import { getHrefLink } from 'utils';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

const EarlyScreen = ({ startTime, startClassroom }: any) => {
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  const goToHomePage = () =>
    window.location.replace(
      getHrefLink(
        `${BASE_URL}?channel=classroom&platform=${isMobile ? 'mweb' : 'web'}`,
        router,
      ),
    );
  return (
    <div className={styles.earlyScreen}>
      <div className={styles.earlyContainer}>
        <div className={styles.topSection}>
          <NextImage
            src="https://media.bitclass.live/image/upload/q_auto,f_auto/v1646831837/earlyScreen_qcb015"
            width={400}
            height={300}
            crossOrigin=""
          />
          <p>Looks like you are very early for the class</p>
        </div>
        {startTime && (
          <div className={styles.dateContainer}>
            <p>Class starts on</p>
            <p className={styles.date}>
              {dayjs.unix(startTime).format('MMM DD, h:mm A')}
            </p>
          </div>
        )}
        <div className={styles.buttonContainer}>
          <BitButton
            className={styles.primaryBtn}
            variant="contained"
            onClick={goToHomePage}
          >
            Explore other courses
          </BitButton>
          <BitButton
            className={styles.secondaryBtn}
            variant="outlined"
            onClick={startClassroom}
          >
            Continue to class
          </BitButton>
        </div>
      </div>
    </div>
  );
};

export default EarlyScreen;
