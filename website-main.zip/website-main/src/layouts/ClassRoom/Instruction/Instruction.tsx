import { Checkbox } from '@mui/material';
import { useState } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';

import styles from './styles.module.scss';

const Instruction = ({ instructions, isTeacher }: any) => {
  const [isChecked, setIsChecked] = useState(false);
  const { external_lesson_url } = useAppSelector(
    (state: AppState) => state.classroom.zoomDetails,
  );

  const handleChange = (e: any) => {
    setIsChecked(e.target.checked);
  };

  const handleSubmit = () => window.location.replace(external_lesson_url);
  return (
    <section className={styles.instructionContainer}>
      <div className={styles.instructionHeading}>
        <span>Important Instructions</span>
      </div>
      <div className={styles.instructionList}>
        <ul>
          {instructions?.map((instruction: any) => {
            return <li key={instruction}>{instruction}</li>;
          })}
        </ul>
      </div>
      <div className={styles.submit}>
        <div>
          {instructions && (
            <>
              <Checkbox onChange={handleChange} checked={isChecked} />
              <b className="checkbox_label">
                I confirm that I have read all the instructions carefully
              </b>
            </>
          )}
        </div>
        <BitButton
          variant="contained"
          fullWidth
          className={styles.submitButton}
          disabled={!isChecked}
          onClick={handleSubmit}
        >{`Click to start ${isTeacher ? 'teaching' : 'class'}`}</BitButton>
      </div>
    </section>
  );
};

export default Instruction;
