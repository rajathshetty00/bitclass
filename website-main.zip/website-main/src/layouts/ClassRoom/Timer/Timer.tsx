import { useEffect, useState } from 'react';

const Timer = ({ zoomData, closeTimerScreen }: any) => {
  const calculateTimeLeft = (classStartTime: any) => {
    const timeNow = Date.now();
    return classStartTime - timeNow / 1000;
  };
  const [remainingTime, setRemainingTime] = useState(
    calculateTimeLeft(zoomData.class_start_ts),
  );

  useEffect(() => {
    let timer: any;
    if (remainingTime <= 60) closeTimerScreen();
    else {
      timer = setInterval(() => {
        const diffInSeconds = calculateTimeLeft(zoomData.class_start_ts);
        setRemainingTime(diffInSeconds);
      }, 1000);
    }
    return () => clearInterval(timer);
  });

  const formatTime = (time: number, value: string) => {
    return time > 1 ? `${time} ${value}s` : `${time} ${value}`;
  };
  const calculateTimeDifference = (diff: number) => {
    const time = diff;
    const days = Math.floor(time / (60 * 60 * 24));
    const hours = Math.floor((time / (60 * 60)) % 24);
    const minutes = Math.floor((time / 60) % 60);
    const seconds = Math.floor(time % 60);
    return `${days > 0 ? formatTime(days, 'day') : ''}${
      days > 0 ? ' : ' : ''
    }${formatTime(hours, 'hour')} : ${formatTime(
      minutes,
      'minute',
    )} : ${formatTime(seconds, 'second')}`;
  };
  return <div>{calculateTimeDifference(remainingTime)}</div>;
};

export default Timer;
