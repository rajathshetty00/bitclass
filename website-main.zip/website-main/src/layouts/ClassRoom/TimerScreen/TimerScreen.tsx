import clsx from 'clsx';
import { ArrowRight } from 'react-feather';
import Timer from '../Timer/Timer';
import styles from './styles.module.scss';

const TimerScreen = ({ closeTimer, zoomDetails }: any) => {
  return (
    <div className={styles.overlay}>
      <div className={styles.modal}>
        <div className={clsx(styles.body, styles.forest)}>
          <div className={styles.content}>
            <div className={styles.timer}>
              <div className={styles.close}>
                <button
                  type="button"
                  className={styles.closeBtn}
                  onClick={() => closeTimer(false)}
                >
                  X Close
                </button>
              </div>
              <div>
                <h1>Your class is about to start in</h1>
                <Timer
                  zoomData={zoomDetails}
                  closeTimerScreen={() => closeTimer(false)}
                />
                <button
                  type="button"
                  onClick={closeTimer}
                  className={styles.continueToClassBtn}
                >
                  Continue to Class <ArrowRight size="10" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimerScreen;
