import { useCallback, useEffect, useMemo, memo, FC } from 'react';
import jwt from 'jsonwebtoken';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import { useRouter } from 'next/router';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { getQuery } from 'utils';
import styles from './styles.module.scss';
import { useZoom } from './useZoom';

const ZoomWebSdk: FC = memo(() => {
  const [initZoom] = useZoom();
  // const [showLoader, setShowLoader] = useState(true);
  const { zoomConfig, zoomEngagementDetails } = useAppSelector(
    (state: AppState) => state.classroom,
  );
  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // @ts-ignore
      window.openCDP = () => {
        appendQueryParamAndNavigate(
          zoomEngagementDetails.in_class_checkout_url,
          getQuery(router),
        );
      };
    }
  }, [zoomEngagementDetails.in_class_checkout_url]);

  const { initCode, initKey, ...restConfig } = zoomConfig;

  const getApiKey = useCallback(() => {
    let key = null;
    try {
      key = jwt.verify(initKey, initCode.split('').reverse().join(''));
    } catch (e) {
      console.log(e);
    }
    // @ts-ignore
    return key ? key?.zoom_api_key : '';
  }, [initCode, initKey]);

  const zoomJoinPayload = useMemo(
    () => ({ ...restConfig, apiKey: getApiKey() }),
    [getApiKey, restConfig],
  );
  useEffect(() => {
    if (!zoomJoinPayload.apiKey) return;
    initZoom({
      zoomConfig: zoomJoinPayload,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zoomJoinPayload]);

  return (
    <div className={styles.loader}>
      <NextImage
        src="https://media.bitclass.live/image/upload/v1646393624/animation_640_l0c5psed_xepysn"
        width={200}
        height={200}
        crossOrigin=""
      />
      <h1>Setting up your classroom ...</h1>
    </div>
  );
});

export default ZoomWebSdk;
