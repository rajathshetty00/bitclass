import { useRouter } from 'next/router';
import { useSelector } from 'react-redux';
import { AppState, useAppSelector } from 'redux/store';
import { getHrefLink } from 'utils';
import { BASE_URL, ZOOM_SDK_VERSION } from 'utils/constants';
import styles from './styles.module.scss';

interface IZoomConfig {
  apiKey: string;
  customerKey: string;
  meetingNumber: string;
  passWord: string;
  signature: string;
  userEmail: string;
  userName: string;
}
interface IInitZoom {
  zoomConfig: IZoomConfig;
}

const getCustomCheckoutBtn = (zoomEngagementDetails: any) => {
  if (!zoomEngagementDetails.in_class_checkout_url) return;
  const checkoutFooterBtn = `<button
      id='zoomCheckoutBtn'
      type="button"
      onclick="openCDP()"
      class="footer-button-base__button ${styles.shimmerButton} ${styles.shimmer}"
      aria-label="Buy this course"
    >
    <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clip-path="url(#clip0_30_13162)">
      <path d="M0.5 1.5C0.5 1.36739 0.552678 1.24021 0.646447 1.14645C0.740215 1.05268 0.867392 1 1 1H2.5C2.61153 1.00003 2.71985 1.03735 2.80773 1.10602C2.89561 1.1747 2.95801 1.27078 2.985 1.379L3.39 3H15C15.0734 3.00007 15.1459 3.0163 15.2124 3.04755C15.2788 3.0788 15.3375 3.12429 15.3844 3.1808C15.4313 3.23731 15.4651 3.30345 15.4835 3.37452C15.502 3.44558 15.5045 3.51984 15.491 3.592L13.991 11.592C13.9696 11.7066 13.9087 11.8101 13.8191 11.8846C13.7294 11.9591 13.6166 11.9999 13.5 12H4.5C4.38343 11.9999 4.27057 11.9591 4.18091 11.8846C4.09126 11.8101 4.03045 11.7066 4.009 11.592L2.51 3.607L2.11 2H1C0.867392 2 0.740215 1.94732 0.646447 1.85355C0.552678 1.75979 0.5 1.63261 0.5 1.5ZM5.5 12C4.96957 12 4.46086 12.2107 4.08579 12.5858C3.71071 12.9609 3.5 13.4696 3.5 14C3.5 14.5304 3.71071 15.0391 4.08579 15.4142C4.46086 15.7893 4.96957 16 5.5 16C6.03043 16 6.53914 15.7893 6.91421 15.4142C7.28929 15.0391 7.5 14.5304 7.5 14C7.5 13.4696 7.28929 12.9609 6.91421 12.5858C6.53914 12.2107 6.03043 12 5.5 12ZM12.5 12C11.9696 12 11.4609 12.2107 11.0858 12.5858C10.7107 12.9609 10.5 13.4696 10.5 14C10.5 14.5304 10.7107 15.0391 11.0858 15.4142C11.4609 15.7893 11.9696 16 12.5 16C13.0304 16 13.5391 15.7893 13.9142 15.4142C14.2893 15.0391 14.5 14.5304 14.5 14C14.5 13.4696 14.2893 12.9609 13.9142 12.5858C13.5391 12.2107 13.0304 12 12.5 12ZM5.5 13C5.76522 13 6.01957 13.1054 6.20711 13.2929C6.39464 13.4804 6.5 13.7348 6.5 14C6.5 14.2652 6.39464 14.5196 6.20711 14.7071C6.01957 14.8946 5.76522 15 5.5 15C5.23478 15 4.98043 14.8946 4.79289 14.7071C4.60536 14.5196 4.5 14.2652 4.5 14C4.5 13.7348 4.60536 13.4804 4.79289 13.2929C4.98043 13.1054 5.23478 13 5.5 13ZM12.5 13C12.7652 13 13.0196 13.1054 13.2071 13.2929C13.3946 13.4804 13.5 13.7348 13.5 14C13.5 14.2652 13.3946 14.5196 13.2071 14.7071C13.0196 14.8946 12.7652 15 12.5 15C12.2348 15 11.9804 14.8946 11.7929 14.7071C11.6054 14.5196 11.5 14.2652 11.5 14C11.5 13.7348 11.6054 13.4804 11.7929 13.2929C11.9804 13.1054 12.2348 13 12.5 13Z" fill="white"/>
      <path d="M6.21429 6.25374C6.21429 5.90631 6.31487 5.63431 6.51601 5.43774C6.72172 5.24117 6.98458 5.14288 7.30458 5.14288C7.62458 5.14288 7.88515 5.24117 8.08629 5.43774C8.29201 5.63431 8.39487 5.90631 8.39487 6.25374C8.39487 6.60574 8.29201 6.88003 8.08629 7.0766C7.88515 7.27317 7.62458 7.37145 7.30458 7.37145C6.98458 7.37145 6.72172 7.27317 6.51601 7.0766C6.31487 6.88003 6.21429 6.60574 6.21429 6.25374ZM10.6166 5.22517L7.92172 10.0252H6.98915L9.67715 5.22517H10.6166ZM7.29772 5.71888C7.04629 5.71888 6.92058 5.89717 6.92058 6.25374C6.92058 6.61488 7.04629 6.79545 7.29772 6.79545C7.42115 6.79545 7.51715 6.75203 7.58572 6.66517C7.65429 6.57374 7.68858 6.4366 7.68858 6.25374C7.68858 5.89717 7.55829 5.71888 7.29772 5.71888ZM9.22458 8.98974C9.22458 8.63774 9.32515 8.36574 9.52629 8.17374C9.73201 7.97717 9.99487 7.87888 10.3149 7.87888C10.6349 7.87888 10.8932 7.97717 11.0897 8.17374C11.2909 8.36574 11.3914 8.63774 11.3914 8.98974C11.3914 9.34174 11.2909 9.61603 11.0897 9.8126C10.8932 10.0092 10.6349 10.1075 10.3149 10.1075C9.99029 10.1075 9.72744 10.0092 9.52629 9.8126C9.32515 9.61603 9.22458 9.34174 9.22458 8.98974ZM10.308 8.45488C10.0474 8.45488 9.91715 8.63317 9.91715 8.98974C9.91715 9.35088 10.0474 9.53146 10.308 9.53146C10.564 9.53146 10.692 9.35088 10.692 8.98974C10.692 8.63317 10.564 8.45488 10.308 8.45488Z" fill="#44332B"/>
      </g>
      <defs>
      <clipPath id="clip0_30_13162">
      <rect width="16" height="16" fill="white" transform="translate(0.5)"/>
      </clipPath>
      </defs>
      </svg>

      ${zoomEngagementDetails.in_class_cta_text}
    </button>`;
  const footer = document.getElementsByClassName('footer__btns-container');
  const Checkout = document.createElement('div');
  Checkout.innerHTML = `${checkoutFooterBtn}`;
  footer[0].prepend(Checkout);
};

const ZOOM_GLOBAL_CDN = `https://source.zoom.us/${ZOOM_SDK_VERSION}/lib`;

export const useZoom = () => {
  const { courseCode, zoomEngagementDetails } = useAppSelector(
    (state: AppState) => state.classroom,
  );
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);

  console.log('the ROuter', router, isMobile);

  const inviteUrlFormat = getHrefLink(
    `${BASE_URL}/live-classes/classroom/${courseCode}?channel=classroom&platform=${
      isMobile ? 'mweb' : 'web'
    }`,
    router,
  );
  const leaveUrl = getHrefLink(
    `${BASE_URL}/lessons/${courseCode}/feedback?channel=classroom&platform=${
      isMobile ? 'mweb' : 'web'
    }`,
    router,
  );

  const initZoom = ({ zoomConfig }: IInitZoom) => {
    import('@zoomus/websdk').then(({ ZoomMtg }) => {
      ZoomMtg.setZoomJSLib(ZOOM_GLOBAL_CDN, '/av');
      ZoomMtg.preLoadWasm();
      ZoomMtg.prepareJssdk();
      ZoomMtg.init({
        leaveUrl,
        isSupportAV: true,
        disableInvite: true,
        inviteUrlFormat,
        disablePreview: true,
        meetingInfo: [
          'topic',
          'host',
          'mn',
          'participant',
          'invite',
          'dc',
          'enctype',
          'report',
        ],
        success: () => {
          ZoomMtg.join({
            ...zoomConfig,
            success: () => {
              getCustomCheckoutBtn(zoomEngagementDetails);
            },
            error: (error: any) => {
              console.error(error);
            },
          });
        },
        error: (error: any) => {
          console.error(error);
        },
      });
    });
  };
  return [initZoom];
};
