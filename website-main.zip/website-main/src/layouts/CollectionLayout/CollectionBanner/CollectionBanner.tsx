import { AppState, useAppSelector } from 'redux/store';
import styles from './styles.module.scss';

const CollectionBanner = () => {
  const {
    collectionData: {
      meta: {
        heading,
        banner: { image },
      },
    },
  } = useAppSelector((state: AppState) => state?.collection);

  const {
    deviceInfo: { isMobile },
  } = useAppSelector((state: AppState) => state?.app);

  const url = isMobile ? image.mobile : image.web;
  const optimizeImg = url;
  const bgImgStylesObj = {
    background: `linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(255,255,255,0) 90%), url(${optimizeImg})`,
    width: '100%',
    height: isMobile ? '84px' : '144px',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
  };

  return (
    <section id="bannerSection" className={styles.bannerContainer}>
      <div className={styles.bannerImgContainer} style={bgImgStylesObj}>
        <h1 className={styles.bannerHeading}>{heading}</h1>
      </div>
    </section>
  );
};

export default CollectionBanner;
