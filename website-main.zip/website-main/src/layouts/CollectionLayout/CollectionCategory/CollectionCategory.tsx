import NextImage from 'src/components/common/NextImage/NextImage';
import styles from './styles.module.scss';

const CollectionCategory = () => {
  const url =
    'https://res.cloudinary.com/bitclass/image/upload/v1631096246/App%20Highlights/Category_icons_prof_courses-33-33_iebvvw.png';
  return (
    <div className={styles.categoryItem}>
      <a href="https://categories.bitclass.live/c/Career%20&%20Business">
        <div className={styles.categoryItemInnerContainer}>
          <NextImage src={url} width="24px" height="24px" />
          <span>Career &amp; Business</span>
        </div>
      </a>
      <a href="https://categories.bitclass.live/c/Career%20&%20Business">
        <div className={styles.categoryItemInnerContainer}>
          <NextImage src={url} width="24px" height="24px" />
          <span>Career &amp; Business</span>
        </div>
      </a>
      <a href="https://categories.bitclass.live/c/Career%20&%20Business">
        <div className={styles.categoryItemInnerContainer}>
          <NextImage src={url} width="24px" height="24px" />
          <span>Career &amp; Business</span>
        </div>
      </a>
      <a href="https://categories.bitclass.live/c/Career%20&%20Business">
        <div className={styles.categoryItemInnerContainer}>
          <NextImage src={url} width="24px" height="24px" />
          <span>Career &amp; Business</span>
        </div>
      </a>
    </div>
  );
};

export default CollectionCategory;
