import React from 'react';
import CollectionCategory from '../CollectionCategory/CollectionCategory';
import styles from './styles.module.scss';

const CollectionCategoryLayout = () => {
  return (
    <section className={styles.categorylayout}>
      <p className={styles.categoryHeading}>
        Looking for more ? Checkout these popular categories
      </p>
      <CollectionCategory />
    </section>
  );
};

export default CollectionCategoryLayout;
