import dynamic from 'next/dynamic';
import React from 'react';
import CollectionBanner from './CollectionBanner/CollectionBanner';
// import CollectionCategoryLayout from './CollectionCategoryLayout/CollectionCategoryLayout';
import CollectionSections from './CollectionSections/CollectionSections';
import styles from './styles.module.scss';

const BitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

const CollectionLayout = () => {
  return (
    <>
      <header>
        <BitAppHeader />
      </header>

      <section id="CollectionSection" className={styles.collectionLayout}>
        <CollectionBanner />
        <CollectionSections />
      </section>
    </>
  );
};

export default CollectionLayout;
