import React, { FC } from 'react';
import { useDynamicSection } from 'hooks/useDynamicSection';
import RectangularSkeletonLoader from 'src/components/profile/RectangularSkeletonLoader/RectangularSkeletonLoader';
import { AppState, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import CourseCardV2 from 'src/components/common/CourseCard/CourseCardV2/CourseCardV2';
import styles from './styles.module.scss';

interface CollectionCoursesProps {
  source: string;
  heading?: string;
}

const CollectionCourses: FC<CollectionCoursesProps> = ({ source, heading }) => {
  const { results, isLoading, fetchData, nextUrl } = useDynamicSection({
    source,
  });

  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );
  return (
    <div className={styles.collectionCoursesWrapper}>
      {isLoading && <RectangularSkeletonLoader height={isMobile ? 600 : 340} />}
      <div className={styles.coursesList}>
        {results?.map((courseDetails: any, index) => (
          <CourseCardV2
            sectionHeading={heading}
            item={{ ...courseDetails, position: index + 1 }}
          />
        ))}
      </div>
      <div className={styles.buttonContainer}>
        {nextUrl && (
          <BitButton id="show-more" onClick={fetchData} variant="outlined">
            {isLoading ? 'Loading...' : 'Show More'}
          </BitButton>
        )}
      </div>
    </div>
  );
};

export default CollectionCourses;
CollectionCourses.defaultProps = {
  heading: '',
};
