import React from 'react';
import { AppState, useAppSelector } from 'redux/store';
import BitFeaturedCarousel from 'src/components/common/BitFeaturedCarousel/BitFeaturedCarousel';
import clsx from 'clsx';
import CollectionCourses from './CollectionCourses/CollectionCourses';
// import CourseCard from 'src/components/CDP/CourseCard/CourseCard/CourseCard';x
import styles from './styles.module.scss';

const CollectionSections = () => {
  const {
    categoryData: { sections },
  } = useAppSelector((state: AppState) => state.category);

  const renderHeaderText = () => {
    if (sections?.length === 2) {
      return 'All Courses';
    }
    return '';
  };

  return (
    <div className={styles.collectionSectionWrapper}>
      {sections?.map(({ heading, source, type }: any) => {
        let result;

        if (type === 'FeaturedCourses') {
          result = (
            <div key={heading} className={styles.sectionContainer}>
              <BitFeaturedCarousel heading={heading} source={source} />
            </div>
          );
        }

        if (type === 'CourseCards') {
          result = (
            <div
              className={clsx(
                styles.sectionContainer,
                styles.sectionContainerOne,
              )}
            >
              <h2>{renderHeaderText()}</h2>
              <CollectionCourses heading={heading} source={source} />
            </div>
          );
        }
        return result;
      })}
    </div>
  );
};

export default CollectionSections;
