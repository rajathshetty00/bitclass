import { IAboutTeacherContent } from 'interfaces/curriculumCdp/aboutTeacher';
import { FC } from 'react';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import SeeMore from 'src/components/common/SeeMore/SeeMore';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';
import styles from './styles.module.scss';

interface IAboutTeacherData {
  sectionData: IAboutTeacherContent;
}

const OVERLAY_COLOR = 'rgb(0,0,0,1)';

const AboutTeacher: FC<IAboutTeacherData> = ({ sectionData }) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const { title, subtitle, description, image } = sectionData;

  return (
    <>
      <section id="about_teacher" className={styles.aboutTeacherContainer}>
        {isMobile && (
          <>
            {/*  */}
            <CurriculumTitle className={styles.aboutHeading}>
              {title}
            </CurriculumTitle>
            <h1 className={styles.teacherName}>{subtitle}</h1>
          </>
        )}
        <div className={styles.teacherProfileImage}>
          <NextImage
            className={styles.teacherProfileImage}
            src={image}
            width={isMobile ? 180 : 300}
            height={isMobile ? 180 : 300}
          />
        </div>
        <div className={styles.teacherDetail}>
          {!isMobile && (
            <>
              <CurriculumTitle className={styles.aboutHeading}>
                {title}
              </CurriculumTitle>
              <h1 className={styles.teacherName}>{subtitle}</h1>
            </>
          )}
          <SeeMore
            text={description}
            size={isMobile ? 10 : 20}
            overlayColor={OVERLAY_COLOR}
            bgColor="transparent"
            customClass={styles.seeMoreWrapper}
          >
            <span
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{
                __html: description,
              }}
            />
          </SeeMore>
        </div>
      </section>
    </>
  );
};

export default AboutTeacher;
