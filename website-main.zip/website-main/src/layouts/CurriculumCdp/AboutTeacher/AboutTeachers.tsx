import {
  IAboutTeacher,
  IAboutTeacherContent,
} from 'interfaces/curriculumCdp/aboutTeacher';
import { FC } from 'react';
import { useSelector } from 'react-redux';
import { AppState, useAppSelector } from 'redux/store';
import BitPureCarousel from 'src/components/common/BitCarousel/BitCarousel';
import { findCarouselCount, getCurriculumGTMData } from 'utils';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';
import AboutTeacher from './AboutTeacher';
import CarouselTeacher from './CarouselTeacher';
import styles from './carouselTeacher.module.scss';

interface IAboutTeacherData {
  sectionData: IAboutTeacher;
}

const AboutTeachers: FC<IAboutTeacherData> = ({ sectionData }) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const { course } = useAppSelector((state: AppState) => state.cdp);

  const { title, subtitle, content } = sectionData;

  const carouselSettings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: isMobile ? 1 : 3,
    centered: true,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 2000,
    swipeToSlide: true,
    arrows: !isMobile,
    beforeChange: (currentSlide: number, nextSlide: number) => {
      saveGtmDataLayerData({
        event: EVENT_NAMES.TEACHER_SHOWCASE_SCROLLED,
        curriculumCdpDetails: getCurriculumGTMData(course, {
          direction: nextSlide > currentSlide ? 'right' : 'left',
          count: findCarouselCount(nextSlide, currentSlide, isMobile),
        }),
      });
    },
  };
  return (
    <div className={styles.teacherCarousel}>
      {content.length > 1 ? (
        <>
          <CurriculumTitle className={styles.teacherCarouselTitle}>
            {title}
          </CurriculumTitle>
          <h3 className={styles.curriculumSubTitle}>{subtitle}</h3>

          <BitPureCarousel carouselSettings={carouselSettings}>
            {content.map((teacherData: IAboutTeacherContent) => (
              <CarouselTeacher
                sectionData={teacherData}
                key={teacherData.title}
              />
            ))}
          </BitPureCarousel>
        </>
      ) : (
        <AboutTeacher sectionData={content[0]} />
      )}
    </div>
  );
};

export default AboutTeachers;
