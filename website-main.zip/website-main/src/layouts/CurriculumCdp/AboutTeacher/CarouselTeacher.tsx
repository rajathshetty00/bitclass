import { IAboutTeacherContent } from 'interfaces/curriculumCdp/aboutTeacher';
import { FC } from 'react';
import SeeMore from 'src/components/common/SeeMore/SeeMore';
import { optimizeCloudinaryImage } from 'utils';
import styles from './carouselTeacher.module.scss';

interface IAboutTeacherData {
  sectionData: IAboutTeacherContent;
}

const OVERLAY_COLOR = 'rgb(0,0,0,1)';

const CarouselTeacher: FC<IAboutTeacherData> = ({ sectionData }) => {
  const { subtitle, description, image } = sectionData;

  return (
    <>
      <section id="about_teacher" className={styles.aboutTeacherContainer}>
        <div
          className={styles.teacherProfileImage}
          style={{
            background: `linear-gradient(180deg, #070D1D 0%, rgba(7, 13, 29, 0) 0.01%, #070D1D 100%), url('${optimizeCloudinaryImage(
              { src: image, width: 280, quality: 60 },
            )}')`,
            backgroundSize: 'cover',
            backgroundPosition: 'top center',
            backgroundRepeat: 'no-repeat',
          }}
        >
          <h1 className={styles.teacherName}>{subtitle}</h1>
        </div>
        <div className={styles.teacherDetail}>
          <SeeMore
            text={description}
            size={10}
            overlayColor={OVERLAY_COLOR}
            bgColor="transparent"
            customClass={styles.aboutDescription}
          >
            <span
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{
                __html: description,
              }}
            />
          </SeeMore>
        </div>
      </section>
    </>
  );
};

export default CarouselTeacher;
