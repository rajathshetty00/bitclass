import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { CurriculumCdpInnerLayout } from 'src/layouts/CurriculumCdp/CurriculumCdpMainLayout/CurriculumCdpMainLayout';
import CurriculumTitle from 'src/layouts/CurriculumCdp/CurriculumTitle/CurriculumTitle';
import { ICertificate } from 'interfaces/curriculumCdp/certificate';
import styles from './styles.module.scss';

interface IcertificateData {
  sectionData: ICertificate;
}

const CurriculumAward = ({ sectionData }: IcertificateData) => {
  const { title, subtitle, description, image } = sectionData;
  return (
    <CurriculumCdpInnerLayout>
      <section
        id="curriculum-award"
        className={styles.curriculumAwardContainer}
      >
        <div className={styles.titleSection}>
          <CurriculumTitle className={styles.awardTitle}>
            {title}
          </CurriculumTitle>
          <p className={styles.awardDescription}>{description}</p>
          <q className={styles.awardQuotes}>{subtitle}</q>
        </div>
        <div className={styles.awardImage}>
          <NextImage
            src={image || assetObject.award}
            width={600}
            height={360}
          />
        </div>
      </section>
    </CurriculumCdpInnerLayout>
  );
};

export default CurriculumAward;
