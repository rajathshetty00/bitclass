import { useSelector } from 'react-redux';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { AppState } from 'redux/store';
import { IBanner } from 'interfaces/curriculumCdp/banner';
import getCurriculumCDPDetails from 'utils/cdp/curriculumCdpData';
import SeeMore from 'src/components/common/SeeMore/SeeMore';
import BannerVideo from './BannerVideo/BannerVideo';

import styles from './styles.module.scss';

interface ICurriculumBannerContent extends IBanner {
  heading: string;
  goal: string;
}
const OVERLAY_COLOR = 'rgb(0,0,0,1)';

const CurriculumBanner = () => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const { course } = useSelector((state: AppState) => state.cdp);

  const {
    heading,
    goal,
    intro_video_thumbnail,
    intro_video,
  }: ICurriculumBannerContent = getCurriculumCDPDetails(course);

  const bgImage = intro_video_thumbnail ?? '';

  const bannerVideoContent: IBanner = { intro_video_thumbnail, intro_video };
  return (
    <div className={styles.bannerContainer}>
      {isMobile && <div className={styles.gradient} />}
      {isMobile && (
        <NextImage
          className={styles.bgImage}
          src={bgImage}
          width="350"
          height="200"
          layout="fill"
          objectPosition="top"
          quality={5}
          priority
          loading="eager"
        />
      )}
      <BannerVideo videoData={bannerVideoContent} />
      <section className={styles.titleSections}>
        <div className={styles.liveCourseContainer}>
          <span>
            <NextImage
              src={assetObject.redImg}
              className={styles.liveLabelIcon}
              width={30}
              height={20}
              quality={10}
              loading="lazy"
            />
          </span>
          <span className={styles.liveLabel}>LIVE CLASS</span>
        </div>
        <h1 className={styles.title}>{heading}</h1>
        {!isMobile && (
          <SeeMore
            text={goal}
            size={isMobile ? 10 : 15}
            overlayColor={OVERLAY_COLOR}
            bgColor="transparent"
            customClass={styles.introDescription}
          >
            <span
              // eslint-disable-next-line react/no-danger
              dangerouslySetInnerHTML={{
                __html: goal,
              }}
            />
          </SeeMore>
        )}
      </section>
    </div>
  );
};

export default CurriculumBanner;
