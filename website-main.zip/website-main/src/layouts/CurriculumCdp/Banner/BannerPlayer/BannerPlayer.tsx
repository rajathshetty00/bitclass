import clsx from 'clsx';
import ReactPlayer from 'react-player';
import styles from './styles.module.scss';

interface IBannerPlayer {
  videoRef: any;
  customClass?: string;
  url: string;
}
const BannerPlayer = ({ videoRef, customClass, url }: IBannerPlayer) => {
  const handleError = () => {
    console.log('Error while playing video');
  };
  return (
    <>
      {url && (
        <ReactPlayer
          ref={videoRef}
          className={clsx(styles.courseVideo, customClass)}
          // className={styles.courseVideo}
          width="100%"
          height="100%"
          controls
          loop={false}
          autoplay
          playing
          url={url}
          onError={handleError}
        />
      )}
    </>
  );
};
BannerPlayer.defaultProps = {
  customClass: '',
};

export default BannerPlayer;
