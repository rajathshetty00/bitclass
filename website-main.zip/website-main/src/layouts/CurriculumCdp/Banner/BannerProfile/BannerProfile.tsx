import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

const BannerProfile = () => {
  return (
    <section className={styles.profileSection}>
      <NextImage
        className={styles.avtarImg}
        src={assetObject.profileImg}
        width={60}
        height={60}
      />
      <div className={styles.profileNameSection}>
        <p className={styles.profilewithlabel}>with </p>
        <p className={styles.userName}>Sainuka Saini</p>
      </div>
    </section>
  );
};

export default BannerProfile;
