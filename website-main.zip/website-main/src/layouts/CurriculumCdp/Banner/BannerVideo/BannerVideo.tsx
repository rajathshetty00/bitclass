import { setIsModelVisibleState } from 'redux/reducers/appReducer';
import { useRef } from 'react';

import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import BitModelComponent from 'src/components/common/BitModelComponent/BitModelComponent';
import clsx from 'clsx';
import { IBanner } from 'interfaces/curriculumCdp/banner';
import BannerPlayer from '../BannerPlayer/BannerPlayer';
import styles from './styles.module.scss';

const PLAY_ICON =
  'https://res.cloudinary.com/bitclass/image/upload/w_256,q_75/v1629453393/Assets/empty-image/playButtonWhite_l07ghh.webp';
interface IBannerVideo {
  videoData: IBanner;
}

const BannerVideo = ({ videoData }: IBannerVideo) => {
  const { isModelVisible } = useAppSelector((state: AppState) => state.app);
  const { intro_video, intro_video_thumbnail } = videoData;

  const dispatch = useAppDispatch();
  const vidRef = useRef<any>(null);
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const bgImage = intro_video_thumbnail ?? '';

  const openVideoModel = () => dispatch(setIsModelVisibleState(true));

  const closeVideoModel = () => dispatch(setIsModelVisibleState(false));

  return (
    <section className={styles.videoSection}>
      {!isMobile && (
        <NextImage
          className={styles.bgImage}
          src={bgImage}
          layout="fill"
          quality={30}
          priority
        />
      )}
      {intro_video && (
        <NextImage
          className={styles.playIcon}
          width={70}
          height={70}
          src={PLAY_ICON}
          onClick={openVideoModel}
        />
      )}
      <BitModelComponent
        handleClose={closeVideoModel}
        isModalOpen={isModelVisible}
        className={clsx({ [styles.videoModelContainer]: isModelVisible })}
      >
        {intro_video && <BannerPlayer videoRef={vidRef} url={intro_video} />}
      </BitModelComponent>
    </section>
  );
};

export default BannerVideo;
