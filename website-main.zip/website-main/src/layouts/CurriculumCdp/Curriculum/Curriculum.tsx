import { ICurriculum } from 'interfaces/curriculumCdp/curriculum';
import { assetObject } from 'utils/assetFileNames';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';
import CurriculumList from './CurriculumList/CurriculumList';
import CurriculumSummary from './CurriculumSummary/CurriculumSummary';
import styles from './styles.module.scss';

interface ICurriculumData {
  sectionData: ICurriculum;
}

const Curriculum = ({ sectionData }: ICurriculumData) => {
  const { title, subtitle, duration, content } = sectionData;
  const { bgImage } = assetObject;
  return (
    <section
      className={styles.curriculumContainer}
      id="curriculum-content"
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundPosition: 'center',
      }}
    >
      <CurriculumTitle className={styles.curriculumTitle}>
        {title}
      </CurriculumTitle>
      <h3 className={styles.curriculumSubTitle}>{subtitle}</h3>
      <CurriculumSummary />
      <CurriculumList duration={duration} content={content} />
    </section>
  );
};

export default Curriculum;
