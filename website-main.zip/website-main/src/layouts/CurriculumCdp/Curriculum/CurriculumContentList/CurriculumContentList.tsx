import { FC } from 'react';

import styles from './styles.module.scss';

interface ICurriculumList {
  contentList: string[];
  index: number;
  isMore: any;
}

const CurriculumContentList: FC<ICurriculumList> = ({
  contentList,
  index,
  isMore,
}) => {
  const DEFAULT_NO_OF_ITEMS = index === 0 ? 2 : 0;

  const contentLength = isMore[index]
    ? contentList.length
    : DEFAULT_NO_OF_ITEMS;
  // const showIcons = contentList.length > 2;

  return (
    <div id="curriculum-content">
      {contentList.slice(0, contentLength).map((content) => {
        return (
          <div className={styles.curriculumContentContainer} key={content}>
            {content}
          </div>
        );
      })}
    </div>
  );
};

export default CurriculumContentList;
