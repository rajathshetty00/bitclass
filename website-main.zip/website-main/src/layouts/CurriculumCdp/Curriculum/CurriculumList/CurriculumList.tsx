import useCheckout from 'hooks/useCheckout';
import { ICurriculumContent } from 'interfaces/curriculumCdp/curriculum';
import { useState } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import ShowMoreLess from 'src/layouts/CurriculumCdp/Curriculum/CurriculumList/ShowMoreLess';
import { getCurriculumGTMData } from 'utils';
import CurriculumContentList from '../CurriculumContentList/CurriculumContentList';
import styles from './styles.module.scss';

interface ICurriculumList {
  duration: string;
  content: ICurriculumContent[];
}

export interface IIsMore {
  [key: number]: boolean;
}
const CurriculumList = ({
  duration,
  content: curriculumListData,
}: ICurriculumList) => {
  const { initiatePaidCheckout, getFullCourseButtonText } = useCheckout();

  const { course } = useAppSelector((state: AppState) => state.cdp);
  const { has_full_course_ended } = course;

  const [isMore, setIsMore] = useState<IIsMore>({});

  const handlePaidRegistrationClick = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.BUY_FULL_COURSE_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, {
        location: 'curriculum_bottom',
      }),
    });
    initiatePaidCheckout();
  };

  const handleIsMore = (index: number) => {
    const updatedIsMore: any = { ...isMore };
    if (updatedIsMore[index]) updatedIsMore[index] = !updatedIsMore[index];
    else updatedIsMore[index] = true;
    setIsMore(updatedIsMore);
  };

  return (
    <div className={styles.curriculumListContainer}>
      <div className={styles.topSection}>
        <span className={styles.curriculumDuration}>{duration}</span>
      </div>
      {curriculumListData.map(({ title, thumbnail_text, items }, index) => {
        return (
          <div className={styles.curriculumContent} key={title}>
            <div className={styles.curriculumListHeading}>{thumbnail_text}</div>
            <h2 className={styles.curriculumTitle}>
              <>{title}</>
              <ShowMoreLess
                handleIsMore={handleIsMore}
                items={items}
                isMore={isMore}
                index={index}
              />
            </h2>
            <CurriculumContentList
              contentList={items}
              index={index}
              isMore={isMore}
            />
          </div>
        );
      })}
      {!has_full_course_ended && (
        <div className={styles.bottomBuyBtn}>
          <BitButton
            variant="contained"
            className="shimmerButton bottomBtn"
            onClick={handlePaidRegistrationClick}
          >
            {getFullCourseButtonText()}
          </BitButton>
        </div>
      )}
    </div>
  );
};

export default CurriculumList;
