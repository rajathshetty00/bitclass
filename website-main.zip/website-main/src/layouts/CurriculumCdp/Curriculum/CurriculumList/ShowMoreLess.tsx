import { FC } from 'react';
import { ChevronDown, ChevronUp } from 'react-feather';
import { IIsMore } from './CurriculumList';

import styles from './styles.module.scss';

interface IProps {
  handleIsMore: Function;
  items: Array<any>;
  isMore: IIsMore;
  index: number;
}
const ShowMoreLess: FC<IProps> = ({ handleIsMore, items, index, isMore }) => {
  return (
    <div>
      {items?.length > 2 && (
        <button
          type="button"
          className={styles.listBtn}
          onClick={() => handleIsMore(index)}
        >
          <span>
            {isMore[index] ? (
              <ChevronUp className={styles.btnIcon} />
            ) : (
              <ChevronDown className={styles.btnIcon} />
            )}
          </span>
          {/* {isMore ? 'Hide Details' : 'Show Details'} */}
        </button>
      )}
    </div>
  );
};

export default ShowMoreLess;
