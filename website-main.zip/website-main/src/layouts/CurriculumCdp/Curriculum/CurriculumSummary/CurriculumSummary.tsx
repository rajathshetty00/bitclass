import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import clsx from 'clsx';
import useCheckout from 'hooks/useCheckout';
import { AppState, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import Features from 'src/layouts/CDP/RightStickySection/Subscription/Features/Features';
import { getCurriculumGTMData } from 'utils';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';

const CurriculumSummary = () => {
  const { course } = useAppSelector((state: AppState) => state.cdp);
  const { sections, full_course_amount, has_full_course_ended } = course;
  const { title, content } = sections?.curriculum_details;

  const { initiatePaidCheckout, getFullCourseButtonText } = useCheckout();
  // const actualGtmData = useCurriclumGtmData({ location: 'curriculum_top' });

  const handlePaidRegistrationClick = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.BUY_FULL_COURSE_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, {
        location: 'curriculum_top',
      }),
    });
    initiatePaidCheckout();
  };

  return (
    <div className={styles.curriculumSummary}>
      <div className={styles.summary}>
        <h1>{title}</h1>
        <div>
          {content.map((item: string) => (
            <div className={styles.details} key={item}>
              <CheckCircleIcon color="primary" />
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>

      <div className={styles.payments}>
        {full_course_amount && <h1>INR {full_course_amount}</h1>}
        {!has_full_course_ended && (
          <BitButton
            variant="contained"
            className={clsx(styles.butBtn, 'shimmerButton')}
            onClick={handlePaidRegistrationClick}
          >
            {getFullCourseButtonText()}
          </BitButton>
        )}
        <Features customClass={styles.features} />
      </div>
    </div>
  );
};

export default CurriculumSummary;
