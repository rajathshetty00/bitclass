import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { useEffect } from 'react';
import getCurriculumCDPDetails from 'utils/cdp/curriculumCdpData';
import CheckoutModal from 'src/components/CDP/CheckoutModal/CheckoutModal';
import CurriculumAward from 'src/layouts/CurriculumCdp/Award/Award';
import CurriculumCdpFeature from 'src/layouts/CurriculumCdp/CurriculumCdpfeature/CurriculumCdpFeature';
import WhyPopular from 'src/layouts/CurriculumCdp/WhyPopular/WhyPopular';
import Summary from 'src/layouts/CurriculumCdp/Summary/Summary';
import StudentGalleryCarousel from 'src/layouts/CurriculumCdp/StudentGallery/StudentGalleryCarousel';
import FreeSyllabus from 'src/layouts/CurriculumCdp/FreeSyllabus/FreeSyllabus';
import CurriculumBanner from 'src/layouts/CurriculumCdp/Banner/Banner';
import Curriculum from 'src/layouts/CurriculumCdp/Curriculum/Curriculum';
import Testimonial from 'src/layouts/CurriculumCdp/Testimonial/Testimonial';
import CurriculumFaq from 'src/layouts/CurriculumCdp/CurriculumFaq/CurriculumFaq';
import WhyBitClass from 'src/layouts/CurriculumCdp/WhyBitclas';
import { hasAuthToken } from 'utils/auth/userInfo';
import { actionCheckRegistration } from 'redux/actions/cdpActions';
import RegistrationModal from 'src/layouts/CDP/components/RegistrationModal/RegistrationModal';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { getCurriculumGTMData, isEmptyObject } from 'utils';
import styles from './styles.module.scss';
import MobileStickyButtons from '../MobileStickyButtons/MobileStickyButtons';
import FreeCoursesModal from '../FreeCoursesModal/FreeCoursesModal';
import AboutTeachers from '../AboutTeacher/AboutTeachers';

const CurriculumCdpLayout = () => {
  const { course } = useAppSelector((state: AppState) => state.cdp);
  const dispatch = useAppDispatch();
  const { sections } = getCurriculumCDPDetails(course);
  const {
    featured,
    why_bitclass,
    faqs,
    teachers,
    testimonials,
    why_buy,
    freeclass_curriculum,
    showcase,
    curriculum,
    certificate,
  } = sections;
  useEffect(() => {
    if (hasAuthToken()) dispatch(actionCheckRegistration(course?.code));
  }, [course?.code, dispatch]);

  useEffect(() => {
    if (!isEmptyObject(course)) {
      saveGtmDataLayerData({
        event: EVENT_NAMES.CURRICULUM_CDP_LANDED,
        curriculumCdpDetails: getCurriculumGTMData(course),
      });
    }
  }, [course]);

  return (
    <div className={styles.curriculumCdpLayoutContainer}>
      <div className={styles.bannerWrapper}>
        <CurriculumBanner />
        <Summary />
      </div>
      {/* why the course is popular section */}
      {why_buy && <WhyPopular sectionData={why_buy} />}
      {/* Free Syllabus component */}
      {freeclass_curriculum && (
        <FreeSyllabus sectionData={freeclass_curriculum} />
      )}
      {/* reward or certificate component here */}
      {certificate && <CurriculumAward sectionData={certificate} />}
      {/* student gallery component */}
      {showcase && <StudentGalleryCarousel sectionData={showcase} />}
      {/* Full couse curriculum component */}
      {curriculum && <Curriculum sectionData={curriculum} />}
      {/* testimonial component */}
      {testimonials && <Testimonial sectionData={testimonials} />}
      {/* About teacher component */}

      {teachers && <AboutTeachers sectionData={teachers} />}
      {/* Why bitclass popular component */}
      {why_bitclass && <WhyBitClass sectionData={why_bitclass} />}
      {/* Course Feature component */}
      {featured && <CurriculumCdpFeature sectionData={featured} />}
      {/* Faq component  */}
      {faqs && <CurriculumFaq sectionData={faqs} />}
      <MobileStickyButtons />
      {course?.category && <FreeCoursesModal />}
      <CheckoutModal />
      <RegistrationModal />
    </div>
  );
};

export default CurriculumCdpLayout;
