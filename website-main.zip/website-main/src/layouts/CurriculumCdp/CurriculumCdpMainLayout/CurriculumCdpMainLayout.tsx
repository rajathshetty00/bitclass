import { ReactNode, FC } from 'react';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

interface IMainLayout {
  children: ReactNode;
}

export const CurriculumCdpMainLayout: FC<IMainLayout> = ({ children }) => {
  const { bgImage } = assetObject;
  return (
    <main
      className={styles.mainLayout}
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundPosition: 'center',
      }}
    >
      {children}
    </main>
  );
};

export const CurriculumCdpInnerLayout: FC<IMainLayout> = ({ children }) => {
  return <main className={styles.innerLayout}>{children}</main>;
};
