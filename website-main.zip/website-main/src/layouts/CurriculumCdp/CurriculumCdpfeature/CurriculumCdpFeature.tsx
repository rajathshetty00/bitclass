import { IFeatured } from 'interfaces/curriculumCdp/feature';
import { FC } from 'react';
import { assetObject } from 'utils/assetFileNames';
import NextImage from '../../../components/common/NextImage/NextImage';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';
import AwardSection from './GoogleAward/AwardSection';
import styles from './styles.module.scss';

interface ICurriculumCdpFeature {
  sectionData: IFeatured;
}

const CurriculumCdpFeature: FC<ICurriculumCdpFeature> = ({ sectionData }) => {
  const { content, title } = sectionData;
  const { bgImage } = assetObject;
  return (
    <section
      id="curriculum_CDP_Feature"
      className={styles.featureContainer}
      style={{ backgroundImage: `url(${bgImage})` }}
    >
      <CurriculumTitle className={styles.featureHeading}>
        {title}
      </CurriculumTitle>
      <div className={styles.featureContent}>
        {content.map(({ image, link }) => {
          return (
            <div className={styles.featureItemContainer} key={image}>
              <div className={styles.featureItem}>
                <a href={link} target="_blank" rel="noreferrer">
                  <NextImage
                    src={image}
                    className={styles.featureImage}
                    width={150}
                    height={60}
                    quality={50}
                    objectFit="contain"
                  />
                </a>
              </div>
            </div>
          );
        })}
      </div>
      <AwardSection />
    </section>
  );
};

export default CurriculumCdpFeature;
