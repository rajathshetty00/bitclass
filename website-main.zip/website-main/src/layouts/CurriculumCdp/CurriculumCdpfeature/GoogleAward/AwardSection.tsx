import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import CurriculumTitle from '../../CurriculumTitle/CurriculumTitle';
import styles from './styles.module.scss';

const AwardSection = () => {
  return (
    <div className={styles.awardContainer}>
      <CurriculumTitle className={styles.awardHeading}>
        .. and awarded the Google Play App of the Year, 2021
      </CurriculumTitle>
      <div className={styles.awardDetails}>
        <NextImage
          src={assetObject.googleAward}
          width="500"
          height="300"
          objectFit="contain"
          quality={60}
          className={styles.awardImage}
        />
        <div className={styles.description}>
          <p>
            BitClass has been recognized by Google Play for its strong
            commitment towards online LIVE learning:
          </p>
          <ul>
            <li>Best App of the Year, 2021</li>
            <li>Best App for Personal Growth, 2021</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AwardSection;
