import { ICurriculumCdpFaq } from 'interfaces/curriculumCdp/curriculumFaq';
import React from 'react';
import { AppState, useAppSelector } from 'redux/store';
import Faqs from 'src/layouts/CDP/Faq/Faqs';
import { getCurriculumGTMData } from 'utils';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';

interface ICurriculumFaq {
  sectionData: ICurriculumCdpFaq;
}

const CurriculumFaq = ({ sectionData }: ICurriculumFaq) => {
  const { content } = sectionData;
  const { course } = useAppSelector((state: AppState) => state.cdp);
  const handleClickExpandFaq = (index: number) => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.FAQ_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, {
        faq_index: index + 1,
      }),
    });
  };
  return (
    <section className={styles.faqContainer}>
      <Faqs
        faqs={content}
        isDefaultIcon={false}
        faqTitle="Still have questions?"
        faqSubTitle="Here are some common ones"
        handleExpandFaq={handleClickExpandFaq}
      />
    </section>
  );
};

export default CurriculumFaq;
