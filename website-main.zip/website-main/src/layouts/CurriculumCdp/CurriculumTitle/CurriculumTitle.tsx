import clsx from 'clsx';
import { FC, ReactNode } from 'react';
import styles from './styles.module.scss';

interface ICurriculumTitle {
  children: ReactNode;
  className?: string;
}

const CurriculumTitle: FC<ICurriculumTitle> = ({ children, className }) => {
  return (
    <h1 className={clsx(className, styles.curriculumTitle)}>{children}</h1>
  );
};

CurriculumTitle.defaultProps = {
  className: '',
};

export default CurriculumTitle;
