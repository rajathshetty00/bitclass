import { FC, useState, useEffect } from 'react';
import { updateBitModalState } from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import CourseCardLite from 'src/components/CDP/CourseCard/CourseCardLite/CourseCardLite';
import { getFreeCourses } from 'utils/api';
import CircularProgress from '@mui/material/CircularProgress';

import { Box, Drawer } from '@mui/material';
import Close from '@mui/icons-material/Close';
import styles from './styles.module.scss';

interface IFreeCoursesProps {}

const FreeCoursesModal: FC<IFreeCoursesProps> = () => {
  const [freeCourses, setFreeCourses] = useState([]);
  const { category } = useAppSelector((state: AppState) => state.cdp.course);
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );

  const dispatch = useAppDispatch();
  const { bitModalState } = useAppSelector((state: AppState) => state.app);
  const handleClose = () => {
    dispatch(updateBitModalState(false));
  };

  useEffect(() => {
    (async () => {
      try {
        const { data } = await getFreeCourses(category);
        setFreeCourses(data);
        if (data.length === 0) dispatch(updateBitModalState(false));
      } catch (error) {
        console.log(error);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  return (
    <Drawer
      className={styles.drawer}
      anchor={isMobile ? 'bottom' : 'right'}
      open={bitModalState}
      onClose={() => dispatch(updateBitModalState(false))}
    >
      <div className={styles.drawerHeader}>
        <h1>Here are some more free classes </h1>
        <Close
          type="button"
          className={styles.closeBtn}
          onClick={handleClose}
        />
      </div>
      <div className={styles.freeCourseCarousel}>
        {freeCourses?.length ? (
          freeCourses.map((course: any) => (
            <CourseCardLite course={course} key={course?.code} />
          ))
        ) : (
          <Box sx={{ display: 'flex', justifyContent: 'center' }}>
            <CircularProgress />
          </Box>
        )}
      </div>
    </Drawer>
  );
};

export default FreeCoursesModal;
