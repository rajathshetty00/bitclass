import { IFreeClass } from 'interfaces/curriculumCdp/freeClass';
import { FC, useState } from 'react';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import CurriculumTitle from 'src/layouts/CurriculumCdp/CurriculumTitle/CurriculumTitle';
import { CurriculumCdpMainLayout } from '../CurriculumCdpMainLayout/CurriculumCdpMainLayout';
import styles from './styles.module.scss';

interface IFreeSyllabus {
  sectionData: IFreeClass;
}

const DEFAULT_MATERIAL_SIZE: number = 3;

const FreeSyllabus: FC<IFreeSyllabus> = ({ sectionData }) => {
  const { title, description, materials_required } = sectionData;
  const [showMore, setShowMore] = useState(false);
  const noOfMaterials = showMore
    ? materials_required.length
    : DEFAULT_MATERIAL_SIZE;

  return (
    <CurriculumCdpMainLayout>
      <section id="FreeSyllabus" className={styles.syllabusContainer}>
        <CurriculumTitle className={styles.syllabusTitle}>
          {title}
        </CurriculumTitle>
        <div className={styles.syllabusCard}>
          <ul
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: description }}
            className={styles.syllabusItems}
          />
          {materials_required && materials_required?.length > 0 && (
            <div className={styles.syllabusMaterials}>
              <h3>Materials Required</h3>
              <ul className={styles.materials}>
                {materials_required
                  .slice(0, noOfMaterials)
                  .map((material: string) => (
                    <li className={styles.material} key={material}>
                      {material}
                    </li>
                  ))}
              </ul>
              {materials_required.length > DEFAULT_MATERIAL_SIZE && (
                <BitButton
                  className={styles.showMore}
                  onClick={() => setShowMore(!showMore)}
                >
                  {showMore ? 'show less' : 'show more'}
                </BitButton>
              )}
            </div>
          )}
        </div>
      </section>
    </CurriculumCdpMainLayout>
  );
};

export default FreeSyllabus;
