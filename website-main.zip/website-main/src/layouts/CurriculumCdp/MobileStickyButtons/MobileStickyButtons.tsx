import { FC } from 'react';
import useCheckout from 'hooks/useCheckout';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import NotifyMeModel from 'src/layouts/CDP/RightStickySection/Components/NotifyMeModel/NotifyMeModel';
import { showNotifyModal } from 'redux/reducers/cdpReducer';
import styles from './styles.module.scss';

const MobileStickyButtons: FC = () => {
  const {
    initiateFreeCheckout,
    initiatePaidCheckout,
    getFreeCourseButtonText,
    getFullCourseButtonText,
  } = useCheckout();
  const { course } = useAppSelector((state: AppState) => state.cdp);

  const dispatch = useAppDispatch();

  const { has_full_course_ended, has_workshop_ended } = course;

  return (
    <div className={styles.checkout}>
      {!has_full_course_ended && has_workshop_ended && (
        <BitButton onClick={initiatePaidCheckout}>
          {getFullCourseButtonText()}
        </BitButton>
      )}
      {!has_workshop_ended && (
        <BitButton
          variant="contained"
          onClick={initiateFreeCheckout}
          className="shimmerButton"
        >
          {getFreeCourseButtonText()}
        </BitButton>
      )}
      {has_workshop_ended && has_full_course_ended && (
        <>
          <BitButton
            variant="contained"
            onClick={() => dispatch(showNotifyModal(true))}
            className={styles.notifyButton}
          >
            Notify
          </BitButton>
          <NotifyMeModel />
        </>
      )}
    </div>
  );
};

export default MobileStickyButtons;
