import { IShowCase, IShowcaseContent } from 'interfaces/curriculumCdp/showCase';
import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import BitPureCarousel from 'src/components/common/BitCarousel/BitCarousel';
import StudentGalleryCard from 'src/layouts/CurriculumCdp/StudentGallery/common/StudentGalleryCard';
import { findCarouselCount, getCurriculumGTMData } from 'utils';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';

interface IStudentGalleryCarouselProps {
  sectionData: IShowCase;
}

const StudentGalleryCarousel: FC<IStudentGalleryCarouselProps> = ({
  sectionData,
}) => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state?.app?.deviceInfo,
  );
  const { course } = useAppSelector((state: AppState) => state.cdp);

  const { title, subtitle, content: studentArray } = sectionData;

  const carouselSettings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: isMobile ? 1.25 : 3,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 2000,
    swipeToSlide: true,
    arrows: !isMobile,
    beforeChange: (currentSlide: number, nextSlide: number) => {
      saveGtmDataLayerData({
        event: EVENT_NAMES.STUDENT_SHOWCASE_SCROLLED,
        curriculumCdpDetails: getCurriculumGTMData(course, {
          direction: nextSlide > currentSlide ? 'right' : 'left',
          count: findCarouselCount(nextSlide, currentSlide, isMobile),
        }),
      });
    },
  };

  return (
    <div className={styles.StudentGalleryWrapper}>
      <h1>{title}</h1>
      <h3 className={styles.curriculumSubTitle}>{subtitle}</h3>
      <BitPureCarousel carouselSettings={carouselSettings}>
        {studentArray.map((item: IShowcaseContent) => (
          <StudentGalleryCard teacher={item} key={item.title} />
        ))}
      </BitPureCarousel>
    </div>
  );
};

export default StudentGalleryCarousel;
