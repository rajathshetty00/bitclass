import { FC } from 'react';
import { optimizeCloudinaryImage } from 'utils';
import styles from '../styles.module.scss';

interface StudentGalleryCardProps {
  teacher: {
    image: string;
    title: string;
    subtitle: string;
  };
}

const StudentGalleryCard: FC<StudentGalleryCardProps> = ({ teacher }) => {
  return (
    <div
      className={styles.studentGalleryCard}
      style={{
        background: `linear-gradient(180deg, #070D1D 0%, rgba(7, 13, 29, 0) 0.01%, #070D1D 100%), url('${optimizeCloudinaryImage(
          {
            src: teacher?.image,
            width: 400,
            quality: 60,
          },
        )}')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      <h4>{teacher?.title}</h4>
      <p>{teacher?.subtitle}</p>
    </div>
  );
};

export default StudentGalleryCard;
