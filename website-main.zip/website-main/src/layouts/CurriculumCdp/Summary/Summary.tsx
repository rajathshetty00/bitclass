import { FC } from 'react';
import useCheckout from 'hooks/useCheckout';
import { useRouter } from 'next/router';
import { AppState, useAppSelector } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import NotifyMeModel from 'src/layouts/CDP/RightStickySection/Components/NotifyMeModel/NotifyMeModel';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { getCurriculumGTMData, getQuery } from 'utils';
import { useBitRouter } from 'src/hooks/useBitRouter';
import styles from './styles.module.scss';

const addtionalObject = { location: 'above_the_fold' };
const Summary: FC = () => {
  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();

  const { asPath: path } = router;

  const getRoute = () =>
    path.includes('curriculum-content') ? path : `${path}#curriculum-content`;

  const { course, courseRegistrationDetails } = useAppSelector(
    (state: AppState) => state.cdp,
  );
  const {
    initiateFreeCheckout,
    initiatePaidCheckout,
    getFullCourseButtonText,
    getFreeCourseButtonText,
  } = useCheckout();
  const { above_the_fold, has_full_course_ended, has_workshop_ended } = course;
  const { course_registration, workshop_registration } =
    courseRegistrationDetails;
  const handleNotfiyOpen = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.CURRICULUM_NOTIFY_ME,
      curriculumCdpDetails: getCurriculumGTMData(course),
    });
  };

  const handlePaidRegistration = () =>
    course_registration
      ? initiatePaidCheckout()
      : appendQueryParamAndNavigate(`${getRoute()}`, getQuery(router), false);

  const handlePaidRegistrationClick = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.BUY_FULL_COURSE_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, addtionalObject),
    });
    handlePaidRegistration();
  };

  const handleFreeCheckout = () => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.BOOK_FREE_CLASS_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, addtionalObject),
    });
    initiateFreeCheckout();
  };

  return (
    <>
      <div className={styles.summary}>
        {above_the_fold?.map(({ heading, subheading }: any) => (
          <div>
            <h5>{heading}</h5>
            <span dangerouslySetInnerHTML={{ __html: subheading }} />
          </div>
        ))}

        <div className={styles.checkout}>
          {course_registration && workshop_registration ? (
            <BitButton
              variant="contained"
              onClick={handlePaidRegistrationClick}
            >
              {getFullCourseButtonText()}
            </BitButton>
          ) : (
            <>
              {!has_full_course_ended && workshop_registration && (
                <BitButton
                  variant={has_workshop_ended ? 'contained' : 'outlined'}
                  onClick={handlePaidRegistrationClick}
                >
                  {getFullCourseButtonText()}
                </BitButton>
              )}
              {!has_workshop_ended && (
                <BitButton
                  variant="contained"
                  onClick={handleFreeCheckout}
                  className="shimmerButton"
                >
                  {getFreeCourseButtonText()}
                </BitButton>
              )}
              {!has_full_course_ended && has_workshop_ended && (
                <BitButton
                  variant="contained"
                  onClick={handleFreeCheckout}
                  className="shimmerButton"
                >
                  {getFullCourseButtonText()}
                </BitButton>
              )}
            </>
          )}

          {has_full_course_ended && has_workshop_ended && (
            <>
              <BitButton
                variant="contained"
                onClick={handleNotfiyOpen}
                className={styles.notifyBitButton}
              >
                <NextImage
                  src={assetObject.whiteBellIcon}
                  width={18}
                  height={18}
                />
                <span>Notify Me</span>
              </BitButton>
              <NotifyMeModel />
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Summary;
