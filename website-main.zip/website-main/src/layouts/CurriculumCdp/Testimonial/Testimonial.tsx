import { FC, useState } from 'react';
import { assetObject } from 'utils/assetFileNames';
import { ITestimonials } from 'interfaces/curriculumCdp/testimonial';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { AppState, useAppSelector } from 'redux/store';
import { getCurriculumGTMData } from 'utils';
import NextImage from '../../../components/common/NextImage/NextImage';
import TestimonialAvatar from './TestimonialAvatar/TestimonialAvatar';
import styles from './styles.module.scss';
import TestimonialCard from './TestimonialVideo/TestimonialVideo';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';

interface ITestimonial {
  sectionData: ITestimonials;
}

const Testimonial: FC<ITestimonial> = ({ sectionData }) => {
  const { title, subtitle, content: testimonials } = sectionData;
  const { course } = useAppSelector((state: AppState) => state.cdp);
  const [isActive, setIsActive] = useState(0);
  const changeIsActive = (ind: number) => {
    setIsActive(ind);
  };
  const handleClickTestimonial = (ind: number) => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.STUDENT_TESTIMONIAL_CLICKED,
      curriculumCdpDetails: getCurriculumGTMData(course, {
        testimonial_index: ind + 1,
      }),
    });
    changeIsActive(ind);
  };

  return (
    <section id="testimonial_section" className={styles.testimonialContainer}>
      <div className={styles.testimonialheadings}>
        <CurriculumTitle className={styles.testimonialTitle}>
          {title}
        </CurriculumTitle>
        <p>{subtitle}</p>
      </div>
      <div className={styles.testimonQuoteIcon}>
        <NextImage
          src={assetObject.testimonialsQuote}
          width={220}
          height={220}
          unoptimized
        />
      </div>
      <TestimonialCard
        name={testimonials[isActive].title}
        description={testimonials[isActive].description}
        videoThumbnail={testimonials[isActive].thumb}
        videoUrl={testimonials[isActive].video}
      />
      <div className={styles.testimonialProfileSections}>
        {testimonials.map(
          ({ title: name, video_thumbnail: profileImage }, ind: number) => {
            return (
              <TestimonialAvatar
                key={name}
                name={name}
                isActive={isActive === ind}
                profileImg={profileImage}
                handleChangeIsActive={() => handleClickTestimonial(ind)}
              />
            );
          },
        )}
      </div>
    </section>
  );
};

export default Testimonial;
