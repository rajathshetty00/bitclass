import clsx from 'clsx';
import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import styles from './styles.module.scss';

interface iTestimonialAvatar {
  isActive: boolean;
  name: string;
  profileImg: string;
  handleChangeIsActive: any;
}

const TestimonialAvatar: FC<iTestimonialAvatar> = ({
  isActive = false,
  name,
  profileImg,
  handleChangeIsActive,
}) => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );
  return (
    <div className={styles.testimonialAvatarContainer}>
      <span className={styles.avatarImg}>
        <NextImage
          src={profileImg}
          width={56}
          height={56}
          quality={30}
          className={clsx({ [styles.isActive]: isActive })}
          onClick={handleChangeIsActive}
          objectFit="cover"
        />
      </span>
      {!isMobile && isActive && (
        <div className={styles.profileDetail}>
          <h4>{name}</h4>
          <p>Bitclass Student</p>
        </div>
      )}
    </div>
  );
};

export default TestimonialAvatar;
