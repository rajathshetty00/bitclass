import { FC, useRef, useState } from 'react';
import BitModelComponent from 'src/components/common/BitModelComponent/BitModelComponent';
import NextImage from 'src/components/common/NextImage/NextImage';
import BannerPlayer from 'src/layouts/CurriculumCdp/Banner/BannerPlayer/BannerPlayer';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

interface iTestimonialCard {
  name: string;
  videoThumbnail?: string;
  description: string;
  videoUrl?: string | null;
}

const TestimonialCard: FC<iTestimonialCard> = ({
  name,
  videoThumbnail,
  description,
  videoUrl,
}) => {
  const [isModalVisible, setIsModalVisible] = useState(false);

  const videoRef = useRef();
  const cardStyleObj = {
    backgroundImage: `url(${videoThumbnail})`,
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    width: '100%',
    // transition: 'all 0.3s ease-in-out',
  };

  const openVideoModel = () => {
    setIsModalVisible(true);
  };
  const closeVideoModel = () => {
    setIsModalVisible(false);
  };
  const playImageIcon =
    'https://res.cloudinary.com/bitclass/image/upload/w_256,q_75/v1629453393/Assets/empty-image/playButtonWhite_l07ghh.webp';

  return (
    <div className={styles.testimonialCardContainer}>
      {videoUrl && (
        <div className={styles.cardVideoSection} style={cardStyleObj}>
          <div className={styles.playIcon}>
            <NextImage
              width={40}
              height={40}
              src={playImageIcon}
              onClick={openVideoModel}
            />
          </div>
        </div>
      )}
      <div className={styles.cardDescription}>
        <NextImage
          unoptimized
          src={assetObject.quoteMark}
          width={20}
          height={20}
        />
        <h4 className={styles.cardTitle}>{name}</h4>
        <p className={styles.cardDetail}>{description}</p>
      </div>
      {videoUrl && (
        <BitModelComponent
          handleClose={closeVideoModel}
          isModalOpen={isModalVisible}
          className={styles.videoModelContainer}
        >
          <BannerPlayer videoRef={videoRef} url={videoUrl} />
        </BitModelComponent>
      )}
    </div>
  );
};

TestimonialCard.defaultProps = {
  videoThumbnail: '',
  videoUrl: '',
};

export default TestimonialCard;
