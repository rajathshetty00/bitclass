import { IWhyBitclassContent } from 'interfaces/curriculumCdp/whyBitclass';
import { FC } from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import styles from './styles.module.scss';

interface IWhyBitclassList {
  contentList: IWhyBitclassContent[];
}

const WhyBitclassList: FC<IWhyBitclassList> = ({ contentList }) => {
  return (
    <div className={styles.whyBitclasslistContainer}>
      <div className={styles.contentList}>
        {contentList.map(({ image, title }) => {
          return (
            <div className={styles.contentListItem} key={title}>
              <div className={styles.imageContainer}>
                <NextImage
                  objectFit="contain"
                  src={image}
                  width={80}
                  height={80}
                />
              </div>
              <span>{title}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default WhyBitclassList;
