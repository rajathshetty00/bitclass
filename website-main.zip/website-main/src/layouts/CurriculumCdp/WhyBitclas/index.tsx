import { assetObject } from 'utils/assetFileNames';
import {
  IWhyBitclass,
  IWhyBitclassContent,
} from 'interfaces/curriculumCdp/whyBitclass';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import WhyBitclassList from './WhyBitclassList/WhyBitclassList';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';
import styles from './styles.module.scss';

interface IWhyBitclassList {
  content: IWhyBitclassContent[];
}
interface IWhyBitclassData {
  sectionData: IWhyBitclass;
}

const WhyBitclassListRender = ({ content }: IWhyBitclassList) => {
  const columnFirstContent = content.slice(0, 3);
  return (
    <div className={styles.whyContentList}>
      <WhyBitclassList contentList={columnFirstContent} />
      <WhyBitclassList contentList={content.slice(3)} />
    </div>
  );
};

const WhyBitClass = ({ sectionData }: IWhyBitclassData) => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const { bgImage } = assetObject;
  const { content } = sectionData;

  return (
    <section
      className={styles.whyBitClassContainer}
      style={{
        backgroundImage: `url(${bgImage})`,
        backgroundPosition: 'center',
      }}
    >
      <div className={styles.whyBitHeader}>
        <div>
          {isMobile && (
            <CurriculumTitle className={styles.whyBitclassTitle}>
              Why Bitclass ?
            </CurriculumTitle>
          )}
          {!isMobile && (
            <CurriculumTitle className={styles.whyBitclassFullTitle}>
              Why take this course on BitClass ?
            </CurriculumTitle>
          )}
          {!isMobile && <WhyBitclassListRender content={content} />}
        </div>
      </div>
      {isMobile && <WhyBitclassListRender content={content} />}
    </section>
  );
};

export default WhyBitClass;
