import { FC } from 'react';
import { IWhyBuyContent } from 'interfaces/curriculumCdp/whyBuy';
import { assetObject } from 'utils/assetFileNames';
import NextImage from 'src/components/common/NextImage/NextImage';
import CurriculumTitle from '../CurriculumTitle/CurriculumTitle';
import styles from './styles.module.scss';

interface IWhyPopularData {
  sectionData: IWhyBuyContent;
}

const WhyPopular: FC<IWhyPopularData> = ({ sectionData }) => {
  const { title, subtitle, description, image } = sectionData;
  return (
    <section className={styles.whyPopularContainer} id="whyPopularContainer">
      <CurriculumTitle className={styles.whyPopularTitle}>
        {title}
      </CurriculumTitle>
      <div className={styles.whyPopularDescription}>
        <NextImage src={image} width={550} height={300} objectFit="cover" />
        <div className={styles.whyPopularDetail}>
          <div className={styles.detailTitle}>
            <NextImage src={assetObject.quoteMark} width={20} height={20} />
            <h1 className={styles.title}>{subtitle}</h1>
            <div className={styles.whyPopularQuoteContainer}>
              <NextImage
                src={assetObject.quoteMark}
                width={20}
                height={20}
                className={styles.reverseQuote}
              />
            </div>
          </div>
          <div
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: description }}
            className={styles.whyPopular}
          />
        </div>
      </div>
    </section>
  );
};

export default WhyPopular;
