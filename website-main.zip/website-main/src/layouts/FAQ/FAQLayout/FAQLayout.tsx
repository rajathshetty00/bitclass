import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import FaqBanner from '../FaqBanner/FaqBanner';
import Faqtabs from '../FaqTabs/Faqtabs';
import styles from './styles.module.scss';

const FAQLayout = () => {
  const {
    faqList: { student, teacher },
  } = useSelector((state: AppState) => state?.faq);
  const tabLabels = ['Student', 'Teacher'];
  const panelFaqContents = [student, teacher];

  return (
    <div className={styles.faqLayout}>
      <FaqBanner />
      <div className={styles.tabContainer}>
        <Faqtabs tabList={tabLabels} panelArr={panelFaqContents} />
      </div>
    </div>
  );
};

export default FAQLayout;
