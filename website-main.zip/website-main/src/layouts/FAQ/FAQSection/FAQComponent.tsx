import {
  Typography,
  AccordionDetails,
  AccordionSummary,
  Accordion,
} from '@mui/material';
import SectionHeading from 'src/layouts/CDP/SectionHeading/SectionHeading';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { IFaq } from 'interfaces/faq/faq';
import { linkifyText } from 'utils';
import { useState } from 'react';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import clsx from 'clsx';
import { SyntheticEvent } from 'hoist-non-react-statics/node_modules/@types/react';
import CurriculumTitle from 'src/layouts/CurriculumCdp/CurriculumTitle/CurriculumTitle';
import styles from './style.module.scss';

type faqProps = {
  faqs: IFaq[];
  isDefaultIcon?: boolean;
  faqTitle?: string;
  faqSubTitle?: string;
};
const Faqs = ({
  faqs,
  isDefaultIcon = true,
  faqTitle,
  faqSubTitle,
}: faqProps) => {
  const [expanded, setExpanded] = useState<number | false | null>(null);

  const handleChange =
    (panel: number) => (event: SyntheticEvent, newExpanded: boolean) => {
      setExpanded(newExpanded ? panel : false);
    };
  const expandIcon = (ind: number) => {
    switch (isDefaultIcon) {
      case true:
        return <ExpandMoreIcon />;
      case false:
        if (expanded === ind)
          return <RemoveIcon className={styles.minusIcon} />;
        return <AddIcon className={styles.plusIcon} />;
      default:
        return <ExpandMoreIcon />;
    }
  };

  return (
    <div className={styles.highlights}>
      {!faqTitle && (
        <SectionHeading>
          Frequently Asked
          <span>Question</span>
        </SectionHeading>
      )}
      {faqTitle && (
        <CurriculumTitle className={styles.faqHeading}>
          {faqTitle}
        </CurriculumTitle>
      )}
      {faqSubTitle && <p className={styles.faqSubTitle}>{faqSubTitle}</p>}

      {faqs &&
        faqs.length > 0 &&
        faqs.map(({ answer: { title, steps }, question }: IFaq, ind) => {
          return (
            <div className={styles.accordionWrapper} key={question}>
              <Accordion
                className={clsx(styles.accordionSection, {
                  [styles.faqPanel]: !isDefaultIcon,
                })}
                expanded={expanded === ind}
                onChange={handleChange(ind)}
              >
                <AccordionSummary
                  expandIcon={expandIcon(ind)}
                  aria-controls={`panel1a-${ind}`}
                  id={`panel1a-${ind}`}
                  className={clsx(styles.expandIcon, {
                    [styles.expanded]: expanded,
                  })}
                >
                  <Typography
                    className={styles.question}
                    variant="subtitle1"
                    gutterBottom
                  >
                    {question}
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <p
                    className={styles.accordion_description}
                    // eslint-disable-next-line react/no-danger
                    dangerouslySetInnerHTML={{
                      __html: linkifyText(title),
                    }}
                  />
                  <div className={styles.stepsContainer}>
                    <ol>
                      {steps &&
                        steps.length > 0 &&
                        steps.map((step: string) => {
                          return (
                            <li
                              key={step}
                              // eslint-disable-next-line react/no-danger
                              dangerouslySetInnerHTML={{
                                __html: linkifyText(step),
                              }}
                            />
                          );
                        })}
                    </ol>
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>
          );
        })}
    </div>
  );
};

Faqs.defaultProps = {
  isDefaultIcon: true,
  faqTitle: '',
  faqSubTitle: '',
};
export default Faqs;
