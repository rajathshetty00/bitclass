import React from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';

import styles from './styles.module.scss';

const FaqBanner = () => {
  return (
    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
      <NextImage
        src={assetObject.faqBanner}
        height={201}
        width={1440}
        // layout="fill"
        objectFit="cover"
        className={styles.bannerImage}
      />
    </div>
  );
};

export default FaqBanner;
