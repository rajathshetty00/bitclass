import { useState, SyntheticEvent, FC } from 'react';
import Tab from '@mui/material/Tab';
import { Box, Tabs } from '@mui/material';
import { IFaq } from 'interfaces/faq/faq';
import TabPanel from '../TabPanel/TabPanel';
import styles from './styles.module.scss';
import FaqComponent from '../FAQSection/FAQComponent';

interface IFaqtabs {
  tabList: Array<string>;
  panelArr: Array<any>;
}

const Faqtabs: FC<IFaqtabs> = ({ tabList, panelArr }) => {
  const [value, setValue] = useState(1);

  const handleChange = (event: SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };
  return (
    <div>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          onChange={handleChange}
          value={value}
          aria-label="lab API tabs example"
        >
          {tabList.map((label: string, ind: number) => {
            return <Tab label={label} key={label} value={ind + 1} />;
          })}
        </Tabs>
      </Box>
      {panelArr.length > 0 &&
        panelArr.map((content: IFaq[], ind: number) => {
          return (
            <TabPanel
              index={ind + 1}
              value={value}
              key={`${content.length > 0 && content[ind].question}`}
            >
              <div className={styles.faqContainer}>
                <div className={styles.faqSection}>
                  <FaqComponent faqs={content} />
                </div>
              </div>
            </TabPanel>
          );
        })}
    </div>
  );
};

export default Faqtabs;
