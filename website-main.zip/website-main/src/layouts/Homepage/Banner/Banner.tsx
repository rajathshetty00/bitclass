import { useEffect, useState } from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import { getBannerImages } from 'utils/api';

import styles from './styles.module.scss';

export const BANNER = 'BANNER';
const HomepageBanner = () => {
  const [images, setImages] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const { data } = await getBannerImages();
        setImages(data.images);
      } catch {}
    })();
  }, []);
  return (
    <div className={styles.search} id="top">
      {images.length > 0 && (
        <div className={styles.searchContents}>
          {/* <BitCarousel
            arrows
            centerMode={false}
            slidesToScroll={1}
            page={HOMEPAGE}
            type={BANNER}
            dots={isMobile}
            autoplay={true}
            infinite={images?.length > 2 ? true : false}
            heading={false}
            onClick={() => {}}
            isMobile={isMobile}
            isTablet={isTablet || isIpad}
          > */}
          {images.map(({ imageUrl, action }) => (
            <div className={styles.imageBanner}>
              <NextImage
                src={imageUrl}
                alt=""
                width={598}
                height={318}
                onClick={() => action && (window.location.href = action)}
                className={!action ? styles.bannerImageNC : styles.bannerImage}
              />
            </div>
          ))}
          {/* </BitCarousel> */}
        </div>
      )}
    </div>
  );
};

export default HomepageBanner;
