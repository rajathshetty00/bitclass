// import React from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

const BottomAppDownloadBanner = () => {
  return (
    <div className={styles.appDownloadBanner}>
      <div className={styles.description}>
        <h3>Learn from Anywhere</h3>
        <p>
          Take Live classes on the go with the BitClass app. Download to watch
          on the bus, the metro, or from wherever you learn the best.
        </p>
        <div className={styles.downloadButtons}>
          <div className={styles.appStoreIcon}>
            <a
              target="_blank"
              href="https://apps.apple.com/us/app/bitclass/id1498797590"
              rel="noreferrer"
            >
              <NextImage
                unoptimized
                src={assetObject.appStore}
                width={200}
                height={60}
              />
            </a>
          </div>
          <div className={styles.playStoreIcon}>
            <a
              target="_blank"
              href="https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=web&utm_medium=home-footer&utm_campaign=gplayicon"
              rel="noreferrer"
            >
              <NextImage
                unoptimized
                src={assetObject.googlePlayStore}
                width={200}
                height={60}
              />
            </a>
          </div>
        </div>
      </div>
      <div className={styles.image}>
        <NextImage src={assetObject.mobileImage} width={300} height={560} />
      </div>
    </div>
  );
};

export default BottomAppDownloadBanner;
