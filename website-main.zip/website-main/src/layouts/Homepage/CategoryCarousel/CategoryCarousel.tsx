import clsx from 'clsx';
import Link from 'next/link';
import { useRouter } from 'next/router';
import React from 'react';
import { AppState, useAppSelector } from 'redux/store';
import BitSlickSlider from 'src/components/common/BitSlickSlider/BitSlickSlider';
import { getHrefLink } from 'utils';
import { BASE_URL } from 'utils/constants';

import styles from './styles.module.scss';

// const categoriesPayload = { card_type: "categories", primary_nav: "home" }
export const CATEGORY_SLIDER = 'CATEGORY_SLIDER';

const CategoryCarousel = () => {
  const { selectedCategory } = useAppSelector((state: AppState) => state.app);
  const router = useRouter();

  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );

  const categories = useAppSelector((state) => state.app.categories);

  return (
    <div className={styles.categorySelectorCarouselWrapper}>
      <BitSlickSlider
        customSettings={{
          slidesToShow: isMobile ? 1 : 8,
          slidesToScroll: isMobile ? 2 : 4,
          arrows: !isMobile,
          className: 'slider variable-width',
          centerMode: false,
          variableWidth: true,
        }}
        customClass={styles.customSlick}
      >
        {categories &&
          [{ display_text: 'All' }, ...categories, { display_text: '' }].map(
            ({ display_text }) => (
              <Link
                href={
                  display_text === 'All'
                    ? getHrefLink('/', router)
                    : getHrefLink(
                        `${BASE_URL}/live-classes/category/${display_text}?channel=home_page_category_tab&platform=${
                          isMobile ? 'mweb' : 'web'
                        }`,
                        router,
                      )
                }
                key={display_text}
                data-category={display_text}
              >
                <div
                  className={clsx({
                    [styles.selectedCategory]:
                      selectedCategory === display_text,
                  })}
                >
                  <div className={styles.category} data-category={display_text}>
                    <div
                      className={styles.details}
                      data-category={display_text}
                    >
                      <span data-category={display_text}>{display_text}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ),
          )}
      </BitSlickSlider>
    </div>
  );
};

export default CategoryCarousel;
