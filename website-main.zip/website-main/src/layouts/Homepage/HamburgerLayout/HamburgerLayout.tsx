import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import BitDrawer from 'src/components/common/BitDrawer/BitDrawer';
import NextImage from 'src/components/common/NextImage/NextImage';
import Seperator from 'src/components/common/Separator/Separator';
import { assetObject } from 'utils/assetFileNames';
import MenuBookIcon from '@mui/icons-material/MenuBook';
import { BASE_URL } from 'utils/constants';
import { useRouter } from 'next/router';
import { getHrefLink } from 'utils';
import { useSelector } from 'react-redux';
import styles from './styles.module.scss';

interface HamburgerLayoutProps {}

const HamburgerLayout: FC<HamburgerLayoutProps> = () => {
  const router = useRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const { showBitDrawer } = useAppSelector((state: AppState) => state?.app);

  return (
    <div>
      <BitDrawer showBitDrawer={showBitDrawer}>
        <div className={styles.hamburgerWrapper}>
          <div className={styles.hamburgerContainer}>
            <div className={styles.imgContainer}>
              <NextImage
                className={styles.img}
                src={assetObject.logoWhite}
                width={180}
                height={52}
              />
            </div>
            <Seperator customClass={styles.seperator} />
            <div className={styles.teachOnBitClasseContainer}>
              <MenuBookIcon />
              <a
                href={getHrefLink(
                  `${BASE_URL}/n/launchpad?channel=sidebar&platform=${
                    isMobile ? 'mweb' : 'web'
                  }`,
                  router,
                )}
              >
                Teach On BitClass
              </a>
            </div>
            <Seperator customClass={styles.seperator} />

            <div className={styles.downloadContainer}>
              <a
                target="_blank"
                href="https://apps.apple.com/us/app/bitclass/id1498797590"
                rel="noreferrer"
              >
                <NextImage
                  src={assetObject.appStore}
                  width={268}
                  height={80}
                  unoptimized
                />
              </a>

              <a
                target="_blank"
                href="https://play.google.com/store/apps/details?id=com.bitclass.android&utm_source=web&utm_medium=home-footer&utm_campaign=gplayicon"
                rel="noreferrer"
              >
                <NextImage
                  src={assetObject.googlePlayStore}
                  width={268}
                  height={80}
                  unoptimized
                />
              </a>
            </div>
          </div>
        </div>
      </BitDrawer>
    </div>
  );
};

export default HamburgerLayout;
