import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import Spacer from 'src/components/common/Spacer/Spacer';
import TeacherCardCarousel from 'src/components/common/TeacherCardCarousel/TeacherCardCarousel';
import Testimonial from 'src/layouts/CurriculumCdp/Testimonial/Testimonial';
import { sectionData } from 'utils/constants';
import BottomAppDownloadBanner from '../BottomAppDownloadBanner/BottomDownloadBanner';
import TeachOnBitClass from '../TeachOnBitClass/TeachOnBitClass';

interface StaticContentLayoutProps {}

const StaticContentLayout: FC<StaticContentLayoutProps> = () => {
  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );

  return (
    <div>
      <TeacherCardCarousel />
      <Spacer size={32} axis="vertical" />
      {/* @ts-ignore */}
      <Testimonial sectionData={sectionData} />
      <Spacer size={64} axis="vertical" />
      <TeachOnBitClass />
      <Spacer size={isMobile ? 0 : 128} axis="vertical" />
      <BottomAppDownloadBanner />
      <Spacer size={32} axis="vertical" />
    </div>
  );
};

export default StaticContentLayout;
