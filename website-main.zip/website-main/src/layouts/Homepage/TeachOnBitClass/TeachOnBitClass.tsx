import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { AppState } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { useBitRouter } from 'src/hooks/useBitRouter';
import { getQuery } from 'utils';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

const images = [
  'https://media.bitclass.live/image/upload/v1650292485/Website%20ICONS/tempTeachOnBitClass_o7thtm.png',
  'http://res.cloudinary.com/bitclass/image/upload/v1619797813/BitClass/egdd7judi6fw6hie6koo.jpg',
];
const TeachOnBitClass = () => {
  const [currentImage, setCurrentImage] = useState(0);
  const imagesLength = images.length;
  const router = useRouter();
  const appendQueryParamAndNavigate = useBitRouter();
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage(currentImage + 1);
    }, 2000);
    return () => {
      clearInterval(timer);
    };
  }, [currentImage]);

  const handleClick = () => {
    // window.open(?utm_source=homepage&platform=web`);
    appendQueryParamAndNavigate(
      `${BASE_URL}/n/launchpad?channel=home_page_teach_on_Bitclass&platform=${
        isMobile ? 'mweb' : 'web'
      }`,
      getQuery(router),
    );
  };

  return (
    <div className={styles.teachOnBitClass}>
      <div className={styles.teacherImage}>
        <img src={images[currentImage % imagesLength]} alt="" />
      </div>

      <div className={styles.details}>
        <h3>Teach on BitClass</h3>
        <p>
          Top instructors from around the world teach millions of students on
          BitClass. We provide the tools and skills to teach what you love.
        </p>
        <BitButton type="button" onClick={handleClick}>
          Start Teaching Today
        </BitButton>
      </div>
    </div>
  );
};

export default TeachOnBitClass;
