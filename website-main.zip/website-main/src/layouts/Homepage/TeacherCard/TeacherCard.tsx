import { useRouter } from 'next/router';
import { AppState, useAppSelector } from 'redux/store';
import { getHrefLink } from 'utils';
import { BASE_URL } from 'utils/constants';
import styles from './styles.module.scss';

const TeacherCard = ({ teacher }: any) => {
  const router = useRouter();
  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );
  return (
    <a
      href={getHrefLink(
        `${BASE_URL}/new/teacher/${
          teacher?.teacherHandle
        }?channel=home_page_teachers&platform=${isMobile ? 'mweb' : 'web'}`,
        router,
      )}
      target="_blank"
      rel="noreferrer"
    >
      <div
        className={styles.teacherCard}
        style={{
          background: `linear-gradient(180deg, #070D1D 0%, rgba(7, 13, 29, 0) 0.01%, #070D1D 100%), url('${teacher?.image}')`,
        }}
      >
        <h4>{teacher?.name}</h4>
        <p>{teacher?.topic}</p>
      </div>
    </a>
  );
};

export default TeacherCard;
