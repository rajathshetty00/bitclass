import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import BitModal from 'src/components/common/BitModal/BitModal';
import IdCard from 'src/components/profile/IdCard/IdCard';
import ProfileFormLayout from '../../ProfileFormLayout';
import styles from './styles.module.scss';

interface DesktopIdCardAndEditProfileLayoutProps {}

const DesktopIdCardAndEditProfileLayout: FC<DesktopIdCardAndEditProfileLayoutProps> =
  () => {
    const { bitModalState } = useAppSelector((state: AppState) => state.app);

    return (
      <div>
        <BitModal
          title="Update your ID Card"
          customClass={styles.desktopIdWrapper}
          open={bitModalState}
        >
          <div className={styles.desktopIdContainer}>
            <div>
              <IdCard isMinified={false} />
            </div>
            <ProfileFormLayout />
          </div>
        </BitModal>
      </div>
    );
  };

export default DesktopIdCardAndEditProfileLayout;
