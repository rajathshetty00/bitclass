import { FC } from 'react';
import dynamic from 'next/dynamic';
import DashboardLayout from '../common/DashboardLayout/DashboardLayout';
import DesktopIdCardAndEditProfileLayout from './DesktopIdCardAndEditProfileLayout/DesktopIdCardAndEditProfileLayout';
import ReferralDetails from '../common/ReferralDetails/ReferralDetails';
import MyClassesLayout from '../common/MyClassesLayout/MyClassesLayout';
// import ReferralDetails from '../common/ReferralDetails/ReferralDetails';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

interface IDesktopProfileLayoutProps {}

const DesktopProfileLayout: FC<IDesktopProfileLayoutProps> = () => {
  return (
    <>
      <div style={{ boxShadow: '0 4px 16px rgb(0 0 0 / 5%)' }}>
        <DynamicBitAppHeader />
      </div>
      <div
        style={{
          display: 'grid',
          gap: '8px',
          gridTemplateColumns: '270px 1fr',
        }}
      >
        <div>
          <DashboardLayout />
        </div>
        <div>
          <ReferralDetails />
          <MyClassesLayout />
        </div>
      </div>
      <DesktopIdCardAndEditProfileLayout />
    </>
  );
};

export default DesktopProfileLayout;
