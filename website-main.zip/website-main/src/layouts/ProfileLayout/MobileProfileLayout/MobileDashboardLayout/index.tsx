import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import BitDrawer from 'src/components/common/BitDrawer/BitDrawer';
import DashboardLayout from '../../common/DashboardLayout/DashboardLayout';

interface MobileDashboardLayoutProps {}

const MobileDashboardLayout: FC<MobileDashboardLayoutProps> = () => {
  const { showBitDrawer } = useAppSelector((state: AppState) => state?.app);

  return (
    <>
      <BitDrawer showBitDrawer={showBitDrawer}>
        <DashboardLayout />
      </BitDrawer>
    </>
  );
};

export default MobileDashboardLayout;
