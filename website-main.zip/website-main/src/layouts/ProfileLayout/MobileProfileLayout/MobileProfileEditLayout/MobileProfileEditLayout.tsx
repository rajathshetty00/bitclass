import { FunctionComponent } from 'react';
import { updateEditDrawer } from 'redux/reducers/appReducer';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import BitDrawer from 'src/components/common/BitDrawer/BitDrawer';
import ProfileFormLayout from '../../ProfileFormLayout';
import styles from './styles.module.scss';

interface MobileProfileEditLayoutProps {}

const MobileProfileEditLayout: FunctionComponent<MobileProfileEditLayoutProps> =
  () => {
    const { showEditDrawer } = useAppSelector((state: AppState) => state?.app);

    const dispatch = useAppDispatch();

    const onDrawerClose = () => {
      return dispatch(updateEditDrawer({ anchor: 'bottom', show: false }));
    };

    return (
      <BitDrawer onDrawerClose={onDrawerClose} showBitDrawer={showEditDrawer}>
        <div className={styles.mobileProfileEditLayoutWrapper}>
          <ProfileFormLayout />
        </div>
      </BitDrawer>
    );
  };

export default MobileProfileEditLayout;
