import { FC } from 'react';
import { updateEditDrawer } from 'redux/reducers/appReducer';
import { useAppDispatch } from 'redux/store';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import Spacer from 'src/components/common/Spacer/Spacer';
import IdCard from 'src/components/profile/IdCard/IdCard';
import styles from './styles.module.scss';

interface ViewIDCardLayoutProps {}

const ViewIDCardLayout: FC<ViewIDCardLayoutProps> = () => {
  const dispatch = useAppDispatch();

  const editClickHandler = () => {
    dispatch(updateEditDrawer({ anchor: 'bottom', show: true }));
  };

  return (
    <div className={styles.idCardWrapper}>
      <h3>Introducing ID Card</h3>
      <IdCard isMinified={false} />
      <Spacer size={32} axis="vertical" />
      <div className={styles.buttonContainers}>
        <CustomDefaultButton onClick={editClickHandler}>
          Edit ID Card
        </CustomDefaultButton>
        <Spacer size={32} axis="vertical" />
      </div>
    </div>
  );
};

export default ViewIDCardLayout;
