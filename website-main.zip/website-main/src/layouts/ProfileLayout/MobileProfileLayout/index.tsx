import dynamic from 'next/dynamic';
import React, { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import MyClassesLayout from '../common/MyClassesLayout/MyClassesLayout';
import ReferralDetails from '../common/ReferralDetails/ReferralDetails';
import ShowReferralScreen from '../common/ShowReferralScreen/ShowReferralScreen';
import MobileDashboardLayout from './MobileDashboardLayout';
import MobileProfileEditLayout from './MobileProfileEditLayout/MobileProfileEditLayout';
import ViewIDCardLayout from './ViewIDCardLayout/ViewIDCardLayout';

const DynamicBitAppHeader = dynamic(
  () => import('src/components/common/BitAppHeader/BitAppHeader'),
  { ssr: false },
);

interface MobileProfileLayoutProps {}

const MobileProfileLayout: FC<MobileProfileLayoutProps> = () => {
  const { isIdLayoutViewable, isReferralShowViewable, isReferAFriendViewable } =
    useAppSelector((state: AppState) => state.profile);

  return (
    <>
      <DynamicBitAppHeader />
      <MobileDashboardLayout />
      {isIdLayoutViewable && <ViewIDCardLayout />}
      <MobileProfileEditLayout />
      {isReferralShowViewable && <ShowReferralScreen />}
      {isReferAFriendViewable && <ReferralDetails />}
      {!isReferAFriendViewable && !isIdLayoutViewable && <MyClassesLayout />}
    </>
  );
};

export default MobileProfileLayout;
