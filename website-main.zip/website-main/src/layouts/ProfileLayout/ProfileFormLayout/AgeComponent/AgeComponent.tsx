import { TextField } from '@mui/material';
import Spacer from 'src/components/common/Spacer/Spacer';
import { ErrorMsg } from 'src/controls';
import styles from './styles.module.scss';

const AgeComponent = ({ errors, name, ...props }: any) => {
  return (
    <section id="name_section" className={styles.ageSection}>
      {/* <InputLabel>Age</InputLabel> */}
      <Spacer size={5} />
      {/* <InputField
        type="text"
        label="Age"
        placeholder="Please enter your age"
        name={name}
        {...props}
      /> */}
      <TextField
        label="Age"
        name={name}
        {...props}
        className={styles.ageInput}
      />

      <div>
        {errors?.[name]?.type === 'required' && (
          <ErrorMsg>This field is required</ErrorMsg>
        )}
        {errors?.[name]?.type === 'min' && (
          <ErrorMsg>Age must be 5 to 99</ErrorMsg>
        )}
        {errors?.[name]?.type === 'max' && (
          <ErrorMsg>Age must be 5 to 99</ErrorMsg>
        )}
      </div>
    </section>
  );
};

export default AgeComponent;
