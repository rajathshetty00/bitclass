import { TextField } from '@mui/material';
import Spacer from 'src/components/common/Spacer/Spacer';
import { ErrorMsg } from 'src/controls';

const FullName = ({ errors, name, onChange, ...props }: any) => {
  return (
    <section id="name_section">
      {/* <InputLabel>Name</InputLabel> */}
      <Spacer size={5} />
      {/* <InputField
        type="text"
        placeholder="Please enter your full name"
        name={name}
        {...props}
      /> */}
      <TextField
        label="Please enter your full name"
        name={name}
        onChange={(e: any) =>
          onChange({
            target: { name: e.target.name, value: e.target.value.trimStart() },
          })
        }
        {...props}
        fullWidth
      />

      <div>
        {errors?.[name]?.type === 'required' && (
          <ErrorMsg>This field is required</ErrorMsg>
        )}
        {errors?.[name]?.type === 'pattern' && (
          <ErrorMsg>Numeric values are not allowed</ErrorMsg>
        )}
      </div>
      <Spacer size={10} />
    </section>
  );
};

export default FullName;
