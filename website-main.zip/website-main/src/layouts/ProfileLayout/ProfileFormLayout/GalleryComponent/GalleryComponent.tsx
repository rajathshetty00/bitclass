import React, { useEffect } from 'react';
import { XSquare } from 'react-feather';
import NextImage from 'src/components/common/NextImage/NextImage';
import Spacer from 'src/components/common/Spacer/Spacer';
import { ErrorMsg, InputLabel } from 'src/controls';
import { useCloudinary } from 'src/hooks/useCloudinary';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

const GalleryComponent = ({ errors, name, onChange, value }: any) => {
  const { openCloudinaryUpload, url } = useCloudinary();
  useEffect(() => {
    if (url) {
      onChange({ target: { name, value: url } });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url]);

  const clearImg = () => {
    onChange({ target: { name, value: '' } });
  };

  return (
    <section id="profile_pricture_section" className={styles.profileSection}>
      <InputLabel>Profile Picture</InputLabel>
      <div>
        <Spacer size={5} />
        {!value && (
          <button
            type="button"
            onClick={openCloudinaryUpload}
            className={styles.chooseGalleryButton}
          >
            <NextImage src={assetObject.galleryIcon} width="16" height="16" />
            Choose from gallery
          </button>
        )}
        {value && (
          <div className={styles.clearContainer}>
            <button
              type="button"
              onClick={clearImg}
              className={`${styles.chooseGalleryButton} ${styles.clearImg}`}
            >
              <XSquare style={{ width: 15 }} />
            </button>
            <p className={styles.clearText}>Uploaded</p>
          </div>
        )}
        <div>
          {errors?.[name]?.type === 'required' && (
            <ErrorMsg>Please choose your profile pic</ErrorMsg>
          )}
          {errors?.[name]?.type === 'pattern' && (
            <ErrorMsg>Only images are allowed</ErrorMsg>
          )}
        </div>
        <Spacer size={10} />
      </div>
    </section>
  );
};

export default GalleryComponent;
