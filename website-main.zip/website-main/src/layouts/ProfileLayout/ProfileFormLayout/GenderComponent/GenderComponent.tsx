// import { Checkbox, FormControlLabel } from '@mui/material';
import clsx from 'clsx';
// import { BitButton } from 'src/components/common/BitButton/BitButton';
import NextImage from 'src/components/common/NextImage/NextImage';
import Spacer from 'src/components/common/Spacer/Spacer';
import { ErrorMsg } from 'src/controls';
import { assetObject } from 'utils/assetFileNames';
import styles from './styles.module.scss';

// const CheckBoxController = ({ label, val, ...props }: any) => {
//   const handleChange = () => {
//     props.onChange(val);
//   };
//   return (
//     <FormControlLabel
//       className={styles.checkboxLabel}
//       control={
//         <Checkbox
//           className={styles.checkboxInput}
//           onChange={handleChange}
//           checked={props.value === val}
//           sx={{
//             '& .MuiSvgIcon-root': { fontSize: 20 },
//             color: '#2e3a59',
//             fontSize: 10,
//             fontFamily: 'Poppins',
//             padding: 0,
//             position: 'absolute',
//             bottom: -20,
//             left: 28,
//             '&:span': {
//               fontSize: 10,
//             },
//             '&:MuiFormControlLabel-label': {
//               paddingLeft: 20,
//               fontFamily: 'Poppins',
//             },
//             '&.Mui-checked': {
//               color: '#079893',
//               fontSize: 10,
//               position: 'absolute',
//               bottom: -20,
//               left: 28,
//             },
//           }}
//         />
//       }
//       label={label}
//     />
//   );
// };
const GenderComponent = ({ errors, name, onChange, value }: any) => {
  return (
    <section id="gender_section" className={styles.genderSection}>
      {/* <InputLabel>Gender</InputLabel> */}
      <Spacer size={5} />
      <div className={styles.profileGenderContainer}>
        <button
          className={clsx(styles.profileCheckbox, {
            [styles.selected]: value === 'male',
          })}
          name="gender"
          type="button"
          // startIcon={
          //   <NextImage src={assetObject.manIcon} width={40} height={40} />
          // }
          onClick={() =>
            onChange({ target: { name: 'gender', value: 'male' } })
          }
        >
          <NextImage src={assetObject.manIcon} width={24} height={24} />
          {/* <NextImage src={assetObject.manIcon} width={24} height={24} /> */}
          <span className={styles.genderText}>Male</span>
        </button>
        <button
          className={clsx(styles.profileCheckbox, {
            [styles.selected]: value === 'female',
          })}
          type="button"
          onClick={() =>
            onChange({ target: { name: 'gender', value: 'female' } })
          }
        >
          <NextImage src={assetObject.womenIcon} width={24} height={24} />
          {/* <CheckBoxController label="Female" val="female" {...props} /> */}
          <span className={styles.genderText}>Female</span>
        </button>
      </div>
      <div>
        {errors?.[name]?.type === 'required' && (
          <ErrorMsg>This field is required</ErrorMsg>
        )}
      </div>
    </section>
  );
};

export default GenderComponent;
