import { Controller, useForm } from 'react-hook-form';
import Spacer from 'src/components/common/Spacer/Spacer';
import { ErrorMsg } from 'src/controls';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  actionGetProfileData,
  actionPatchProfileData,
} from 'redux/actions/profileActions';
import { debounce } from 'lodash';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import { updateEditDrawer } from 'redux/reducers/appReducer';
import { Autocomplete, TextField } from '@mui/material';
import { getCities } from 'utils/constants/city';
import BitSnackBar from 'src/components/common/BitSnackBar/BitSnackBar';
import { useState, SyntheticEvent, useCallback } from 'react';
import AgeComponent from './AgeComponent/AgeComponent';
import FullName from './FullName/FullName';
import GalleryComponent from './GalleryComponent/GalleryComponent';
import GenderComponent from './GenderComponent/GenderComponent';
import styles from './styles.module.scss';

const optionList = [
  'School Student',
  'College Student',
  'Working Professional',
  'Homemaker',
  'Retired',
];

export interface IFormInput {
  name: string;
  profile_pic: string;
  age: number | null;
  location: string;
  profession: string;
  gender: string;
}

const ProfileFormLayout = () => {
  const { profileDetails, isProfileUpdatePending } = useAppSelector(
    (state: AppState) => state.profile,
  );

  const [visible, setVisible] = useState(false);
  const dispatch = useAppDispatch();

  const {
    control,
    handleSubmit,
    formState: { errors, isDirty, isValid },
  } = useForm<IFormInput>({
    mode: 'onChange',
    reValidateMode: 'onChange',
    defaultValues: {
      name: profileDetails?.name,
      profile_pic: profileDetails?.profile_pic ?? '',
      age: profileDetails?.meta_info?.age ?? '',
      location: profileDetails?.meta_info?.location ?? '',
      profession: profileDetails?.meta_info?.profession ?? '',
      gender: profileDetails?.meta_info?.gender,
    },
  });

  const onSubmit = async (formData: any) => {
    const { ...restData } = formData;
    // Api call to submit form Data
    setVisible(true);
    await dispatch(actionPatchProfileData(restData));
    await dispatch(actionGetProfileData());
    dispatch(updateEditDrawer({ anchor: 'bottom', show: false }));
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncProfileUpdate = useCallback(
    debounce(async (name, value) => {
      if (!value) return;
      await dispatch(actionPatchProfileData({ [name]: value }));
      await dispatch(actionGetProfileData());
    }, 1000),
    [],
  );

  const handleChangewithApi = (e: any) => {
    const { name, value } = e.target;
    debouncProfileUpdate(name, value);
    if (name === 'name' || name === 'profile_pic') {
      // @ts-ignore
      const userData = JSON.parse(localStorage.getItem('userInfo'));
      if (name === 'name') userData.firstName = value || 'A';
      if (name === 'profile_pic') userData.image = value;
      localStorage.setItem('userInfo', JSON.stringify(userData));
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)}>
        {/* full name section */}
        <Controller
          defaultValue={profileDetails?.name}
          name="name"
          control={control}
          rules={{ required: true, pattern: /^[A-Za-z\s]+$/ }}
          render={({ field }) => (
            <FullName
              errors={errors}
              {...field}
              onChange={(e: SyntheticEvent) => {
                field.onChange(e);
                handleChangewithApi(e);
              }}
            />
          )}
        />

        <Spacer size={10} />
        {/* Choose from gallery section */}
        <Controller
          name="profile_pic"
          control={control}
          rules={{
            pattern: /\.(gif|jpe?g|tiff?|png|svg|webp|bmp)$/i,
          }}
          render={({ field }) => (
            <GalleryComponent
              errors={errors}
              {...field}
              onChange={(e: any) => {
                field.onChange(e);
                handleChangewithApi(e);
              }}
            />
          )}
        />

        <Spacer size={10} />
        {/* Age section */}
        <div className={styles.ageContainer}>
          <Controller
            name="age"
            control={control}
            rules={{
              required: true,
              min: 5,
              max: 99,
            }}
            render={({ field }) => (
              <AgeComponent
                type="number"
                errors={errors}
                {...field}
                onChange={(e: SyntheticEvent) => {
                  field.onChange(e);
                  handleChangewithApi(e);
                }}
              />
            )}
          />
          {/* Gender section */}
          <Spacer size={10} />
          <Controller
            name="gender"
            control={control}
            rules={{
              required: true,
            }}
            render={({ field }) => (
              <GenderComponent
                errors={errors}
                {...field}
                onChange={(e: SyntheticEvent) => {
                  field.onChange(e);
                  handleChangewithApi(e);
                }}
              />
            )}
          />
        </div>

        {/* <Spacer size={10} /> */}

        <Spacer size={10} />
        {/* City section */}
        <section id="city_section" className={styles.citySection}>
          {/* <InputLabel>City</InputLabel> */}
          <Spacer size={5} />
          <Controller
            name="location"
            control={control}
            rules={{
              required: true,
            }}
            render={({ field }) => (
              <Autocomplete
                fullWidth
                disablePortal
                id="city_search"
                options={getCities()}
                sx={{ width: 300 }}
                className={styles.inputFullWidth}
                defaultValue={field.value}
                onSelect={(e: any) => {
                  field.onChange(e);
                  handleChangewithApi(e);
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Select your City"
                    name="location"
                  />
                )}
              />
            )}
          />
          {errors?.location?.type === 'required' && (
            <ErrorMsg>This field is required</ErrorMsg>
          )}
        </section>
        <Spacer size={20} />
        {/* Profession section */}
        <section
          id="professional_section"
          className={styles.professionalSection}
        >
          {/* <InputLabel>Profession</InputLabel> */}
          <Spacer size={5} />
          <Controller
            name="profession"
            control={control}
            rules={{
              required: true,
            }}
            render={({ field }) => (
              // <DropDown
              //   optionList={optionList}
              //   placeholder="Please choose your profession"
              //   errors={errors}
              //   {...field}
              // />
              <Autocomplete
                className={styles.inputFullWidth}
                fullWidth
                disablePortal
                options={optionList}
                sx={{ width: 300 }}
                defaultValue={field.value}
                onSelect={(e: any) => {
                  field.onChange(e);
                  handleChangewithApi(e);
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Please choose your profession"
                    name="profession"
                  />
                )}
              />
            )}
          />
          {errors?.profession?.type === 'required' && (
            <ErrorMsg>This field is required</ErrorMsg>
          )}
        </section>
        <Spacer size={25} />
        <div className={styles.buttonContainer}>
          <CustomDefaultButton
            loading={isProfileUpdatePending}
            variant="contained"
            type="submit"
            className="bottomBtn"
            disabled={!isDirty || !isValid}
          >
            Save and Submit
          </CustomDefaultButton>
        </div>
      </form>
      <BitSnackBar
        visible={visible}
        onClose={() => setVisible(false)}
        vertical="top"
        horizontal="right"
        message="Saved Successfully"
      />
    </div>
  );
};

export default ProfileFormLayout;
