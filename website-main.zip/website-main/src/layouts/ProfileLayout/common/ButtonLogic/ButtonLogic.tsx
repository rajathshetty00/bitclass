import { FC } from 'react';
import { useSelector } from 'react-redux';
import {
  updateBitDrawer,
  updateBitModalState,
} from 'redux/reducers/appReducer';
import {
  showIdLayoutPage,
  showReferralPage,
} from 'redux/reducers/profileReducer';
import { AppState, useAppDispatch } from 'redux/store';
import { CustomDefaultButton } from 'src/components/common/BitMuiButton';
import styles from './styles.module.scss';

interface ButtonLogicProps {}

const ButtonLogic: FC<ButtonLogicProps> = () => {
  const { isMobile } = useSelector((state: AppState) => state?.app?.deviceInfo);
  const dispatch = useAppDispatch();

  const onViewClickHandler = () => {
    dispatch(updateBitDrawer({ anchor: 'left', show: false }));
    dispatch(showIdLayoutPage(true));
    dispatch(showReferralPage(false));
  };

  const onEditClickHandler = () => {
    dispatch(updateBitModalState(true));
  };

  return (
    <div className={styles.buttonLogic}>
      {isMobile ? (
        <CustomDefaultButton
          onClick={onViewClickHandler}
          className={styles.button}
          fullWidth
        >
          View ID Card
        </CustomDefaultButton>
      ) : (
        <CustomDefaultButton
          onClick={onEditClickHandler}
          className={styles.button}
          fullWidth
        >
          Edit ID Card
        </CustomDefaultButton>
      )}
    </div>
  );
};

export default ButtonLogic;
