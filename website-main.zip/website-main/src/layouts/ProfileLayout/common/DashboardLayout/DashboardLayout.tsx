import { FC } from 'react';
import Spacer from 'src/components/common/Spacer/Spacer';
import IdCard from 'src/components/profile/IdCard/IdCard';
import SwitchToTeacher from 'src/components/profile/SwitchToTeacher/SwitchToTeacher';
// import { CustomDefaultButton } from 'src/components/common/BitMuiButton';

import ButtonLogic from '../ButtonLogic/ButtonLogic';
import MyClassesMenu from '../MyClassesMenu/MyClassesMenu';
import styles from './styles.module.scss';

interface IDashboardLayoutProps {}

const DashboardLayout: FC<IDashboardLayoutProps> = () => {
  return (
    <div className={styles.dashboardWrapper}>
      <div className={styles.sectionOne}>
        <IdCard isMinified />
        <Spacer size={24} axis="vertical" />
        <ButtonLogic />
        <Spacer size={24} axis="vertical" />
      </div>
      <div className={styles.sectionTwo}>
        <MyClassesMenu />
        <SwitchToTeacher />
      </div>
    </div>
  );
};

export default DashboardLayout;
