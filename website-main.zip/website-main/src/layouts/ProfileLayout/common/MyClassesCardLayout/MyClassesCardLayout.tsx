import { FC } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import NextImage from 'src/components/common/NextImage/NextImage';
import MyClassesCard from 'src/components/profile/MyClassesCard/MyClassesCard';
import { assetObject } from 'utils/assetFileNames';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll';
import styles from './styles.module.scss';

interface MyClassesCardLayoutProps {}

const MyClassesCardLayout: FC<MyClassesCardLayoutProps> = () => {
  const { selectedTab } = useAppSelector((state: AppState) => state.profile);

  const { results, lastResultElement, loading, hasMore } = useInfiniteScroll(
    Boolean(selectedTab),
  );
  return (
    <>
      {results.length ? (
        <>
          <div className={styles.myClassesCardLayoutWrapper}>
            {results.map((course, index) => (
              <MyClassesCard
                courseDetails={course}
                ref={results.length - 1 === index ? lastResultElement : null}
              />
            ))}
          </div>

          {loading && <div className={styles.noMoreResults}>Loading..</div>}
          {!hasMore && (
            <div className={styles.noMoreResults}>No more results</div>
          )}
        </>
      ) : (
        <div className={styles.noClasses}>
          {!loading ? (
            <NextImage
              src={assetObject.noCoursesFound}
              width={500}
              height={400}
            />
          ) : (
            <NextImage
              src={assetObject.bitLoaderGif}
              width={200}
              height={200}
              crossOrigin=""
            />
          )}
        </div>
      )}
    </>
  );
};

export default MyClassesCardLayout;
