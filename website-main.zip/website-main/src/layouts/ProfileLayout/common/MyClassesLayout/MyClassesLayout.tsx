import { FC } from 'react';
import * as React from 'react';
import BitTab from 'src/components/common/BitTab/BitTab';
import styles from './styles.module.scss';
import MyClassesCardLayout from '../MyClassesCardLayout/MyClassesCardLayout';

interface MyClassesLayoutProps {}

const tabArray = [{ label: 'Upcoming Classes' }, { label: 'Past Classes' }];

const MyClassesLayout: FC<MyClassesLayoutProps> = () => {
  return (
    <div className={styles.myClassesLayoutWrapper}>
      <BitTab tabArray={tabArray} tabChildren={<MyClassesCardLayout />} />
    </div>
  );
};

export default MyClassesLayout;
