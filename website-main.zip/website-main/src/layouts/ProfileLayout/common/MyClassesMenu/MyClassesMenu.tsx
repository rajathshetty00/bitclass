import React, { FC, useState } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import { useAppDispatch } from 'redux/store';
import { updateSelectedCourseType } from 'redux/reducers/profileReducer';
import styles from './styles.module.scss';

interface MyClassesMenuProps {}

const COURSE_TYPE: any = {
  '1': '',
  '2': 'workshop',
  '3': 'course',
};
const MyClassesMenu: FC<MyClassesMenuProps> = () => {
  const [expanded, setExpanded] = useState<string | false>('panel1');

  const [buttonSelected, setButtonSelected] = useState('1');

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
      setExpanded(newExpanded ? panel : false);
    };

  const dispatch = useAppDispatch();
  const handleSelectedMenu = (menu: string) => {
    setButtonSelected(menu);
    dispatch(updateSelectedCourseType(COURSE_TYPE[menu]));
  };

  return (
    <div className={styles.myClassesMenuWrapper}>
      <Accordion
        expanded={expanded === 'panel1'}
        onChange={handleChange('panel1')}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
          className={styles.myClassesContainer}
        >
          <h3>My Classes</h3>
        </AccordionSummary>
        <AccordionDetails className={styles.myClassesBody}>
          <BitButton
            className={buttonSelected === '1' ? styles.btnSelected : ''}
            variant="text"
            fullWidth
            onClick={() => handleSelectedMenu('1')}
          >
            All Classes
          </BitButton>
          <BitButton
            className={buttonSelected === '2' ? styles.btnSelected : ''}
            onClick={() => handleSelectedMenu('2')}
            variant="text"
            fullWidth
          >
            Workshops
          </BitButton>
          <BitButton
            className={buttonSelected === '3' ? styles.btnSelected : ''}
            onClick={() => handleSelectedMenu('3')}
            variant="text"
            fullWidth
          >
            Courses
          </BitButton>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};

export default MyClassesMenu;
