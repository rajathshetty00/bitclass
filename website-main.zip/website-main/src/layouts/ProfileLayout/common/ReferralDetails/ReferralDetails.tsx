/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { FC, useEffect, useState } from 'react';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { AppState, useAppDispatch, useAppSelector } from 'redux/store';
import {
  showReferAFriendPage,
  showReferralPage,
  showTransactionHistory,
} from 'redux/reducers/profileReducer';
import { actionGetReferralData } from 'redux/actions/profileActions';
import { copyText } from 'utils';
import BitSnackBar from 'src/components/common/BitSnackBar/BitSnackBar';
import BitModal from 'src/components/common/BitModal/BitModal';
import RectangularSkeletonLoader from 'src/components/profile/RectangularSkeletonLoader/RectangularSkeletonLoader';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import styles from './styles.module.scss';
import ViewTransaction from '../ViewTransactions/ViewTransactions';

interface ReferralDetailsProps {}

const ReferralDetails: FC<ReferralDetailsProps> = () => {
  const dispatch = useAppDispatch();

  const { istransactionHistoryViewable, referralDetails } = useAppSelector(
    (state: AppState) => state.profile,
  );

  const { isMobile } = useAppSelector(
    (state: AppState) => state.app.deviceInfo,
  );

  const [visible, setVisible] = useState(false);

  useEffect(() => {
    (async () => {
      await dispatch(actionGetReferralData());
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const backButtonHandler = () => {
    if (istransactionHistoryViewable) {
      dispatch(showReferAFriendPage(true));
      dispatch(showTransactionHistory(false));
    } else {
      saveGtmDataLayerData({
        event: EVENT_NAMES.REFERRAL_SCREEN_CLOSED,
      });
      dispatch(showReferAFriendPage(false));
      dispatch(showReferralPage(true));
    }
  };

  const transactionViewHandler = () => {
    dispatch(showTransactionHistory(true));
  };

  const onBtnClickHandler = () => {
    copyText(referralDetails?.bitcash_intro?.share_text);
    setVisible(true);
  };

  const closeTransactionScreen = () => {
    dispatch(showTransactionHistory(false));
    saveGtmDataLayerData({ event: EVENT_NAMES.REFERRAL_HISTORY_SCREEN_CLOSED });
  };

  return (
    <div className={styles.referralDetailsWrapper}>
      {isMobile && (
        <BitButton
          onClick={backButtonHandler}
          className={styles.backbutton}
          variant="text"
        >
          <ChevronLeftIcon />
          Back
        </BitButton>
      )}

      <div className={styles.referFriendWrapper}>
        {referralDetails ? (
          <>
            <div className={styles.referFriendContainer}>
              <h4>Refer a friend</h4>
              <NextImage
                src={assetObject.bitcash}
                width={50}
                height={50}
                className={styles.image}
              />
              <h5>You Have</h5>
              <h4 className={styles.bitcash}>
                {referralDetails?.wallet_balance}
                <br />
                Bitcash
              </h4>
              <h6>1 Bitcash = 1 Rupee</h6>
            </div>

            <div className={styles.howDoesItWorkContainer}>
              <h5>{referralDetails?.bitcash_intro?.content?.heading}</h5>
              <ul>
                {referralDetails?.bitcash_intro?.content?.text?.map(
                  (item: string) => (
                    <li
                      key={item}
                      dangerouslySetInnerHTML={{
                        __html: item,
                      }}
                    />
                  ),
                )}
              </ul>
              <BitButton
                onClick={transactionViewHandler}
                className={styles.transactionButton}
              >
                View Your Transactions
              </BitButton>
            </div>
            <div className={styles.magicLinkContainer}>
              <div className={styles.flexContainer1}>
                <p>Magic Link: </p>
                <BitButton
                  onClick={onBtnClickHandler}
                  className={styles.transactionButton}
                  id="magic-link"
                >
                  refer.bitclass.live
                </BitButton>
              </div>

              <BitButton
                onClick={onBtnClickHandler}
                className={styles.copyButton}
                variant="contained"
                id="copy-link"
              >
                Click To Copy
              </BitButton>
              <p>
                You have referred{' '}
                <strong>
                  {referralDetails?.bitcash_intro?.total_referrals} people
                </strong>
              </p>
            </div>
          </>
        ) : (
          <RectangularSkeletonLoader height={isMobile ? 600 : 200} />
        )}
      </div>

      <BitModal
        title="Transactions"
        customClass={styles.transactionModalWrapper}
        open={istransactionHistoryViewable}
        onClose={closeTransactionScreen}
      >
        <div className={styles.desktopIdContainer}>
          <ViewTransaction />
        </div>
      </BitModal>
      <BitSnackBar
        visible={visible}
        onClose={() => setVisible(false)}
        vertical="top"
        horizontal="right"
        message="Link Copied Successfully"
      />
    </div>
  );
};

export default ReferralDetails;
