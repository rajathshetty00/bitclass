import { FC } from 'react';
import {
  showReferAFriendPage,
  showReferralPage,
} from 'redux/reducers/profileReducer';
import { useAppDispatch } from 'redux/store';
import { BitButton } from 'src/components/common/BitButton/BitButton';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';

interface ShowReferralScreenProps {}

const ShowReferralScreen: FC<ShowReferralScreenProps> = () => {
  const dispatch = useAppDispatch();

  const onShowReferralClickHandler = () => {
    dispatch(showReferralPage(false));
    dispatch(showReferAFriendPage(true));
    saveGtmDataLayerData({
      event: EVENT_NAMES.REFERRAL_SCREEN_VIEWED,
    });
  };

  return (
    <div className={styles.showReferralRoot}>
      <div className={styles.showReferralWrapper}>
        <div>
          <h3>Want any paid course for FREE?</h3>
          <BitButton onClick={onShowReferralClickHandler} variant="outlined">
            Click Here
          </BitButton>
        </div>
        <NextImage width="140" height="100" src={assetObject.referralGirl} />
      </div>
      <h4>Refer and earn Rs 250/- in your bank account</h4>
    </div>
  );
};

export default ShowReferralScreen;
