import clsx from 'clsx';
import dayjs from 'dayjs';
import { FC, useEffect } from 'react';
import NextImage from 'src/components/common/NextImage/NextImage';
import { assetObject } from 'utils/assetFileNames';
import { EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import styles from './styles.module.scss';
import { useTransactionInfiniteScroll } from './useTransactionInfiniteScroll';

interface ViewTransactionProps {}

const ViewTransaction: FC<ViewTransactionProps> = () => {
  const { results, apiResponse, loading, lastResultElement } =
    useTransactionInfiniteScroll();

  useEffect(() => {
    saveGtmDataLayerData({
      event: EVENT_NAMES.REFERRAL_HISTORY_SCREEN_VIEWED,
    });
  }, []);

  return (
    <div className={styles.viewTransactionContainer}>
      <p>Total BitCash Balance</p>
      <h3>{apiResponse?.wallet_balance}</h3>
      <p>1 BitCash = 1 Rupee</p>
      <p className={styles.lightfont}>*Can be used to buying any course</p>
      {results.map((transaction: any) => (
        <div
          className={styles.transactionCard}
          ref={results.length ? lastResultElement : null}
        >
          <div className={styles.transaction}>
            <div className={styles.detailsContainer}>
              <h6>{transaction?.reason}</h6>
              <p>
                {dayjs.unix(transaction?.transaction_ts).format('DD MMM, YYYY')}
              </p>
            </div>
            <div
              className={clsx(styles.priceContainer, {
                [styles.debit]: transaction.type === 'debit',
                [styles.credit]: transaction.type === 'credit',
              })}
            >
              <span className={styles.price}>
                <NextImage
                  src={assetObject.bitcashLogo}
                  width={20}
                  height={20}
                  className={styles.logo}
                />
                &nbsp;
                <span className={styles.amount}>{transaction?.amount}</span>
              </span>
              {transaction?.expiry_ts && (
                <p>{dayjs.unix(transaction?.expiry_ts).format('DD MMM')}</p>
              )}
            </div>
          </div>
        </div>
      ))}
      {loading && 'LOADING...'}
    </div>
  );
};

export default ViewTransaction;
