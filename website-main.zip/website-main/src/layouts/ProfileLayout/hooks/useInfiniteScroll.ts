import axios from 'axios';
import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, useAppSelector } from 'redux/store';
import { initDefaultsRequestHeader } from 'utils';

const API_ENDPOINT: string = 'v4/profiles/student/my-courses';

function axiosGetV2(endPoint: string, options?: any) {
  initDefaultsRequestHeader();
  return axios.get(`${endPoint}`, options).then((res) => res.data);
}
export const useInfiniteScroll = (isEnded: boolean) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [pageNumber, setPageNumber] = useState(1);
  const { selectedCourseType } = useAppSelector(
    (state: AppState) => state.profile,
  );

  const observer = useRef<any>();
  const lastResultElement = useCallback(
    (node) => {
      if (loading) return;
      if (observer.current) observer.current?.disconnect();
      observer.current = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting && hasMore) {
          setPageNumber((prevPage) => prevPage + 1);
        }
      });
      if (node) observer.current.observe(node);
    },
    [loading, hasMore],
  );
  useEffect(() => {
    setResults([]);
    setApiResponse(null);
    setPageNumber(1);
  }, [isEnded, selectedCourseType]);
  useEffect(() => {
    let cancel: any;
    setLoading(true);
    setError(false);
    (async () => {
      try {
        const { data } = await axiosGetV2(API_ENDPOINT, {
          params: {
            is_ended: isEnded,
            course_type: selectedCourseType,
            pageNum: pageNumber,
            limit: 10,
          },
          // eslint-disable-next-line no-return-assign
          cancelToken: new axios.CancelToken((c) => {
            cancel = c;
            return cancel;
          }),
        });
        const { courses } = data || {};
        const coursesList = courses || [];
        setResults((prevResults: any[]) => [...prevResults, ...coursesList]);
        setApiResponse(data);
        setHasMore(courses.length > 0);
        setLoading(false);
      } catch (err) {
        if (axios.isCancel(err)) return;
        setError(true);
        setLoading(false);
      }
    })();
    return () => {
      if (cancel instanceof Function) cancel();
    };
  }, [isEnded, pageNumber, selectedCourseType]);

  return { loading, error, hasMore, results, apiResponse, lastResultElement };
};
