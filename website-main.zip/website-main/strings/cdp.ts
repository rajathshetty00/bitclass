export const checkoutModalFooterText: string = 'Pay and Book';
