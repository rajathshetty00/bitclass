import axios, { AxiosError, AxiosResponse } from 'axios';
import { API_URL, BASE_URL } from 'utils/constants';

const Axios = axios.create({
  baseURL: BASE_URL || API_URL,
  timeout: 10000,
});
export default Axios;

export const responseHandler = (response: AxiosResponse) => {
  if (response.status === 401) {
    const param = new URLSearchParams(response.config.params);
    const paramStr = param.toString();
    if (paramStr.length) {
      localStorage.setItem('url_params', paramStr);
      window.location.href = `/live-classes/signin?${paramStr}`;
    } else {
      window.location.href = `/live-classes/signin?${paramStr}`;
    }
  }
  return response;
};
export const errorHandler = (error: AxiosError) => {
  const { response } = error;
  if (response?.status === 401) {
    const param = new URLSearchParams(response.config.params);
    const paramStr = param.toString();
    if (paramStr.length) {
      localStorage.setItem('url_params', paramStr);
      window.location.href = `/live-classes/signin?${paramStr}`;
    } else {
      window.location.href = `/live-classes/signin${paramStr}`;
    }
  }
  // Do something with request error
  return Promise.reject(error);
};
