/* eslint-disable import/prefer-default-export */
import {
  axiosDel,
  axiosGet,
  axiosPatch,
  axiosPost,
  fetchGetData,
} from 'utils/api/request';
import { ENV, GRAVITON_API_URL } from 'utils/constants';
import { CDP_TYPE } from 'utils/constants/cdp';

export const getAllCategories = () => axiosGet('v2/discovery/categories');

export const getFreeCourses = (category: string) =>
  axiosGet(
    `v2/discovery/search?course_type=${
      CDP_TYPE.free
    }&pageNum=${1}&limit=10&categories=${encodeURIComponent(category)}`,
  );

export const getTeacherList = () => axiosGet('v2/feed/top-teachers');

export const getBannerImages = () => axiosGet(`v2/feed/highlights`);

export const getFullCourseV3 = (courseCode: string) =>
  axiosGet(`v3/courses/${courseCode}`);

export const getCdpTmprDataV3 = (tmprCode: string) =>
  axiosGet(`v3/courses/tmpr/${tmprCode}`);

export const getSubscriptionPlan = (courseCode: string) =>
  axiosGet(`subscription/${courseCode}/get_plans/`, GRAVITON_API_URL);

export const makeSubscriptionOrder = (payload: any) =>
  axiosPost(`order/`, payload, GRAVITON_API_URL);

export const generateOTP = (payload: any) =>
  axiosPost(
    `v1/auth/generate-otp
`,
    payload,
    GRAVITON_API_URL,
  );

export const userLogin = (payload: any) => {
  if (ENV === 'local') {
    return axiosPost(`v1/auth/login?platform=iOS`, payload, GRAVITON_API_URL);
  }
  return axiosPost(`v1/auth/login`, payload, GRAVITON_API_URL);
};

export const getUserInfo = (payload = '') =>
  axiosGet(`v1/users/info${payload}`, GRAVITON_API_URL);

export const patchUserInfo = (payload: any) =>
  axiosPatch(`v1/users/info`, payload, GRAVITON_API_URL);

export const createCourseOrder = (payload: any) =>
  axiosPost(`v2/orders`, payload);

export const createSubscriptionOrder = (payload: any) =>
  axiosPost(`order/`, payload, GRAVITON_API_URL);

export const createOrder = (payload: any) =>
  axiosPost(`order/`, payload, GRAVITON_API_URL);

export const createV2Order = (payload: any) => axiosPost(`v2/orders`, payload);

export const registerUserForCourse = (payload: any, code: string) => {
  return axiosPost(`v2/courses/${code}/register`, payload);
};

// API for Follow/Un-Follow
export const followTeacher = (code: any) =>
  axiosPost(`v2/student-profiling/follow/${code}`, {});

export const unfollowTeacher = (code: any) =>
  axiosDel(`v2/student-profiling/follow/${code}`);

export const getFollowingList = (code: any) =>
  axiosGet(`v2/student-profiling/${code}/following`);

export const getMyFollowingList = () =>
  axiosGet(`v2/student-profiling/following`);

export const validateCoupon = (payload: any) =>
  axiosPost('v2/coupons/validate', payload);

export const getMyFaqList = () => axiosGet(`v3/courses/student_faq`);
// notify cdp
export const saveNotifyUser = (courseCode: any) =>
  axiosPost('v2/leads/notify-me', {
    intent: {
      course_code: courseCode,
    },
  });

export const getCurriculumDetails = (courseCode: string) =>
  axiosGet(`v1/courses/curriculum/${courseCode}/`, GRAVITON_API_URL);

export const checkRegistrations = (courseCode: string) =>
  axiosGet(`v1/courses/${courseCode}/check-registration`, GRAVITON_API_URL);

export const checkRegistrationOfCourse = (courseCode: string) =>
  axiosGet(`v3/courses/${courseCode}/check-registration`);

export const checkRegistrationOfCourseInTmpr = (tmprCode: string) =>
  axiosGet(`v2/marketing/${tmprCode}/check-tmpr-registration-status`);

export const getWalletBalanceOfUser = (amount: any = '') =>
  axiosGet(`v1/users/wallet?amount=${amount}`, GRAVITON_API_URL);

export const getStreamingTokenGeneric = (courseCode: string) =>
  axiosGet(`v2/videos/generate-live-token/${courseCode}`);

export const getZoomEngagementData = (courseCode: string) =>
  axiosGet(`v3/videos/zoom_engagement_config/${courseCode}`);

export const getSelf = () => axiosGet(`v2/users/me`);
export const getReferralLink = () =>
  axiosGet(`v1/users/referral-link`, GRAVITON_API_URL);

export const getProfileDetails = () => axiosGet(`v2/student-profiling/profile`);

export const patchProfileInfo = (payload: any) =>
  axiosPatch(`v2/student-profiling/profile`, payload);

export const getTeacherApplicationStatus = () =>
  axiosGet('v2/profiles/application/status');

// collection apis
export const getCollectionPublicData = (slug: string) =>
  axiosGet(`collections/v2/${slug}/`, GRAVITON_API_URL);

export const getResultsFromDynamicEndPoint = (endpoint: string) =>
  fetchGetData(endpoint);

export const getCategoryPublicData = (slug: string) => {
  if (!slug) return axiosGet(`v1/homepage/`, GRAVITON_API_URL);
  return axiosGet(
    `v1/categories/public/${slug === '' ? slug : `${slug}/`}`,
    GRAVITON_API_URL,
  );
};

export const getRecordingDetailsById = (recordingId: any) =>
  fetchGetData(
    `https://discovery-service.bitclass.live/api/videos/video?id=${recordingId}`,
  );
