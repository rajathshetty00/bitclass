import axios, { AxiosResponse } from 'axios';
import {
  getCookie,
  //  getAuthToken, getCookie,
  initDefaultsRequestHeader,
  isEmptyObject,
} from 'utils';
import { ENV } from 'utils/constants';
import Axios from './axios';

export function axiosPost(endPoint: string, payload: any, baseUrl?: string) {
  initDefaultsRequestHeader(baseUrl);
  return axios.post(`/${endPoint}`, payload).then((res) => {
    return res.data;
  });
}

export function axiosPatch(endPoint: string, payload: any, baseUrl?: string) {
  initDefaultsRequestHeader(baseUrl);
  return axios.patch(`/${endPoint}`, payload).then((res) => res.data);
}

export function axiosGet(endPoint: string, baseUrl?: string) {
  initDefaultsRequestHeader(baseUrl);
  return axios.get(`/${endPoint}`).then((res) => res.data);
}

export function axiosDel(endPoint: string, baseUrl?: string) {
  initDefaultsRequestHeader(baseUrl);
  return axios.delete(`/${endPoint}`).then((res) => res.data);
}

export async function fetchGetData(endpoint: string) {
  const opts: any = {
    headers: {
      'Content-Type': 'application/json',
    },
    method: 'get',
    baseURL: endpoint,
    withCredentials: true,
  };

  if (ENV === 'local' && typeof window !== 'undefined') {
    opts.headers.Authorization = getCookie('auth-key');
  }

  return Axios(endpoint, opts).then(async (res: AxiosResponse) => {
    if (res.status === 200) return res.data;
    if (res.status === 401) {
      window.location.href = '/live-classes/signin';
    }
    return null;
  });
}

export const getReqParams = () => {
  if (typeof window !== 'undefined') {
    const { search } = window.location;
    const params = Object.fromEntries(new URLSearchParams(search));
    if (!isEmptyObject(params)) {
      return params;
    }
  }
  return {};
};
