// set user info in localstorage

import { getTeacherApplicationStatus } from 'utils/api';

export const saveUserInfo = (data: any) => {
  const {
    id,
    username,
    code,
    image,
    chat_auth_token: chatAuthToken,
    admin,
    teacherHandle,
    phone,
    email,
    first_name: firstName,
    Authorization,
    compliance_state,
  } = data;
  const extractedInfo = {
    id,
    username,
    code,
    image,
    chatAuthToken,
    admin,
    teacherHandle,
    phone,
    email,
    firstName,
    Authorization,
    compliance_state,
  };
  localStorage.setItem('userInfo', JSON.stringify(extractedInfo));
  if (compliance_state) localStorage.setItem('state', compliance_state);

  localStorage.setItem('authenticated', JSON.stringify(true));
  localStorage.setItem('role', 'student');
};

// get user info stored in localstorage
export const hasAuthToken = () =>
  JSON.parse(localStorage.getItem('authenticated') || 'false');

export const getUserInfo = () => JSON.parse(localStorage.getItem('userInfo')!);

export const getStudentChatAuthToken = () =>
  getUserInfo()?.chatAuthToken?.student_chat_auth_token;

export const getTeacherChatAuthToken = () =>
  getUserInfo()?.chatAuthToken?.teacher_chat_auth_token;

export const getUID = () => {
  return getUserInfo()?.id;
};

export const getTeacherHandle = () => getUserInfo()?.teacherHandle;

export const getName = () =>
  getUserInfo()?.firstName ? getUserInfo()?.firstName : getUserInfo()?.username;

export const getComplianceState = () => localStorage.getItem('state');

export const getPhone = () => getUserInfo()?.phone;

export const getEmail = () => getUserInfo()?.email;

export const getAdmin = () => getUserInfo()?.admin;

export const getRole = () => localStorage.getItem('role');

export const getCode = () => getUserInfo()?.code;

export const setRole = (role: string) => localStorage.setItem('role', role);

export const getDefaultRouteForLoggedIn = async () => {
  if (hasAuthToken()) {
    // const role = getRole();
    // if (role === 'student') {
    //   setRole('student');
    //   return '/profile';
    // }
    try {
      const status_res = await getTeacherApplicationStatus();
      if (status_res?.data) {
        switch (status_res.data.application_status) {
          case 'not_started':
          case 'started':
          case 'submitted':
          case 'approved':
          case 'rejected':
            setRole('teacher');
            return '/profile/apply';
          case 'approved_notified':
            setRole('teacher');
            // route change
            // return `/${getTeacherHandle()}/profile`
            return `/profile`;

          default:
            setRole('student');
            return '/live-classes/profile';
        }
      } else {
        setRole('student');
        return '/live-classes/profile';
      }
    } catch (e) {
      setRole('student');
      return '/live-classes/profile';
    }
  } else {
    return '/';
  }
};
