/* eslint-disable camelcase */
import { ITestimonial } from 'interfaces/cdp/testimonial';
import { ITeacher } from 'interfaces/cdp/teacher';
import { IFaq } from 'interfaces/cdp/faqs';
import { assetObject } from 'utils/assetFileNames';
import { IAdditional } from 'interfaces/cdp/additonalInfo';
import { getFullCourseV3 } from 'utils/api';
import { saveCourseData } from 'redux/reducers/cdpReducer';
import { savePageType } from 'redux/reducers/appReducer';
import PAGE_TYPES from 'utils/constants/pageTypes';
import { routeToNotFoundPage } from 'utils';
import { BASE_URL } from 'utils/constants';

interface IBanner {
  heading: string;
  intro_video_thumbnail: string;
  intro_video: string;
}
interface ICourse extends IBanner {
  start_ts: Float32Array;
  teacher: ITeacher;
  highlights: String[];
  testimonials: ITestimonial[];
  faqs: IFaq[];
  additional_info: IAdditional;
  actualCourseUrl: string;
  heading: string;
  code: string;
  type: string;
}

const setCourseUrl = (contextData: any) => {
  return BASE_URL + contextData.req.url;
};

export const cdpTypeController = async ({
  dispatch,
  courseCode,
  context,
}: any) => {
  try {
    const { data: courseData, success } = await getFullCourseV3(courseCode);
    if (success) {
      dispatch(
        saveCourseData({ ...courseData, couse_sub_url: setCourseUrl(context) }),
      );
      dispatch(savePageType(PAGE_TYPES.CDP_SUBSCRIPTION_PAGE));
    } else {
      routeToNotFoundPage(context.res);
    }
  } catch (error) {
    return error;
  }
};

const getBannerDetails = (course: IBanner) => {
  return {
    heading: course.heading,
    introVideoThumbnail:
      course?.intro_video_thumbnail ?? assetObject.defaultCdpImage,
    introVideo: course?.intro_video,
  };
};

const getTeacherResults = (courseData: ICourse) => {
  const { teacher } = courseData;
  return {
    teacher_name: teacher?.teacher_name,
    profile_id: teacher?.profile_id,
    story: teacher?.story,
    image: teacher?.image ?? assetObject.teacherEmpty,
    code: teacher?.code,
  };
};

const getCourseDetails = (courseData: ICourse) => {
  const banner = getBannerDetails(courseData);
  const teacherDetails = getTeacherResults(courseData);
  const {
    highlights,
    testimonials,
    faqs,
    additional_info,
    actualCourseUrl,
    heading,
    code,
    type,
  } = courseData;
  return {
    teacherDetails,
    highlights,
    testimonials,
    banner,
    faqs,
    additionalInfo: additional_info,
    courseUrl: actualCourseUrl,
    heading,
    code,
    type,
  };
};
export default getCourseDetails;
