/* eslint-disable camelcase */
import { IAboutTeacher } from 'interfaces/curriculumCdp/aboutTeacher';
import { IBanner } from 'interfaces/curriculumCdp/banner';
import { ICertificate } from 'interfaces/curriculumCdp/certificate';
import { ICurriculum } from 'interfaces/curriculumCdp/curriculum';
import { ICurriculumCdpFaq } from 'interfaces/curriculumCdp/curriculumFaq';
import { IFeatured } from 'interfaces/curriculumCdp/feature';
import { IFreeClass } from 'interfaces/curriculumCdp/freeClass';
import { IShowCase } from 'interfaces/curriculumCdp/showCase';
import { ITestimonials } from 'interfaces/curriculumCdp/testimonial';
import { IWhyBitclass } from 'interfaces/curriculumCdp/whyBitclass';
import { IWhyBuyContent } from 'interfaces/curriculumCdp/whyBuy';
import { assetObject } from 'utils/assetFileNames';

export interface ISections {
  faqs: ICurriculumCdpFaq;
  why_buy: IWhyBuyContent;
  showcase: IShowCase;
  freeclass_curriculum: IFreeClass;
  featured: IFeatured;
  why_bitclass: IWhyBitclass;
  teachers: IAboutTeacher;
  testimonials: ITestimonials;
  curriculum: ICurriculum;
  certificate: ICertificate;
}
// CurriculumCdp interface
interface ICurriculumCdp extends IBanner {
  id: number;
  slug?: string;
  heading: string;
  goal: string;
  currency: string;
  additional_info: string;
  testimonials: string | null;
  meta: string | null;
  active: boolean;
  status: string;
  code: string;
  type: string;
  sections: ISections;
  full_course_amount: number;
  workshop_course_amount: number;
  next_course_batch_start_ts: number;
  has_full_course_ended: boolean;
  has_workshop_ended: boolean;
  num_classes: number;
}

const getBannerDetails = (curriculumCdp: IBanner) => {
  return {
    introVideoThumbnail:
      curriculumCdp?.intro_video_thumbnail ?? assetObject.defaultCdpImage,
    introVideo: curriculumCdp?.intro_video,
  };
};
const getCurriculumCDPDetails = (curriculumCdp: ICurriculumCdp) => {
  const banner = getBannerDetails(curriculumCdp);
  const {
    code,
    type,
    sections,
    heading,
    intro_video_thumbnail,
    intro_video,
    goal,
    id,
  } = curriculumCdp;
  return {
    code,
    type,
    sections,
    banner,
    goal,
    id,
    heading,
    intro_video,
    intro_video_thumbnail,
  };
};
export default getCurriculumCDPDetails;
