export const CDP_TYPE = {
  subscription: 'subscription',
  freemium: 'freemium',
  free: 'free',
  fullCourse: 'full_course',
  workshop: 'workshop',
  advancedCourse: 'advanced_course',
  curriculum: 'curriculum',
  tmpr: 'tmpr',
};
export const CHECKOUT_STATES = Object.freeze({
  batchSelection: 'batchSelection',
  orderSummary: 'orderSummary',
  slotSelection: 'slotSelection',
  paymentSuccess: 'paymentSuccess',
  paymentFailure: 'paymentFailure',
});

export const PAYMENT_TYPE = Object.freeze({
  paid: 'paid',
  free: 'free',
});

export const RIGHT_SECTION_STATUS = {
  LOADING: 'LOADING',
  SUBSCRIPTION: 'SUBSCRIPTION',
  FREEMIUM: 'FREEMIUM',
  FULLCOURSE: 'FULLCOURSE',
  TMPR: 'TMPR',
};

export const ABTestingObject: any = {
  TMPR67e4e7: {
    thumbnail:
      'https://media.bitclass.live/image/upload/f_auto,q_auto/NEw%20-%20CDP/Divya/CDP_thumbnail_5_oogzcp.jpg',
    about: `<p><strong>Want to get creative with craft and learn new skills and techniques?</strong> <br /><br />Get started with the french technique called Decoupage art! <br /><br />In this course, you'll learn to create different masterpieces with beautiful papers and even start your own business. <br /><br /></p>
    <h3><strong>What you'll learn in this class? </strong></h3>
    <ul>
    <li>How to prime any base. How to use and put decoupage paper or decoupage tissue.</li>
    <li>Techniques to get the wrinkle-free effect</li>
    <li>What paints to use</li>
    <li>How to merge the paints</li>
    <li>Stenciling technique</li>
    <li>Loads of ideas and tips to create your own gifting and home decor items</li>
    </ul>
    <p>&nbsp;</p>
    <p><em>What are the materials required? </em></p>
    <ul>
    <li>Any base of your choice (coaster, bottle, box, plate, jar, bowl)</li>
    <li>Decoupage napkin / design paper / printout Decoupage glue / fevicol</li>
    <li>Flat brush No. 6 or 8 and Round brush No.1 or 2</li>
    <li>A small piece of sponge</li>
    <li>A bowl of water</li>
    <li>A pallet Plastic sheet / transparent plastic cover Acrylic paints - white compulsory.</li>
    </ul>
    <p>&nbsp;</p>
    <p><strong>REGISTER TODAY</strong> and discover how to create beautiful paper art!</p>
`,
  },

  TMPRa7f77b: {
    thumbnail:
      'https://media.bitclass.live/image/upload/f_auto,q_auto/NEw%20-%20CDP/Divya/CDP_thumbnail_2_zobu9w.jpg',
    about: `<p><strong>Have you ever dreamed of flying high?</strong><br /><strong>Is working as a cabin crew your dream job?</strong></p>
<p><br />If you answered <strong>YES</strong> to the above, then you are at the right place!</p>
<h3><br />What you'll learn in this 1-day workshop?</h3>
<ul>
<li>Introduction video on how to become a cabin crew</li>
<li>Perks of being a cabin crew</li>
<li>Different departments of aviation (basics)</li>
<li>Customer service basics</li>
<li>Tips &amp; tricks to kickstart your career as a flight attendant</li>
</ul>
<p><strong>REGISTER TODAY</strong> to forge ahead in the aviation industry!<br /></p>
      `,
  },

  TMPRfc51b2: {
    thumbnail:
      'https://media.bitclass.live/image/upload/f_auto,q_auto/App%20Highlights/resin_CDP_1_zrhbes.jpg',
    about: `<p><strong>Welcome to the World of Resin Art</strong></p>
<h3><br />What you will discover in this course?</h3>
<ul>
<li>Resin &amp; types of resin</li>
<li>Preparing the base</li>
<li>Proper way of mixing</li>
<li>Use of pigments and tools needed</li>
<li>Essence of resin art- lacing effect. It's the main charm of resin art</li>
<li>How to finish up the product</li>
<li>What are the materials required for the course?</li>
<li>Any resin medium</li>
<li>Any wooden/MDF base piece/coasters available</li>
<li>Resin colors (minimum 3)</li>
<li>White acrylic color</li>
<li>Any Metallic Color (Silver/Gold)</li>
<li>Brushes</li>
<li>Weighing Scale, blow torch, mask &amp; gloves</li>
<li>Plastic cups</li>
<li>Ice cream sticks</li>
<li>Tissue paper</li>
<li>Plastic sheet to spread to avoid spoilage of working place</li>
<li>Straw</li>
<li>Abro-tape or Latex</li>
</ul>
<p>Make way for your resin masterpiece!</p>
<p><br /><strong>REGISTER NOW</strong> and explore unique and innovative DIY craft methods!</p>
      `,
  },
};
