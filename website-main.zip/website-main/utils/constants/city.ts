import indianCities from 'utils/constants/json/IndianCities.json';

export const getCities = () => indianCities;
