export const GTM_ID = process.env.NEXT_PUBLIC_GOOGLE_TAG_MANAGER_ID;
export const API_URL = process.env.NEXT_PUBLIC_API_URL;
export const GRAVITON_API_URL = process.env.NEXT_PUBLIC_GRAVITON_API_URL;
export const DISCOVERY_API_URL = process.env.NEXT_PUBLIC_DISCOVERY_URL;

export const BASE_URL: string = process.env.NEXT_PUBLIC_BASE_URL ?? '';
export const ROOT_URL = process.env.NEXT_PUBLIC_ROOT_URL;
export const RAZORPAY_ID = process.env.NEXT_PUBLIC_RAZORPAY_ID;
export const GOOGLE_CLIENT_ID: any = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;
export const ENV = process.env.NEXT_PUBLIC_ENV;
export const COOKIE_DOMAIN = process.env.NEXT_PUBLIC_COOKIE_DOMAIN;
export const ZOOM_SDK_VERSION = '2.3.5';
export const PAYMENT_MODE = 'national';
export const RAZORPAY_SDK_URL = 'https://checkout.razorpay.com/v1/checkout.js';
export const RAZORPAY_COLOR_CODE = '#2aa39a';
export const BIT_CLASS_LOGO =
  'https://res.cloudinary.com/bitclass/image/upload/q_50/v1611642325/Logos/LogoForWhiteBg_fzifpm.svg';

export const CHRISTMAS_LOGOS = {
  logoForWhiteBg:
    'https://res.cloudinary.com/bitclass/image/upload/v1640065489/BitClass/Logos/BitClass-Christmas/full-logo_qjwn5d.png',
  logoSmallForWhiteBg:
    'https://res.cloudinary.com/bitclass/image/upload/v1640065489/BitClass/Logos/BitClass-Christmas/logo-512_wwjvfa.png',
  logoForBlackBg:
    'https://res.cloudinary.com/bitclass/image/upload/v1640065488/BitClass/Logos/BitClass-Christmas/white-full-01_btpz4n.png',
  logoSmallForBlackBg:
    'https://res.cloudinary.com/bitclass/image/upload/v1640065488/BitClass/Logos/BitClass-Christmas/white-icon-02_igwor7.png',
};

export const CLOUDINARY_CONFIG = {
  cloud_name: 'bitclass',
  upload_preset: 'jp936t7u',
  folder: 'BitClass',
  sources: ['local', 'url'],
  showUploadMoreButton: false,
  secure: true,
};

// @ts-ignore
export const sectionData = {
  title: 'Why our students love us?',
  subtitle: 'See what people are saying about our unique and effective formula',
  content: [
    {
      title: 'Tarun - Cryptocurrency',
      description:
        "I attended crypto course on BitClass with Munish and he taught me a lot about crypto and I'm really grateful for it. Right now I started investing really a bit in crypto.",
      video_thumbnail:
        'https://res.cloudinary.com/bitclass/image/upload/v1627376960/Assets/Student%20Testimonials/tarun_qkt5pp.png',
      video:
        'https://res.cloudinary.com/bitclass/video/upload/v1622050959/Assets/WhatsApp_Video_2021-05-26_at_21.06.30_fg5hvk.m3u8',
      thumb:
        'https://res.cloudinary.com/bitclass/image/upload/v1622056543/Assets/Student%20Testimonials/tarun_xnrgon.png',
    },
    {
      title: 'Priyanshu - Acting',
      description:
        'Ankur sir and Sagar sir taught me about acting. I learnt camera acting, emotions and secrets to auditions.',
      video_thumbnail:
        'https://res.cloudinary.com/bitclass/image/upload/v1627376960/Assets/Student%20Testimonials/priyanshu_gtrudz.png',
      video:
        'https://res.cloudinary.com/bitclass/video/upload/v1621866278/Assets/Student%20Testimonials/Priyanshu%2Bacting.m3u8',
      thumb:
        'https://res.cloudinary.com/bitclass/video/upload/v1621866278/Assets/Student%20Testimonials/Priyanshu%2Bacting.png',
    },
    {
      title: 'Vidya - Hyper Realism ',
      description: `I took Realism class in Potrait Sketching with Richa ma'am. It was very interactive, informative, in detail explanation and I enjoyed learning.`,
      video_thumbnail:
        'https://res.cloudinary.com/bitclass/image/upload/v1627376960/Assets/Student%20Testimonials/vidya_bhsw3h.png',
      video:
        'https://res.cloudinary.com/bitclass/video/upload/v1621866274/Assets/Student%20Testimonials/Vidya.m3u8',
      thumb:
        'https://res.cloudinary.com/bitclass/image/upload/c_fit/v1621874505/Assets/Student%20Testimonials/vidya_jgjdas.png',
    },
    {
      title: 'Aishikee - Interior Designing',
      description: `I attended interior designing classes by mehak. The relationship was close that we could as her for any doubts. The time spent here was great and I learnt a lot of things. Thanks to BitClass.`,
      video_thumbnail:
        'https://res.cloudinary.com/bitclass/image/upload/v1627376960/Assets/Student%20Testimonials/aisheke_k3hfqd.png',
      video:
        'https://res.cloudinary.com/bitclass/video/upload/v1622050991/Assets/20210526_193556_ceqwka.m3u8',
      thumb:
        'https://res.cloudinary.com/bitclass/image/upload/c_fit/v1622056544/Assets/Student%20Testimonials/aisheeki_odfu1s.png',
    },
  ],
};
