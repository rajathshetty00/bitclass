// eslint-disable-next-line import/prefer-default-export
export interface IPageTypeProps {
  [key: string]: string;
}

const PAGE_TYPES: IPageTypeProps = {
  CDP_SUBSCRIPTION_PAGE: 'CDP_SUBSCRIPTION_PAGE',
  CDP_FREEMIUM_PAGE: 'CDP_FREEMIUM_PAGE',
  CDP_CURRICULUM_PAGE: 'CDP_CURRICULUM_PAGE',
  CDP_FULL_COURSE_PAGE: 'CDP_FULL_COURSE_PAGE',
  CDP_FREE_COURSE_PAGE: 'CDP_FREE_COURSE_PAGE',
  CDP_WORKSHOP_PAGE: 'CDP_WORKSHOP_PAGE',
  CDP_TMPR_PAGE: 'CDP_TMPR_PAGE',
  PROFILE_PAGE: 'PROFILE_PAGE',
  COLLECTION_PAGE: 'COLLECTION_PAGE',
  CATEGORY_PAGE: 'CATEGORY_PAGE',
  HOME_PAGE: 'HOME_PAGE',
};

export default PAGE_TYPES;

export const CHANNEL_LIST: any = {
  CDP_SUBSCRIPTION_PAGE: 'CDP_SUBSCRIPTION_PAGE',
  CDP_FREEMIUM_PAGE: 'CDP_FREEMIUM_PAGE',
  CDP_CURRICULUM_PAGE: 'CDP_CURRICULUM_PAGE',
  CDP_FULL_COURSE_PAGE: 'CDP_FULL_COURSE_PAGE',
  CDP_FREE_COURSE_PAGE: 'CDP_FREE_COURSE_PAGE',
  CDP_WORKSHOP_PAGE: 'CDP_WORKSHOP_PAGE',
  CDP_TMPR_PAGE: 'CDP_TMPR_PAGE',
  PROFILE_PAGE: 'PROFILE_PAGE',
  COLLECTION_PAGE: 'collection_page',
  CATEGORY_PAGE: 'category_page',

  HOME_PAGE: {
    search: 'search',
    teacher: 'home_teachers',
    highlights: 'webbanner',
    upcoming_live_classes: 'web_home_carousel',
    upcoming_full_courses: 'web_home_carousel',
  },
};
export const extractPageTypeFromURL = (url: string) => {
  if (url.includes('category')) return 'category';
  if (url.includes('collection')) return 'collection';
  if (url.includes('profile')) return 'my_classes';

  if (url.includes('')) return 'home';
};

export const channeQueryMaker = (channel: string, isMobile: boolean = true) =>
  `channel=${channel}&platform=${isMobile ? 'mweb' : 'web'}`;
export const getChannel = (url: string) => {
  const pageType = extractPageTypeFromURL(url);
  switch (pageType) {
    case 'category':
      return 'category_page';
    case 'collection':
      return 'collection_page';
    default:
      return 'home_page';
  }
};
