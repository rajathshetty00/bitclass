// @ts-ignore
export const studentId = JSON.parse(localStorage.getItem('userInfo'))?.id;
