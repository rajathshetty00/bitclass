import dayjs from 'dayjs';
import { getDateFormat } from 'utils';
import { getCode } from './auth/userInfo';

export const extractCdpData = (data: any) => {
  return {
    source: 'direct',
    course_title: data?.heading,
    course_code: data?.code,
    teacher_name: data?.teacher?.teacher_name,
    course_type: data?.type,
    course_start_date: getDateFormat(data?.start_ts, 'MMM DD, YYYY'),
    course_end_date: getDateFormat(data?.end_ts, 'MMM DD, YYYY'),
    course_category: data?.category ?? data?.categories[0],
    course_currency: data?.currency,
    course_amount: data?.amount,
    student_id: getCode(),
    bitcash_used: data?.bitcash_used,
    coupon_used: data?.coupon_used,
    course_time_schedule: data?.weekly_schedule
      ? data?.weekly_schedule.map((ws: any) => dayjs.unix(ws).format('hh:mm a'))
      : [],
  };
};

export const extractCollectionData = (data: any) => {
  return {
    heading: data?.meta?.heading,
    description: data?.meta?.description,
    slug: data?.meta?.slug ?? data?.meta?.heading,
  };
};

export const extractCategoryData = (data: any) => {
  return {
    heading: data?.meta?.heading,
    description: data?.meta?.description,
  };
};
