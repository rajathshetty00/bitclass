/* eslint-disable import/prefer-default-export */
import currencyList from 'utils/currencyList.json';

export const getCurrencySymbol = (currency: string) => {
  // @ts-ignore
  return currencyList?.[currency]?.symbol;
};

export const CURRENCY_SYMBOL: any = {
  INR: '₹',
};
