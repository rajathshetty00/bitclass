/* eslint-disable camelcase */
/* eslint-disable no-underscore-dangle */
import dayjs from 'dayjs';

const _DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const formatDate = (epoch: any, format = 'DD MMM YYYY') => {
  if (!epoch || !format) return '';
  try {
    const _r = dayjs.unix(epoch).format(format);
    return _r;
  } catch (e) {
    return '';
  }
};
export const getCourseScheduleDetails = (
  schedule = [],
  duration = 0,
  onlyStartTime: any,
) => {
  if (!Array.isArray(schedule) || schedule.length <= 0) return [];

  const _r = [];
  const _b: any = {};
  schedule.forEach((v) => {
    const _d = formatDate(v, 'ddd');
    const _start_time = formatDate(v, 'hh:mma');
    const _end_time = formatDate(v + duration * 60, 'hh:mma');
    const _e = onlyStartTime
      ? `${_d}: ${_start_time}`
      : `${_d}: ${_start_time} - ${_end_time}`;
    _r.push(_e);
    const _key = onlyStartTime
      ? `${_start_time}`
      : `${_start_time} - ${_end_time}`;
    if (Array.isArray(_b[_key])) {
      _b[_key].push(_d);
    } else {
      _b[_key] = [_d];
    }
  });
  for (const i in _b) {
    _b[i] = Array.from(
      new Set(
        _b[i].sort((a: any, b: any) => _DAYS.indexOf(a) - _DAYS.indexOf(b)),
      ),
    );
  }
  let _text = [];
  for (const i in _b) {
    if (_b[i].length === 7) {
      _text.push({ label: 'Everyday:', data: i });
    } else {
      let _daysArr = [];
      for (let j = 0; j < _b[i].length; j++) {
        const __day = _b[i][j];
        const __nextDay = _b[i][j + 1];
        _daysArr.push(__day);
        if (
          typeof __nextDay === 'undefined' ||
          _DAYS.indexOf(__nextDay) - _DAYS.indexOf(__day) > 1
        ) {
          _text.push(
            _daysArr.length > 2
              ? { label: `${_daysArr[0]} - ${__day} :`, data: i }
              : { label: `${_daysArr.join(', ')} :`, data: i },
          );
          _daysArr = [];
        }
      }
    }
  }

  // sort the response
  _text = _text.sort(
    (a, b) =>
      _DAYS.indexOf(a.label.substring(0, 3)) -
      _DAYS.indexOf(b.label.substring(0, 3)),
  );
  return _text;
};
