export const EVENT_NAMES = {
  CDP_LANDED: 'course_description_page_viewed',
  CDP_JOIN_CLICKED: 'course_description_page_join_this_course_button_clicked',
  SUBSCRIPTION_RENEW_CLICKED: 'subscription_renew_clicked',
  LOGIN_VIEWED: 'login_page_screen_viewed',
  LOGIN_SIGNIN_WITH_OTP_CLICKED: 'login_page_signin_with_otp_clicked',
  LOGIN_GOOGLE_LOGIN_CLICKED: 'login_page_signin_with_google_clicked',
  LOGIN_OTP_SUCCESSFUL: 'verify_otp_page_otp_successful',
  LOGIN_GOOGLE_SUCCESSFUL: 'login_page_signin_with_google_successful',
  LOGIN_SUCCESSFUL: 'login_successful',
  SIGNUP_PAGE_VIEWED: 'signup_page_viewed',
  SIGNUP_SUCCESSFUL: 'signup_successful',
  LOGOUT_CLICKED: 'logout_clicked',
  SUBSCRIPTION_PLAN_SELECTED: 'subscription_plan_selected',
  SUBSCRIPTION_EXPIRED_SCREEN_SHOWN: 'subscription_expired_screen_shown',
  HOMEPAGE_VIEWED: 'web_home_page_landed',

  BOOK_FREE_CLASS_CLICKED: 'book_free_class_clicked',
  STUDENT_SHOWCASE_SCROLLED: 'student_showcase_scrolled',
  BUY_FULL_COURSE_CLICKED: 'buy_full_course_clicked',
  STUDENT_TESTIMONIAL_CLICKED: 'student_testimonial_clicked',
  TEACHER_SHOWCASE_SCROLLED: 'teacher_showcase_scrolled',
  FAQ_CLICKED: 'faq_clicked',
  CURRICULUM_NOTIFY_ME: 'curriculum_notify_me',
  SLOT_SELECTION_SLOT_SELECTED: 'course_slot_selection_slot_selected',
  SLOT_SELECTION_CONFIRM_SLOT_CLICKED:
    'course_slot_selection_confirm_slot_clicked',
  CDP_SHOW_MORE_CLICKED: 'CDP_SHOW_MORE_CLICKED',
  PAY_AND_BOOK_CLICKED: 'pay_and_book_clicked',
  SHARE_CLICKED: 'share_clicked',
  CDP_FAQ_CLICK: 'course_description_page_faq_clicked',
  COURSE_SLOT_SELECTION_POPUP_VIEWED: 'course_slot_selection_popup_viewed',
  COURSE_SLOT_SELECTION: 'course_slot_selection',
  COURSE_SLOT_SELECTION_CONFIRM_SLOT_CLICKED:
    'course_slot_selection_confirm_slot_clicked',
  COURSE_ORDER_SUMMARY_SCREEN_VIEWED: 'course_order_summary_screen_viewed',
  CURRICULUM_CDP_LANDED: 'cdp_landed',
  APPLY_COUPON_CLICKED: 'apply_promo_code_apply_button_clicked',
  COUPON_STATUS: 'promo_code_status',
  CDP_VIDEO_CLICKED: 'video_action_clicked',

  // payment events
  PAYMENT_SCREEN_VIEWED: 'payment_screen_viewed',
  PAYMENT_FAILED: 'payment_failed',
  PAYMENT_SUCCESSFUL: 'payment_successful',

  // footer
  FOOTER_HOME_CLICKED: 'home_footer_home_clicked',
  FOOTER_BLOG_CLICKED: 'home_bottom_bar_blog_clicked',
  FOOTER_ABOUT_CLICKED: 'home_bottom_bar_about_clicked',
  FOOTER_CONTACT_US_CLICKED: 'home_bottom_bar_contacts_clicked',
  TEACH_ON_BITCLASS_CLICKED: 'teach_on_bitclass_page_clicked',
  FOOTER_CAREERS_CLICKED: 'home_bottom_bar_careers_clicked',
  FOOTER_POLICY_CLICKED: 'home_bottom_bar_policy_clicked',
  FOOTER_PHONE_CLICKED: 'home_bottom_bar_phone_clicked',
  FOOTER_EMAIL_CLICKED: 'home_bottom_bar_email_clicked',
  FOOTER_FB_CLICKED: 'home_bottom_bar_fb_clicked',
  FOOTER_TWITTER_CLICKED: 'home_bottom_bar_twitter_clicked',
  FOOTER_LINKEDIN_CLICKED: 'home_bottom_bar_linkedin_clicked',
  FOOTER_INSTAGRAM_CLICKED: 'home_bottom_bar_instagram_clicked',
  FOOTER_TERM_CLICKED: 'home_bottom_bar_term_clicked',

  // profile
  DASHBOARD_LANDED: 'dashboard_landed',

  // referral
  REFERRAL_SCREEN_VIEWED: 'referral_screen_viewed',
  REFERRAL_SHARE_LINK_CLICKED: 'referral_share_link_clicked',
  REFERRAL_VIEW_YOUR_TRANSACTION_CLICKED:
    'referral_screen_view_redemptions_clicked',
  REFERRAL_SCREEN_MAGIC_LINK_CLICKED: 'referral_screen_magic_link_clicked',
  REFERRAL_SCREEN_CLOSE_CLICKED: 'referral_screen_close_clicked',
  REFERRAL_SCREEN_CLOSED: 'referral_screen_closed',
  REFERRAL_HISTORY_SCREEN_VIEWED: 'referral_history_screen_viewed',
  REFERRAL_HISTORY_SCREEN_CLOSED: 'referral_history_screen_closed',
  REFERRAL_HISTORY_PAGE_SCROLL: 'referral_history_page_scroll',
  REFERRAL_HISTORY_START_EARNING_CLICKED:
    'referral_history_start_earning_clicked',
  REFERRAL_HISTORY_BACK_CLICKED: 'referral_history_back_clicked',
  REFERRAL_SUCCESS_SCREEN_SHOWN: 'referral_success_screen_shown',
  REFERRAL_SUCCESS_SCREEN_CLOSED: 'referral_success_screen_closed',
  REFERRAL_SUCCESS_CLOSE_CLICKED: 'referral_success_close_clicked',
  REFERRAL_HISTORY_PAGE_LOAD_MORE_CLICKED:
    'referral_history_page_load_more_clicked',
  // a/b experiment
  CDP_EXPERIMENT_LANDED: 'cdp_experiment_landed',

  // collection page
  COLLECTION_PAGE_VIEWED: 'collection_page_screen_viewed',

  // category page
  CATEGORY_PAGE_VIEWED: 'category_page_screen_viewed',

  // cards events
  COURSE_CARD_CLICKED: 'course_card_clicked',
  JOIN_COURSE_CLICKED: 'join_course_clicked',
  QUICK_CHECKOUT_OPENED: 'quick_checkout_opened',
};

export const FB_PIXEL_FREE_COURSE = 'FB_PIXEL_FREE_COURSE';

export const FB_PIXEL_EVENT_NAMES = {
  FreeCourseRegistered: 'FreeCourseRegistered',
  CoursePurchaseSuccess: 'CoursePurchaseSuccess',
  FullCourseRegistered: 'FullCourseRegistered',
};
