import PAGE_TYPES from '../constants/pageTypes';
import { extractCdpData } from '../courseAnalytics';
import { EVENT_NAMES } from './eventNames';

export const getPageEventData = (page: string, store: any) => {
  switch (page) {
    case PAGE_TYPES.CDP_SUBSCRIPTION_PAGE:
      return {
        data: extractCdpData(store.getState().cdp.course),
        event: EVENT_NAMES.CDP_LANDED,
      };

    case PAGE_TYPES.CDP_FREEMIUM_PAGE:
      return {
        data: extractCdpData(store.getState().cdp.course),
        event: EVENT_NAMES.CDP_LANDED,
      };

    default:
      return {
        data: store.getState().cdp.course,
        event: EVENT_NAMES.CDP_LANDED,
      };
  }
};

export const saveGtmDataLayerData = (data: any) => {
  try {
    
    window.dataLayer?.push(data);
  } catch (e) {
    console.error(e);
  }
};
