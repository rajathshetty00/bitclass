import { parse } from 'next-useragent';
// import { ImageLoaderProps } from 'next/image';
import { API_URL, COOKIE_DOMAIN, ENV } from 'utils/constants';
import axios from 'axios';
import dayjs from 'dayjs';
import PhoneNumber from 'awesome-phonenumber';
import { NextRouter } from 'next/router';
import { getCurrencySymbol } from './currency';
import { getCode, getRole } from './auth/userInfo';
import { getSelf } from './api';

export const isEmptyObject = (obj: any) =>
  Object.entries(obj).length === 0 && obj.constructor === Object;
export const arrayFromNumber = (number: Number) =>
  Array.from(Array(number), (_, i) => i + 1);

export const optimizeCloudinaryImage = ({ src, quality = 'auto' }: any) => {
  if (
    (src?.includes('https') || src?.includes('http')) &&
    (src?.includes('cloudinary') || src?.includes('media.bitclass.live'))
  ) {
    if (!src?.includes('https')) {
      // eslint-disable-next-line no-param-reassign
      src = src?.replace('http', 'https');
    }
    const optimizeURL: any = src.split('upload/');
    const endingUrl: string | [] = optimizeURL[1].split('/').slice(1).join('/');
    return [optimizeURL[0], `upload/q_${quality},f_auto/`, endingUrl].join('');
  }
  return src;
};

export const getUserAgent = (uaString: string) =>
  uaString ? parse(uaString) : parse(window.navigator.userAgent);

export const countryToFlag = (isoCode: any) =>
  typeof String.fromCodePoint !== 'undefined'
    ? isoCode
        .toUpperCase()
        .replace(/./g, (char: any) =>
          String.fromCodePoint(char.charCodeAt(0) + 127397),
        )
    : isoCode;

export function exists(x: any) {
  return !!(typeof x !== 'undefined' && x !== null && x !== '');
}

export const deleteCookie = (name: any) => {
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/;domain=${COOKIE_DOMAIN}`;
};

export function getCookie(cname: any) {
  const name = `${cname}=`;
  const ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i += 1) {
    let c = ca[i];
    while (c.charAt(0) === ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) === 0) {
      return c.substring(name.length, c.length);
    }
  }
  return '';
}
// for seesion storage only
export const setAuthToken = (token: any) =>
  sessionStorage.setItem('_auth', token);
export const getAuthToken = () => sessionStorage?.getItem('_auth');

export const initDefaultsRequestHeader = (baseUrl?: string | undefined) => {
  axios.defaults.baseURL = baseUrl || API_URL;
  axios.defaults.headers.common.platform = 'web';
  axios.defaults.headers.post['Content-Type'] =
    'application/x-www-form-urlencoded';
  try {
    if (getAuthToken()) {
      axios.defaults.headers.Authorization = getAuthToken();
    } else if (ENV === 'local' && typeof window !== 'undefined') {
      axios.defaults.headers.Authorization = getCookie('auth-key');
    } else {
      axios.defaults.headers.Credentials = 'include';
      axios.defaults.withCredentials = true;
    }
  } catch (error) {
    console.error(error);
  }
};

export function setCookie(name: any, value: any, exp: any) {
  const d = new Date();
  d.setTime(d.getTime() + exp * 24 * 60 * 60 * 1000);
  const expires = `expires=${d.toUTCString()}`;
  document.cookie = `${name}=${value};${expires};path=/;domain=${COOKIE_DOMAIN}`;
}

export const getDateFormat = (epoch: any, format: string = 'DD MMM') => {
  return dayjs.unix(epoch).format(format);
};

export const getFinalAmount = ({
  currency,
  amount,
  couponData,
  finalAmount,
}: any) => {
  if (exists(couponData?.amount)) {
    if (couponData?.amount === 0) {
      return 0;
    }
    return `${getCurrencySymbol(currency)}${couponData?.amount}`;
  }

  if (exists(finalAmount)) {
    if (finalAmount === 0) {
      return 0;
    }
    return `${getCurrencySymbol(currency)}${finalAmount}`;
  }

  if (amount === 0 || !amount) {
    return 'FREE';
  }

  return ` ${getCurrencySymbol(currency)}${amount}`;
};

export const routeToNotFoundPage = (res: any) => {
  res.writeHead(302, {
    Location: '/course-not-found',
    'Content-Type': 'text/html; charset=utf-8',
  });
  res.end();
};

export const validPhoneNumberHandler = (val: any) => {
  const regionCode = PhoneNumber.getRegionCodeForCountryCode(91);
  const newNumber = new PhoneNumber(val, regionCode);
  return newNumber.isValid();
};

export const linkifyText = (inputText: string) => {
  let replacedText;
  // URLs starting with http://, https://, or ftp://
  const replacePattern1 =
    /(\b(https?|ftp):\/\/[-A-Z0-9+&@#/%?=~_|!:,.;]*[-A-Z0-9+&@#/%=~_|])/gim;
  replacedText = inputText.replace(
    replacePattern1,
    '<a href="$1" target="_blank">$1</a>',
  );

  // URLs starting with "www." (without // before it, or it'd re-link the ones done above).
  const replacePattern2 = /(^|[^/])(www\.[\S]+(\b|$))/gim;
  replacedText = replacedText.replace(
    replacePattern2,
    '$1<a href="http://$2" target="_blank">$2</a>',
  );

  // Change email addresses to mailto:: links.
  const replacePattern3 =
    /(([a-zA-Z0-9\-_.])+@[a-zA-Z_]+?(\.[a-zA-Z]{2,6})+)/gim;
  replacedText = replacedText.replace(
    replacePattern3,
    '<a href="mailto:$1">$1</a>',
  );

  return replacedText;
};

export const validBoolean = (variable: any) => {
  if (typeof variable === 'boolean') {
    return true;
  }
  return false;
};

export const determineCourseDate = ({ StartDate, EndDate }: any) => {
  const startDate = getDateFormat(StartDate);
  const endDate = getDateFormat(EndDate);
  if (startDate === endDate) return startDate;
  return `${startDate} - ${endDate}`;
};

export const determineCoursePrice = ({ currency, amount }: any) =>
  exists(amount) && amount > 0
    ? `${getCurrencySymbol(currency)} ${amount}/-`
    : 'FREE';

export const findCarouselCount = (
  nextSlide: number,
  currentSlide: number,
  isMobileData: boolean,
) => {
  if (isMobileData) {
    return nextSlide > currentSlide ? 1 + nextSlide : nextSlide + 1;
  }
  return nextSlide > currentSlide ? 3 + nextSlide : nextSlide + 1;
};

export const getCurriculumGTMData = (course: any, additonalObject?: any) => {
  return {
    student_id: getCode() || '',
    tmpr_code: '',
    source: 'direct',
    course_code: course?.code || '',
    course_type: course?.type || '',
    course_title: course?.heading || '',
    ...(additonalObject && !isEmptyObject(additonalObject) && additonalObject),
  };
};

export const getSlicedString = (str: string, charLimit: number) =>
  str?.slice(0, charLimit);

export const htmlSanitizer = (string: any) => {
  return string
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
};

export const deleteAuthToken = () => {
  sessionStorage.clear();
  deleteCookie('_auth');
  localStorage.clear();
};
// function called when _auth token available in URLs
export const loginWithAuthToken = async (authToken: any) => {
  // clear the userinfo in local storage befor setting the _auth cookie
  localStorage.removeItem('userInfo');
  const adminAuth = authToken || '';
  setAuthToken(adminAuth);
  try {
    const { data } = await getSelf();

    const {
      id,
      username,
      code,
      image,
      chat_auth_token,
      admin,
      teacherHandle,
      phone,
      email,
      first_name: firstName,
    } = data;

    const extractedInfo = {
      id,
      username,
      code,
      image,
      chat_auth_token,
      admin,
      teacherHandle,
      phone,
      email,
      firstName,
    };
    localStorage.setItem('userInfo', JSON.stringify(extractedInfo));
    localStorage.setItem('authenticated', JSON.stringify(true));
    localStorage.setItem('role', getRole() || 'student');
  } catch (err) {
    if (err) {
      localStorage.clear();
      window.location.reload();
      deleteAuthToken();
    }
  }
};

export const copyText = (text: any) => {
  const textArea = document.createElement('textarea');
  textArea.value = text;
  textArea.style.position = 'fixed';
  textArea.style.top = '0';
  textArea.style.left = '0';
  textArea.style.width = '1px';
  textArea.style.height = '1px';
  textArea.style.padding = '0';
  textArea.style.border = 'none';
  textArea.style.outline = 'none';
  textArea.style.boxShadow = 'none';
  textArea.style.background = 'transparent';
  document.querySelector('body')!.appendChild(textArea);
  textArea.select();
  textArea.setSelectionRange(0, 99999);
  document.execCommand('copy');
  textArea.remove();
};

export const getDuration = ({ start_ts, end_ts }: any) => {
  if (start_ts === end_ts) dayjs.unix(start_ts).format('DD MMM');
  return `${dayjs.unix(start_ts).format('DD MMM')} - ${dayjs
    .unix(end_ts)
    .format('DD MMM')}`;
};

export const sanitizeSpecialCharacter = (str: string) =>
  str.replace(/[^\w\s]/gi, '');

export const cleanQueryParam = (nextUrl: any, queryParams: any) => {
  if (nextUrl.indexOf('?') !== -1) {
    return `${nextUrl}&${queryParams}`;
  }
  return `${nextUrl}?${queryParams}`;
};

export const convertUnderScoreText = (Text: string) =>
  Text.toLowerCase()
    .replace(/[^\w ]+/g, '')
    .replace(/ +/g, '_')
    .replace(/^-+/, '') // reomve "/ " from stary text
    .replace(/_+$/, ''); // remove "/" from end text

export const isQueryURl = (url: string) => {
  const newUrl = url?.split('?')[1];
  return !!newUrl;
};
export const removePlusFromQuery = (query: any) =>
  query.toString().trim().replace(/\+/g, '%20');

export const removeChannel = (query: string, url?: string): string => {
  const params = new URLSearchParams(query);
  params.delete('channel');
  params.delete('platform');
  if (url?.includes('utm_source') && query?.includes('utm_source')) {
    params.delete('utm_source');
  }
  return removePlusFromQuery(params);
};

export const generateActualUrl = (url: string, query: string) => {
  if (url?.includes('channel') && query?.includes('channel')) {
    const params = removeChannel(query, url);
    return isQueryURl(url)
      ? `${url}&${removePlusFromQuery(params)}`
      : `${url}?${removePlusFromQuery(params)}`;
  }
  return isQueryURl(url)
    ? `${url}${query ? `&${removePlusFromQuery(query)}` : ''}`
    : `${url}${query ? `?${removePlusFromQuery(query)}` : ''}`;
};

export const getQuery = (router: NextRouter, url?: string): string => {
  return removeChannel(router.asPath.split('?')[1], url);
};

export const getHrefLink = (url: string, router: NextRouter) => {
  return generateActualUrl(url, getQuery(router, url));
};
