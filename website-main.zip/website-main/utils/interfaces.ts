import { ReactNode } from 'react';
import { ButtonProps } from '@mui/material';

// global interface declaration starts
declare global {
  // eslint-disable-next-line no-unused-vars
  interface Window {
    Razorpay: any;
    dataLayer: any;
  }
}
// global interface declaration ends

export interface OptimizeImage {
  src: string;
  width: any;
  quality: number;
}

export interface BitMuiDialogInterface {
  children: ReactNode;
  props?: any;
  onCancel?: () => void;
}

export interface BitMuiPlainDialogInterface {
  title: ReactNode;
  children: ReactNode;
  footer?: ReactNode | null;
  props?: any;
  handleCustomClose: () => void;
  open: boolean;
}

export interface BitMuiButtonInterface extends ButtonProps {
  children: ReactNode;
  className?: string;
  startIcon?: ReactNode;
  props?: any;
  fullWidth?: boolean;
  size?: any;
  variant?: any;
  type?: any;
  onClick?: any;
  disabled?: boolean;
  loading?: boolean;
  style?: any;
  ref?: any;
}

export interface IBitMuiAlertDialogProps {
  children: ReactNode;
  props?: any;
  handleClose?: () => void;
  fullScreen?: boolean;
  className?: string;
}

export interface IBitMuiModelComponentProps extends IBitMuiAlertDialogProps {
  isModalOpen: boolean;
}
