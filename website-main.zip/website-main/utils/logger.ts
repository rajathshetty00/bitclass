import * as Sentry from '@sentry/react';
import { ENV } from 'utils/constants/index';

const constructMessage = (msg: any) => {
  let defaultMsg = '';
  // eslint-disable-next-line array-callback-return
  Object.keys(msg).map((key) => {
    defaultMsg += ` ${key}::${msg[key]}`;
  });
  return defaultMsg;
};

export const log = (msg: any) => {
  try {
    if (ENV === 'prod') {
      Sentry.captureMessage(constructMessage(msg));
    } else {
      console.log(constructMessage(msg));
    }
  } catch (e) {
    console.log('logger failed');
  }
};

// level - error, fatal, warning, log, info, debug, critical
export const sentryLog = (msg: any, level: any = 'info') => {
  try {
    if (ENV === 'prod') {
      Sentry.captureMessage(msg, level);
    } else {
      console.log(msg);
    }
  } catch (e) {
    console.log('logger failed');
  }
};
