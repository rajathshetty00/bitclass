import { assetObject } from 'utils/assetFileNames';

interface ILogos {
  [key: string]: IEvents;
}
interface IEvents {
  [key: string]: {
    [key: string]: string;
  };
}

export const LOGOS: ILogos = {
  makarSankranti: {
    logo: {
      light:
        'https://res.cloudinary.com/bitclass/image/upload/v1642142630/Logos/lightLog_tt59vr.svg',
      dark: 'https://res.cloudinary.com/bitclass/image/upload/v1642143734/Logos/darkLogo_g67iue',
    },
    icon: {
      light:
        'https://res.cloudinary.com/bitclass/image/upload/v1642142630/Logos/lightIcon_m5npmx.svg',
      dark: 'https://res.cloudinary.com/bitclass/image/upload/v1642143734/Logos/darkIcon_laijlm',
    },
  },
  republicDay: {
    logo: {
      light:
        'https://res.cloudinary.com/bitclass/image/upload/v1643128994/Logos/republicDayLogo',
      dark: 'https://res.cloudinary.com/bitclass/image/upload/v1643128994/Logos/republicDayLogo',
    },
    icon: {
      light:
        'https://res.cloudinary.com/bitclass/image/upload/v1643128995/Logos/republicDayIconLogo',
      dark: 'https://res.cloudinary.com/bitclass/image/upload/v1643128995/Logos/republicDayIconLogo',
    },
  },
  noEvent: {
    logo: {
      light: assetObject.logoWhite,
      dark: assetObject.logoDark,
    },
    icon: {
      light: assetObject.logoWhiteSmall,
      dark: assetObject.logoDarkSmall,
    },
  },
};
export const EVENTS = {
  makarSankranti: 'makarSankranti',
  republicDay: 'republicDay',
  noEvent: 'noEvent',
};
