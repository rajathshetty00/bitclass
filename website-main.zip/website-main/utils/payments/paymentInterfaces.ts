/* eslint-disable no-unused-vars */
interface ISubscriptionDetails {
  id: string;
  type: string;
}

export interface IFreeCourseCheckoutProps {
  prePayment: () => void;
  postPayment: (a?: any, b?: any) => void;
  finalCourseDetailsBeforePayment: any;
}

export interface IPaidCourseCheckoutProps {
  currency: string;
  amount: number;
  prePayment: () => void;
  postPayment: (a?: any, b?: any) => void;
  fastCheckout: boolean;
  finalCourseDetailsBeforePayment: any;
}

export interface IOpenRazorpayModalProps {
  currency: string;
  amount: any;
  prePayment: () => void;
  postPayment: (a?: any, b?: any) => void;
  fastCheckout: boolean;
  finalCourseDetailsBeforePayment: any;
}

export interface IInitiatePaymentProps {
  finalCourseDetailsBeforePayment: any;
  currency: string;
  amount: any;
  prePayment: () => void;
  postPayment: (a?: any, b?: any) => void;
  fastCheckout?: boolean;
}
