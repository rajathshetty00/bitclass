/* eslint-disable no-unused-vars */
import { getPhone, getEmail } from 'utils/auth/userInfo';
import {
  BIT_CLASS_LOGO,
  RAZORPAY_COLOR_CODE,
  RAZORPAY_ID,
} from 'utils/constants';
import { EVENT_NAMES, FB_PIXEL_EVENT_NAMES } from 'utils/gtm/eventNames';
import { saveGtmDataLayerData } from 'utils/gtm/gtm';
import { exists } from 'utils';
import { log } from 'utils/logger';
import {
  IFreeCourseCheckoutProps,
  IInitiatePaymentProps,
  IOpenRazorpayModalProps,
  IPaidCourseCheckoutProps,
} from 'utils/payments/paymentInterfaces';

const openRazorpayModal = async ({
  currency,
  amount,
  prePayment,
  postPayment,
  fastCheckout = false,
  finalCourseDetailsBeforePayment: { heading },
}: IOpenRazorpayModalProps) => {
  try {
    const orderID: any = await prePayment();
    const options = {
      key: RAZORPAY_ID,
      amount: amount * 100 /* paise */,
      currency: exists(currency) ? currency : 'INR',
      name: `Buy ${exists(heading) ? heading : ''}`,
      description: '',
      order_id: orderID?.external_code,
      image: BIT_CLASS_LOGO,
      // eslint-disable-next-line camelcase
      handler: ({ razorpay_payment_id }: any) =>
        postPayment(razorpay_payment_id, orderID),
      notes: {
        order_id: orderID?.external_code,
        outside_login: fastCheckout,
      },
      theme: {
        color: RAZORPAY_COLOR_CODE,
      },
      prefill: {
        contact: getPhone(),
        email: getEmail(),
      },
      modal: {
        escape: true,
        ondismiss: () => {
          // window.location.reload();
        },
      },
    };
    if (orderID) {
      saveGtmDataLayerData({
        event: EVENT_NAMES.PAYMENT_SCREEN_VIEWED,
      });
      const rzp = new window.Razorpay(options);
      rzp.open();
      rzp.on('payment.failed');
    }
  } catch (err: any) {
    log({ msg: `Failed to complete payment $${err?.message || err}` });
  }
};

const freeCourseCheckout = async ({
  finalCourseDetailsBeforePayment,
  prePayment,
  postPayment,
}: IFreeCourseCheckoutProps) => {
  try {
    const orderID = await prePayment();
    await postPayment(null, orderID);
    // saveGtmDataLayerData({
    //   event: EVENT_NAMES.PAYMENT_SUCCESSFUL,
    //   pixelEvent: FB_PIXEL_EVENT_NAMES.FreeCourseRegistered,
    //   amount: 0,
    //   orderID,
    //   orderDetails: finalCourseDetailsBeforePayment,
    //   selectedPlan: finalCourseDetailsBeforePayment.selectedPlan,
    // });
  } catch (err: any) {
    log({ msg: `Failed to register for free course $${err.message || err}` });
  }
};

const paidCourseCheckout = ({
  currency,
  amount,
  prePayment,
  postPayment,
  fastCheckout = false,
  finalCourseDetailsBeforePayment,
}: IPaidCourseCheckoutProps) => {
  try {
    openRazorpayModal({
      currency,
      amount,
      prePayment,
      finalCourseDetailsBeforePayment,
      postPayment,
      fastCheckout,
    });
  } catch (error) {
    //
  }
};

export const initiatePayment = ({
  finalCourseDetailsBeforePayment,
  currency,
  amount,
  prePayment,
  postPayment,
  fastCheckout = false,
}: IInitiatePaymentProps) => {
  const isFreeProduct = amount === 0 || !amount;

  return isFreeProduct
    ? freeCourseCheckout({
        finalCourseDetailsBeforePayment,
        prePayment,
        postPayment,
      })
    : paidCourseCheckout({
        finalCourseDetailsBeforePayment,
        currency,
        amount,
        prePayment,
        postPayment,
        fastCheckout,
      });
};
