import * as yup from 'yup';
import PhoneNumber from 'awesome-phonenumber';

export const phoneNumberValidationSchema = yup.object().shape({
  phoneNumber: yup
    .string()
    .test('', 'Enter a valid number', (val: any) => {
      const regionCode = PhoneNumber.getRegionCodeForCountryCode(91);
      const newNumber = new PhoneNumber(val, regionCode);
      return newNumber.isValid();
    })
    .test('', 'Only numbers are allowed', (val: any) => {
      const reg = new RegExp('^[0-9]+$');
      return reg.test(val);
    })
    .required('Phone number is required'),
});

export const userNameValidationSchema = yup.object().shape({
  userName: yup
    .string()
    .min(4)
    .max(32)
    .required('Username can not be blank')
    .matches(/^[aA-zZ\s]+$/, 'Only alphabets are allowed'),
});

export default { phoneNumberValidationSchema, userNameValidationSchema };
